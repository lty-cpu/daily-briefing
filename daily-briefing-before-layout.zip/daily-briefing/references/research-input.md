# 正常研究输入（schema7）

执行顺序是 `start自动基础取数 → 五域发现并submit小批量 → 入选公司用data补数 → compute → 一次综合review → finish`。密度、准入和取舍见[统一编辑规则](editorial.md)。命令为 `python <skill>/scripts/run.py submit --run-id <ID> --run-token <TOKEN> --input <UTF-8 JSON文件>`；`{"packets":[...]}`原子提交，失败不部分写入。每个packet写kind、task及稳定alias；观察用task:themes，审阅用task:synthesis。需要对象时用 `inspect --group facts/metrics/evidence/sources/tasks/review`（选一个集合），不用任务名代替集合名。

本页定义submit输入，inspect返回的是存储对象。ID及alias以英文字母开头，只含英文字母、数字、下划线或连字符，最长96字符；中文名称另填title/name。判断的refs至少含一个事实/指标ID或对应回执别名，证据ID可补充定位；来源ID不能代替已读片段。已有来源用 `"source":"回执中的来源别名"` 复用，不重填其发布和读取信息；新来源对象按下例填写，版本字段为version。

## 来源、消息与窗口

消息的必要字段如下；source、title、fact_text、text及unknowns为两种消息共用。unknowns只写实际未决处，不以“未披露”代替“本次未取得”；已有明确复核事项时可用next_check代替。阶段和身份由证据支持，不机械填写confirmed。

| kind | 其余必要字段 | 栏目 |
|---|---|---|
| event | entity_id、subject、section | section选news/ai/market/macro |
| company | name、entity_id、announcement_type | 自动进入companies；ticker、announcement_id、财务基线有则填 |

来源kind用official/company/media/data/public_account，read_method用original/cached/search_summary，read_status用full/partial/unavailable；时间边界见[编辑规则](editorial.md#准入与措辞)。以下形状示例不是实际新闻：

```json
{"task":"official","kind":"event","alias":"policy_notice","section":"news","entity_id":"ORG_X","subject":"公共建筑节能试点","title":"机构X拟在两市试点公共建筑节能改造","fact_text":"机构X于9月24日发布试点征求意见稿，拟2027年底前改造两市公共建筑的照明与空调，项目名单和补助比例另定。","text":"9月24日，机构X发布公共建筑节能改造试点征求意见稿，拟在甲、乙两市更换照明和空调设备，以降低公共建筑运行能耗。\n\n试点目标为2027年底前完成改造，由两市主管部门组织申报，符合条件的项目可获补助；具体名单和补助比例另行公布。目前处于征求意见阶段，尚未成为已批准的施工或拨款安排。","status":"confirmed","proposition":"publication","stage":"征求意见","unknowns":"正式方案、项目名单和补助比例待后续文件确认","source":{"title":"公共建筑节能试点征求意见稿（虚构示例）","publisher":"机构X","url":"https://example.org/notice","published_at":"2026-09-24T10:00:00+08:00","retrieved_at":"2026-09-24T11:00:00+08:00","version":"首版","kind":"official","read_status":"full","read_method":"original","locator":"目标及实施方式段","quote":"拟在甲、乙两市开展公共建筑照明与空调节能改造，目标于2027年底完成。由两市主管部门组织申报，符合条件的项目可予补助；项目名单和补助比例另定。现公开征求意见。","context":"这是拟议方案，不是批准、施工或拨款记录"}}
```

`fact_text` 是证据支持的命题；`text` 是按[消息完整性标准](editorial.md#两层密度)写给读者的正文，不复制fact_text作一句话摘要。可用 `\n\n` 分段，全部核心内容默认可见；引用片段的quote/context须覆盖正文实际使用的数字、条件与背景，不只摘一句支持标题。独立影响确有增量才加relevance；interpretation为旧结构化对象，普通消息不用它。事项发生须有原文支持才写 `proposition:"occurrence", occurrence_evidence:"current", verification_at:<实际核验时间>`，程序将current绑定本条证据。媒体与时间边界见[编辑规则](editorial.md#准入与措辞)。重要候选在event或task中记录采用、待核或排除原因。

同一事件后续确认、更正、否认用稳定 `event_identity={entity,subject,family,release_id,version,attributes,importance,next_check,aliases?}`；新来源不能仅因URL或标题变化生成另一个业务事件。改正时用 `novelty:"correction"` 和来源 `source_basis:"correction"`（否认用 `denial`），旧表述保留在可展开历史，主文显示当前版本。`content_role` 是 news/continuing_event/context/financial_baseline；旧财报用 financial_baseline，不能伪装本期新闻。`domain` 独立于 `section`；国内央行是 cn_official，海外变量明确写 overseas，AI 明确写 ai。

有界发现记录可随消息提交；只更新检查范围或任务状态用 `kind:"task"`，无需source或消息正文，不生成新闻卡。`attempt:{at,query_or_url,result,status,evidence_ids,tool_ref?}` 中at为实际检查的ISO时点，result为范围及候选处置，status选ok/empty/failed/restricted，evidence_ids为ID数组。任务结果 `result:{status,current_conclusion,next,stop_reason?}`，status选running/done/verified_none/blocked/budget_stop/user_stop。blocked记录实际故障或宿主明确禁用（restricted），不必为已知禁用再发请求；budget_stop仅真实到限使用。

无需为完成发现另填各站窗口；只有专门核验来源窗口时才用 `kind:"window"`，包含 `obligations:[覆盖义务ID],url,status,method,checked_at,window_start,window_end,content_scope,note,refs`。义务ID取自 `inspect --group coverage` 的obligation_ids，不用领域名代替；状态含义见[编辑规则](editorial.md#广度产物和停止条件)。`kind:"index"` 只登记已读列表，不创造财经事实。

## 数值与更正

`kind:"market"` 的 `rows` 每行写 entity_id、label、value（缺失用 null，0 不等于缺失）、unit、currency、scale、period、as_of、scope、measure、alias。每个观测引用实际 source/evidence，图表只用同口径有效值。市场同一观测的身份由主体、指标、期间/时点、样本与价格口径决定，换 packet alias 不生成第二张卡。不同来源值冲突不能自动并入确定值；核实后用 `update:"correction"`、`correction_reason` 和新的证据提交，保留旧版更正记录。`support:{status:"reviewed",locator,quote,note}` 需说明主体、期间、单位/表头和数值；程序绑定本值、单位、指标、证据版本，改值或改证据后须重新核对。单位转换用 `conversion:{raw_value,raw_unit,raw_scale,evidence_id,entity,period,measure}`，原值须在真实片段中；原表行与表头可由 context 辅助，不用捏造单行全包含。

市场任务的measure用`index_change`（指数日涨跌）、`turnover`（成交额）、`breadth`（同一明确样本的涨跌广度）；breadth的category区分up/down/flat。变化型指标按原文涨跌方向解释数值，“收跌1.22%”可支持-1.22，无需额外signed开关；复核引用须含方向词。同一数值、同一证据重提support或signed会更新复核信息，不新增观测；改变值或证据仍须重新审核。基础行情和公司补数见[有界历史补齐](history-data.md)。宏观任务独立取得海外利率、汇率或能源变量；缺历史不造趋势。

`market` packet的rows只登记数值；同时填写title和text才生成市场正文，text用 `{metric:回执返回的指标ID}` 引用已登记数值。正文职责和缺项处理见[显示规则](editorial.md#数值显示与更新)，featured仅选总览数值，不代替市场正文。自动取数后可用同一观测再提交带title/text的market packet，无需创造第二套指标。

## 深主题、观察和综合编辑

有独立影响才解释普通消息；入选深主题使用 `kind:"thesis",task:"themes"`，元信息填alias、theme、thesis（稳定主题与判断标识）、sector、title、review_at、expires_at、why_this。正常聚焦格式只需 `blocks` 的 `judgment,mechanism,alternative,support,invalidation`，每项 `{text,refs}`。三个期限填 `horizons.intraday/short/medium` 的 `conclusion,direction,refs,next_observation,review_at,confidence`，只写期限差异；direction用positive/negative/mixed/neutral/unknown，confidence用high/medium/low/unknown。比较与选题标准见[统一编辑规则](editorial.md#两层密度)。旧十字段compact仅供旧运行与特殊迁移。

主题的验证条件只在support/invalidation两个block中写一次，必须包含可区分解释的后续结果。`observe:{trigger,target,baseline,decision_if}`四项均为文字；target写核对对象与来源，baseline写事实基准，decision_if只写据共用条件如何调整研究判断，不再建立另一套条件。程序生成关联行动。近期会话用session_offset:1表示下一已核验会话（0为目标日），可加delay_minutes:30在收盘后复核；程序复用报告calendar生成observe_at。已知具体时点也可直接传observe_at/calendar_id；缺日历或未公布日程时保留事件触发，不虚构日期。

非共识与待验证候选按[编辑规则](editorial.md#两层密度)筛查。主题已有合格线索时，在observe中加 `watch:{title,question}`，观察栏引用同一行动。单独提交的observation必填kind、task:themes、alias、title、divergence（未决问题）和refs；另外二选一：已有验证同一问题的行动则写action_ref（主题别名或行动ID），否则写expectation（事实基准）、mechanism、materiality、opposition和test（时点/触发、来源、支持与削弱结果）。同一问题选一种入口，后续同action_ref更新现有卡；不能借用无关主题的条件。默认watch；有公开预期证据才用contrarian与consensus_refs。无合格观察时，observation_review记录已查范围或受阻原因，不能因已有主题就判空。

首次综合编辑用 `kind:"review",task:"synthesis"` 提交headline、summary:[{text,refs}]、实际已审的reviewed及reviewer/method/status。summary每次整体替换，内容是读者关心的市场变化；补审只填reviewed、reviewer、method、status，不传headline/summary。reviewed默认累积，replace:true仅重置审阅集合；审阅范围见[发布前研究审阅](review-and-evaluation.md)。featured引用指标别名或ID，备用数据不必列入正文。preview只读，正式归档用finish；needs_research补对应缺口，needs_review补审，沿用同一时钟。

安静日及连续复核的可选review字段如下；语义沿用编辑与审阅规则。字段不确定时只用 `describe --group <对应顶层字段>` 查询，不逐个猜字段。

| 字段 | 输入形状 |
|---|---|
| selection_review | `{reason,evidence_ids}`，说明少选主线的依据 |
| observation_review | `{status,reason,evidence_ids}`；status为checked_none/hypotheses/blocked/not_checked |
| prior_reviews | `[{thesis_id,previous_version,status,explanation,new_evidence_ids}]`；沿用上期判断ID/版本，status为supported/weakened/refuted/maintained/retired/unknown；尚无法验证写unknown及具体原因，不把旧证据列为新增 |
