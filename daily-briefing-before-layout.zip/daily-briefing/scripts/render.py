"""Escaped, deterministic HTML/SVG renderer. Never fetches external resources."""
from __future__ import annotations
from datetime import date, datetime
from html import escape
from pathlib import Path
import math
import re
from briefing import TOKEN, metric_date, source_ids

PALETTE=['#5a46c8','#007d83','#a04773','#835716','#4969a5']
ROLE={'industry':'产业龙头','trading':'交易龙头','both':'产业与交易龙头','representative':'代表性公司','watch':'观察对象'}
STATUS={'confirmed':'已确认','reported':'来源声明','conflicted':'来源冲突','unverified':'待核实','supported':'有据判断','watch':'待验证','contrarian':'非共识观察','expected':'预计'}
STATUS['expected']='已公告计划'

def esc(v): return escape(str(v),quote=True)
def fmt(value,unit='',signed=False,precision=None,approximate=False):
    if value is None: return '—'
    if precision is not None and precision<0:value=round(value,precision)
    digits=0 if unit in ('家','只','个','台','艘') else max(0,precision) if precision is not None else 2
    s=f'{value:+,.{digits}f}' if signed else f'{value:,.{digits}f}'
    return ('约' if approximate else '')+s+unit
def short(value):
    if abs(value)>=10000: return f'{value/10000:.1f}万'
    if abs(value)>=1000: return f'{value/1000:.1f}k'
    return f'{value:.2f}'.rstrip('0').rstrip('.')
def signclass(v): return 'neutral' if v is None or v==0 else ('pos' if v>0 else 'neg')


def metric_color(metric,value):
    if metric.get('category') in ('up','down','flat'):return {'up':'pos','down':'neg','flat':'neutral'}[metric['category']]
    if metric.get('dimensions',{}).get('measure') in ('yield','yield_level','yield_change','real_yield'):return 'neutral'
    return signclass(value) if metric.get('signed') or metric['op'] in ('return','excess_return','daily_change','growth','bp_change','difference','pair_difference') else 'neutral'
def table(headers,rows,classes='',header_text=esc):
    return '<div class="table-wrap"><table class="'+classes+'"><thead><tr>'+''.join('<th>'+header_text(h)+'</th>' for h in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td data-label="'+header_text(headers[i])+'">'+c+'</td>' for i,c in enumerate(r))+'</tr>' for r in rows)+'</tbody></table></div>'

class Renderer:
    def __init__(self,d,checks):
        self.d=d; self.values=checks['values']; self.checks=checks
        self.facts={x['id']:x for x in d['facts']}; self.sources={x['id']:x for x in d['sources']}; self.metrics={x['id']:x for x in d['metrics']}; self.series={x['id']:x for x in d['series']}; self.analyses={x['id']:x for x in d['analyses']}; self.events={x['id']:x for x in d.get('events',[])}
        self.fnums={k:i+1 for i,k in enumerate(self.facts)}
        self.cnums={item['id']:index+1 for index,item in enumerate(d['claims'])}
        self.enums={item['id']:index+1 for index,item in enumerate(d['evidence'])}
        self.backlinks={};self.reference_count=0
    def plain(self,value):
        value=re.sub(r'\*\*([^*\n]+)\*\*',r'\1',str(value))
        return esc(TOKEN.sub(lambda m: self.metric(m.group(1)),value))
    def text(self,value):
        def replace(m):
            metric=self.metrics[m.group(1)]; v=self.values[m.group(1)]
            signed=metric.get('signed',metric['op'] in ('return','excess_return','bp_change','difference','pair_difference'))
            return '<span class="metric '+metric_color(metric,v)+'">'+esc(self.metric(metric['id']))+'</span>'
        safe=esc(value)
        safe=re.sub(r'\*\*([^*\n]+)\*\*',r'<strong>\1</strong>',safe)
        safe=re.sub(r'\[risk:([^\]\n]+)\]',r'<mark class="risk">\1</mark>',safe)
        return TOKEN.sub(replace,safe).replace('\n','<br>')
    def refs(self,ids):
        return '<span class="refs">'+''.join(self.reference('f-'+fid,'['+str(self.fnums[fid])+']','证据'+str(self.fnums[fid])) for fid in dict.fromkeys(ids) if fid in self.facts)+'</span>'
    def analysis_refs(self, ids):
        return '<span class="refs">'+''.join('<a href="#a-'+self.plain(x)+'" aria-label="查看关联研究">研究</a>' for x in dict.fromkeys(ids))+'</span>'
    def claim_refs(self, ids):
        return '<span class="refs">'+''.join(self.reference('c-'+identifier,'〔'+str(self.cnums.get(identifier,'?'))+'〕','查看主张证据链') for identifier in dict.fromkeys(ids))+'</span>'
    def evidence_refs(self, ids):
        return '<span class="refs">'+''.join(self.reference('e-'+identifier,'原文 '+str(self.enums.get(identifier,'?')),'查看原文') for identifier in dict.fromkeys(ids))+'</span>'
    def reference(self,target,label,description):
        self.reference_count+=1;identifier='ref-'+str(self.reference_count)
        self.backlinks.setdefault(target,identifier)
        return '<a id="'+identifier+'" href="#'+self.plain(target)+'" aria-label="'+self.plain(description)+'">'+self.plain(label)+'</a>'
    def backref(self,target):
        identifier=self.backlinks.get(target)
        return '<a class="backref" href="#'+identifier+'">返回引用处 ↑</a>' if identifier else ''
    def source_links(self,ids):
        return ' · '.join('<a href="'+self.plain(self.sources[x]['url'])+'" target="_blank" rel="noopener noreferrer">'+self.plain(self.sources[x]['publisher'])+'</a>' for x in dict.fromkeys(ids) if x in self.sources)
    def metric(self,mid,attribution=True):
        m=self.metrics[mid]; v=self.values[mid]
        if self.d['schema_version']>=5 and mid in self.checks.get('unready_metrics',[]):return '—（待核 / 数据不足）'
        detail=self.checks.get('metric_details',{}).get(mid,{})
        from editorial import metric_identity
        identity=metric_identity(self.d,m)
        suffix={'reported':'（来源报道值）','conditional':'（若属实情景）'}.get(identity,'')
        if m.get('kind')=='forecast':suffix+='（计划 / 预测）'
        unit=m['unit'];precision=detail.get('precision',m.get('precision'))
        if precision is None:
            measure=m.get('dimensions',{}).get('measure','').lower()
            precision=4 if any(word in measure for word in ('exchange_rate','fx_rate','usdcny','usdcnh')) else 0 if unit in ('家','只','个','台','艘') else 2
        if unit=='元' and v is not None and abs(v)>=100000000:
            unit='万亿元' if abs(v)>=1000000000000 else '亿元'
            v=v/(1000000000000 if unit=='万亿元' else 100000000)
        elif unit=='亿元' and v is not None and abs(v)>=10000:
            unit='万亿元';v=v/10000
        elif unit=='万元' and v is not None and abs(v)>=10000:
            unit='亿元';v=v/10000
        return fmt(v,unit,m.get('signed',m['op'] in ('return','excess_return','daily_change','growth','bp_change','difference','pair_difference')),precision,detail.get('approximate',m.get('approximate',False)))+(suffix if attribution else '')
    def chain(self,a):
        out='<div class="chain">'
        for e in a['mechanism']:
            assumption=e['basis']=='assumption'
            out+='<div class="chain-row '+('assumption' if assumption else '')+'">'+self.text(e['from'])+'<span class="arrow">→</span>'+self.text(e['to'])+self.refs(e['fact_ids'])
            out+='<small>'+('假设环节：'+self.text(e['assumption']) if assumption else '事实联系；因果含义需结合正文解释')+'</small></div>'
        return out+'</div>'
    def spark(self,sid):
        s=self.series[sid]; obs=s['observations'][-21:]
        vals=[p['value'] for p in obs if p['value'] is not None]
        if len(vals)<2: return ''
        lo,hi=min(vals),max(vals); span=hi-lo or max(abs(lo)*.01,1)
        paths=[]; path=''
        for i,p in enumerate(obs):
            if p['value'] is None:
                if path: paths.append(path); path=''
            else:
                x=4+i/max(1,len(obs)-1)*292; y=44-(p['value']-lo)/span*38
                path+=('M' if not path else 'L')+f'{x:.2f},{y:.2f} '
        if path: paths.append(path)
        return '<svg class="spark" viewBox="0 0 300 48" role="img" aria-label="'+self.plain(s['label']+'实际历史序列，缺失处断开')+'">'+''.join('<path d="'+p+'" fill="none" stroke="#26817c" stroke-width="2"/>' for p in paths)+'</svg>'
    def chart(self,c):
        typ=c['type']; body=''; data=[]; headers=[]; sids=[]
        if typ in ('breadth','bars','comparison_table'):
            items=[(i['label'],i['metric_id'],self.values[i['metric_id']]) for i in c['items']]
            headers=['对象','数值','所属日期']; data=[[self.plain(label),self.plain(self.metric(mid)),self.plain(metric_date(self.d,self.metrics[mid]))] for label,mid,v in items]
            for _,mid,_ in items: sids+=source_ids(self.d,self.metrics[mid])
            if typ=='comparison_table':body=table(headers,data,header_text=self.plain);data=[]
            elif typ=='breadth':
                total=sum(v for _,_,v in items if v is not None)
                if any(v is None for _,_,v in items) or total<=0: body='<p class="empty">数据不完整，保留原始表格，未绘制占比。</p>'
                else:
                    colors=[{'up':'var(--up)','flat':'var(--muted)','down':'var(--down)'}[i['category']] for i in c['items']]
                    body='<div class="breadth-track" role="img" aria-label="'+self.plain('；'.join(label+' '+str(v)+'家' for label,mid,v in items))+'">'
                    for j,(label,mid,v) in enumerate(items): body+=f'<span style="width:{v/total*100:.5f}%;--s:{colors[j%3]}" data-tip="{self.plain(label+" "+self.metric(mid)+" / "+fmt(v/total*100,"%"))}"></span>'
                    body+='</div><div class="legend">'+''.join(f'<span><i class="swatch" style="--s:{colors[j%3]}"></i>{self.plain(label)} <b>{self.plain(self.metric(mid))}</b></span>' for j,(label,mid,v) in enumerate(items))+'</div>'
            else:
                vals=[v for _,_,v in items if v is not None]; low=min(vals+[0]); high=max(vals+[0]); span=high-low or 1; zero=-low/span*100
                for label,mid,v in items:
                    tone=metric_color(self.metrics[mid],v)
                    color={'pos':'var(--up)','neg':'var(--down)','neutral':'var(--brand)'}[tone]
                    fill='' if v is None else f'<span class="bar-fill" style="left:{min(zero,((v-low)/span*100)):.3f}%;width:{abs(v)/span*100:.3f}%;--s:{color}"></span>'
                    body+='<div class="bar-row"><span>'+self.plain(label)+'</span><div class="bar-track">'+f'<span class="bar-zero" style="left:{zero:.3f}%"></span>'+fill+'</div><span class="bar-value '+tone+'">'+self.plain(self.metric(mid))+'</span></div>'
        elif typ=='heatmap':
            headers=['对象']+c['columns']; data=[]
            body='<div class="table-wrap"><table class="heatmap"><thead><tr>'+''.join('<th>'+self.plain(x)+'</th>' for x in headers)+'</tr></thead><tbody>'
            for row in c['rows']:
                body+='<tr><th>'+self.plain(row['label'])+'</th>'; r=[self.plain(row['label'])]
                for mid in row['metric_ids']:
                    v=self.values[mid]; intensity=min(abs(v)/10,.8) if v is not None else 0
                    color=f'rgba(183,55,55,{.04+intensity*.22:.3f})' if v is not None and v>0 else (f'rgba(24,112,75,{.04+intensity*.22:.3f})' if v is not None and v<0 else 'var(--card)')
                    value=self.metric(mid); body+='<td class="'+signclass(v)+'" style="background:'+color+'">'+self.plain(value)+'</td>'; r.append(self.plain(value)); sids+=source_ids(self.d,self.metrics[mid])
                body+='</tr>'; data.append(r)
            body+='</tbody></table></div>'
        elif typ=='line':
            sets=[self.series[x] for x in c['series_ids']]
            for s in sets: sids+=s['source_ids']
            if c.get('window'):
                import copy
                windows=[]
                for count in (20,60):
                    from calculations import history_window_ready
                    ready=all(history_window_ready(self.d,series,count) for series in sets)
                    windows.append((count,ready))
                chosen=max(count for count,ready in windows if ready) if any(ready for count,ready in windows) else None
                body='<div class="window-controls" role="group" aria-label="真实历史窗口" data-enhancement hidden>'+''.join('<button type="button" data-window="'+str(count)+'" aria-pressed="'+str(count==chosen).lower()+'" '+('' if ready else 'disabled title="连续会话不足"')+'>'+str(count)+'会话'+('' if ready else ' · 不足')+'</button>' for count,ready in windows)+'</div>'
                for count,ready in windows:
                    if ready:
                        subset=copy.deepcopy(sets)
                        for series in subset:series['observations']=series['observations'][-count-1:]
                        chart,window_data,window_headers=self.line(subset,c['normalize'])
                        body+='<div data-window-panel="'+str(count)+'"'+(' hidden' if count!=chosen else '')+'>'+chart+'<details><summary>窗口原始值</summary>'+table(window_headers,window_data,header_text=self.plain)+'</details></div>'
            else:body,data,headers=self.line(sets,c['normalize'])
        elif typ=='scatter':
            pts=c['points']; valid=[p for p in pts if self.values[p['x_metric']] is not None and self.values[p['y_metric']] is not None]
            headers=['对象','超额收益','量能比']; data=[[self.plain(p['label']),self.plain(self.metric(p['x_metric'])),self.plain(self.metric(p['y_metric']))] for p in pts]
            for p in pts:
                for k in ('x_metric','y_metric'): sids+=source_ids(self.d,self.metrics[p[k]])
            if valid:
                xs=[self.values[p['x_metric']] for p in valid]; ys=[self.values[p['y_metric']] for p in valid]
                xmin,xmax=min(xs+[0]),max(xs+[0]); ymin,ymax=min(ys+[1,0]),max(ys+[1]); xp=(xmax-xmin)*.15 or 1; yp=(ymax-ymin)*.15 or .2
                xmin-=xp;xmax+=xp;ymin=max(0,ymin-yp);ymax+=yp
                X=lambda x:80+(x-xmin)/(xmax-xmin)*510; Y=lambda y:220-(y-ymin)/(ymax-ymin)*180
                body='<svg viewBox="0 0 640 275" role="img" aria-label="相对强弱和量能，不能解释为资金净流入"><title>横轴超额收益（百分点），纵轴量能比（倍）</title>'
                for y in (ymin,(ymin+ymax)/2,ymax): body+=f'<line class="grid" x1="80" x2="590" y1="{Y(y):.2f}" y2="{Y(y):.2f}"/><text x="65" y="{Y(y)+5:.2f}" text-anchor="end">{short(y)}</text>'
                for x in (xmin,0,xmax): body+=f'<text x="{X(x):.2f}" y="252" text-anchor="middle">{short(x)}</text>'
                body+=f'<line class="refline" x1="{X(0):.2f}" x2="{X(0):.2f}" y1="40" y2="220"/><line class="refline" x1="80" x2="590" y1="{Y(1):.2f}" y2="{Y(1):.2f}"/>'
                for j,p in enumerate(valid):
                    x,y=X(self.values[p['x_metric']]),Y(self.values[p['y_metric']]); tip=p['label']+'：'+self.metric(p['x_metric'])+' / '+self.metric(p['y_metric'])
                    body+=f'<circle cx="{x:.2f}" cy="{y:.2f}" r="9" fill="{PALETTE[j%4]}" data-tip="{self.plain(tip)}"><title>{self.plain(tip)}</title></circle>'
                body+='</svg><div class="legend">横轴：同期超额收益（百分点） · 纵轴：量能比（倍）</div>'
                body+='<div class="legend">'+''.join('<span><i class="swatch" style="--s:'+PALETTE[j%4]+'"></i>'+self.plain(p['label'])+'</span>' for j,p in enumerate(valid))+'</div>'
            else: body='<p class="empty">缺少可比的价格与成交额窗口，未绘制散点。</p>'
        elif typ=='mechanism':
            a=self.analyses[c['analysis_id']]; body=self.chain(a)
            for fid in a['fact_ids']: sids+=self.facts[fid]['source_ids']
        elif typ=='timeline':
            body='<ol class="timeline">'
            for e in sorted((self.events[i] for i in c['event_ids']),key=lambda e:e['at']):
                body+='<li><time>'+self.plain(e['at'].replace('T',' '))+'</time><b>'+self.plain(e['label'])+'</b> <span class="status">'+STATUS[e['status']]+'</span><p>'+self.text(e['detail'])+self.refs(e['fact_ids'])+'</p></li>'
                for f in e['fact_ids']: sids+=self.facts[f]['source_ids']
            body+='</ol>'
        from editorial import metric_identity
        used=[self.metrics[item['metric_id']] for item in c.get('items',[])]
        identity_states={metric_identity(self.d,m) for m in used}
        qualifier='若属实情景｜' if 'conditional' in identity_states else '来源报道值｜' if 'reported' in identity_states else ''
        content='<figure class="chart chart-'+typ+' '+('wide' if typ in ('mechanism','timeline') else '')+'" id="chart-'+self.plain(c['id'])+'"><h3>'+self.plain(qualifier+c['title'])+'</h3><p class="takeaway">'+self.text(c['takeaway'])+'</p>'+body
        formulas=[self.metrics[item['metric_id']].get('formula') for item in c.get('items',[]) if self.metrics[item['metric_id']].get('formula')]
        content+='<figcaption class="chart-note">'+self.text(c['note'])+(' · 派生：'+self.text('；'.join(formulas)) if formulas else '')+'<br>'+self.source_links(sids)+'</figcaption>'
        if data: content+='<details><summary>查看数据与口径</summary>'+table(headers,data,header_text=self.plain)+'</details>'
        return content+'</figure>'
    def line(self,sets,normalize):
        lookup=[{p['date']:p['value'] for p in s['observations']} for s in sets]
        all_dates=sorted(set().union(*(m.keys() for m in lookup)))
        if not all_dates: return '<p class="empty">无历史序列。</p>',[],[]
        common=sorted(set.intersection(*(set(k for k,v in m.items() if v is not None and v>0) for m in lookup))) if normalize else []
        if normalize and not common: return '<p class="empty">无共同有效基准日，未归一化。</p>',[],[]
        if normalize:
            first=common[0]; all_dates=[day for day in all_dates if day>=first]
            lookup=[{k:(v/m[first]*100 if v is not None and k>=first else None) for k,v in m.items()} for m in lookup]
        vals=[v for m in lookup for k,v in m.items() if k in all_dates and v is not None]
        rows=[[self.plain(day)]+[self.plain(fmt(m.get(day),'',False)) for m in lookup] for day in all_dates]
        headers=['日期']+[s['label']+(' (基期=100)' if normalize else ' ('+s['unit']+')') for s in sets]
        if len(all_dates)<2 or not vals: return '<p class="empty">至少需要两个观测日期，原始数据见下表。</p>',rows,headers
        lo,hi=min(vals),max(vals); pad=(hi-lo)*.15 or max(abs(lo)*.01,1);lo-=pad;hi+=pad
        ords=[date.fromisoformat(x).toordinal() for x in all_dates];start,end=ords[0],ords[-1]
        X=lambda day:80+(date.fromisoformat(day).toordinal()-start)/(end-start)*510
        Y=lambda value:215-(value-lo)/(hi-lo)*175
        svg='<svg viewBox="0 0 640 265" role="img" aria-label="'+self.plain('；'.join(headers[1:]))+'"><title>'+self.plain('真实观测序列，缺失点断开；'+('共同基期归一化' if normalize else '原始单位'))+'</title>'
        for y in (lo,(lo+hi)/2,hi): svg+=f'<line class="grid" x1="80" x2="590" y1="{Y(y):.2f}" y2="{Y(y):.2f}"/><text x="65" y="{Y(y)+5:.2f}" text-anchor="end">{short(y)}</text>'
        for i in sorted({0,len(all_dates)//2,len(all_dates)-1}):
            day=all_dates[i]; anchor='start' if i==0 else ('end' if i==len(all_dates)-1 else 'middle')
            svg+=f'<text x="{X(day):.2f}" y="247" text-anchor="{anchor}">{self.plain(day[5:])}</text>'
        for j,m in enumerate(lookup):
            path=''; segments=[]
            for day in all_dates:
                v=m.get(day)
                if v is None:
                    if path: segments.append(path);path=''
                else: path+=('M' if not path else 'L')+f'{X(day):.2f},{Y(v):.2f} '
            if path: segments.append(path)
            for path in segments: svg+='<path d="'+path+'" fill="none" stroke="'+PALETTE[j%4]+'" stroke-width="2.8"/>'
            for day in all_dates:
                if m.get(day) is not None:
                    tip=sets[j]['label']+' '+day+' '+fmt(m[day],'基期点' if normalize else sets[j]['unit'])
                    svg+=f'<circle cx="{X(day):.2f}" cy="{Y(m[day]):.2f}" r="5" fill="{PALETTE[j%4]}" data-tip="{self.plain(tip)}"><title>{self.plain(tip)}</title></circle>'
        svg+='</svg><div class="legend">'+''.join('<span><i class="swatch" style="--s:'+PALETTE[j%4]+'"></i>'+self.plain(s['label'])+'</span>' for j,s in enumerate(sets))+'</div>'
        svg+='<div class="chart-note">'+self.plain(('共同基期 '+all_dates[0]+' = 100' if normalize else '纵轴单位：'+sets[0]['unit'])+' · '+all_dates[0]+' 至 '+all_dates[-1])+'</div>'
        return svg,rows,headers
    def articles(self,section,show_empty=True):
        articles={article['id']:article for article in self.d['articles']}
        rows=self.plan['article_rows'].get(section,[])
        output=''.join('<div class="article-row'+(' paired' if len(row)==2 else '')+'">'+''.join(self.article(articles[identifier]) for identifier in row)+'</div>' for row in rows)
        return '<div class="article-grid">'+output+'</div>' if output else self.empty(section) if show_empty else ''
    def identity(self,item):
        from editorial import label
        return label(self.d,item)
    def attribution(self,item):
        from editorial import dependencies,local_time
        _,_,sources=dependencies(self.d,item)
        return ' · '.join('<a href="'+self.plain(source['url'])+'" target="_blank" rel="noopener noreferrer">'+self.plain(source['publisher'])+'</a> '+self.plain(local_time(source['published_at'],self.d['meta']['timezone'])) for source in sources)
    def company(self,article):
        company=article.get('company')
        if not company:return ''
        fields=[(key,label) for key,label in (('financial_baseline','财务基准'),('conditions','执行条件')) if company.get(key)]
        if not fields:return ''
        return '<details class="company-baseline"><summary>公司基准与执行条件</summary>'+''.join('<p><b>'+label+'：</b>'+self.text(company[key])+'</p>' for key,label in fields)+'</details>'
    def metric_list(self,identifiers):
        if not identifiers:return ''
        return '<dl class="baseline-metrics">'+''.join('<div><dt>'+self.plain(self.metrics[identifier]['label'])+'</dt><dd class="'+metric_color(self.metrics[identifier],self.values.get(identifier))+'">'+self.plain(self.metric(identifier))+'</dd></div>' for identifier in identifiers)+'</dl>'
    def article(self,article):
        from editorial import display_role
        members=self.plan.get('article_merges',{}).get(article['id'],[])
        if members:
            combined=[item for item in self.d['articles'] if item['id'] in members]
            article=dict(article,text='\n'.join(dict.fromkeys(item['text'] for item in combined)),
                claim_ids=list(dict.fromkeys(cid for item in combined for cid in item['claim_ids'])))
        role=self.plan['article_roles'][article['id']];semantic=display_role(article)
        if role=='baseline':semantic='financial_baseline'
        role_label={'financial_baseline':'公司基线','context':'政策 / 产业背景','continuing_event':'延续关注'}.get(semantic,'本期消息')
        stage=article.get('stage','')
        references=''
        active_segments=[part for part in article.get('segments',[]) if not part.get('superseded')]
        active_identity=dict(fact_ids=list(dict.fromkeys(fid for part in active_segments for fid in part['fact_ids'])),
                             claim_ids=list(dict.fromkeys(cid for part in active_segments for cid in part['claim_ids']))) if active_segments else article
        out='<article class="article article-'+role+'" id="article-'+self.plain(article['id'])+'"><div class="article-meta">'+self.plain(role_label+'｜'+self.identity(active_identity)+(('｜'+stage) if stage else ''))+'</div><h3>'+self.plain(self.plan['article_titles'][article['id']])+'</h3><p class="source-attribution">'+self.attribution(active_identity)+'</p>'
        if article.get('disposition')=='pending':out+='<p class="notice">'+self.text(article['disposition_reason'])+'</p>'
        segments=article.get('segments',[])
        def paragraphs(text,references='',prefix='',css=''):
            parts=re.split(r'\n\s*\n',text.strip())
            return ''.join('<p'+(' class="'+css+'"' if css else '')+'>'+(prefix if index==0 else '')+self.text(part)+(references if index==len(parts)-1 else '')+'</p>' for index,part in enumerate(parts))
        if segments:
            active=[segment for segment in segments if not segment.get('superseded')]
            superseded=[segment for segment in segments if segment.get('superseded')]
            def segment_html(segment):
                prefix='<small>'+self.plain(self.identity(dict(fact_ids=segment['fact_ids'],claim_ids=segment['claim_ids'])))+' · '+self.plain('、'.join(self.sources[sid]['publisher'] for sid in segment['source_ids'] if sid in self.sources))+'</small><br>'
                return paragraphs(segment['text'],self.refs(segment['fact_ids'])+self.claim_refs(segment['claim_ids']),prefix,'attributed-segment')
            main=''.join(segment_html(segment) for segment in active)
            if superseded:main+='<details class="prior-version"><summary>查看已被更正的旧表述</summary>'+''.join(segment_html(segment) for segment in superseded)+'</details>'
        else:
            references=self.refs(article['fact_ids'])+self.analysis_refs(article['analysis_ids'])+self.claim_refs(article['claim_ids'])
            main=paragraphs(article['text'],references)
        out+='<div class="article-body"><div class="article-main">'+main
        interpretation=article.get('interpretation',{})
        if interpretation:
            visible=[]
            for field in ('channel','scale_conditions','judgment'):
                value=interpretation.get(field,'')
                if value and value not in article['text'] and value not in visible:visible.append(value)
            if visible:out+='<p class="implication">'+self.text(' '.join(visible))+'</p>'
            if interpretation.get('risk_next'):out+='<p class="risk-line">'+self.text(interpretation['risk_next'])+'</p>'
        else:
            if article.get('relevance') and article['relevance'].strip()!=article['text'].strip():out+='<p class="implication">'+self.text(article['relevance'])+'</p>'
            if article.get('unknowns'):out+='<p class="risk-line">'+self.text(article['unknowns'])+'</p>'
        out+=self.metric_list(self.plan['article_metrics'].get(article['id'],[]))+self.company(article)+'</div></div>'
        linked=[item for item in self.d['articles'] if self.plan['baseline_parents'].get(item['id'])==article['id']]
        if linked:out+='<details class="related-baseline"><summary>关联公司财务基线</summary>'+''.join(self.article(item) for item in linked)+'</details>'
        return out+'</article>'
    def empty(self,section):
        task_id={'news':'official','ai':'ai' if self.d['schema_version']>=7 else 'official','news-companies':'companies','companies':'companies','macro':'macro','market':'market','sectors':'themes','observations':'themes','actions':'synthesis'}.get(section)
        task=next((item for item in self.checks.get('research_completion',{}).get('tasks',[]) if item['id']==task_id),{})
        status=task.get('status','planned')
        message={'planned':'本栏目尚未完成资料整理','running':'本栏目研究尚未完成','verified_none':'已查指定窗口，未发现重要事项','blocked':'本栏目资料尚未完成核验','budget_stop':'本栏目研究未在本期完成','user_stop':'按用户要求停止本栏目研究','done':'已有研究内容，本栏目无适用事项'}.get(status,'本栏目核验状态未知')
        if status in ('blocked','budget_stop','user_stop'):
            return '<p class="empty">'+self.plain(message+'；具体范围见来源与复核。')+'</p>'
        return '<p class="empty">'+self.plain(message+'。'+task.get('stop_reason',''))+'</p>'
    def analysis(self,a):
        out='<article class="analysis" id="a-'+self.plain(a['id'])+'"><span class="status">'+self.plain(a['sector'])+'</span><span class="status">'+self.plain(a.get('horizon','三个期限'))+'</span><span class="status '+('watch' if a['status']=='watch' else '')+'">'+STATUS[a['status']]+'</span><h3>'+self.plain(a['title'])+'</h3><p class="source-attribution">'+self.plain(self.identity(a))+'</p><p class="lead">'+self.text(a['conclusion'])+self.refs(a['fact_ids'])+'</p><p class="materiality"><b>传导与量级</b> '+self.text(a['materiality'])+self.claim_refs(a['field_claims'].get('materiality',[]))+'</p><details class="research-detail"><summary>事实基线、传导与竞争解释</summary><div class="fields">'
        if a.get('format')=='focused':
            out+='<div class="field full"><span class="label">替代解释</span><p>'+self.text(a['alternative'])+self.claim_refs(a['field_claims'].get('alternative',[]))+'</p></div>'
        for key,label in [('novelty','新增变化'),('earnings','利润传导'),('distribution','利益分配'),('pricing','市场反应'),('expectation','预期基准'),('alternative','竞争性解释'),('counterevidence','反证与脆弱环节')]:
            if key not in a or a.get('format')=='focused':continue
            out+='<div class="field '+('full' if key=='counterevidence' else '')+'"><span class="label">'+label+'</span><p>'+self.text(a[key])+self.claim_refs(a['field_claims'].get(key,[]))+'</p></div>'
        out+='</div><p><b>研究优先级 P'+str(a['priority'])+'：</b>'+self.text(a['priority_reason'])+'</p></details>'
        state=self.checks['delivery']['analysis_status'].get(a['id'],{})
        if state.get('reasons'):out+='<div class="notice">本主题有限覆盖：'+self.text('；'.join(state['reasons']))+'</div>'
        out+='<div class="horizon-grid">'
        for key,label in [('intraday','当日至3个交易日'),('short','1—4周'),('medium','1—3个月')]:
            h=a['horizons'][key]
            out+='<div class="horizon"><h4>'+label+'</h4><p class="horizon-conclusion">'+self.text(h['conclusion'])+self.claim_refs(h['claim_ids'])+'</p>'
            for key,caption in (('earnings_channel','盈利'),('valuation_channel','估值'),('base_case','基本情景'),('counter_case','反向情景'),('uncertainty','不确定性')):
                if key in h:out+='<p>'+caption+'：'+self.text(h[key])+'</p>'
            out+='<p>下一观察：'+self.text(h['next_observation'])+'<br>复核：'+self.plain(h['review_at'])+'</p></div>'
        out+='</div><div class="verification"><div><b>支持判断的条件</b>'+self.text(a['support'])+'</div><div><b>削弱或推翻的条件</b>'+self.text(a['invalidation'])+'</div></div>'
        if a.get('update'):out+='<p>跨期变化：'+self.plain(a['update']['status'])+' · '+self.text(a['update']['reason'])+'</p>'
        out+=''.join(self.chart(c) for c in self.plan['charts'] if self.plan['routes'][c['id']]=='analysis:'+a['id'])
        if a['leaders']:
            out+='<h4>龙头与代表对象对照</h4><div class="leader-grid">'
            for l in a['leaders']:
                out+='<div class="leader"><h4>'+self.plain(l['name'])+'</h4><span class="ticker">'+self.plain(l['ticker']+' · '+l['market'])+'</span> <span class="status">'+ROLE[l['role']]+'</span>'+self.refs(l['fact_ids'])
                if l.get('series_id'): out+=self.spark(l['series_id'])
                out+='<dl>'
                for k,label in [('exposure','业务敞口'),('realization','兑现阶段'),('performance','市场表现'),('catalyst','下一催化'),('risk','主要风险')]: out+='<dt>'+label+'</dt><dd>'+self.text(l[k])+'</dd>'
                if l.get('industry_basis'):
                    b=l['industry_basis']
                    out+='<dt>产业地位比较依据</dt><dd>'+self.text(b['scope']+' · '+b['period']+' · '+b['comparison'])+self.refs(b['fact_ids'])+'</dd>'
                out+='</dl></div>'
            out+='</div>'
        out+='<details><summary>展开传导环节与研究缺口</summary>'+self.chain(a)
        out+=('<ul>'+''.join('<li>'+self.text(x)+'</li>' for x in a['gaps'])+'</ul>' if a['gaps'] else '')+'</details></article>'
        return out
    def observation(self,o):
        if o.get('action_id'):
            action=next(item for item in self.d['actions'] if item['id']==o['action_id'])
            analysis=self.analyses[action['analysis_id']]
            o=dict(o,expectation=action['baseline'],opposition=analysis['alternative'],
                mechanism=analysis['materiality'],materiality=action['implication'],
                test=action['when']+'；核对 '+action['target'])
        out='<article class="obs"><span class="status '+('watch' if o['kind']=='watch' else '')+'">'+STATUS[o['kind']]+'</span><h3>'+self.plain(o['title'])+'</h3>'
        if o['kind']=='watch':
            out+='<p class="lead"><b>观察问题：</b>'+self.text(o['divergence'])+self.refs(o['fact_ids'])+self.claim_refs(o['claim_ids'])+'</p>'
            out+='<div class="pair"><div><b>已知基准</b>'+self.text(o['expectation'])+'</div><div><b>另一种解释</b>'+self.text(o['opposition'])+'</div></div>'
            out+='<p><b>下次如何判别：</b>'+self.text(o['test'])
            if o.get('action_id'):out+=' · <a href="#action-'+self.plain(o['action_id'])+'">查看共用支持与失效条件</a>'
            out+='</p>'
            out+='<details><summary>为什么值得观察</summary><p><b>可能机制：</b>'+self.text(o['mechanism'])+'</p><p><b>判断价值：</b>'+self.text(o['materiality'])+'</p></details>'
        else:
            out+='<div class="pair"><div><b>已有预期／讨论基准</b>'+self.text(o['expectation'])+self.refs(o['consensus_fact_ids'])+'</div><div><b>偏离证据</b>'+self.text(o['divergence'])+self.refs(o['fact_ids'])+'</div></div>'
            for k,label in [('mechanism','解释机制'),('materiality','为什么重要'),('opposition','最强反方'),('test','如何区分')]: out+='<p><b>'+label+'：</b>'+self.text(o[k])+'</p>'
        return out+(self.claim_refs(o['claim_ids']) if o['kind']=='contrarian' else '')+'</article>'
    def action(self,a):
        out='<article class="action" id="action-'+self.plain(a['id'])+'"><div class="priority">P'+str(a['priority'])+'</div><div><div class="action-when">'+self.plain(a['when'])+'</div><h3>'+self.text(a['target'])+'</h3><p class="source-attribution">'+self.plain(self.identity(a))+'</p><p class="implication">'+self.text(a['implication'])+self.claim_refs(a['claim_ids'])+'</p><details class="action-detail"><summary>当前基准、支持与失效条件</summary><div class="action-grid">'
        for k,label in [('baseline','当前基准'),('support','支持条件'),('invalidation','否定条件'),('rule_basis','条件依据')]: out+='<div><b>'+label+'</b>'+self.text(a[k])+'</div>'
        out+='</div></details><div class="meta"><span>有效至 '+self.plain(a['expires_at'].replace('T',' '))+'</span><a href="#a-'+self.plain(a['analysis_id'])+'">关联研究</a>'+self.refs(a['fact_ids'])+'</div></div></article>'
        return out
    def appendix(self):
        from research import coverage_view
        d=self.d; out='<details><summary>覆盖范围与数据缺口</summary>'
        out+='<ul>'+''.join('<li>'+self.text(g)+'</li>' for g in d['gaps'])+'</ul>' if d['gaps'] else '<p>本期没有记录全局数据缺口。</p>'
        labels={'checked_new':'已检查有发现','checked_none':'声明范围未见相关发现','partial':'部分覆盖','failed':'访问失败','not_checked':'未检查','cache_reused':'复用缓存·非本轮访问'}
        out+=table(['来源范围','实际状态','说明'],[[self.plain(c['name']),labels[c['status']]+(' · 定向检索' if c['method']=='search' else ''),self.text(c['note'])+'<small>'+self.plain(c.get('content_scope','窗口范围未声明'))+'</small>'] for c in coverage_view(d['coverage'],d['meta']['window_start'],d['meta']['cutoff'])],'coverage-table')+'</details>'
        out+='<details id="evidence"><summary>事实与引用（'+str(len(d['facts']))+'项）</summary><ol class="evidence">'
        for f in d['facts']:
            role='公司自述' if any(self.sources[sid]['kind']=='company' for sid in f['source_ids']) else '官方声明' if any(self.sources[sid]['kind']=='official' for sid in f['source_ids']) else '媒体报道'
            label=role if f['status']=='reported' else STATUS[f['status']]
            out+='<li id="f-'+self.plain(f['id'])+'"><span class="status">'+label+'</span> '+self.text(f['statement'])+self.evidence_refs(f['evidence_ids'])+'<small>观测期：'+self.plain(f['as_of'])+' · 可得：'+self.plain(f['available_at'] or '未知')+' · '+self.text(f['locator'])+'</small><small>'+self.source_links(f['source_ids'])+'</small>'+self.backref('f-'+f['id'])+'</li>'
        out+='</ol></details><details><summary>来源目录（'+str(len(d['sources']))+'项）</summary><ol class="source-list">'
        for s in d['sources']:
            prefix='包内读取记录' if d['meta'].get('evidence_mode')=='fixed_pack' else '来源读取记录'
            out+='<li><a href="'+self.plain(s['url'])+'" target="_blank" rel="noopener noreferrer">'+self.plain(s['title'])+'</a><br>'+self.plain(s['publisher']+' · 发布 '+s['published_at'])+'<br>'+self.plain(prefix+'：'+s['read_status']+' · '+s['accessed_at']+' · 同源组 '+s['origin_group'])
            v=s.get('verification')
            if v:
                labels={'verified':'完成原文核验','partial':'部分读取','failed':'访问失败','not_attempted':'未尝试'}
                out+='<br>'+self.plain('本轮复核：'+labels[v['status']]+' · '+v.get('checked_at','核验时间未记录'))+'<br>'+self.text(v['note'])
                if v.get('url'): out+=' · <a href="'+self.plain(v['url'])+'" target="_blank" rel="noopener noreferrer">实际访问地址</a>'
            out+='</li>'
        pairs=[m for m in d['metrics'] if m['op']=='pair_difference']
        if pairs:
            out+='</ol></details><details><summary>数值比较的计算依据</summary><ul>'
            for m in pairs:
                a=self.metrics[m['from_metric']]; b=self.metrics[m['to_metric']]
                out+='<li>'+self.plain(m['label'])+'：'+self.plain(self.metric(m['id']))+'<br>'+self.text(m.get('formula',m['comparison_basis']))+'<br>'+self.plain(b['label']+' '+self.metric(b['id'])+' − '+a['label']+' '+self.metric(a['id'])+('；百分点差 × 100 转为基点' if m['unit']=='bp' and a['unit']=='%' else ''))+'<br>'+self.source_links(source_ids(d,m))+'</li>'
            out+='</ul>'
        else: out+='</ol>'
        out+='</details><details><summary>上期判断复核</summary>'
        if d.get('prior_reviews'):
            for p in d['prior_reviews']: out+='<p><b>'+self.plain(p['thesis_id'])+' v'+str(p['previous_version'])+'</b><br>'+self.plain(p['status'])+'：'+self.text(p['explanation'])+'</p>'
        else: out+='<p>本期没有可读取的上期判断记录，不作历史一致性声明。</p>'
        out+='</details><details><summary>审阅记录与计算检查</summary><p>'+self.plain(d['review']['reviewer'])+' · '+self.text(d['review']['method'])+'</p><p>结构与计算校验不证明来源真实性或经济因果。</p>'
        for issue in d['review']['issues']: out+='<p>'+('已解决：' if issue['resolved'] else '待处理：')+self.text(issue['message'])+((' · '+self.text(issue['resolution'])) if issue.get('resolved') else '')+'</p>'
        if self.checks['warnings']: out+='<ul>'+''.join('<li>'+self.plain(w['path']+'：'+w['message'])+'</li>' for w in self.checks['warnings'])+'</ul>'
        out+='</details><details id="claims"><summary>主张到证据的引用链</summary>'
        for c in d['claims']:
            out+='<div class="claim-record" id="c-'+self.plain(c['id'])+'"><div class="meta">主张 '+str(self.cnums[c['id']])+' · '+self.plain(c['status'])+'</div><p>'+self.text(c['text'])+self.refs(c['fact_ids'])
            out+=' '.join('<a href="#m-'+self.plain(mid)+'">'+self.plain(self.metrics[mid]['label'])+'</a>' for mid in c['metric_ids'])+'</p>'+self.backref('c-'+c['id'])+'<details class="technical"><summary>技术标识</summary><code>'+self.plain(c['id'])+'</code></details></div>'
            if c['limitations']:out+='<p class="notice">'+self.text('；'.join(g['message']+'：'+g['impact'] for g in c['limitations']))+'</p>'
        for mid,metric in self.metrics.items():
            detail=self.checks['metric_details'][mid]
            out+='<p id="m-'+self.plain(mid)+'">'+self.plain(metric['label'])+'：'+self.plain(self.metric(mid))+' · '+self.plain(detail['as_of'])+' · '+self.source_links(detail['source_ids'])+'</p>'
        for e in d['evidence']:
            out+='<blockquote id="e-'+self.plain(e['id'])+'">'+self.text(e['quote'])+'<small>'+self.text(e['context'])+' · '+self.text(e['locator'])+' · '+self.source_links([e['source_id']])+'</small>'+self.backref('e-'+e['id'])+'</blockquote>'
        return out+'</details>'

def display_plan(d,checks):
    from common import fingerprint
    from validation import validate_charts
    from edition import route, sections
    from calculations import comparison_errors
    from urllib.parse import urlsplit
    edition=d['meta'].get('edition','snapshot');charts=[];omitted=[]
    maps={group:{item['id']:item for item in d[group]} for group in ('metrics','series','analyses','events')}
    groups={};evidence={item['id']:item for item in d['evidence']};sources={item['id']:item for item in d['sources']}
    claims={item['id']:item for item in d['claims']};facts={item['id']:item for item in d['facts']}
    def article_domain(article):
        if article.get('content_role') in ('financial_baseline','baseline') and (article.get('company') or any(metric['dimensions']['entity_id']==article.get('primary_entity') and metric.get('domain')=='company' for metric in d['metrics'])):return 'company'
        if article.get('domain'):return article['domain']
        if article.get('company'):return 'company'
        source_list=[sources[source_id] for fact_id in article['fact_ids'] if fact_id in facts for source_id in facts[fact_id]['source_ids'] if source_id in sources]
        if any((urlsplit(source['url']).hostname or '').endswith('.gov.cn') for source in source_list):return 'cn_official'
        return {'macro':'overseas','ai':'ai','market':'cn_market','companies':'company'}.get(article['section'],'cn_official')
    def placement(domain):return {'overseas':'macro','cn_official':'news','ai':'ai','company':'companies','cn_market':'market'}.get(domain,'market')
    def metric_domain(metric):
        if metric.get('domain'):return metric['domain']
        related=[article_domain(article) for article in d['articles'] if any(metric['id'] in claims.get(ident,{}).get('metric_ids',[]) for ident in article['claim_ids'])]
        return related[0] if related else 'cn_market'
    def title(text,fallback):
        return text if re.search(r'[\u3400-\u9fff]',text) else fallback
    for chart in d['charts']:
        metric_ids=[item['metric_id'] for item in chart.get('items',[])]+[mid for row in chart.get('rows',[]) for mid in row['metric_ids']]+[item[key] for item in chart.get('points',[]) for key in ('x_metric','y_metric')]
        if set(metric_ids)&set(checks.get('unready_metrics',[])):omitted.append(dict(group=chart['title'],reason='数值支持尚待复核；保留原始记录，不画成已核验图形'))
        else:charts.append(chart)
    mentioned={item['metric_id'] for chart in charts for item in chart.get('items',[])}
    qualified=[]
    for metric in d['metrics']:
        eligible=checks['values'].get(metric['id']) is not None and metric['id'] not in checks.get('unready_metrics',[])
        if metric['op']=='observed':eligible=eligible and bool(metric.get('evidence_ids')) and all(evidence.get(ident,{}).get('read_method') in ('original','cached') for ident in metric.get('evidence_ids',[]))
        if eligible:qualified.append(metric)
        if eligible and metric['op']=='observed' and metric.get('chart_group') and metric.get('chart_takeaway') and metric['id'] not in mentioned:
            key=(metric['chart_group'],metric_domain(metric),metric['unit'],metric['dimensions']['currency'],metric['dimensions']['scale'],metric['dimensions']['measure'],metric['as_of'],metric['dimensions']['period'],metric.get('price_basis'),metric.get('return_type'))
            groups.setdefault(key,[]).append(metric)
    for key,metrics in groups.items():
        if len(metrics)<2:continue
        categories={metric.get('category') for metric in metrics}
        breadth=categories in ({'up','down'},{'up','down','flat'})
        comparison='parts_of_whole' if breadth else 'cross_entity_same_measure'
        known_sample=breadth and 'flat' not in categories
        if comparison_errors(metrics,comparison,known_sample):continue
        if len(charts)>=(2 if edition=='intraday' else 5):continue
        chart=dict(id='auto_'+fingerprint(key)[:16],type='breadth' if breadth else 'bars',title='已知涨跌样本' if known_sample else title(key[0],'同类指标比较'),takeaway=metrics[0]['chart_takeaway'],
                   note='同日截面 · '+key[6]+' · '+'；'.join(dict.fromkeys(metric.get('scope','') for metric in metrics))+' · 单位 '+key[2]+('；只含已知涨跌样本，不代表全市场。' if known_sample else '；原始值与各对象样本范围保留。'),
                   placement=placement(key[1]),items=[dict(label=metric['label'],metric_id=metric['id'],**({'category':metric['category']} if breadth else {})) for metric in metrics],generated=True,
                   scope=metrics[0].get('scope','各自对象'),comparison_kind=comparison,known_sample=known_sample)
        errors=[];validate_charts(dict(d,schema_version=5,charts=[chart]),maps,lambda *args:errors.append(args))
        if errors:omitted.append(dict(group=key[0],reason=str(errors)))
        else:charts.append(chart)
    used_series={ident for chart in charts for ident in chart.get('series_ids',[])}
    heat_groups={}
    if edition!='intraday':
        for metric in qualified:
            series=maps['series'].get(metric.get('series_id'))
            if not series or metric['op']!='return' or metric.get('n') not in (20,60):continue
            key=tuple(series.get(field) for field in ('market','provider','classification','adjustment','frequency','calendar_id','domain'))
            heat_groups.setdefault(key,{}).setdefault(series['id'],{})[metric['n']]=metric['id']
        for key,rows in heat_groups.items():
            if len(rows)<2 or len(charts)>=5:continue
            windows=sorted(set.intersection(*(set(row) for row in rows.values())))
            if not windows:continue
            chart=dict(id='auto_heat_'+fingerprint(key)[:12],type='heatmap',title='宽基 / 同类对象历史比较',takeaway='同窗收益用于描述历史差异，不代表独立超额收益能力。',
                note='只显示各对象均已核验的连续窗口；成分范围各自保留，未满足的窗口不补数。',placement=placement(key[-1] or 'cn_market'),classification=key[2],scope='各自对象成分范围',
                columns=[str(window)+'会话收益' for window in windows],rows=[dict(label=maps['series'][identifier]['label'],metric_ids=[metrics[window] for window in windows]) for identifier,metrics in rows.items()],generated=True)
            errors=[];validate_charts(dict(d,schema_version=5,charts=[chart]),maps,lambda *args:errors.append(args))
            if not errors:charts.append(chart)
    for series in d['series']:
        if edition=='intraday' or len(charts)>=5:break
        from calculations import history_window_ready
        ready=series['basis']=='price' and history_window_ready(d,series,20)
        if not ready or series['id'] in used_series:continue
        charts.append(dict(id='auto_line_'+fingerprint(series['id'])[:12],type='line',title=series['label']+' · 实际历史',
            takeaway='已取得连续会话；历史表现不代表未来收益或盈利趋势。',note=series['scope']+' · '+series['adjustment'],
            placement=placement(series.get('domain','cn_market')),series_ids=[series['id']],normalize=True,window=60,generated=True))
        used_series.add(series['id'])
    def slot(placement,analysis=None):
        if placement=='theme':return 'analysis:'+analysis
        return route(edition,placement)
    routes={chart['id']:slot(chart['placement'],chart.get('analysis_id')) for chart in charts}
    if len(routes)!=len(charts):raise ValueError('展示计划存在重复图表ID')
    featured=d['meta'].get('featured_metrics',[])
    if not featured:
        featured=[metric['id'] for metric in qualified if metric['op']=='observed'][:6]
    featured=[mid for mid in featured if checks['values'].get(mid) is not None and mid not in checks.get('unready_metrics',[]) and metric_domain(maps['metrics'][mid]) in ('cn_market','overseas')][:6]
    article_routes={};article_titles={};reused={};baselines={}
    for article in d['articles']:
        article_titles[article['id']]=article.get('display_title') or article['title']
        target=slot(article['section'] if d['schema_version']>=7 else placement(article_domain(article)))
        if article.get('content_role')=='financial_baseline':target=slot('companies')
        if article.get('disposition')=='excluded' or (d['schema_version']>=6 and article.get('disposition')=='pending'):target='excluded';reused[article['id']]=article.get('disposition_reason','明确排除')
        key=article.get('baseline_key')
        if key and key in baselines:target='reused';reused[article['id']]='复用财务基线 '+baselines[key]
        elif key:baselines[key]=article['id']
        article_routes[article['id']]=target
    from common import get_zone, iso
    zone=get_zone(d['meta']['timezone']);window=iso(d['meta']['window_start'])
    def is_baseline(article):
        from editorial import display_role
        if display_role(article)=='financial_baseline' or (article.get('content_role')=='baseline' and article_domain(article)=='company'):return True
        if article.get('content_role') in ('context','background','continuing_event','baseline'):return False
        company=article.get('company',{})
        dated=[facts[identifier].get('available_at') for identifier in article['fact_ids'] if identifier in facts]
        return bool(company.get('financial_baseline') and company.get('metric_ids') and not article.get('interpretation') and dated and all(value and iso(value,date_only=True,tz=zone)<window for value in dated))
    def normalize_entity(value):return re.sub(r'\s+','',value).replace('（','(').replace('）',')').casefold()
    aliases={}
    for article in d['articles']:
        company=article.get('company')
        if not company:continue
        identity=company.get('entity_id') or article.get('primary_entity')
        if not identity:continue
        for value in (identity,company['name'],company.get('ticker',''),company['name']+'('+company.get('ticker','')+')'):
            aliases.setdefault(normalize_entity(value),set()).add(identity)
    def entity(article):
        identity=article.get('company',{}).get('entity_id') or article.get('primary_entity','')
        matches=aliases.get(normalize_entity(identity),set())
        return next(iter(matches)) if len(matches)==1 else identity if not matches else None
    ordered=sorted(d['articles'],key=lambda article:article['priority'])
    # Different measures of one entity/session remain separate observations,
    # but do not need separate reader cards. Keep every claim in the merged card.
    article_merges={};market_groups={}
    for article in ordered:
        if edition=='intraday' or article['id'] in reused or article.get('content_role') or article['fact_ids'] or article['kind']!='analysis':continue
        metric_ids={mid for cid in article['claim_ids'] for mid in claims.get(cid,{}).get('metric_ids',[])}
        metrics=[maps['metrics'][mid] for mid in metric_ids if mid in maps['metrics']]
        keys={(m['dimensions']['entity_id'],m['dimensions']['period'],m.get('as_of'),m.get('scope')) for m in metrics if m['op']=='observed'}
        if len(keys)!=1 or len(metrics)!=len(metric_ids) or any(m['op']!='observed' for m in metrics):continue
        key=(article_routes[article['id']],next(iter(keys)))
        if key in market_groups:
            parent=market_groups[key];article_merges.setdefault(parent,[parent]).append(article['id'])
            reused[article['id']]='同一主体和会话的行情观测合并展示';article_routes[article['id']]='reused'
        else:market_groups[key]=article['id']
    baseline_parents={};article_roles={};article_metrics={};metric_owners=set()
    for article in ordered:
        identifier=article['id']
        if is_baseline(article):
            article_roles[identifier]='baseline'
            candidates=[other for other in ordered if not is_baseline(other) and entity(article) and entity(other)==entity(article) and article_routes[other['id']]==article_routes[identifier] and other['id'] not in reused]
            if candidates and identifier not in reused:baseline_parents[identifier]=candidates[0]['id']
        else:
            interpretation=article.get('interpretation',{})
            visible_size=len(article['text'])+sum(len(interpretation.get(field,'')) for field in ('judgment','risk_next'))
            total_size=len(article['text'])+sum(len(value) for value in interpretation.values())
            article_roles[identifier]='brief' if visible_size<=240 and total_size<=420 and len(article['text'])<=150 and len(article_titles[identifier])<=56 and not re.search(r'\n\s*\n',article['text']) else 'reading'
        if identifier not in reused:
            owned=[mid for mid in article.get('company',{}).get('metric_ids',[]) if mid in maps['metrics'] and mid not in metric_owners]
            article_metrics[identifier]=owned;metric_owners.update(owned)
    for identifier in baseline_parents.values():article_roles[identifier]='reading'
    article_rows={};article_lookup={article['id']:article for article in ordered}
    for article in ordered:
        identifier=article['id'];target=article_routes[identifier]
        if identifier in reused or identifier in baseline_parents:continue
        rows=article_rows.setdefault(target,[])
        previous=article_lookup[rows[-1][0]] if rows else None
        paired=previous and len(rows[-1])==1 and article_roles[identifier]==article_roles[previous['id']]=='brief' and article['kind']==previous['kind'] and article['priority']==previous['priority'] and min(len(article['text']),len(previous['text']))>=max(len(article['text']),len(previous['text']))*.6
        if paired:rows[-1].append(identifier)
        else:rows.append([identifier])
    featured_groups=[];grouped=set()
    for identifier in featured:
        if identifier in grouped:continue
        metric=maps['metrics'][identifier];group=[identifier]
        if metric.get('category') in ('up','down','flat'):
            peers=[maps['metrics'][mid] for mid in featured if mid not in grouped and maps['metrics'][mid].get('category') in ('up','down','flat') and maps['metrics'][mid]['unit']==metric['unit'] and metric_date(d,maps['metrics'][mid])==metric_date(d,metric)]
            if len(peers)>=2 and len({item['category'] for item in peers})==len(peers) and not comparison_errors(peers,'parts_of_whole',True):group=[item['id'] for item in peers]
        featured_groups.append(group);grouped.update(group)
    displayed=set(featured)|metric_owners|{item['metric_id'] for chart in charts for item in chart.get('items',[])}|{mid for chart in charts for row in chart.get('rows',[]) for mid in row['metric_ids']}
    tables={}
    # A partially blocked task must not erase already usable market data.
    # This is a bounded display fallback, not a synthesized market narrative.
    if edition!='intraday' and not article_rows.get('market') and 'market' not in routes.values():
        candidates=[metric for metric in qualified if metric_domain(metric)=='cn_market' and metric['op']=='observed'
                    and metric.get('kind','actual')=='actual' and metric.get('value_identity')!='conditional'
                    and metric['dimensions']['measure'] in ('index_change','turnover','breadth')]
        if candidates:
            latest=max(metric_date(d,metric)[:10] for metric in candidates)
            candidates=[metric for metric in candidates if metric_date(d,metric)[:10]==latest]
            selected=[]
            for measure,limit in (('index_change',5),('turnover',2),('breadth',3)):
                group=[metric for metric in candidates if metric['dimensions']['measure']==measure]
                if measure=='breadth':
                    # Keep one declared sample; never mix providers/universes.
                    if group:
                        sample=lambda metric:(metric['dimensions']['entity_id'],metric.get('scope'),tuple(metric.get('source_ids',[])),metric.get('universe_id'),metric.get('universe_version'))
                        group=[metric for metric in group if sample(metric)==sample(group[0])]
                selected.extend(metric['id'] for metric in group[:limit])
            tables['market']=selected
            displayed.update(selected)
    visible_text=[a['text'] for a in d['articles'] if a.get('disposition','retained')=='retained']+[a.get(k,'') for a in d['analyses'] for k in ('conclusion','materiality')]+[s['text'] for s in d['summary']]
    displayed.update(match.group(1) for text in visible_text for match in TOKEN.finditer(text))
    # The appendix already preserves all metrics. Only chosen charts, featured
    # values and article comparisons belong in the main reading path.
    supplemental=[metric['id'] for metric in qualified if metric['id'] not in displayed]
    return dict(charts=charts,routes=routes,articles=article_routes,article_titles=article_titles,tables=tables,reused=reused,sections=sections(edition),
                summary='hero' if edition=='evening' else 'status' if edition=='intraday' else 'overview',featured=featured,
                featured_groups=featured_groups,article_rows=article_rows,article_roles=article_roles,baseline_parents=baseline_parents,article_metrics=article_metrics,
                article_merges=article_merges,supplemental_metrics=supplemental,
                omitted=omitted,accounting=dict(summary=len(d['summary']),metrics=len(featured),charts=len(charts),articles=len(d['articles']),reused=len(reused),tables=sum(map(len,tables.values()))))


def render_report(d,checks=None):
    from briefing import display_document
    from validation import validate
    from common import fingerprint
    if checks is None or checks.get('document_sha256')!=fingerprint(d):checks=validate(d)
    if checks['errors']:raise ValueError('渲染前校验未通过')
    return _render_display(display_document(d,checks),checks)


def _render_display(d,checks):
    from edition import policy
    from common import iso
    from research import near_action
    from editorial import local_time,metric_identity
    renderer=Renderer(d,checks);meta=d['meta'];renderer.plan=display_plan(d,checks)
    plan=renderer.plan;edition=meta.get('edition','snapshot')
    titles=plan['sections'];overrides=meta.get('section_titles',{})
    nav='<nav data-section-nav aria-label="报告目录">'+''.join('<a data-section-link="'+item['id']+'" href="#'+item['id']+'"'+(' class="subnav"' if item['parent'] else '')+'><span>'+item['number']+'</span>'+renderer.plain(overrides.get(item['id'],item['title']))+'</a>' for item in titles)+'</nav>'
    tools='<div class="tools" data-enhancement hidden><button type="button" data-theme aria-pressed="false">切换深色</button><button type="button" data-expand aria-pressed="false">展开证据</button><button type="button" data-print>打印</button></div>'
    delivery=checks['delivery']
    labels={'full':'信息整理与审阅完成','limited':'有限研究','observation':'观察版','draft':'草稿','incremental_verified':'增量核验完成','first_observation':'首次观察','partial_coverage':'部分覆盖'}
    lead=d['summary'][0] if d['summary'] else None
    headline=meta['title']
    if headline.startswith('每日关注简报'):headline='市场环境、重要变化与下一观察'
    generated=d.get('publication',{}).get('generated_at') or checks.get('generated_at')
    content='<div class="topbar"><span>'+renderer.plain(meta['date']+' · '+policy(edition)['label'])+' / 研究快照</span>'+tools+'</div>'
    title_size='long' if len(renderer.plain(headline))>36 else 'medium' if len(renderer.plain(headline))>22 else 'short'
    content+='<header class="hero title-'+title_size+'"><div class="hero-main"><div class="eyebrow">DAILY BRIEFING · '+renderer.plain(meta['date']+' '+policy(edition)['label'])+'</div><h1>'+renderer.text(headline)+'</h1>'
    content+='<div class="hero-meta"><span>信息截止 '+renderer.plain(local_time(meta['cutoff'],meta['timezone'])+'（'+meta['timezone']+'）')+'</span><span>范围 '+renderer.plain(' / '.join(meta['scope']))+'</span>'
    if generated:content+='<span>实际生成 '+renderer.plain(local_time(generated,meta['timezone']))+'</span>'
    if generated and meta['mode']=='live' and (iso(generated)-iso(meta['cutoff'])).total_seconds()>3600:content+='<span>延后生成 · 信息截止未顺延</span>'
    content+='</div><p class="delivery-status"><span>'+labels[delivery['grade']]+'</span><a href="#sources">查看证据与研究边界 ↗</a></p>'
    if meta['mode']!='live':content+='<p class="hero-note">'+('合成测试 · 非市场事实' if meta['mode']=='teaching' else '历史时点重建 · 非准时交付记录')+'</p>'
    content+='</div><div class="hero-cues">'
    for position,summary in enumerate(d['summary'][:5],1):
        content+='<div class="hero-cue"><span>'+f'{position:02}'+'</span><div><strong>'+renderer.text(summary.get('priority_object') or '当期要点')+'</strong><p class="summary-text">'+renderer.text(summary['text'])+renderer.refs(summary['fact_ids'])+renderer.claim_refs(summary['claim_ids'])+'</p><small>'+renderer.plain(renderer.identity(summary))+'</small>'
        if summary.get('key_risk'):content+='<details class="summary-boundary"><summary>判断边界</summary>'+renderer.text(summary['key_risk'])+'</details>'
        content+='</div></div>'
    content+='</div></header>'
    if meta.get('revision_note'):content+='<p class="revision-note">'+renderer.plain(meta['revision_note'])+'</p>'
    scope_note=meta.get('scope_note') or ('本期仍有'+str(len(delivery['coverage']['missing']))+'个来源范围未完整覆盖，具体范围见附录；消息身份逐条标注。' if delivery['coverage']['missing'] else '本期已整理所声明范围，证据身份与未来兑现条件逐条标注。')
    content+='<p class="scope-note">'+renderer.plain(scope_note)+'</p><div class="mobile-nav">'+nav+'</div>'
    def section(key,body):
        item=next(item for item in titles if item['id']==key)
        tag='h3' if item['parent'] else 'h2'
        return '<section data-report-section id="'+key+'"><'+tag+' tabindex="-1"><span class="sec-num">'+item['number']+' /</span>'+renderer.plain(overrides.get(key,item['title']))+'</'+tag+'>'+body+'</section>'
    def visuals(key):
        charts=[chart for chart in plan['charts'] if plan['routes'][chart['id']]==key]
        output='<div class="chart-grid">'+''.join(renderer.chart(chart) for chart in charts)+'</div>' if charts else ''
        metric_ids=plan['tables'].get(key,[])
        if metric_ids:
            rows=[]
            for identifier in metric_ids:
                metric=renderer.metrics[identifier]
                rawdate=metric_date(d,metric)
                observed=local_time(rawdate,meta['timezone']) if 'T' in rawdate else rawdate
                rows.append([renderer.plain(metric['label']),'<b>'+renderer.plain(renderer.metric(identifier))+'</b>',renderer.plain(observed),renderer.plain(metric.get('scope',metric['dimensions']['segment']))+'<br>'+renderer.source_links(source_ids(d,metric))])
            output+='<div class="metric-table"><h3>关键数值与口径</h3>'+table(['指标','数值','观测时点 / 期间','范围'],rows,classes='market-snapshot' if key=='market' else '')+'</div>'
        return output
    def stats():
        cards=[]
        for group in plan['featured_groups']:
            values=''
            for identifier in group:
                metric=renderer.metrics[identifier];formatted=renderer.metric(identifier,False);unit=metric['unit']
                value=renderer.plain(formatted[:-len(unit)])+'<span class="unit">'+renderer.plain(unit)+'</span>' if unit and formatted.endswith(unit) else renderer.plain(formatted)
                status={'reported':'来源报道值','conditional':'若属实情景','official':'原始发布值'}[metric_identity(d,metric)]
                values+='<div><div class="label">'+renderer.plain(metric['label'])+'</div><div class="value '+metric_color(metric,checks['values'].get(identifier))+'">'+value+'</div><small>'+status+'</small></div>'
            rawdate=metric_date(d,renderer.metrics[group[0]])
            observed=local_time(rawdate,meta['timezone']) if 'T' in rawdate else rawdate
            cards.append('<div class="stat'+(' stat-pair' if len(group)>1 else '')+'"><div class="stat-values">'+values+'</div><small>'+renderer.plain(observed)+'</small></div>')
        return '<div class="stats" data-count="'+str(len(cards))+'">'+''.join(cards)+'</div>' if cards else ''
    def themes():
        cards=''
        if len(d['analyses'])>1:
            cards='<nav class="theme-grid" aria-label="研究主题">'
            for position,analysis in enumerate(d['analyses']):
                cards+='<a class="theme-card tone-'+str(position%3)+'" href="#a-'+renderer.plain(analysis['id'])+'"><small>'+f'{position+1:02}'+' · '+renderer.plain(analysis['sector'])+'</small><span>'+renderer.plain(analysis['title'])+'</span></a>'
            cards+='</nav>'
        return cards+''.join(renderer.analysis(analysis) for analysis in d['analyses']) if d['analyses'] else renderer.empty('sectors')
    def observations():
        if d['observations']:return ''.join(renderer.observation(item) for item in d['observations'])
        review=d.get('observation_review',{})
        labels={'checked_none':'已检查候选线索，未形成可复核观察','hypotheses':'已有待验证条件，尚未形成独立观察卡','blocked':'观察候选研究受阻','not_checked':'观察候选尚未完成筛查'}
        return '<p class="empty">'+renderer.plain(labels.get(review.get('status'),'相关研究尚未完成；不能推断没有非共识机会')+'。'+review.get('reason',''))+renderer.evidence_refs(review.get('evidence_ids',[]))+'</p>'
    def actions():
        near=[];triggered=[];medium=[]
        for action in sorted(d['actions'],key=lambda item:item['priority']):
            (near if near_action(action,d) else triggered if action.get('trigger') else medium).append(action)
        output='<h3>当日至3会话</h3>'+(''.join(renderer.action(action) for action in near) or '<p class="empty">尚无经会话日历确认的近期观察时点；中期计划不代替今日观察。</p>')
        if triggered:output+='<h3>事件触发时复核</h3>'+''.join(renderer.action(action) for action in triggered)
        if medium:output+='<h3>中期复核 / 日历待确认</h3>'+''.join(renderer.action(action) for action in medium)
        return output
    if edition=='intraday':
        baseline=checks.get('delta',{}).get('baseline')
        state='相对前一正式报告的增量' if baseline else '无已锁定的可比基线；首次观察或历史范围受限'
        content+=section('status','<p>'+state+'</p>'+stats()+visuals('status'))
        for key,kinds in (('changes',{'new','progress','correction','late_discovery'}),('market',{'market','trigger'})):
            changes=[item for item in d['changes'] if item['kind'] in kinds]
            cards=''.join('<article class="change-item"><h3>'+renderer.text(item['text'])+'</h3><p>'+renderer.text(item['why'])+'</p><p><strong>'+renderer.text(item['impact'])+'</strong>'+renderer.claim_refs(item['claim_ids'])+'</p></article>' for item in changes)
            content+=section(key,(cards or '<p class="empty">在已核验窗口内未发现重大新增；未查或失败入口不代表无新增。</p>')+renderer.articles(key,False)+visuals(key))
        content+=section('next',''.join('<p>'+renderer.text(item['next_observation'])+'</p>' for item in d['changes'] if item.get('next_observation')) or '<p class="empty">沿用已冻结观察条件；没有新增条件。</p>')
    else:
        if edition=='evening':content+='<div class="hero-content">'+stats()+visuals('hero')+'</div>'
        for item in titles:
            key=item['id']
            if key=='sources' or item['parent']:continue
            if key=='overview':body=stats()+visuals('overview')
            elif key=='sectors':body=themes()+visuals(key)
            elif key=='observations':body=observations()
            elif key=='actions':body=actions()
            elif key=='news' and edition in ('morning','snapshot'):
                body='<h3>中国官方与重大事件</h3>'+renderer.articles('news')+visuals('news')+'<div id="news-companies"><h3>重要公司消息与相关基线</h3>'+renderer.articles('news-companies')+visuals('news-companies')+'</div>'
            else:
                articles=renderer.articles(key,False);charts_and_data=visuals(key)
                body=articles+charts_and_data
                if not body:body=renderer.empty(key)
                elif key=='market' and not articles:
                    body='<p class="scope-note">以下为已取得并通过数值核对的行情。市场概况文字尚未完成；未显示的指标与具体限制见来源与复核。</p>'+body
                rows=plan['article_rows'].get(key,[])
                if key=='market' and len(rows)==1 and len(rows[0])==1 and not next(article for article in d['articles'] if article['id']==rows[0][0]).get('interpretation') and sum(target==key for target in plan['routes'].values())==1 and not plan['tables'].get(key):body='<div class="market-composition">'+body+'</div>'
            content+=section(key,body)
    pending=[event for event in d.get('research_events',[]) if event.get('importance',0)>=5 and not event.get('reported') and event.get('reporting_disposition')=='retained_pending']
    audit=''
    if pending:audit+='<div class="notice"><b>重要事项尚待核验</b>'+''.join('<p>'+renderer.text(event.get('reporting_reason','待补证'))+renderer.claim_refs(event['claim_ids'])+'</p>' for event in pending)+'</div>'
    coverage=delivery['coverage']
    audit+='<p class="coverage-strip">核心窗口 '+str(coverage['covered'])+' / '+str(coverage['required'])+' 已认可；这是覆盖边界，不是研究质量得分。</p>'
    audit+='<details><summary>交付、任务与展示记录</summary><p>'+renderer.text('；'.join(delivery['reasons']) or '通过当前程序门槛；不证明全部事实或经济因果。')+'</p>'
    for task in checks.get('research_completion',{}).get('tasks',[]):
        detail=task.get('stop_reason') or (task.get('next') if task.get('status') in ('planned','running') else '')
        if detail:audit+='<p>'+renderer.plain('制作复核｜'+task['question']+'：'+detail)+'</p>'
    audit+=''.join('<p>'+renderer.plain(item['group']+'：'+item['reason'])+'</p>' for item in plan['omitted'])
    audit+=''.join('<p>'+renderer.plain(reason)+'</p>' for reason in plan['reused'].values())+'</details>'
    content+=section('sources',audit+renderer.appendix())
    for chart in plan['charts']:
        if content.count('id="chart-'+renderer.plain(chart['id'])+'"')!=1:raise ValueError('图表必须恰好展示一次：'+chart['id'])
    for article in d['articles']:
        if article['id'] not in plan['reused'] and content.count('id="article-'+renderer.plain(article['id'])+'"')!=1:raise ValueError('正文必须恰好展示一次：'+article['id'])
    content+='<footer>信息截至 '+renderer.plain(local_time(meta['cutoff'],meta['timezone']))+'。离线快照，不自动刷新；事实、判断与情景分开复核。<br>作者 / 环境：'+renderer.plain(meta['author'])+'</footer>'
    assets=Path(__file__).resolve().parent.parent/'assets'
    css=(assets/'report.css').read_text(encoding='utf-8');script=(assets/'report.js').read_text(encoding='utf-8')
    return '<!doctype html>\n<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light dark"><title>'+renderer.plain(meta['title'])+'</title><style>'+css+'</style></head><body><a class="skip" href="#'+titles[0]['id']+'">跳到研究正文</a><div class="shell"><aside class="side"><div class="brand">每日关注<small>DAILY BRIEFING</small></div>'+nav+'<p class="side-note">证据 · 机制 · 验证<br>离线快照 / 非实时行情</p></aside><main>'+content+'</main></div><div class="chart-tip" role="tooltip" hidden></div><script>'+script+'</script></body></html>\n'
