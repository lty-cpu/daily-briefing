# briefing.json v1

UTF-8 JSON，`schema_version: 1`。文本为纯文本，不接受任意HTML。引用编号使用字母开头的ASCII字母/数字/下划线/连字符，各集合内唯一。完整样例见`examples/briefing.json`。先理解字段含义再写，不把样例数据搬到当前早报。

## 顶层

必需：meta、sources、facts、series、metrics、summary、articles、analyses、observations、actions、charts、coverage、gaps、review。空集合用[]，不删除必需字段。可选events、prior_reviews，默认[]。

- `meta`：title、date(YYYY-MM-DD)、cutoff(ISO8601含时区)、timezone(IANA)、window_start(ISO)、profile、author、mode(live/historical/teaching)、coverage_status(complete/limited)、scope。`scope`是字符串数组。`market_dates`可用市场→最近完整交易日的映射。`run_id`可选，安全ASCII名称；省略时脚本生成独立目录。
- `sources[]`：id、title、publisher、url(HTTP/S)、published_at、accessed_at、kind(official/company/media/data)、read_status(full/partial/unavailable)、origin_group。发布只有日期时按该日结束保守检查，不能把当天未知时间的资料强算为盘前已知。访问时间可以晚于报告截止。旧网页后来修订需明确原始资料的可得性。
- `facts[]`：id、statement、source_ids、status(confirmed/reported/conflicted/unverified)、core(bool)、as_of、locator。`locator`记录支持段落/表格位置或简短摘录，不是新推断。官方confirmed不能只引用媒体；reported表示有据的报道，不等于官方确认。冲突/未核实事实不得成为核心结论的唯一支撑。
- `coverage[]`：name、url、status(checked_new/checked_none/failed/not_checked)、checked_at、note、source_ids。`checked_none`表示查过相关栏目和窗口，不是搜索无结果。
- `gaps[]`：缺口及对结论的影响，字符串数组。

meta还可带`featured_metrics`（最多4个已有指标ID，用于首屏数字）和`section_titles`（栏目ID→标题；栏目为overview/news/ai/market/sectors/macro/observations/actions/sources）。无此字段使用默认页面。

固定资料模式：`meta.evidence_mode` 可取 `independent`（默认）或 `fixed_pack`；后者必须提供 `meta.evidence_pack: {name, sha256}`，SHA256由文件实际字节计算。该模式下，sources中的accessed_at/read_status表示包内原记录；每项另需 `verification: {status, note, checked_at?, url?}`。status为verified/partial/failed/not_attempted，除not_attempted外需实际checked_at，url保存本次实际访问地址（含采用的官方镜像）。verified表示本次完整复核正文；HTTP成功但登录页/空页不能记verified。固定包来源复核失败仍可沿用包内材料作对照，但脚本和HTML必须保留未独立核验提示。`coverage`只记录本次操作，原包的覆盖记录不能冒充本次完成的检查。

来源只有发布日期时，可附`published_timezone`（发布者该日的UTC偏移，如+08:00、-07:00），以该时区日终检查可得性，不能用读者时区代替发布者时区。未知时按UTC−12日终保守处理。若仍不能确认截止前已公开，补足发布时间或将该来源排除出该时点报告；“待核实”标签不能掩盖使用未来信息。

## 原始序列与计算

`series[]`：id、label、unit、basis(price/turnover/yield_percent/shares/count/level)、market、provider、adjustment、classification、source_ids、observations。observations按日期严格升序，每项`{date: YYYY-MM-DD, value: number|null}`。按原始交易日表保留缺失null，不生成日期、不插值。price/turnover不能为负。不同源/复权/交易日期不可悄悄拼接。只收入截止时刻已公开的数据。

`metrics[]`：id、label、op、unit，以及以下操作所需字段：

| op | 字段 | 结果 |
|---|---|---|
| observed | value, as_of, source_ids | 原文直接公布的数字，不伪装成重算值 |
| return | series_id, n | (最新/前n交易日−1)×100，unit必须% |
| excess_return | series_id, benchmark_id, n | 同日期窗口收益率差，unit必须百分点 |
| volume_ratio | series_id | 最后成交额/此前20日中位数，unit必须倍 |
| bp_change | series_id, n | 收益率百分点差×100，unit必须bp |
| difference | series_id, n | 原单位差，unit必须与序列一致 |
| pair_difference | from_metric, to_metric, comparison_basis | 两个observed指标的后值减前值；两个输入同单位，百分率之差用百分点或bp（乘100），其他保持原单位 |

return/excess仅用于price；volume_ratio仅turnover；bp_change仅yield_percent。n正整数。不足n+1或21个有效连续记录则值为null并产生警告；缺失不跳过，也不能用少数点假装20日数据。excess要求相同日期窗口、市场、provider和adjustment。

序列观测若恰为截止当天，必须带`available_at`（含时区时间，且不晚于截止）。这防止把当日收盘数据填入盘前报告。历史值后来修订的可得性仍须人工复核；脚本无法推断发布时点或交易所日历。

任何文本里可用`{metric:metric_id}`，渲染器统一替换为数值和单位；编号不存在会失败。禁止在文字里重复手填同一计算结果。`value`不能为NaN/Infinity或bool。

引用已自带单位与正负号，写“上涨家数为{metric:UP}”，不要再加一个“家”；写“日变动{metric:Change}”，不要把负值写成“下跌−3%”。区间上限、下限、中值与完整区间是不同含义：只有上限4%的指标不能写成“目标区间为4%”，应称“目标区间上限”或同时引用上下限。

指标可加`signed: true`显示正负号；原文公布的涨跌幅也应启用。收益率变化类运算默认带符号，利率水平不默认加号。

`pair_difference` 用于两个实际披露数值的比较，不需要伪造时间序列。只接受observed输入，禁止循环或嵌套；任一输入缺失则结果null。`comparison_basis`写明两个期间/口径、实绩或指引、可比条件。来源由两输入合并，数据日期显示两输入中较晚的日期。该运算不证明经济可比性。例：本期毛利率62%、下期指引中值61%，差值为−100bp；指引±25bp另作为原文指标，不能充当变化幅度。正文写“指引中值与实绩之差为{metric:MarginDelta}”，不用手填计算结果。差值为负时用“变化/差值”，避免“下降−100bp”的双重符号。

## 叙述和分析

- `summary[]`：text、fact_ids、analysis_ids。每项至少引用一个事实/分析；最多3项。摘要结论不可超出所引用正文。
- `articles[]`：id、section(news/ai/market/macro)、title、text、kind(fact/analysis/watch)、fact_ids、analysis_ids、priority(1–7)。按priority排序。
- `analyses[]`：id、sector、title、conclusion、horizon、status(supported/watch)、fact_ids、novelty、earnings、distribution、pricing、expectation、alternative、counterevidence、support、invalidation、gaps、mechanism、leaders。上述论证文本即使缺数据也须说明缺口，不能填“暂无风险”。
- `mechanism[]`：from、to、basis(fact/assumption)、fact_ids、assumption。fact边必须引用事实；assumption边必须解释假设。箭头是论证结构，不声称已证明因果。
- `leaders[]`：name、ticker、market、role(industry/trading/both/representative/watch)、exposure、realization、performance、catalyst、risk、fact_ids、role_evidence。`role_evidence`是industry/trading→事实编号数组；both必须两类均有。`series_id`可选，用于真实序列小图。缺少角色证据时主动降为representative/watch。
- 当role为industry/both时，另需 `industry_basis: {scope, period, comparison, fact_ids}`，说明在哪个行业范围、哪个期间、与谁/何种行业基准比较，以及支持引用。大额公司收入本身不足以证明领先地位；脚本检查记录齐全，真实比较含义仍须研究审阅。
- `observations[]`：id、kind(contrarian/watch)、title、expectation、consensus_fact_ids、divergence、mechanism、materiality、opposition、test、fact_ids。contrarian必须有可核验预期事实，不能引用unverified/conflicted。
- `actions[]`：id、analysis_id、priority(1–3)、when、expires_at(含时区ISO)、target、baseline、support、invalidation、implication、rule_basis、fact_ids。必须关联本报告已有分析，未过期，有可复核条件；`rule_basis`明确阈值/条件的依据。提示何时观察，不代表自动监控。
- `events[]`：id、at(含时区ISO或YYYY-MM-DD)、label、status(confirmed/expected)、detail、fact_ids。只知道日期就保留日期，不编造钟点。未来事件可以列出，证据本身需在截止前公开。
- `prior_reviews[]`：thesis_id、previous_report、original_conclusion、original_support、original_invalidation、status(supported/weakened/refuted/unknown)、explanation、fact_ids。不改旧报告，由本报告保存更新。

## 图表

通用字段id、type、title、takeaway、note。每图自动附可展开数据表及来源；note须注明范围/日期，不能让图名替代定义。

广度图items必须恰有三个互异`category`：up、flat、down，标签可自定；某类家数未知则指标value为null，不省略该类别。这样不会用局部数据生成误导性的100%占比，配色也不依赖条目顺序。强弱热力图使用return/excess_return计算指标，分类须与原始序列一致。

- `breadth`：items=[{label,metric_id}]，指标同单位“家”、同日期、非负，scope说明样本。
- `bars`：items同上，指标同单位/日期，展示截面，不冒充连续历史。
- `heatmap`：columns=[字符串]；rows=[{label,metric_ids:[与columns等长]}]；classification、scope。各列同一种运算和窗口，同列日期/来源/市场/分类/复权口径一致。不同缺失值留空。
- `scatter`：points=[{label,x_metric,y_metric}]；横轴必须excess_return，纵轴volume_ratio，同日期、市场、来源和分类；不能绘制主观强弱分。
- `line`：series_ids数组，normalize(bool)；不同单位不得放同一纵轴。normalize只用于price，以各序列共同首个有效日期=100，不填补断点。
- `mechanism`：analysis_id，直接渲染对应机制；事实线和假设线不同样式。
- `timeline`：event_ids，来自events。

## 审阅与报告状态

`review`：status(draft/reviewed)、reviewer、method、checked_fact_ids、checked_analysis_ids、issues。

issue：severity(blocking/warning)、message、resolved(bool)、resolution(解决时必填)。reviewed要求所有core事实、所有分析已复核，且无未解决blocking；只是审阅记录，不能自行证明判断正确。draft只能生成标注草稿的HTML。

可选 `remaining_limitation` 保存错误主张已修正后仍存在的证据缺口；只要非空，脚本继续产生warning。全局gaps或failed/not_checked覆盖记录也自动保留覆盖warning，不能用把所有issue标成resolved清除它。fixed_pack里 `checked_fact_ids` 表示已对包内材料复核，独立原文访问是否完成以verification为准。

`complete`要求coverage没有failed/not_checked，且没有全局gaps。任何覆盖缺口改为limited；不得删掉失败记录骗过检查。

## 命令与输出

```text
python scripts/briefing.py validate --input briefing.json
python scripts/briefing.py build --input briefing.json --output-dir outputs/daily-briefing
python scripts/briefing.py history --output-dir outputs/daily-briefing --limit 3
python -m unittest discover -s tests -v
```

每次构建独立目录包含`briefing.html`、原始`briefing.json`、`checks.json`、`theses.json`。checks记录错误、警告、计算值和结构检查性质；同名运行拒绝覆盖。脚本不联网，不下载、执行来源内容，也不修改模型配置。history仅列出完整构建结果。需要合并跨期观点时由模型读取原记录后做有来源的复核。
