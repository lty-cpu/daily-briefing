# 在 DeepSeek / MiMo 环境中运行 v1.2

技能是普通 Markdown 和 Python 3.10+ 标准库程序，不要求 Codex 插件。保留用户指定的模型全名，不切换模型或修改 Harness 配置。后两端由用户实际运行并回传；开发者的程序回放不能当成真实模型通过。

## 固定资料整报

每端把同一份对照压缩包解压到独立目录，开启全新会话，以解压根目录为工作目录，执行 `comparison/01-同资料整报-v1.2.txt`。不引用旧长对话、不带其他模型答案、旧报告、评分或修订示例。已有成功的 DeepSeek v1.1 输出保留作历史基准，不能冒称为 v1.2 复测。

固定包只读 `sources/facts/metrics/series` 及资料限制。包内 `accessed_at/read_status/coverage` 是提供者历史记录；本轮状态由初始化设为 `not_attempted`、当前 coverage 留空，实际访问后才更新。沿用资料包不等于独立核验。发现事实/截止错误，写入 `evidence-differences.json` 并暂停使用该事实，不私改固定包。允许增加只依赖包内输入的计算指标，不补包外事实。

执行顺序：

1. 只读 `daily-briefing/SKILL.md`，直接运行 `scripts/run.py start`。它自动算哈希、复制证据并准备 JSON 骨架，不需要模型编写复制/哈希/生成报告的辅助脚本。
2. 按阶段用 `guide --name research/analysis/finance/evidence/contract` 各读取一次，再直接编辑运行目录中的 `briefing.json`。每次 `--name` 只选一个名称。保留详细研究卡、反证、资金/龙头边界，不能为省上下文降低分析标准。
3. 正文完成后用 `guide --name review` 审阅，运行一次 `finish`。最多两次输入修正；原样重跑会被拦截。错误全文保存在 `checks.json`，只定位相关字段，不重读所有资料或源码。
4. 有可用浏览器才做一轮视觉检查。无浏览器明确写未验收，不安装软件或遍历截图配置。保存原始回答和实际检查情况。

正常固定轮不运行单元测试，不读 `scripts/*.py`、assets、examples、eval 或旧对话。文件已到 EOF/输出为空即停止读取，不能不断增大行号。连续两次没有新增资料、输入修改或新检查结果，应停止并交付现有文件。预算耗尽不另开目录绕过；独立重测由用户另行启动。

## 联网整报

同一日期、截止和主题；用 `run.py start --cutoff <含时区ISO时间>` 初始化，其余遵循 SKILL.md。各端独立检索，记录实际覆盖差异，不把工具不可达自动归因于模型推理。历史回放只用截止前已公开的信息；不存在的行情序列留缺，不补造图表。

## 回传和续接

回传运行目录，包含 `briefing.json`、`checks.json`、`run-state.json`、`run-info.txt`、`evidence-differences.json`、原始回答，以及成功时 `reports/` 下的 HTML、输入、检查和 `theses.json`。失败也回传已有文件，不必把全部命令输出塞进消息。

中断或上下文压缩后先调用 `run.py status --work-dir <原目录>`，从已有输入续接；只对真正丢失的规范使用一次 `guide --recover`。这不能清除旧任务已经积累的上下文，也不保证修复代理的压缩/协议问题。

开发案例和保留案例只在明确安排的开发测试中运行。固定轮结果、独立盲测、同会话回放必须分开标识；不同 Harness、推理设置和模型快照分别记录。
