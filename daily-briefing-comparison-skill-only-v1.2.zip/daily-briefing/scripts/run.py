#!/usr/bin/env python3
"""Bounded, resumable report workflow. Python 3.10+, standard library, no network."""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
import sys

from briefing import build, iso, load, validate

VERSION = "1.2"
SKILL = Path(__file__).resolve().parents[1]
STATE = "run-state.json"
MAX_ATTEMPTS = 3
GUIDES = {
    "research": "research-method.md",
    "analysis": "analysis-cards.md",
    "contract": "data-contract.md",
    "finance": "finance-ai.md",
    "review": "review-and-evaluation.md",
}


def stamp():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, data):
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def emit(data):
    print(json.dumps(data, ensure_ascii=False, indent=2))


def read_state(work):
    state = load(work / STATE)
    if state.get("skill_version") != VERSION:
        raise ValueError("运行记录版本不同；保留该目录，为新版本使用新目录。")
    return state


def status(work, state):
    return {
        "phase": state["phase"],
        "work_dir": str(work),
        "input": str(work / "briefing.json"),
        "attempts": len(state["attempts"]),
        "max_attempts": MAX_ATTEMPTS,
        "guides_read": state["guides_read"],
        "output": state.get("output"),
        "next": state["next"],
        "note": "状态在磁盘中；续接不读取旧对话、脚本源码或已构建的HTML全文。",
    }


def start(args, work):
    # Repeated initialization is a status query, never a reset of budgets or input.
    if (work / STATE).exists():
        return status(work, read_state(work))
    if work.exists() and any(work.iterdir()):
        raise ValueError("初始化需要空目录；已有 run-state.json 时使用 status 续接。")
    pack = load(args.evidence_pack) if args.evidence_pack else None
    if pack is not None:
        if not isinstance(pack, dict) or any(not isinstance(pack.get(k), list) for k in ("sources", "facts", "metrics", "series")):
            raise ValueError("资料包需有 sources/facts/metrics/series 数组。")
        if args.cutoff and args.cutoff != pack.get("cutoff"):
            raise ValueError("固定包截止与请求不一致；不更改输入资料的时间边界。")
    cutoff = iso(pack["cutoff"] if pack is not None else args.cutoff)
    window = iso(args.window_start) if args.window_start else cutoff - timedelta(days=1)
    if window > cutoff:
        raise ValueError("窗口起点不能晚于截止。")
    scope = args.scope or (pack.get("scope") if pack is not None else ["A股", "全球宏观", "AI"])
    if not isinstance(scope, list) or not scope or not all(isinstance(s, str) and s for s in scope):
        raise ValueError("scope 需要非空文本数组。")
    meta = dict(title="每日关注简报", date=cutoff.date().isoformat(), cutoff=cutoff.isoformat(),
                timezone=args.timezone, window_start=window.isoformat(), profile=args.profile,
                author=args.model, mode="historical" if pack is not None else "live",
                coverage_status="limited", scope=scope, run_id="report")
    d = dict(schema_version=1, meta=meta,
             **{k: [] for k in ("sources", "facts", "series", "metrics", "summary", "articles", "analyses",
                                "observations", "actions", "charts", "coverage", "gaps", "events", "prior_reviews")})
    d["review"] = dict(status="draft", reviewer=args.model, method="尚未完成研究审阅",
                       checked_fact_ids=[], checked_analysis_ids=[], issues=[])
    state = dict(skill_version=VERSION, phase="writing", created_at=stamp(), guides_read={}, attempts=[],
                 model=args.model, harness=args.harness, reasoning=args.reasoning,
                 next="按 SKILL.md 读取各阶段 guide 各一次，然后直接编辑 briefing.json 的正文。")
    if pack is not None:
        for key in ("sources", "facts", "series", "metrics", "gaps"):
            d[key] = copy.deepcopy(pack.get(key, []))
        for source in d["sources"]:
            source["verification"] = dict(status="not_attempted", note="本轮尚未访问原文；包内读取记录不是本轮核验。")
        d["gaps"].append("本轮沿用固定资料包；独立原文复核和覆盖扫描尚未完成。")
        # Historical coverage is deliberately not copied into current-run coverage.
        raw = Path(args.evidence_pack).read_bytes()
        state["evidence_sha256"] = hashlib.sha256(raw).hexdigest()
        meta.update(evidence_mode="fixed_pack", evidence_pack=dict(name="evidence-pack.json", sha256=state["evidence_sha256"]))
    else:
        d["gaps"].append("资料收集及覆盖记录待完成。")
    work.mkdir(parents=True, exist_ok=True)
    if pack is not None:
        (work / "evidence-pack.json").write_bytes(raw)
        save(work / "evidence-differences.json", [])
    save(work / "briefing.json", d)
    save(work / STATE, state)
    (work / "run-info.txt").write_text(
        f"skill_version: {VERSION}\nactual_model: {args.model}\nharness: {args.harness}\n"
        f"reasoning: {args.reasoning}\ncutoff: {meta['cutoff']}\nwindow_start: {meta['window_start']}\n"
        f"evidence_sha256: {state.get('evidence_sha256', 'independent')}\n"
        "research_review: pending\nvisual_check: not_performed\n"
        "运行进度、失败检查和输出路径见 run-state.json；实际审阅见 briefing.json。\n",
        encoding="utf-8")
    return status(work, state)


def guide(args, work, state):
    name = args.name
    count = state["guides_read"].get(name, 0)
    if count >= (2 if args.recover else 1):
        return {"status": "already_read", "name": name, "eof": True,
                "next": "该资料已完整返回；停止读取，编辑 briefing.json。仅上下文压缩后丢失规范时可用一次 --recover。"}
    if name == "evidence":
        path = work / "evidence-pack.json"
        if not path.exists():
            raise ValueError("本轮没有固定包；依据研究阶段实际取得的资料写入输入。")
        if digest(path) != state.get("evidence_sha256"):
            raise ValueError("固定包已被改变，停止；恢复原资料，不以修改输入消除问题。")
        # Remove indentation, not evidence. All original fields and facts are retained.
        content = json.dumps(load(path), ensure_ascii=False, separators=(",", ":"))
    else:
        path = SKILL / "references" / GUIDES[name]
        content = path.read_text(encoding="utf-8-sig")
    if len(content) > 14000:
        raise ValueError("此资料超过单次阅读预算；停止并说明输入规模，勿逐行无限翻页或截断事实。")
    state["guides_read"][name] = count + 1
    save(work / STATE, state)
    return {"name": name, "characters": len(content), "lines": len(content.splitlines()),
            "eof": True, "content": content,
            "next": "本文件已到末尾，不再读取。按当前阶段继续研究或写入 briefing.json。"}


def brief_checks(checks, work):
    def short(items, limit):
        return [{"path": str(x.get("path", ""))[:160], "message": str(x.get("message", ""))[:300]} for x in items[:limit]]
    return {"error_count": len(checks["errors"]), "warning_count": len(checks["warnings"]),
            "errors": short(checks["errors"], 6), "warnings": short(checks["warnings"], 3),
            "checks_file": str(work / "checks.json")}


def finish(work, state):
    input_path = work / "briefing.json"
    sha = digest(input_path)
    if state["phase"] == "complete":
        if sha != state["built_input_sha256"]:
            raise ValueError("本轮已有产物且输入已改变；保留产物，新一轮使用新目录。")
        return {**status(work, state), "status": "already_built"}, 0
    if len(state["attempts"]) >= MAX_ATTEMPTS:
        return {**status(work, state), "status": "stopped", "next": "已达3次校验上限；交付现有输入、检查与缺口，停止命令调用。"}, 3
    if any(a["input_sha256"] == sha and a["status"] == "failed" for a in state["attempts"]):
        return {"status": "unchanged_input", "next": "这份输入已校验失败；不重跑相同输入。按 checks.json 定位修改，或交付阻塞说明。",
                "checks_file": str(work / "checks.json")}, 3
    for previous in state["attempts"]:
        if previous["status"] == "started":
            previous["status"] = "interrupted"
    number = len(state["attempts"]) + 1
    attempt = dict(number=number, input_sha256=sha, started_at=stamp(), status="started",
                   checks_file=f"checks-attempt-{number:02d}.json")
    state["attempts"].append(attempt)
    state["phase"] = "checking"
    state["next"] = "读取简短校验结果，只修输入中明确报错的字段；不读取或修改脚本。"
    save(work / STATE, state)  # Persist before executing so interruptions cannot reset the budget.
    def record_checks(checks):
        save(work / attempt["checks_file"], checks)
        save(work / "checks.json", checks)
    try:
        d = load(input_path)
        checks = validate(d)
        if isinstance(d, dict):
            if not d.get("summary") or not (d.get("articles") or d.get("analyses")):
                checks["errors"].append(dict(path="report", message="初始化骨架不能作为早报交付：请先撰写摘要及正文。"))
            if state.get("evidence_sha256"):
                if digest(work / "evidence-pack.json") != state["evidence_sha256"]:
                    checks["errors"].append(dict(path="evidence-pack", message="固定包字节改变；停止并恢复原资料。"))
                meta = d.get("meta") if isinstance(d.get("meta"), dict) else {}
                identity = meta.get("evidence_pack") if isinstance(meta.get("evidence_pack"), dict) else {}
                if meta.get("evidence_mode") != "fixed_pack" or identity.get("sha256") != state["evidence_sha256"]:
                    checks["errors"].append(dict(path="meta.evidence_pack", message="报告的固定包标识与本轮输入不一致。"))
        record_checks(checks)
        if not checks["errors"]:
            # An interrupted build may leave a partial directory. Preserve it and
            # give the next bounded attempt its own destination, never overwrite.
            destination = work / "reports"
            if number > 1:
                destination = destination / f"attempt-{number:02d}"
            out = build(d, checks, destination)
            state.update(phase="complete", output=str(out / "briefing.html"), built_input_sha256=sha,
                         review_status=d["review"]["status"], next="交付HTML及检查文件；可用浏览器做一次视觉验收并如实记录。")
            attempt["status"] = "built"
            save(work / STATE, state)
            return {**brief_checks(checks, work), **status(work, state), "review_status": d["review"]["status"]}, 0
    except (ValueError, TypeError, KeyError, OSError, AttributeError, IndexError) as exc:
        checks = dict(errors=[dict(path="input_or_build", message=str(exc))], warnings=[], values={})
        record_checks(checks)
    attempt.update(status="failed", error_count=len(checks["errors"]))
    state["phase"] = "stopped" if len(state["attempts"]) >= MAX_ATTEMPTS else "needs_input_fix"
    if state["phase"] == "stopped":
        state["next"] = "已达3次校验上限；交付现有输入、检查与缺口，停止命令调用。"
    save(work / STATE, state)
    return {**brief_checks(checks, work), **status(work, state)}, 2


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    p = commands.add_parser("start", help="Create input and persistent progress in an empty work directory")
    p.add_argument("--work-dir", required=True)
    p.add_argument("--evidence-pack")
    p.add_argument("--cutoff", help="ISO time with offset; required for live mode")
    p.add_argument("--window-start")
    p.add_argument("--timezone", default="Asia/Shanghai")
    p.add_argument("--profile", default="finance-ai")
    p.add_argument("--scope", nargs="+")
    p.add_argument("--model", default="unknown")
    p.add_argument("--harness", default="unknown")
    p.add_argument("--reasoning", default="unknown")
    for name in ("guide", "finish", "status"):
        p = commands.add_parser(name)
        p.add_argument("--work-dir", required=True)
        if name == "guide":
            p.add_argument("--name", choices=[*GUIDES, "evidence"], required=True)
            p.add_argument("--recover", action="store_true", help="One reread only after context loss")
    args = parser.parse_args(argv)
    try:
        work = Path(args.work_dir).resolve()
        if args.command == "start":
            emit(start(args, work)); return 0
        state = read_state(work)
        if args.command == "status":
            emit(status(work, state)); return 0
        if args.command == "guide":
            emit(guide(args, work, state)); return 0
        result, code = finish(work, state)
        emit(result); return code
    except (ValueError, TypeError, KeyError, OSError) as exc:
        emit({"status": "stopped", "error": str(exc)[:800],
              "next": "停止重复命令。说明缺少的输入或环境能力，保留现有文件；不要探索源码或扩大输出预算。"})
        return 3


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    raise SystemExit(main())
