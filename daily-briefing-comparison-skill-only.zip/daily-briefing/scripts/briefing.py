#!/usr/bin/env python3
"""Portable briefing CLI. Python >=3.10, standard library only. No network."""
from __future__ import annotations
import argparse
import json
import math
import re
import statistics
import sys
from datetime import date, datetime, time, timezone, timedelta
from pathlib import Path
from urllib.parse import urlsplit
from uuid import uuid4

ID = re.compile(r'^[A-Za-z][A-Za-z0-9_-]*$')
TOKEN = re.compile(r'\{metric:([A-Za-z][A-Za-z0-9_-]*)\}')
COLLECTIONS = ('sources','facts','series','metrics','summary','articles','analyses','observations','actions','charts','coverage','gaps')
ANALYSIS_TEXT = ('sector','title','conclusion','horizon','novelty','earnings','distribution','pricing','expectation','alternative','counterevidence','support','invalidation')

def num(v):
    return isinstance(v, (int,float)) and not isinstance(v,bool) and math.isfinite(v)

def iso(v, date_only=False, tz=timezone.utc):
    if not isinstance(v,str): raise ValueError('date must be string')
    if date_only and re.fullmatch(r'\d{4}-\d{2}-\d{2}',v):
        return datetime.combine(date.fromisoformat(v),time.max,tzinfo=tz)
    d = datetime.fromisoformat(v.replace('Z','+00:00'))
    if d.tzinfo is None: raise ValueError('ISO timestamp needs timezone offset')
    return d

def source_ids(d, metric):
    if metric['op']=='observed': return metric.get('source_ids',[])
    sm = {s['id']:s for s in d['series']}
    result = []
    for key in ('series_id','benchmark_id'):
        if metric.get(key) in sm: result.extend(sm[metric[key]].get('source_ids',[]))
    return list(dict.fromkeys(result))

def metric_date(d, metric):
    if metric['op']=='observed': return metric.get('as_of','')
    s=next((s for s in d['series'] if s['id']==metric.get('series_id')),None)
    return s['observations'][-1]['date'] if s and s['observations'] else ''

def compute_metric(m, series):
    op=m['op']
    if op=='observed': return m['value']
    s=series[m['series_id']]['observations']
    n=20 if op=='volume_ratio' else m['n']
    if len(s)<n+1: return None
    window=s[-n-1:]
    if any(p['value'] is None for p in window): return None
    a,b=window[0]['value'],window[-1]['value']
    if op=='volume_ratio':
        denominator=statistics.median(p['value'] for p in window[:-1])
        return b/denominator if denominator>0 else None
    if op=='bp_change': return (b-a)*100
    if op=='difference': return b-a
    if a<=0: return None
    result=(b/a-1)*100
    if op=='excess_return':
        bseries=series[m['benchmark_id']]['observations'][-n-1:]
        if len(bseries)!=len(window) or [p['date'] for p in bseries]!=[p['date'] for p in window]:
            raise ValueError('benchmark windows do not align')
        if any(p['value'] is None for p in bseries) or bseries[0]['value']<=0: return None
        result-=(bseries[-1]['value']/bseries[0]['value']-1)*100
    return result

def validate(d):
    errors=[]; warnings=[]; values={}
    def err(path,message): errors.append({'path':path,'message':message})
    def warn(path,message): warnings.append({'path':path,'message':message})
    def required(obj,keys,path):
        if not isinstance(obj,dict): err(path,'必须是对象'); return False
        for key in keys:
            if key not in obj: err(path+'.'+key,'缺少字段')
        return all(key in obj for key in keys)
    def textfields(obj,keys,path):
        for key in keys:
            if not isinstance(obj.get(key),str) or not obj[key].strip(): err(path+'.'+key,'必须是非空文本')
    def enum(obj,key,allowed,path):
        if obj.get(key) not in allowed: err(path+'.'+key,'允许值: '+','.join(allowed))
    def url(v,path):
        try:
            u=urlsplit(v)
            if u.scheme not in ('http','https') or not u.netloc or u.username or u.password: raise ValueError()
        except (ValueError,TypeError): err(path,'必须是无凭证的HTTP/S URL')
    if not isinstance(d,dict): return {'errors':[{'path':'root','message':'JSON根必须是对象'}],'warnings':[],'values':{}}
    if d.get('schema_version')!=1: err('schema_version','仅支持1')
    for key in COLLECTIONS:
        if not isinstance(d.get(key),list): err(key,'必须为数组，空集合使用[]')
    if not required(d.get('meta'),('title','date','cutoff','timezone','window_start','profile','author','mode','coverage_status','scope'),'meta'): return {'errors':errors,'warnings':warnings,'values':values}
    if errors: return {'errors':errors,'warnings':warnings,'values':values}
    meta=d['meta']; textfields(meta,('title','timezone','profile','author'),'meta')
    enum(meta,'mode',('live','historical','teaching'),'meta'); enum(meta,'coverage_status',('complete','limited'),'meta')
    try:
        cutoff=iso(meta['cutoff']); start=iso(meta['window_start'])
        if start>cutoff: err('meta.window_start','不能晚于截止')
        date.fromisoformat(meta['date'])
        if meta['date']!=cutoff.date().isoformat(): err('meta.date','应为截止时间所在日期')
    except (ValueError,TypeError): err('meta','日期或带时区时间无效'); return {'errors':errors,'warnings':warnings,'values':values}
    if not isinstance(meta['scope'],list) or not meta['scope'] or not all(isinstance(x,str) for x in meta['scope']): err('meta.scope','非空字符串数组')
    if 'run_id' in meta and not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,79}',str(meta['run_id'])): err('meta.run_id','运行名不安全')
    if not isinstance(meta.get('market_dates',{}),dict): err('meta.market_dates','必须为对象')
    if not isinstance(meta.get('section_titles',{}),dict): err('meta.section_titles','必须为对象')
    else:
        for key,value in meta.get('section_titles',{}).items():
            if key not in ('overview','news','ai','market','sectors','macro','observations','actions','sources') or not isinstance(value,str) or not value.strip(): err('meta.section_titles','未知栏目或空标题')
    if not all(isinstance(g,str) and g.strip() for g in d['gaps']): err('gaps','缺口必须为非空文本')
    if errors: return {'errors':errors,'warnings':warnings,'values':values}
    for market,day in meta.get('market_dates',{}).items():
        try:
            if date.fromisoformat(day)>cutoff.date(): err('meta.market_dates.'+market,'交易日不能晚于截止日期')
        except (ValueError,TypeError): err('meta.market_dates.'+market,'无效交易日期')
    for extra in ('events','prior_reviews'):
        if extra in d and not isinstance(d[extra],list): err(extra,'必须是数组')
    if errors: return {'errors':errors,'warnings':warnings,'values':values}
    maps={}
    for group in ('sources','facts','series','metrics','articles','analyses','observations','actions','charts','events'):
        maps[group]={}
        for i,item in enumerate(d.get(group,[])):
            path=f'{group}[{i}]'
            if not isinstance(item,dict): err(path,'必须为对象'); continue
            identifier=item.get('id')
            if not isinstance(identifier,str) or not ID.fullmatch(identifier): err(path+'.id','无效编号'); continue
            if identifier in maps[group]: err(path+'.id','重复编号')
            maps[group][identifier]=item
    def refs(obj,key,group,path,minimum=0):
        v=obj.get(key)
        if not isinstance(v,list) or not all(isinstance(x,str) for x in v): err(path+'.'+key,'必须是编号数组'); return []
        if len(v)<minimum: err(path+'.'+key,'缺少支持引用')
        for x in v:
            if x not in maps[group]: err(path+'.'+key,'不存在的引用: '+x)
        return [x for x in v if x in maps[group]]
    def before(v,path,tz=None):
        try:
            t=iso(v,date_only=True,tz=tz or cutoff.tzinfo)
            if t>cutoff: err(path,'不能确认在截止前可得：晚于截止或仅有当天日期')
        except (ValueError,TypeError): err(path,'无效时间')
    if 'featured_metrics' in meta:
        refs(meta,'featured_metrics','metrics','meta')
        if isinstance(meta['featured_metrics'],list) and len(meta['featured_metrics'])>4: err('meta.featured_metrics','首页最多4个关键指标')
    for sid,s in maps['sources'].items():
        p='sources.'+sid
        textfields(s,('title','publisher','published_at','accessed_at','origin_group'),p); url(s.get('url'),p+'.url')
        enum(s,'kind',('official','company','media','data'),p); enum(s,'read_status',('full','partial','unavailable'),p)
        publisher_tz=cutoff.tzinfo
        if re.fullmatch(r'\d{4}-\d{2}-\d{2}',str(s.get('published_at'))):
            offset=s.get('published_timezone')
            if offset is None:
                publisher_tz=timezone(timedelta(hours=-12))
                warn(p,'只有发布日期且时区未知，按UTC−12日终保守验证；不得默认使用读者时区')
            else:
                try:
                    if not re.fullmatch(r'[+-]\d{2}:\d{2}',str(offset)): raise ValueError()
                    publisher_tz=iso('2000-01-01T00:00:00'+offset).tzinfo
                except (ValueError,TypeError): err(p+'.published_timezone','必须为有效UTC偏移，如+08:00')
        before(s.get('published_at'),p+'.published_at',publisher_tz)
        try:
            accessed=iso(s.get('accessed_at'))
            if accessed<iso(s.get('published_at'),date_only=True,tz=publisher_tz) and len(str(s.get('published_at')))>10: err(p+'.accessed_at','读取早于发布')
        except (ValueError,TypeError): err(p+'.accessed_at','无效时间')
        if s.get('read_status')!='full': warn(p,'正文未完整读取，不应支持确定性核心事实')
    for fid,f in maps['facts'].items():
        p='facts.'+fid; textfields(f,('statement','as_of','locator'),p)
        enum(f,'status',('confirmed','reported','conflicted','unverified'),p)
        ids=refs(f,'source_ids','sources',p,1)
        if not isinstance(f.get('core'),bool): err(p+'.core','必须为bool')
        if f.get('core') and f.get('status') in ('conflicted','unverified'): err(p,'冲突/未核实事实不得作为核心事实')
        if f.get('core') and not any(maps['sources'][x].get('read_status')=='full' for x in ids): err(p,'核心事实需完整读取至少一个支持来源')
        if f.get('status')=='confirmed' and ids and all(maps['sources'][x].get('kind')=='media' for x in ids): err(p,'仅媒体依据请标为reported')
    for sid,s in maps['series'].items():
        p='series.'+sid; textfields(s,('label','unit','market','provider','adjustment','classification'),p)
        enum(s,'basis',('price','turnover','yield_percent','shares','count','level'),p); refs(s,'source_ids','sources',p,1)
        obs=s.get('observations')
        if not isinstance(obs,list): err(p+'.observations','必须为数组'); continue
        prev=''
        for i,o in enumerate(obs):
            q=f'{p}.observations[{i}]'
            if not required(o,('date','value'),q): continue
            try:
                od=date.fromisoformat(o['date'])
                if od>cutoff.date(): err(q,'数据晚于截止日期')
                if od==cutoff.date() and not o.get('available_at'): err(q,'截止当天数据须提供含时区available_at，避免使用盘后数据')
                if o['date']<=prev: err(q,'日期必须严格升序且无重复')
                prev=o['date']
            except (ValueError,TypeError): err(q,'无效日期')
            if o.get('available_at'): before(o['available_at'],q+'.available_at')
            if o['value'] is not None and not num(o['value']): err(q,'数字必须有限，缺失用null')
            elif num(o['value']) and s.get('basis') in ('price','turnover','shares','count') and o['value']<0: err(q,'此类数据不能为负')
    for mid,m in maps['metrics'].items():
        p='metrics.'+mid; textfields(m,('label','unit'),p)
        if 'signed' in m and not isinstance(m['signed'],bool): err(p+'.signed','必须为bool')
        enum(m,'op',('observed','return','excess_return','volume_ratio','bp_change','difference'),p)
        if m.get('op')=='observed':
            if m.get('value') is not None and not num(m.get('value')): err(p+'.value','必须为有限数值或null')
            if 'value' not in m: err(p+'.value','缺少字段')
            refs(m,'source_ids','sources',p,1); before(m.get('as_of'),p+'.as_of')
        else:
            s=maps['series'].get(m.get('series_id',''))
            if not s: err(p+'.series_id','序列不存在'); continue
            if m.get('op')!='volume_ratio' and (not isinstance(m.get('n'),int) or isinstance(m.get('n'),bool) or m['n']<=0): err(p+'.n','正整数窗口')
            expected={'return':('price','%'),'excess_return':('price','百分点'),'volume_ratio':('turnover','倍'),'bp_change':('yield_percent','bp')}.get(m.get('op'))
            if expected and (s.get('basis'),m.get('unit'))!=expected: err(p,'运算、序列类型或单位不匹配')
            if m.get('op')=='difference' and m.get('unit')!=s.get('unit'): err(p,'差值单位必须与序列相同')
            if m.get('op')=='excess_return':
                b=maps['series'].get(m.get('benchmark_id',''))
                if not b: err(p+'.benchmark_id','基准不存在')
                elif b.get('basis')!='price' or any(s.get(k)!=b.get(k) for k in ('market','provider','adjustment')): err(p,'基准类型、市场、来源或复权口径不一致')
    for a in d['summary']:
        if not isinstance(a,dict): err('summary','条目必须为对象'); continue
        textfields(a,('text',),'summary'); fs=refs(a,'fact_ids','facts','summary'); an=refs(a,'analysis_ids','analyses','summary')
        if not fs and not an: err('summary','摘要需要事实或判断依据')
    if len(d['summary'])>3: err('summary','摘要最多3条')
    for aid,a in maps['articles'].items():
        p='articles.'+aid; textfields(a,('title','text'),p)
        enum(a,'section',('news','ai','market','macro'),p); enum(a,'kind',('fact','analysis','watch'),p)
        fs=refs(a,'fact_ids','facts',p); ans=refs(a,'analysis_ids','analyses',p)
        if not fs and not ans: err(p,'需事实或分析引用')
        if not isinstance(a.get('priority'),int) or not 1<=a['priority']<=7: err(p+'.priority','1–7')
    for aid,a in maps['analyses'].items():
        p='analyses.'+aid; textfields(a,ANALYSIS_TEXT,p); fs=refs(a,'fact_ids','facts',p,1)
        enum(a,'status',('supported','watch'),p)
        if a.get('status')=='supported' and fs and not any(maps['facts'][x].get('status') in ('confirmed','reported') for x in fs): err(p,'判断缺少已核实事实')
        if not isinstance(a.get('gaps'),list): err(p+'.gaps','必须为数组')
        if not isinstance(a.get('mechanism'),list) or not a['mechanism']: err(p+'.mechanism','至少一个传导环节')
        else:
            for i,e in enumerate(a['mechanism']):
                q=f'{p}.mechanism[{i}]'
                if not required(e,('from','to','basis','fact_ids','assumption'),q): continue
                textfields(e,('from','to'),q); enum(e,'basis',('fact','assumption'),q)
                refs(e,'fact_ids','facts',q,1 if e['basis']=='fact' else 0)
                if e['basis']=='assumption': textfields(e,('assumption',),q)
        if not isinstance(a.get('leaders'),list): err(p+'.leaders','必须为数组')
        else:
            for i,l in enumerate(a['leaders']):
                q=f'{p}.leaders[{i}]'
                if not isinstance(l,dict): err(q,'必须为对象'); continue
                textfields(l,('name','ticker','market','exposure','realization','performance','catalyst','risk'),q)
                enum(l,'role',('industry','trading','both','representative','watch'),q); refs(l,'fact_ids','facts',q,1)
                proof=l.get('role_evidence',{})
                if not isinstance(proof,dict): err(q+'.role_evidence','必须为对象'); continue
                for role in ('industry','trading'):
                    if l.get('role') in (role,'both'): refs(proof,role,'facts',q+'.role_evidence',1)
                if l.get('series_id') and l['series_id'] not in maps['series']: err(q+'.series_id','序列不存在')
    for oid,o in maps['observations'].items():
        p='observations.'+oid; textfields(o,('title','expectation','divergence','mechanism','materiality','opposition','test'),p)
        enum(o,'kind',('contrarian','watch'),p); refs(o,'fact_ids','facts',p,1)
        cs=refs(o,'consensus_fact_ids','facts',p,1 if o.get('kind')=='contrarian' else 0)
        if any(maps['facts'][x].get('status') in ('conflicted','unverified') for x in cs): err(p,'预期基准尚未核实')
    for aid,a in maps['actions'].items():
        p='actions.'+aid; textfields(a,('when','target','baseline','support','invalidation','implication','rule_basis'),p)
        if a.get('analysis_id') not in maps['analyses']: err(p+'.analysis_id','行动必须关联已有判断')
        refs(a,'fact_ids','facts',p)
        if not isinstance(a.get('priority'),int) or not 1<=a['priority']<=3: err(p+'.priority','1–3')
        try:
            if iso(a.get('expires_at'))<=cutoff: err(p+'.expires_at','观察条件已过期')
        except (TypeError,ValueError): err(p+'.expires_at','无效带时区时间')
    for eid,e in maps['events'].items():
        p='events.'+eid; textfields(e,('label','detail'),p); refs(e,'fact_ids','facts',p,1); enum(e,'status',('confirmed','expected'),p)
        try: iso(e.get('at'),date_only=True,tz=cutoff.tzinfo)
        except (ValueError,TypeError): err(p+'.at','无效日期或带时区时间')
    for i,c in enumerate(d['coverage']):
        p=f'coverage[{i}]'
        if not isinstance(c,dict): err(p,'必须为对象'); continue
        textfields(c,('name','note'),p); url(c.get('url'),p+'.url')
        enum(c,'status',('checked_new','checked_none','failed','not_checked'),p); refs(c,'source_ids','sources',p)
        if c.get('status')!='not_checked':
            try: iso(c.get('checked_at'))
            except (TypeError,ValueError): err(p+'.checked_at','无效实际检查时刻')
    if meta['coverage_status']=='complete' and (d['gaps'] or any(c.get('status') in ('failed','not_checked') for c in d['coverage'] if isinstance(c,dict))): err('meta.coverage_status','存在覆盖缺口，须标为limited')
    for i,pv in enumerate(d.get('prior_reviews',[])):
        p=f'prior_reviews[{i}]'
        if not isinstance(pv,dict): err(p,'必须为对象'); continue
        textfields(pv,('thesis_id','previous_report','original_conclusion','original_support','original_invalidation','explanation'),p)
        enum(pv,'status',('supported','weakened','refuted','unknown'),p); refs(pv,'fact_ids','facts',p)
    r=d.get('review')
    if required(r,('status','reviewer','method','checked_fact_ids','checked_analysis_ids','issues'),'review'):
        enum(r,'status',('draft','reviewed'),'review'); textfields(r,('reviewer','method'),'review')
        cf=refs(r,'checked_fact_ids','facts','review'); ca=refs(r,'checked_analysis_ids','analyses','review')
        if not isinstance(r['issues'],list): err('review.issues','必须为数组')
        else:
            for issue in r['issues']:
                if not isinstance(issue,dict): err('review.issues','条目必须为对象'); continue
                enum(issue,'severity',('blocking','warning'),'review.issues'); textfields(issue,('message',),'review.issues')
                if not isinstance(issue.get('resolved'),bool): err('review.issues','resolved必须为bool')
                if issue.get('resolved'): textfields(issue,('resolution',),'review.issues')
                if issue.get('severity')=='blocking' and not issue.get('resolved') and r['status']=='reviewed': err('review','存在未解决的blocking问题')
                if issue.get('severity')=='warning' and not issue.get('resolved'): warn('review.issues',issue.get('message','研究问题未解决'))
        if r['status']=='reviewed':
            if set(maps['analyses'])-set(ca): err('review','分析尚未全部复核')
            if {k for k,f in maps['facts'].items() if f.get('core')}-set(cf): err('review','核心事实尚未全部复核')
        else: warn('review','草稿：研究审阅未完成')
    # Numeric computation only after structural safety checks.
    if not errors:
        for mid,m in maps['metrics'].items():
            try:
                values[mid]=compute_metric(m,maps['series'])
                if values[mid] is None: warn('metrics.'+mid,'数据不足/含缺失/分母无效，保持空值')
                elif not num(values[mid]): err('metrics.'+mid,'计算结果非有限数')
            except (ValueError,KeyError,TypeError,ZeroDivisionError) as exc: err('metrics.'+mid,str(exc))
    def walk(v,path):
        if isinstance(v,str):
            for token in TOKEN.findall(v):
                if token not in maps['metrics']: err(path,'数值引用不存在: '+token)
        elif isinstance(v,list):
            for i,x in enumerate(v): walk(x,f'{path}[{i}]')
        elif isinstance(v,dict):
            for k,x in v.items(): walk(x,path+'.'+k)
    walk(d,'root')
    if not errors:
        for cid,c in maps['charts'].items():
            p='charts.'+cid; textfields(c,('title','takeaway','note'),p)
            enum(c,'type',('breadth','bars','heatmap','scatter','line','mechanism','timeline'),p)
            try: validate_chart(c,d,maps,values)
            except (ValueError,KeyError,TypeError,IndexError) as exc: err(p,str(exc))
    return {'errors':errors,'warnings':warnings,'values':values,'check_type':'结构/引用/时间/计算校验；不证明来源真实性或经济因果'}

def validate_chart(c,d,maps,values):
    mm=maps['metrics']; ss=maps['series']; typ=c['type']
    def ms(ids):
        if not isinstance(ids,list) or not ids: raise ValueError('图表引用不能为空')
        return [mm[x] for x in ids]
    def same_date(items):
        if len({metric_date(d,m) for m in items})>1: raise ValueError('图表数据日期不一致')
    def comparable(items):
        datasets=[ss[m['series_id']] for m in items if m['op']!='observed']
        for k in ('market','provider','adjustment','classification'):
            if len({s[k] for s in datasets})>1: raise ValueError('图表比较口径不一致: '+k)
    if typ in ('breadth','bars'):
        items=ms([i['metric_id'] for i in c['items']]); same_date(items)
        if len({m['unit'] for m in items})!=1: raise ValueError('截面图单位不同')
        if typ=='breadth':
            if not c.get('scope'): raise ValueError('广度图需样本范围')
            if len(c['items'])!=3 or {i.get('category') for i in c['items']}!={'up','flat','down'}: raise ValueError('广度需up/flat/down三个类别；未知类别数值用null，不能省略')
            if any(m['unit']!='家' or (values[m['id']] is not None and (values[m['id']]<0 or values[m['id']]!=int(values[m['id']]))) for m in items): raise ValueError('广度必须是非负整数家数')
    elif typ=='heatmap':
        if not c.get('classification') or not c.get('scope') or not c.get('columns'): raise ValueError('热力图需分类、范围及列名')
        rows=c['rows']
        if not rows: raise ValueError('热力图无行')
        for row in rows:
            if len(row['metric_ids'])!=len(c['columns']): raise ValueError('热力图列数不匹配')
            ms(row['metric_ids'])
        for col in zip(*(r['metric_ids'] for r in rows)):
            items=ms(list(col)); same_date(items); comparable(items)
            if any(m['op'] not in ('return','excess_return') for m in items): raise ValueError('强弱热力图须使用原始序列计算的收益或超额收益')
            if any(ss[m['series_id']]['classification']!=c['classification'] for m in items): raise ValueError('图名分类与原始序列分类不一致')
            if len({(m['op'],m.get('n'),m['unit']) for m in items})!=1: raise ValueError('热力图同列公式或窗口不一致')
    elif typ=='scatter':
        pts=c['points']
        if not pts: raise ValueError('散点图无点')
        xs=ms([p['x_metric'] for p in pts]); ys=ms([p['y_metric'] for p in pts]); same_date(xs+ys)
        if any(m['op']!='excess_return' for m in xs) or any(m['op']!='volume_ratio' for m in ys): raise ValueError('散点图只允许超额收益与量能比')
        comparable(xs); comparable(ys)
        if len({(m['n'],m['benchmark_id']) for m in xs})!=1: raise ValueError('超额收益窗口或基准不同')
        for p,x,y in zip(pts,xs,ys):
            if ss[x['series_id']]['label']!=ss[y['series_id']]['label']: raise ValueError('价格与成交额不是同一对象')
    elif typ=='line':
        series=[ss[i] for i in c['series_ids']]
        if not series or len(series)>4: raise ValueError('折线图使用1–4条序列')
        if not isinstance(c.get('normalize'),bool): raise ValueError('normalize必须为bool')
        if c['normalize'] and any(s['basis']!='price' for s in series): raise ValueError('归一化仅用于价格')
        if not c['normalize'] and len({s['unit'] for s in series})!=1: raise ValueError('不同单位不能共用纵轴')
    elif typ=='mechanism':
        if c['analysis_id'] not in maps['analyses']: raise ValueError('机制图分析不存在')
    elif typ=='timeline':
        if not c.get('event_ids') or any(x not in maps['events'] for x in c['event_ids']): raise ValueError('时间轴事件不存在')

def load(path):
    def bad(x): raise ValueError('非法JSON数字: '+x)
    return json.loads(Path(path).read_text(encoding='utf-8-sig'),parse_constant=bad)

def build(d,result,root):
    from render import render_report
    html=render_report(d,result)
    root=Path(root).resolve(); root.mkdir(parents=True,exist_ok=True)
    rid=d['meta'].get('run_id') or datetime.now(timezone.utc).strftime('%H%M%S')+'-'+uuid4().hex[:8]
    out=root/(d['meta']['date']+'-'+rid)
    out.mkdir(exist_ok=False)
    def write(name,value): (out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    write('briefing.json',d)
    theses={'cutoff':d['meta']['cutoff'],'report':str(out/'briefing.html'),'items':[{'id':a['id'],'original_conclusion':a['conclusion'],'original_support':a['support'],'original_invalidation':a['invalidation'],'horizon':a['horizon'],'fact_ids':a['fact_ids'],'status':'unreviewed','action_conditions':[x for x in d['actions'] if x['analysis_id']==a['id']]} for a in d['analyses']]}
    write('theses.json',theses)
    (out/'briefing.html').write_text(html,encoding='utf-8')
    write('checks.json',{**result,'built_at':datetime.now(timezone.utc).isoformat(),'review_status':d['review']['status'],'research_issues':d['review']['issues'],'output':str(out/'briefing.html')})
    return out

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    for name in ('validate','build'):
        p=sub.add_parser(name); p.add_argument('--input',required=True)
        if name=='build': p.add_argument('--output-dir',required=True)
    p=sub.add_parser('history'); p.add_argument('--output-dir',required=True); p.add_argument('--limit',type=int,default=3)
    args=parser.parse_args(argv)
    try:
        if args.command=='history':
            root=Path(args.output_dir)
            entries=[]
            for path in root.glob('*/checks.json'):
                check=load(path)
                if not check.get('errors') and (path.parent/'theses.json').exists(): entries.append((check['built_at'],str(path.parent/'theses.json')))
            print(json.dumps(sorted(entries,reverse=True)[:max(0,args.limit)],ensure_ascii=False,indent=2)); return 0
        d=load(args.input); result=validate(d)
        if result['errors']:
            print(json.dumps(result,ensure_ascii=False,indent=2)); return 2
        if args.command=='build':
            out=build(d,result,args.output_dir)
            print(json.dumps({'output':str(out/'briefing.html'),'warnings':result['warnings'],'review':d['review']['status']},ensure_ascii=False,indent=2))
        else: print(json.dumps(result,ensure_ascii=False,indent=2))
        return 0
    except (ValueError,TypeError,KeyError,OSError) as exc:
        print(json.dumps({'error':str(exc)},ensure_ascii=False)); return 2

if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    raise SystemExit(main())
