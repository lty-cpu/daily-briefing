"""Escaped, deterministic HTML/SVG renderer. Never fetches external resources."""
from __future__ import annotations
from datetime import date, datetime
from html import escape
from pathlib import Path
import math
import re
from briefing import TOKEN, metric_date, source_ids

PALETTE=['#245b83','#26817c','#b7793b','#805b91']
ROLE={'industry':'产业龙头','trading':'交易龙头','both':'产业与交易龙头','representative':'代表性公司','watch':'观察对象'}
STATUS={'confirmed':'已确认','reported':'媒体报道','conflicted':'来源冲突','unverified':'待核实','supported':'有据判断','watch':'待验证','contrarian':'非共识观察','expected':'预计'}
def esc(v): return escape(str(v),quote=True)
def fmt(value,unit='',signed=False):
    if value is None: return '—'
    digits=0 if unit in ('家','台','艘') else 2
    s=f'{value:+,.{digits}f}' if signed else f'{value:,.{digits}f}'
    return s+unit
def short(value):
    if abs(value)>=10000: return f'{value/10000:.1f}万'
    if abs(value)>=1000: return f'{value/1000:.1f}k'
    return f'{value:.2f}'.rstrip('0').rstrip('.')
def signclass(v): return 'neutral' if v is None or v==0 else ('pos' if v>0 else 'neg')
def table(headers,rows,classes=''):
    return '<div class="table-wrap"><table class="'+classes+'"><thead><tr>'+''.join('<th>'+esc(h)+'</th>' for h in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+c+'</td>' for c in r)+'</tr>' for r in rows)+'</tbody></table></div>'

class Renderer:
    def __init__(self,d,checks):
        self.d=d; self.values=checks['values']; self.checks=checks
        self.facts={x['id']:x for x in d['facts']}; self.sources={x['id']:x for x in d['sources']}; self.metrics={x['id']:x for x in d['metrics']}; self.series={x['id']:x for x in d['series']}; self.analyses={x['id']:x for x in d['analyses']}; self.events={x['id']:x for x in d.get('events',[])}
        self.fnums={k:i+1 for i,k in enumerate(self.facts)}
    def text(self,value):
        def replace(m):
            metric=self.metrics[m.group(1)]; v=self.values[m.group(1)]
            signed=metric.get('signed',metric['op'] in ('return','excess_return','bp_change','difference'))
            return '<span class="metric '+(signclass(v) if signed else 'neutral')+'">'+esc(fmt(v,metric['unit'],signed))+'</span>'
        return TOKEN.sub(replace,esc(value)).replace('\n','<br>')
    def refs(self,ids):
        return '<span class="refs">'+''.join(f'<a href="#f-{esc(fid)}" aria-label="证据{self.fnums[fid]}">[{self.fnums[fid]}]</a>' for fid in dict.fromkeys(ids) if fid in self.facts)+'</span>'
    def source_links(self,ids):
        return ' · '.join('<a href="'+esc(self.sources[x]['url'])+'" target="_blank" rel="noopener noreferrer">'+esc(self.sources[x]['publisher'])+'</a>' for x in dict.fromkeys(ids) if x in self.sources)
    def metric(self,mid):
        m=self.metrics[mid]; v=self.values[mid]
        return fmt(v,m['unit'],m.get('signed',m['op'] in ('return','excess_return','bp_change','difference')))
    def chain(self,a):
        out='<div class="chain">'
        for e in a['mechanism']:
            assumption=e['basis']=='assumption'
            out+='<div class="chain-row '+('assumption' if assumption else '')+'">'+self.text(e['from'])+'<span class="arrow">→</span>'+self.text(e['to'])+self.refs(e['fact_ids'])
            out+='<small>'+('假设环节：'+self.text(e['assumption']) if assumption else '事实联系；因果含义需结合正文解释')+'</small></div>'
        return out+'</div>'
    def spark(self,sid):
        s=self.series[sid]; obs=s['observations'][-21:]
        vals=[p['value'] for p in obs if p['value'] is not None]
        if len(vals)<2: return ''
        lo,hi=min(vals),max(vals); span=hi-lo or max(abs(lo)*.01,1)
        paths=[]; path=''
        for i,p in enumerate(obs):
            if p['value'] is None:
                if path: paths.append(path); path=''
            else:
                x=4+i/max(1,len(obs)-1)*292; y=44-(p['value']-lo)/span*38
                path+=('M' if not path else 'L')+f'{x:.2f},{y:.2f} '
        if path: paths.append(path)
        return '<svg class="spark" viewBox="0 0 300 48" role="img" aria-label="'+esc(s['label']+'实际历史序列，缺失处断开')+'">'+''.join('<path d="'+p+'" fill="none" stroke="#26817c" stroke-width="2"/>' for p in paths)+'</svg>'
    def chart(self,c):
        typ=c['type']; body=''; data=[]; headers=[]; sids=[]
        if typ in ('breadth','bars'):
            items=[(i['label'],i['metric_id'],self.values[i['metric_id']]) for i in c['items']]
            headers=['对象','数值','所属日期']; data=[[esc(label),esc(self.metric(mid)),esc(metric_date(self.d,self.metrics[mid]))] for label,mid,v in items]
            for _,mid,_ in items: sids+=source_ids(self.d,self.metrics[mid])
            if typ=='breadth':
                total=sum(v for _,_,v in items if v is not None)
                if any(v is None for _,_,v in items) or total<=0: body='<p class="empty">数据不完整，保留原始表格，未绘制占比。</p>'
                else:
                    colors=[{'up':'#b73737','flat':'#94a3b2','down':'#18704b'}[i['category']] for i in c['items']]
                    body='<div class="breadth-track" role="img" aria-label="'+esc('；'.join(label+' '+str(v)+'家' for label,mid,v in items))+'">'
                    for j,(label,mid,v) in enumerate(items): body+=f'<span style="width:{v/total*100:.5f}%;--s:{colors[j%3]}" data-tip="{esc(label+" "+self.metric(mid)+" / "+fmt(v/total*100,"%"))}"></span>'
                    body+='</div><div class="legend">'+''.join(f'<span><i class="swatch" style="--s:{colors[j%3]}"></i>{esc(label)} <b>{esc(self.metric(mid))}</b></span>' for j,(label,mid,v) in enumerate(items))+'</div>'
            else:
                vals=[v for _,_,v in items if v is not None]; low=min(vals+[0]); high=max(vals+[0]); span=high-low or 1; zero=-low/span*100
                for label,mid,v in items:
                    color='#b73737' if v is not None and v>=0 else '#18704b'
                    fill='' if v is None else f'<span class="bar-fill" style="left:{min(zero,((v-low)/span*100)):.3f}%;width:{abs(v)/span*100:.3f}%;--s:{color}"></span>'
                    body+='<div class="bar-row"><span>'+esc(label)+'</span><div class="bar-track">'+f'<span class="bar-zero" style="left:{zero:.3f}%"></span>'+fill+'</div><span class="bar-value '+signclass(v)+'">'+esc(self.metric(mid))+'</span></div>'
        elif typ=='heatmap':
            headers=['对象']+c['columns']; data=[]
            body='<div class="table-wrap"><table class="heatmap"><thead><tr>'+''.join('<th>'+esc(x)+'</th>' for x in headers)+'</tr></thead><tbody>'
            for row in c['rows']:
                body+='<tr><th>'+esc(row['label'])+'</th>'; r=[esc(row['label'])]
                for mid in row['metric_ids']:
                    v=self.values[mid]; intensity=min(abs(v)/10,.8) if v is not None else 0
                    color=f'rgba(183,55,55,{.04+intensity*.22:.3f})' if v is not None and v>0 else (f'rgba(24,112,75,{.04+intensity*.22:.3f})' if v is not None and v<0 else '#f3f5f7')
                    value=self.metric(mid); body+='<td class="'+signclass(v)+'" style="background:'+color+'">'+esc(value)+'</td>'; r.append(esc(value)); sids+=source_ids(self.d,self.metrics[mid])
                body+='</tr>'; data.append(r)
            body+='</tbody></table></div>'
        elif typ=='line':
            sets=[self.series[x] for x in c['series_ids']]
            for s in sets: sids+=s['source_ids']
            body,data,headers=self.line(sets,c['normalize'])
        elif typ=='scatter':
            pts=c['points']; valid=[p for p in pts if self.values[p['x_metric']] is not None and self.values[p['y_metric']] is not None]
            headers=['对象','超额收益','量能比']; data=[[esc(p['label']),esc(self.metric(p['x_metric'])),esc(self.metric(p['y_metric']))] for p in pts]
            for p in pts:
                for k in ('x_metric','y_metric'): sids+=source_ids(self.d,self.metrics[p[k]])
            if valid:
                xs=[self.values[p['x_metric']] for p in valid]; ys=[self.values[p['y_metric']] for p in valid]
                xmin,xmax=min(xs+[0]),max(xs+[0]); ymin,ymax=min(ys+[1,0]),max(ys+[1]); xp=(xmax-xmin)*.15 or 1; yp=(ymax-ymin)*.15 or .2
                xmin-=xp;xmax+=xp;ymin=max(0,ymin-yp);ymax+=yp
                X=lambda x:80+(x-xmin)/(xmax-xmin)*510; Y=lambda y:220-(y-ymin)/(ymax-ymin)*180
                body='<svg viewBox="0 0 640 275" role="img" aria-label="相对强弱和量能，不能解释为资金净流入"><title>横轴超额收益（百分点），纵轴量能比（倍）</title>'
                for y in (ymin,(ymin+ymax)/2,ymax): body+=f'<line class="grid" x1="80" x2="590" y1="{Y(y):.2f}" y2="{Y(y):.2f}"/><text x="65" y="{Y(y)+5:.2f}" text-anchor="end">{short(y)}</text>'
                for x in (xmin,0,xmax): body+=f'<text x="{X(x):.2f}" y="252" text-anchor="middle">{short(x)}</text>'
                body+=f'<line class="refline" x1="{X(0):.2f}" x2="{X(0):.2f}" y1="40" y2="220"/><line class="refline" x1="80" x2="590" y1="{Y(1):.2f}" y2="{Y(1):.2f}"/>'
                for j,p in enumerate(valid):
                    x,y=X(self.values[p['x_metric']]),Y(self.values[p['y_metric']]); tip=p['label']+'：'+self.metric(p['x_metric'])+' / '+self.metric(p['y_metric'])
                    body+=f'<circle cx="{x:.2f}" cy="{y:.2f}" r="9" fill="{PALETTE[j%4]}" data-tip="{esc(tip)}"><title>{esc(tip)}</title></circle>'
                body+='</svg><div class="legend">横轴：同期超额收益（百分点） · 纵轴：量能比（倍）</div>'
                body+='<div class="legend">'+''.join('<span><i class="swatch" style="--s:'+PALETTE[j%4]+'"></i>'+esc(p['label'])+'</span>' for j,p in enumerate(valid))+'</div>'
            else: body='<p class="empty">缺少可比的价格与成交额窗口，未绘制散点。</p>'
        elif typ=='mechanism':
            a=self.analyses[c['analysis_id']]; body=self.chain(a)
            for fid in a['fact_ids']: sids+=self.facts[fid]['source_ids']
        elif typ=='timeline':
            body='<ol class="timeline">'
            for e in sorted((self.events[i] for i in c['event_ids']),key=lambda e:e['at']):
                body+='<li><time>'+esc(e['at'].replace('T',' '))+'</time><b>'+esc(e['label'])+'</b> <span class="status">'+STATUS[e['status']]+'</span><p>'+self.text(e['detail'])+self.refs(e['fact_ids'])+'</p></li>'
                for f in e['fact_ids']: sids+=self.facts[f]['source_ids']
            body+='</ol>'
        content='<figure class="chart '+('wide' if typ in ('mechanism','timeline') else '')+'" id="chart-'+esc(c['id'])+'"><h3>'+esc(c['title'])+'</h3><p class="takeaway">'+self.text(c['takeaway'])+'</p>'+body
        content+='<figcaption class="chart-note">'+self.text(c['note'])+'<br>'+self.source_links(sids)+'</figcaption>'
        if data: content+='<details><summary>查看数据与口径</summary>'+table(headers,data)+'</details>'
        return content+'</figure>'
    def line(self,sets,normalize):
        lookup=[{p['date']:p['value'] for p in s['observations']} for s in sets]
        all_dates=sorted(set().union(*(m.keys() for m in lookup)))
        if not all_dates: return '<p class="empty">无历史序列。</p>',[],[]
        common=sorted(set.intersection(*(set(k for k,v in m.items() if v is not None and v>0) for m in lookup))) if normalize else []
        if normalize and not common: return '<p class="empty">无共同有效基准日，未归一化。</p>',[],[]
        if normalize:
            first=common[0]; all_dates=[day for day in all_dates if day>=first]
            lookup=[{k:(v/m[first]*100 if v is not None and k>=first else None) for k,v in m.items()} for m in lookup]
        vals=[v for m in lookup for k,v in m.items() if k in all_dates and v is not None]
        rows=[[esc(day)]+[esc(fmt(m.get(day),'',False)) for m in lookup] for day in all_dates]
        headers=['日期']+[s['label']+(' (基期=100)' if normalize else ' ('+s['unit']+')') for s in sets]
        if len(all_dates)<2 or not vals: return '<p class="empty">至少需要两个观测日期，原始数据见下表。</p>',rows,headers
        lo,hi=min(vals),max(vals); pad=(hi-lo)*.15 or max(abs(lo)*.01,1);lo-=pad;hi+=pad
        ords=[date.fromisoformat(x).toordinal() for x in all_dates];start,end=ords[0],ords[-1]
        X=lambda day:80+(date.fromisoformat(day).toordinal()-start)/(end-start)*510
        Y=lambda value:215-(value-lo)/(hi-lo)*175
        svg='<svg viewBox="0 0 640 265" role="img" aria-label="'+esc('；'.join(headers[1:]))+'"><title>'+esc('真实观测序列，缺失点断开；'+('共同基期归一化' if normalize else '原始单位'))+'</title>'
        for y in (lo,(lo+hi)/2,hi): svg+=f'<line class="grid" x1="80" x2="590" y1="{Y(y):.2f}" y2="{Y(y):.2f}"/><text x="65" y="{Y(y)+5:.2f}" text-anchor="end">{short(y)}</text>'
        for i in sorted({0,len(all_dates)//2,len(all_dates)-1}):
            day=all_dates[i]; anchor='start' if i==0 else ('end' if i==len(all_dates)-1 else 'middle')
            svg+=f'<text x="{X(day):.2f}" y="247" text-anchor="{anchor}">{esc(day[5:])}</text>'
        for j,m in enumerate(lookup):
            path=''; segments=[]
            for day in all_dates:
                v=m.get(day)
                if v is None:
                    if path: segments.append(path);path=''
                else: path+=('M' if not path else 'L')+f'{X(day):.2f},{Y(v):.2f} '
            if path: segments.append(path)
            for path in segments: svg+='<path d="'+path+'" fill="none" stroke="'+PALETTE[j%4]+'" stroke-width="2.8"/>'
            for day in all_dates:
                if m.get(day) is not None:
                    tip=sets[j]['label']+' '+day+' '+fmt(m[day],'基期点' if normalize else sets[j]['unit'])
                    svg+=f'<circle cx="{X(day):.2f}" cy="{Y(m[day]):.2f}" r="5" fill="{PALETTE[j%4]}" data-tip="{esc(tip)}"><title>{esc(tip)}</title></circle>'
        svg+='</svg><div class="legend">'+''.join('<span><i class="swatch" style="--s:'+PALETTE[j%4]+'"></i>'+esc(s['label'])+'</span>' for j,s in enumerate(sets))+'</div>'
        svg+='<div class="chart-note">'+esc(('共同基期 '+all_dates[0]+' = 100' if normalize else '纵轴单位：'+sets[0]['unit'])+' · '+all_dates[0]+' 至 '+all_dates[-1])+'</div>'
        return svg,rows,headers
    def articles(self,section):
        out=''
        for a in sorted((a for a in self.d['articles'] if a['section']==section),key=lambda x:x['priority']):
            kind={'fact':'事实更新','analysis':'分析判断','watch':'待验证'}[a['kind']]
            out+='<article class="article" id="article-'+esc(a['id'])+'"><div class="article-meta">'+kind+' · 优先级 '+str(a['priority'])+'</div><h3>'+esc(a['title'])+'</h3><p>'+self.text(a['text'])+self.refs(a['fact_ids'])+'</p></article>'
        return out or '<p class="empty">本期未纳入经核验的新增内容；具体覆盖范围见附录。</p>'
    def analysis(self,a):
        out='<article class="analysis" id="a-'+esc(a['id'])+'"><span class="status">'+esc(a['sector'])+'</span><span class="status">'+esc(a['horizon'])+'</span><span class="status '+('watch' if a['status']=='watch' else '')+'">'+STATUS[a['status']]+'</span><h3>'+esc(a['title'])+'</h3><p class="lead">'+self.text(a['conclusion'])+self.refs(a['fact_ids'])+'</p><div class="fields">'
        for key,label in [('novelty','新增变化'),('earnings','利润传导'),('distribution','利益分配'),('pricing','市场反应'),('expectation','预期基准'),('alternative','竞争性解释'),('counterevidence','反证与脆弱环节')]:
            out+='<div class="field '+('full' if key=='counterevidence' else '')+'"><span class="label">'+label+'</span><p>'+self.text(a[key])+'</p></div>'
        out+='</div><div class="verification"><div><b>支持判断的条件</b>'+self.text(a['support'])+'</div><div><b>削弱或推翻的条件</b>'+self.text(a['invalidation'])+'</div></div>'
        if a['leaders']:
            out+='<h4>龙头与代表对象对照</h4><div class="leader-grid">'
            for l in a['leaders']:
                out+='<div class="leader"><h4>'+esc(l['name'])+'</h4><span class="ticker">'+esc(l['ticker']+' · '+l['market'])+'</span> <span class="status">'+ROLE[l['role']]+'</span>'+self.refs(l['fact_ids'])
                if l.get('series_id'): out+=self.spark(l['series_id'])
                out+='<dl>'
                for k,label in [('exposure','业务敞口'),('realization','兑现阶段'),('performance','市场表现'),('catalyst','下一催化'),('risk','主要风险')]: out+='<dt>'+label+'</dt><dd>'+self.text(l[k])+'</dd>'
                out+='</dl></div>'
            out+='</div>'
        out+='<details><summary>展开传导环节与研究缺口</summary>'+self.chain(a)
        out+=('<ul>'+''.join('<li>'+self.text(x)+'</li>' for x in a['gaps'])+'</ul>' if a['gaps'] else '<p>本条未记录额外资料缺口；仍需跟踪上述验证条件。</p>')+'</details></article>'
        return out
    def observation(self,o):
        out='<article class="obs"><span class="status '+('watch' if o['kind']=='watch' else '')+'">'+STATUS[o['kind']]+'</span><h3>'+esc(o['title'])+'</h3><div class="pair"><div><b>已有预期／讨论基准</b>'+self.text(o['expectation'])+self.refs(o['consensus_fact_ids'])+'</div><div><b>偏离证据</b>'+self.text(o['divergence'])+self.refs(o['fact_ids'])+'</div></div>'
        for k,label in [('mechanism','解释机制'),('materiality','为什么重要'),('opposition','最强反方'),('test','如何区分')]: out+='<p><b>'+label+'：</b>'+self.text(o[k])+'</p>'
        return out+'</article>'
    def action(self,a):
        out='<article class="action"><div class="priority">P'+str(a['priority'])+'</div><div><div class="action-when">'+esc(a['when'])+'</div><h3>'+self.text(a['target'])+'</h3><div class="action-grid">'
        for k,label in [('baseline','当前基准'),('support','支持条件'),('invalidation','否定条件'),('rule_basis','条件依据')]: out+='<div><b>'+label+'</b>'+self.text(a[k])+'</div>'
        out+='</div><p class="implication">'+self.text(a['implication'])+'</p><div class="meta"><span>有效至 '+esc(a['expires_at'].replace('T',' '))+'</span><a href="#a-'+esc(a['analysis_id'])+'">关联研究</a>'+self.refs(a['fact_ids'])+'</div></div></article>'
        return out
    def appendix(self):
        d=self.d; out='<details open><summary>覆盖范围与数据缺口</summary>'
        out+='<ul>'+''.join('<li>'+self.text(g)+'</li>' for g in d['gaps'])+'</ul>' if d['gaps'] else '<p>本期没有记录全局数据缺口。</p>'
        labels={'checked_new':'已查·有新增','checked_none':'已查·未发现新增','failed':'访问失败','not_checked':'未检查'}
        out+=table(['来源范围','实际状态','说明'],[[esc(c['name']),labels[c['status']],self.text(c['note'])] for c in d['coverage']])+'</details>'
        out+='<details id="evidence"><summary>事实与引用（'+str(len(d['facts']))+'项）</summary><ol class="evidence">'
        for f in d['facts']:
            out+='<li id="f-'+esc(f['id'])+'"><span class="status">'+STATUS[f['status']]+'</span> '+self.text(f['statement'])+'<small>观测期：'+esc(f['as_of'])+' · '+self.text(f['locator'])+'</small><small>'+self.source_links(f['source_ids'])+'</small></li>'
        out+='</ol></details><details><summary>来源目录（'+str(len(d['sources']))+'项）</summary><ol class="source-list">'
        for s in d['sources']:
            out+='<li><a href="'+esc(s['url'])+'" target="_blank" rel="noopener noreferrer">'+esc(s['title'])+'</a><br>'+esc(s['publisher']+' · 发布 '+s['published_at']+' · 读取 '+s['accessed_at'])+'<br>'+esc('正文状态 '+s['read_status']+' · 同源组 '+s['origin_group'])+'</li>'
        out+='</ol></details><details><summary>上期判断复核</summary>'
        if d.get('prior_reviews'):
            for p in d['prior_reviews']: out+='<p><b>'+esc(p['original_conclusion'])+'</b><br>'+esc({'supported':'得到支持','weakened':'被削弱','refuted':'被推翻','unknown':'尚无法判断'}[p['status']])+'：'+self.text(p['explanation'])+self.refs(p['fact_ids'])+'</p>'
        else: out+='<p>本期没有可读取的上期判断记录，不作历史一致性声明。</p>'
        out+='</details><details><summary>审阅记录与计算检查</summary><p>'+esc(d['review']['reviewer'])+' · '+self.text(d['review']['method'])+'</p><p>结构与计算校验不证明来源真实性或经济因果。</p>'
        for issue in d['review']['issues']: out+='<p>'+('已解决：' if issue['resolved'] else '待处理：')+self.text(issue['message'])+((' · '+self.text(issue['resolution'])) if issue.get('resolved') else '')+'</p>'
        if self.checks['warnings']: out+='<ul>'+''.join('<li>'+esc(w['path']+'：'+w['message'])+'</li>' for w in self.checks['warnings'])+'</ul>'
        return out+'</details>'

def render_report(d,checks):
    r=Renderer(d,checks); meta=d['meta']
    titles=[('overview','01','今日总览'),('news','02','昨日 / 夜间重要消息'),('ai','03','AI / ChatGPT / Codex'),('market','04','A股整体表现'),('sectors','05','板块深度分析'),('macro','06','美股与宏观'),('observations','07','非共识与待验证观察'),('actions','08','今日行动提示'),('sources','09','来源与复核')]
    # Explicit title overrides support other topics while keeping content slots stable.
    overrides=meta.get('section_titles',{})
    titles=[(i,n,overrides.get(i,t)) for i,n,t in titles]
    nav='<nav aria-label="报告目录">'+''.join('<a href="#'+i+'">'+n+' '+esc(t)+'</a>' for i,n,t in titles)+'</nav>'
    tools='<div class="tools"><button type="button" data-expand aria-pressed="false">展开证据与数据</button><button type="button" data-print>打印 / 存为PDF</button></div>'
    content='<header><div class="eyebrow">DAILY BRIEFING · '+esc(meta['date'])+'</div><h1>'+esc(meta['title'])+'</h1><div class="meta"><span>截至 '+esc(meta['cutoff'].replace('T',' '))+'</span><span>'+esc(meta['timezone'])+'</span><span>'+esc(' / '.join(meta['scope']))+'</span></div>'
    if meta.get('market_dates'): content+='<div class="meta">'+''.join('<span>'+esc(k+'行情：'+v)+'</span>' for k,v in meta['market_dates'].items())+'</div>'
    if meta['mode']!='live': content+='<span class="status">'+('教学测试数据' if meta['mode']=='teaching' else '历史时点回放')+'</span>'
    if d['review']['status']=='draft': content+='<div class="notice">草稿 · 尚未完成研究审阅，不应作为已核验结论使用。</div>'
    if meta['coverage_status']=='limited': content+='<div class="notice">本期为有限覆盖：'+r.text(d['gaps'][0] if d['gaps'] else '部分来源尚未核验，详见来源与复核。')+'</div>'
    content+='<details class="mobile-nav"><summary>报告目录与工具</summary>'+nav+tools+'</details></header>'
    def section(key,body):
        _,n,t=next(x for x in titles if x[0]==key)
        return '<section id="'+key+'"><h2><span class="sec-num">'+n+'</span>'+esc(t)+'</h2>'+body+'</section>'
    summary='<div class="summary-grid">'
    for i,s in enumerate(d['summary']): summary+='<div class="summary-item"><div class="number">'+f'{i+1:02}'+'</div><p>'+r.text(s['text'])+r.refs(s['fact_ids'])+'</p></div>'
    summary+='</div>'
    feature=meta.get('featured_metrics',[])[:4]
    if feature:
        summary+='<div class="stats">'
        for mid in feature:
            m=r.metrics[mid]; summary+='<div class="stat"><div class="label">'+esc(m['label'])+'</div><div class="value">'+esc(r.metric(mid))+'</div><small>'+esc(metric_date(d,m))+'</small></div>'
        summary+='</div>'
    if d['charts']: summary+='<div class="chart-grid" style="margin-top:26px">'+''.join(r.chart(c) for c in d['charts'])+'</div>'
    content+=section('overview',summary)+section('news',r.articles('news'))+section('ai',r.articles('ai'))+section('market',r.articles('market'))
    content+=section('sectors',''.join(r.analysis(a) for a in d['analyses']) or '<p class="empty">本期没有达到深度分析证据要求的板块。</p>')
    content+=section('macro',r.articles('macro'))
    content+=section('observations',''.join(r.observation(o) for o in d['observations']) or '<p class="empty">本期暂无达到证据要求的新增观察。</p>')
    content+=section('actions',''.join(r.action(a) for a in sorted(d['actions'],key=lambda a:a['priority'])) or '<p class="empty">本期没有新增可复核行动条件。</p>')
    content+=section('sources',r.appendix())
    content+='<footer class="footer">'+esc(meta['title'])+' · 截至 '+esc(meta['cutoff'])+' 的研究快照。图表来自本报告资料；页面不自动更新行情。<br>作者/运行环境：'+esc(meta['author'])+' · 数据与审阅记录随报告保存。</footer>'
    assets=Path(__file__).resolve().parent.parent/'assets'
    css=(assets/'report.css').read_text(encoding='utf-8'); js=(assets/'report.js').read_text(encoding='utf-8')
    return '<!doctype html>\n<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light"><title>'+esc(meta['title'])+'</title><style>'+css+'</style></head><body><div class="shell"><aside class="side"><div class="brand">DAILY BRIEFING</div>'+nav+'<small>证据 · 机制 · 验证<br>'+esc(meta['date'])+'</small>'+tools+'</aside><main>'+content+'</main></div><div class="chart-tip" role="tooltip" hidden></div><script>'+js+'</script></body></html>\n'
