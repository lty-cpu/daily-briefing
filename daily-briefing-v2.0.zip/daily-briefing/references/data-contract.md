# 数据协议 v2 与增量命令

唯一结构定义由程序维护。首次需要某集合时用 `run.py describe --work-dir <run> --group <集合>`查看该集合的必需/可选字段；不用阅读源码，也不加载整个schema。UTF-8 JSON拒绝重复键、NaN/Infinity、bool冒充数字、无效枚举和悬空引用。ID为字母开头的ASCII字母/数字/下划线/连字符，最多96字符。

## 输入与时间

start生成顶层集合和meta。原请求保存在request.json，并由run-state核对哈希。`meta`中的cutoff/timezone/date/scope/profile/mode/evidence_mode不可静默改变。`window_start`为实际研究回溯起点，扩大时填写window_adjustment_reason，request中的原窗口保留。

- `sources`：真实来源ID、标题、发布机构、HTTP/S直达URL、published_at、retrieved_at、kind、read_status、origin_group和vintage（版本id及available_at）。只有发布日期而不知发布者偏移时按UTC−12日终保守核对。后来修订版本不能冒充当时可得原版。
- `evidence`：相关原文quote、locator、必要context、source_id、实际retrieved_at及read_method（original/cached/search_summary）。片段支持关系仍需人/模型复核。search_summary不能使重要事实获得已核验资格；读到相关完整段落不必标整本文档full。
- `facts`：statement、source_ids、evidence_ids、status、core、kind(actual/forecast/event)、可解析as_of及available_at。核心实绩不能在截止后；预先公开的未来事件/预测可合法存在，必须正确kind。可选event_at/effective_at/observation_period分别记录发生、生效和观测期间。
- 昨天的观测可能今天才公开。available_at未知用null，不能假定与观测日期相同；未知点不进入收益计算或趋势绘图。retrieved_at可晚于截止，实际使用的vintage必须早于截止。

## 序列与会话

`series`除名称、单位和来源，记录entity_id、market、provider、classification、adjustment、scope、frequency、calendar_id、completeness、roll_policy、vintage、evidence_ids。观测点为date/value/available_at/status(traded/missing/suspended)，缺失或停牌为null。期货连续序列必须说明换月规则；复权不可默默拼接。

`calendars`记录market、IANA timezone、来源/片段、version、valid_from/valid_to、complete及明确的date/close_at会话清单。周一至周五不等于真实日历。synthetic只允许teaching。

交易日指标要求daily、完整且有来源的会话清单、连续目标会话及非缺失点。周度/不规则记录只能显式window_basis=observations，显示“观测期”而非交易日；缺记录或停牌输出null。不同市场日期错位先对齐目标会话。发布规则可用有证据的session_close和delay_seconds推导逐点可得时刻，不能用无依据规则补时间。

同源是默认简化条件。合法跨源比较提供mappings，列series_ids/entity_ids/source_ids、口径证据和已对齐的provider/market/adjustment/classification/scope；显示名相同不是实体一致。散点同点的实体、实际窗口、范围必须对齐。

## 确定性指标

metrics必有id/label/op/unit/dimensions。dimensions明确entity_id、currency（无币种用none）、scale、period、segment、measure；乘积另用dimensions幂映射表示单位维度。不要混同总收入与分部、指引与实绩。

| op | 输入和约束 |
|---|---|
| observed | value、as_of、available_at、kind、source_ids、evidence_ids；缺失为null |
| return/excess_return | series_id、正整数n、window_basis；价格收益%；超额另有benchmark_id、单位百分点 |
| volume_ratio | 成交序列、n、window_basis；最后值/之前n期中位数，单位倍 |
| bp_change/difference | series_id、n、window_basis；前者收益率百分点差×100，后者保持原单位 |
| pair_difference | from_metric/to_metric、comparison_basis及comparison_evidence_ids；后值减前值，百分率差用bp或百分点 |
| ratio/growth | inputs两个指标及口径依据；ratio为同单位比值（%或倍），growth为后值/前值−1（%）；不能隐式换汇或混期间/分部 |
| sum/product | inputs与口径依据；同期间，求和同单位，乘积的单位幂必须相符；数量级由程序换算 |
| sensitivity | 一个inputs、显式相对shock和口径依据；基值×(1+shock)，标为情景，不是概率或已发生事实 |

派生依赖允许嵌套但不能成环，不执行任意eval。零/非法分母保持null并保留质量说明。正文使用`{metric:ID}`，由程序统一渲染，引用自带单位与符号。不可手填重复计算结果或写“下降−100bp”。

## 主张、研究和交付

`claims`记录text、kind(fact/inference/scenario)、status(supported/hypothesis/unknown)、fact_ids/metric_ids、assumptions和limitations。limitations项有message/impact/critical，可关联claim_ids/attempt_ids。重要主张引用闭包由摘要、行动及分析字段构建，不受手填core=false影响。

analyses沿用研究卡文本、机制与代表对象，增加稳定theme_id/thesis_id/entity_ids、version、priority及理由、materiality、assumptions、review_at/expires_at、field_claims和三个horizons。每个期限有conclusion/direction/claim_ids、earnings_channel/valuation_channel、base_case/counter_case、next_observation/review_at/confidence。字段精确定义用describe按需读取。

summary/articles分别引用fact_ids、analysis_ids、claim_ids；只有analysis_ids也有可跳转引用。actions关联analysis_id和claim_ids，填写observe_at/when、expires_at、对象、基准、支持/失效、implication与rule_basis。近期条件需当日至3个有来源交易会话内，24小时内的条件可直接确认时距；更长时间提供calendar_id。observations无预期依据用watch，contrarian需consensus_fact_ids。

review.status=not_reviewed/self_review/independent_review，保存reviewer/method、实际checked_fact_ids/checked_analysis_ids/checked_claim_ids、evidence_ids、issues。独立审核还需不同的independent_actor_id；程序不自动证明其独立或语义正确。

coverage逐项关联start生成的obligation_ids，记录status、method、source_ids、实际checked_at及window_start/window_end。聚合入口用aggregate并给mapping_evidence_ids，搜索无结果不能checked_none，cache_reused不算今天重扫官方入口。没有列出义务不会缩小分母。

`meta.requested_grade`是请求等级，不是认证。checks.delivery推导full/limited/observation/draft及各主题降级理由。缺关键资料可合法构建有限报告；一来源一文章、无分析行动不能full。原始gaps和局部关键limitations都保留。built仅表示产物生成。

图表支持breadth/bars/heatmap/scatter/line/mechanism/timeline。每图id/type/title/takeaway/note/placement必需；各标签和引用由类型校验。placement为overview/theme/news/ai/market/macro，theme需analysis_id；首屏最多两图，其余放对应栏目。describe charts查看具体字段。

## 日常数据命令

```text
python <skill>/scripts/run.py merge --work-dir <run> --input <小片段.json>
python <skill>/scripts/run.py import-series --work-dir <run> --input <CSV或观测数组JSON> --metadata <单条series元数据.json>
python <skill>/scripts/run.py compute --work-dir <run> --ids M1 M2
python <skill>/scripts/run.py inspect --work-dir <run> --group evidence --id E1
```

merge按ID替换/增加集合条目，缺ID则按内容分配稳定ID；summary等无ID集合整段替换。保存前版本，不允许merge改锁定请求。序列CSV列为date,value,available_at，可带status/session_id；空数值是null，空时间是未知。原始与规范化数据保存为哈希工件，模型不需手抄所有点。compute输出选定计算值和质量摘要，完整checks落盘。

`task --input <JSON>`记录id/question/priority/target_evidence/current_conclusion/query_or_url/result/next/stop_reason/status。`record --input <JSON>`记录kind(query/open/cache/import/compute/render/stage/recovery/usage)、stage和实际wall_ms；真实宿主usage须measurement=host_reported，不知为null。`cache-put/cache-get`在显式state-root按ID和版本保存/读取四层缓存，不扫描其他目录。

长规范 `guide --name <live/research/finance/analysis/contract/review> --page-chars 3500` 返回哈希、游标、内容及末尾ack_token。完整读到token后下一调用加`--ack <token>`确认；最后一页也要确认。截断用`--replay`，不推进确认游标。真实压缩后传新的`--context-epoch`和`--recovery-reason`，恢复次数受运行预算约束。

## 历史、兼容与视觉

state-root保存index与按thesis_id/version追加的冻结快照；包括当时来源版本、证据片段、已计算值/单位/期间、原结论和原条件。`history`只按索引读有界摘要，嵌套attempt产物也可找到。新版本需update(previous_version/status/new_evidence_ids/reason)。maintained不得更改结论、条件或期限，修订用新证据明确说明。冷启动version=1；不读未知目录。

旧schema1显式迁移：`python <skill>/scripts/briefing.py migrate --input <旧文件> --output <新文件>`。迁移保留原内容，不自动填造时间、日历、原文或核验结果；新文件是未审核草稿，按提示补齐。旧运行状态保留，重新start锁定新契约；多次start同目录只恢复，不能重置预算。

构建后视觉结果JSON为`{"status":"passed|failed|not_performed","method":"实际方法","notes":"实际检查及限制"}`，由`run.py visual --input <文件>`生成展示修订，保留原HTML，同步run-info与交付页。不把print媒体模拟写成PDF分页通过。
