"""External append-only research history and content-addressed artifacts."""
from __future__ import annotations
import copy
from datetime import datetime, timezone
from pathlib import Path
from contextlib import contextmanager
import hashlib
import os
from common import TOKEN, canonical, fingerprint, load, save, stamp


@contextmanager
def lock(root):
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    path=root/'.writer.lock'
    try:fd=os.open(path,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    except FileExistsError as exc:raise OSError('已有写入锁；确认原进程已停止后用 unlock 显式移除，不能并发覆盖') from exc
    try:
        os.write(fd,str(os.getpid()).encode());os.close(fd)
        yield
    finally:
        path.unlink(missing_ok=True)


def freeze(text, details):
    def replace(match):
        m=details[match.group(1)]
        return ('未知' if m['value'] is None else format(m['value'],'.10g'))+m['unit']
    return TOKEN.sub(replace,text)


def snapshots(d, checks):
    result=[];details=checks['metric_details']
    for a in d['analyses']:
        claims={x for ids in a['field_claims'].values() for x in ids}
        claims.update(x for h in a['horizons'].values() for x in h['claim_ids'])
        cs=[x for x in d['claims'] if x['id'] in claims]
        facts=set(a['fact_ids'])|{x for c in cs for x in c['fact_ids']}
        mids={x for c in cs for x in c['metric_ids']}
        def scan(value):
            if isinstance(value,str):mids.update(TOKEN.findall(value))
            elif isinstance(value,list):
                for v in value:scan(v)
            elif isinstance(value,dict):
                for v in value.values():scan(v)
        scan(a)
        def expand(mid):
            if mid not in details:return
            for x in details[mid]['dependencies']:
                if x not in mids:mids.add(x);expand(x)
        for mid in list(mids):expand(mid)
        sourceids={s for f in d['facts'] if f['id'] in facts for s in f['source_ids']}
        sourceids.update(s for mid in mids for s in details.get(mid,{}).get('source_ids',[]))
        item=dict(thesis_id=a['thesis_id'],theme_id=a['theme_id'],entity_ids=a['entity_ids'],version=a['version'],
                  first_proposed=d['meta']['date'],as_of=d['meta']['cutoff'],
                  conclusion=freeze(a['conclusion'],details),support=freeze(a['support'],details),
                  invalidation=freeze(a['invalidation'],details),assumptions=a['assumptions'],priority=a['priority'],
                  expires_at=a['expires_at'],review_at=a['review_at'],horizons=copy.deepcopy(a['horizons']),
                  status=a.get('update',{}).get('status','new'),update=a.get('update'),
                  facts=[copy.deepcopy(f) for f in d['facts'] if f['id'] in facts],
                  metrics={mid:details[mid] for mid in mids if mid in details},
                  sources=[copy.deepcopy(s) for s in d['sources'] if s['id'] in sourceids],
                  evidence=[copy.deepcopy(e) for e in d['evidence'] if e['source_id'] in sourceids],
                  claims=copy.deepcopy(cs),run_id=d['meta']['run_id'],delivery=checks['delivery']['grade'])
        # Freeze every narrative, not just top-level conclusions.
        def frozen(v):
            if isinstance(v,str):return freeze(v,details)
            if isinstance(v,list):return [frozen(x) for x in v]
            if isinstance(v,dict):return {k:frozen(x) for k,x in v.items()}
            return v
        result.append(frozen(item))
    return result


def history(root, limit=12):
    if not root:return dict(cold_start=True,active=[],recent=[])
    root=Path(root);index=root/'index.json'
    if not index.exists():return dict(cold_start=True,active=[],recent=[])
    data=load(index);active=[]
    for ident,entry in sorted(data.get('theses',{}).items(),key=lambda x:(x[1]['priority'],x[1]['review_at'])):
        if entry['status'] not in ('retired','refuted'):
            entry=dict(entry)
            for key in ('conclusion','support','invalidation'):entry[key]=entry[key][:600]
            entry['entity_ids']=entry['entity_ids'][:30]
            from common import iso
            entry['review_due']=iso(entry['review_at'])<=datetime.now(timezone.utc)
            active.append(dict(thesis_id=ident,**entry))
    return dict(cold_start=False,active=active[:limit],recent=data.get('runs',[])[-limit:],
                active_total=len(active),omitted=max(0,len(active)-limit))


def commit_history(root,d,checks,report):
    if not root:return
    root=Path(root)
    with lock(root):
        path=root/'index.json'
        idx=load(path) if path.exists() else dict(theses={},runs=[])
        rh=fingerprint(d)
        if any(x['input_sha256']==rh for x in idx['runs']):return
        if any(x['run_id']==d['meta']['run_id'] for x in idx['runs']):raise ValueError('研究索引中run_id已使用；新研究运行需新ID')
        pending=[]
        for item in snapshots(d,checks):
            ident=item['thesis_id'];old=idx['theses'].get(ident);version=item['version']
            if old:
                update=item['update']
                if version!=old['version']+1 or not update or update['previous_version']!=old['version']:
                    raise ValueError('历史版本冲突: '+ident+'；需引用上一版本并显式更新，不能覆盖原判断')
                item['first_proposed']=old['first_proposed']
                if not update['new_evidence_ids'] and update['status'] not in ('maintained','retired'):
                    raise ValueError('修订判断需新增证据: '+ident)
                if update['status']=='maintained':
                    previous=load(root/old['snapshot'])
                    if any(item[key]!=previous[key] for key in ('conclusion','support','invalidation','assumptions','expires_at')):
                        raise ValueError('维持判断不能静默改变原结论/阈值/期限: '+ident+'；使用有证据的修订状态')
            elif version!=1:raise ValueError('冷启动判断版本必须为1: '+ident)
            target=root/'theses'/ident/(str(version)+'.json')
            if target.exists() and load(target)!=item:raise ValueError('历史快照已存在且不同: '+ident)
            pending.append((target,item))
        for target,item in pending:
            if not target.exists():save(target,item,exclusive=True)
            idx['theses'][item['thesis_id']]={k:item[k] for k in ('version','first_proposed','priority','review_at','expires_at','status','conclusion','support','invalidation','theme_id','entity_ids')}
            idx['theses'][item['thesis_id']]['snapshot']=str(target.relative_to(root))
        idx['runs'].append(dict(run_id=d['meta']['run_id'],cutoff=d['meta']['cutoff'],report=str(report),input_sha256=rh))
        save(path,idx)


def put_artifact(root, raw, suffix):
    root=Path(root);digest=hashlib.sha256(raw).hexdigest()
    path=root/'artifacts'/(digest+suffix)
    path.parent.mkdir(parents=True,exist_ok=True)
    if not path.exists():path.write_bytes(raw)
    elif path.read_bytes()!=raw:raise ValueError('工件哈希冲突')
    return dict(path=str(path.relative_to(root)),sha256=digest,format={'.json':'json','.csv':'csv','.txt':'text'}[suffix])


def resolve_artifact(root,artifact):
    root=Path(root).resolve();path=(root/artifact['path']).resolve()
    if not path.is_relative_to(root):raise ValueError('工件路径越界')
    raw=path.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=artifact['sha256']:raise ValueError('工件哈希不一致')
    return raw


def materialize(d,root):
    result=copy.deepcopy(d)
    for s in result['series']:
        if s.get('artifact'):
            from common import loads
            if s['observations']:raise ValueError('外部序列工件不能同时含内联观测')
            s['observations']=loads(resolve_artifact(root,s['artifact']).decode('utf-8-sig'))
    return result


def cache_put(root,entry):
    for key in ('id','layer','source_url','retrieved_at','vintage_at','valid_until','recheck_triggers','data'):
        if key not in entry:raise ValueError('缓存缺少字段: '+key)
    from common import ID, iso, safe_url
    if not ID.fullmatch(entry['id']) or entry['layer'] not in ('news','market','fundamental','thesis') or not safe_url(entry['source_url']):raise ValueError('缓存标识/来源无效')
    for key in ('retrieved_at','vintage_at','valid_until'):iso(entry[key])
    if iso(entry['retrieved_at'])<iso(entry['vintage_at']) or iso(entry['valid_until'])<iso(entry['vintage_at']):raise ValueError('缓存获取/适用期限与版本矛盾')
    if not isinstance(entry['recheck_triggers'],list) or not entry['recheck_triggers']:raise ValueError('缓存需失效触发条件')
    path=Path(root)/'cache'/entry['id']/(fingerprint(entry)+'.json')
    if not path.exists():save(path,entry,exclusive=True)
    return str(path)


def cache_get(root,identifier,cutoff,triggers=()):
    from common import ID, iso
    if not ID.fullmatch(identifier):raise ValueError('无效缓存ID')
    base=Path(root)/'cache'/identifier;matches=[]
    # Explicit one key only; never recursively scans research or workspace roots.
    for path in sorted(base.glob('*.json'))[-100:]:
        e=load(path)
        if iso(e['vintage_at'])<=iso(cutoff)<=iso(e['valid_until']) and not set(triggers)&set(e['recheck_triggers']):matches.append(e)
    if not matches:return dict(status='miss',reason='没有符合截止、版本和失效条件的缓存')
    e=max(matches,key=lambda x:iso(x['vintage_at']))
    return dict(status='cache_reused',actual_retrieved_at=e['retrieved_at'],entry=e,
                note='缓存命中不表示本轮重新访问；新闻官方覆盖仍需本轮扫描。')
