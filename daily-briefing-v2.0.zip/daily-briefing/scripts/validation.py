"""One shared validator and publication assessment for CLI, runner and renderer."""
from __future__ import annotations
from datetime import date, timedelta, timezone
import re
from common import TOKEN, fingerprint, get_zone, iso, localize, num, obligations, period_bounds
from schema import SCHEMA, ANALYSIS_TEXT, check
from calculations import SERIES_OPS, FINANCIAL_OPS, calculate, inputs, mapping_valid, point_available

GROUPS=('sources','evidence','facts','calendars','series','metrics','claims','articles','analyses',
        'observations','actions','charts','events','mappings','coverage')
FIELD_CLAIMS=('conclusion','novelty','earnings','distribution','pricing','expectation','alternative',
              'counterevidence','support','invalidation','priority_reason','materiality')


def validate(d, contract=None, pack=None):
    r=dict(errors=[],warnings=[],values={},metric_details={},check_type='结构、时间、口径与依赖检查；不证明事实或引文语义、因果真实')
    def issue(path,message,category='input_error'):
        dest='warnings' if category=='insufficient_data' else 'errors'
        item=dict(path=path,message=message,category=category)
        if item not in r[dest]:r[dest].append(item)
    if not isinstance(d,dict) or d.get('schema_version')!=2 or type(d.get('schema_version')) is not int:
        issue('schema_version','需要schema 2；旧输入使用 migrate 命令生成新文件，不覆盖原件');return r
    r['errors']=check(d)
    if r['errors']:return r
    m=d['meta']
    try:
        cutoff=iso(m['cutoff']);zone=get_zone(m['timezone']);local=localize(m['cutoff'],m['timezone'])
        if m['date']!=local.date().isoformat():issue('meta.date','必须按报告时区而非输入偏移计算日期')
        if iso(m['window_start'])>cutoff:issue('meta.window_start','窗口不能晚于截止')
    except (ValueError,TypeError) as exc:issue('meta',str(exc));return r
    if not m['scope']:issue('meta.scope','范围不能为空')
    if any(k not in ('overview','news','ai','market','sectors','macro','observations','actions','sources') for k in m.get('section_titles',{})):issue('meta.section_titles','未知栏目ID')
    if contract:
        for key,target in [('cutoff','initial_cutoff'),('timezone','timezone'),('date','date'),('scope','scope'),
                           ('profile','profile'),('mode','mode'),('evidence_mode','evidence_mode')]:
            if m[key]!=contract[target]:issue('contract.'+key,'与start锁定请求不一致；需要显式新运行/修订')
        if m['window_start']!=contract['requested_window_start']:
            if not m['window_adjustment_reason'] or iso(m['window_start'])>iso(contract['requested_window_start']):
                issue('meta.window_start','只允许有原因的回溯扩展；保留请求窗口且不延后截止')
    maps={}
    for group in GROUPS:
        maps[group]={}
        for x in d[group]:
            if x['id'] in maps[group]:issue(group+'.'+x['id'],'重复ID')
            maps[group][x['id']]=x
    if len({a['thesis_id'] for a in d['analyses']})!=len(d['analyses']):issue('analyses.thesis_id','同一报告中的判断ID重复')
    def refs(ids,group,path):
        for x in ids:
            if x not in maps[group]:issue(path,'不存在的'+group+'引用: '+x)
    refs(m.get('featured_metrics',[]),'metrics','meta.featured_metrics')
    if len(m.get('featured_metrics',[]))>4:issue('meta.featured_metrics','首屏最多4个关键数值')
    def before(value,path,required=False,date_ok=False):
        if value is None:
            issue(path,'可得时间未知，不能作为已核验当前信息', 'insufficient_data' if not required else 'input_error');return None
        try:
            dt=iso(value,date_only=date_ok,tz=zone)
            if dt>cutoff:issue(path,'信息/版本在截止之后可得')
            return dt
        except (ValueError,TypeError):issue(path,'不可解析的ISO日期/时间');return None
    def time_any(value,path,date_ok=False):
        try:return iso(value,date_only=date_ok,tz=zone)
        except (ValueError,TypeError):issue(path,'不可解析的ISO日期/时间');return None
    for source in d['sources']:
        p='sources.'+source['id'];value=source['published_at']
        if re.fullmatch(r'\d{4}-\d{2}-\d{2}',value):
            try:
                tz=iso('2000-01-01T00:00:00'+source.get('published_timezone','-12:00')).tzinfo
                if iso(value,date_only=True,tz=tz)>cutoff:issue(p+'.published_at','只有日期不能确认在截止前公开')
            except ValueError:issue(p+'.published_timezone','无效UTC偏移')
        else:before(value,p+'.published_at',required=True)
        before(source['vintage']['available_at'],p+'.vintage.available_at')
        retrieved=time_any(source['retrieved_at'],p+'.retrieved_at')
        if retrieved and len(value)>10:
            try:
                if retrieved<iso(value):issue(p+'.retrieved_at','读取早于发布')
            except ValueError:pass
    for e in d['evidence']:
        refs([e['source_id']],'sources','evidence.'+e['id'])
        time_any(e['retrieved_at'],'evidence.'+e['id']+'.retrieved_at')
    for f in d['facts']:
        p='facts.'+f['id'];refs(f['source_ids'],'sources',p);refs(f['evidence_ids'],'evidence',p)
        if not f['source_ids']:issue(p,'事实缺来源')
        if f['kind']=='actual':
            t=time_any(f['as_of'],p+'.as_of',True)
            if t and t.astimezone(zone).date()>local.date():issue(p+'.as_of','实绩观测不能在未来')
        else:time_any(f['as_of'],p+'.as_of',True)
        before(f['available_at'],p+'.available_at')
        for key in ('event_at','effective_at'):
            if key in f:time_any(f[key],p+'.'+key,True)
        if 'observation_period' in f:
            a=time_any(f['observation_period']['start'],p+'.period.start',True)
            b=time_any(f['observation_period']['end'],p+'.period.end',True)
            if a and b and (a>b or (f['kind']=='actual' and b.astimezone(zone).date()>local.date())):issue(p,'实绩期间无效')
        for eid in f['evidence_ids']:
            if eid in maps['evidence'] and maps['evidence'][eid]['source_id'] not in f['source_ids']:issue(p,'证据片段与事实来源不一致')
        if f['status']=='confirmed' and f['source_ids'] and all(maps['sources'].get(x,{}).get('kind')=='media' for x in f['source_ids']):issue(p,'仅媒体来源请标reported')
    for cal in d['calendars']:
        p='calendars.'+cal['id'];refs(cal['source_ids'],'sources',p);refs(cal['evidence_ids'],'evidence',p)
        try:
            get_zone(cal['timezone']);a=date.fromisoformat(cal['valid_from']);b=date.fromisoformat(cal['valid_to'])
            days=[s['date'] for s in cal['sessions']]
            if days!=sorted(set(days)) or a>b:raise ValueError('会话须唯一有序，范围合法')
            for s in cal['sessions']:
                day=date.fromisoformat(s['date']);dt=localize(s['close_at'],cal['timezone'])
                if not a<=day<=b or dt.date()!=day:raise ValueError('会话日期/收盘时间超出适用范围')
            if cal.get('synthetic') and m['mode']!='teaching':issue(p,'合成日历只允许教学演示')
            if cal['complete'] and (not cal['source_ids'] or not cal['evidence_ids']):issue(p,'完整日历需来源和版本证据，不可用工作日猜测')
        except (ValueError,TypeError) as exc:issue(p,str(exc))
    for s in d['series']:
        p='series.'+s['id'];refs(s['source_ids'],'sources',p);refs(s['evidence_ids'],'evidence',p)
        if not s['source_ids']:issue(p,'原始序列需要来源')
        for eid in s['evidence_ids']:
            if eid in maps['evidence'] and maps['evidence'][eid]['source_id'] not in s['source_ids']:issue(p,'序列片段与声明来源不一致')
        if s['calendar_id']:refs([s['calendar_id']],'calendars',p)
        cal=maps['calendars'].get(s['calendar_id'])
        if cal and cal['market']!=s['market']:issue(p,'序列市场与日历不一致')
        before(s['vintage']['available_at'],p+'.vintage')
        rule=s.get('release_rule')
        if rule:
            refs(rule['evidence_ids'],'evidence',p+'.release_rule')
            if not rule['evidence_ids'] or rule['delay_seconds']<0 or not cal:issue(p,'发布规则需日历、非负延迟及原文依据')
        days=[]
        for i,o in enumerate(s['observations']):
            q=p+'.observations['+str(i)+']'
            try:
                day=date.fromisoformat(o['date']);days.append(o['date'])
                if day>local.date():issue(q,'序列观测在未来')
            except ValueError:issue(q,'日期无效')
            av=point_available(o,s,maps)
            if av:before(av,q+'.available_at')
            if av and cal and s['frequency']=='daily' and o['status']=='traded':
                session=next((x for x in cal['sessions'] if x['date']==o['date']),None)
                try:
                    if session and iso(av)<iso(session['close_at']):issue(q,'完整日会话数值不能在该会话收盘前已知；盘中值用带时点观测指标')
                except ValueError:pass
            if o.get('vintage'):before(o['vintage']['available_at'],q+'.vintage')
            if o['value'] is not None and s['basis'] in ('price','turnover','count','shares') and o['value']<0:issue(q,'该数据类型不能为负')
            if o['status'] in ('missing','suspended') and o['value'] is not None:issue(q,'停牌或缺失必须null，不能以前值补齐')
        if days!=sorted(set(days)):issue(p,'观测日期须唯一且升序')
        if cal and s['frequency']=='daily' and any(day not in {x['date'] for x in cal['sessions']} for day in days):issue(p,'日度观测不属于声明的有效会话')
    for mapping in d['mappings']:
        p='mappings.'+mapping['id']
        for key,group in [('series_ids','series'),('source_ids','sources'),('evidence_ids','evidence')]:refs(mapping[key],group,p)
        if not mapping['evidence_ids']:issue(p,'跨源映射缺少口径证据')
    for metric in d['metrics']:
        p='metrics.'+metric['id'];op=metric['op'];dim=metric['dimensions']
        if dim['scale']<=0:issue(p+'.dimensions.scale','数量级必须为正')
        try:
            period=period_bounds(dim['period'])
            if period and metric.get('kind')=='actual' and period[1]>local.date():issue(p+'.dimensions.period','实绩期间结束在未来')
        except ValueError:issue(p+'.dimensions.period','期间需ISO日期/范围、YYYY-MM、YYYY或YYYY-Qn；财年映射用ISO范围')
        if op=='observed':
            for key in ('value','as_of','available_at','kind','source_ids','evidence_ids'):
                if key not in metric:issue(p+'.'+key,'观测指标缺少字段')
            if 'as_of' in metric:
                t=time_any(metric['as_of'],p+'.as_of',True)
                if t and metric.get('kind')=='actual' and t.astimezone(zone).date()>local.date():issue(p,'未来值必须标forecast且在截止前发布')
            before(metric.get('available_at'),p+'.available_at')
            refs(metric.get('source_ids',[]),'sources',p);refs(metric.get('evidence_ids',[]),'evidence',p)
            if not metric.get('source_ids'):issue(p,'观测指标缺少来源')
            for eid in metric.get('evidence_ids',[]):
                if eid in maps['evidence'] and maps['evidence'][eid]['source_id'] not in metric.get('source_ids',[]):issue(p,'观测片段与声明来源不一致')
        elif op in SERIES_OPS:
            for key in ('series_id','n','window_basis'):
                if key not in metric:issue(p+'.'+key,'序列计算缺少字段')
            if metric.get('n',0)<=0:issue(p+'.n','窗口必须为正整数')
            refs([metric.get('series_id','')],'series',p)
            s=maps['series'].get(metric.get('series_id'))
            if s:
                if dim['entity_id']!=s['entity_id']:issue(p,'指标实体与序列实体不一致')
                expected={'return':('price','%'),'excess_return':('price','百分点'),'volume_ratio':('turnover','倍'),'bp_change':('yield_percent','bp')}.get(op)
                if expected and (s['basis'],metric['unit'])!=expected:issue(p,'运算、基础量和单位不符')
                if op=='difference' and metric['unit']!=s['unit']:issue(p,'差值单位不符')
                if metric.get('window_basis')=='observations' and ('交易日' in metric['label']):issue(p,'观测期指标不能标交易日')
            if op=='excess_return':
                refs([metric.get('benchmark_id','')],'series',p);b=maps['series'].get(metric.get('benchmark_id'))
                if s and b:
                    if b['basis']!='price':issue(p,'基准必须为价格')
                    if any(s[k]!=b[k] for k in ('market','provider','adjustment','classification','scope')) and not mapping_valid(metric.get('mapping_id'),[s,b],maps):issue(p,'不可比基准；跨源组合需完整映射')
        else:
            deps=inputs(metric);refs([x or '' for x in deps],'metrics',p)
            if not deps:issue(p,'计算缺少输入依赖');continue
            if any(x not in maps['metrics'] for x in deps):continue
            ins=[maps['metrics'][x] for x in deps]
            if len(ins)!=(1 if op=='sensitivity' else 2) and op not in ('sum','product'):issue(p,'运算输入个数错误')
            if not metric.get('comparison_basis') or not metric.get('comparison_evidence_ids'):issue(p,'财务计算需口径说明及证据')
            refs(metric.get('comparison_evidence_ids',[]),'evidence',p)
            for x in ins:
                xd=x['dimensions']
                if xd['entity_id']!=dim['entity_id']:issue(p,'财务计算实体不一致')
                if xd['currency'] not in ('none',dim['currency']) and dim['currency']!='none':issue(p,'币种不一致，不能隐式换汇')
            if len({x['dimensions']['currency'] for x in ins if x['dimensions']['currency']!='none'})>1:issue(p,'输入币种不一致')
            if op in ('pair_difference','growth','sum','sensitivity'):
                for key in ('segment','measure'):
                    if any(x['dimensions'][key]!=ins[0]['dimensions'][key] for x in ins):issue(p,'总量/分部或财务量不一致: '+key)
                if len({x['unit'] for x in ins})>1:issue(p,'同类计算输入单位不同')
            if op in ('ratio','sum','product') and len({x['dimensions']['period'] for x in ins})>1:issue(p,'同期运算的期间不一致')
            if op in ('ratio','growth') and dim['currency']!='none':issue(p,'无量纲比率输出currency必须为none')
            if op=='pair_difference':
                if (ins[0]['unit']=='%' and metric['unit'] not in ('bp','百分点')) or (ins[0]['unit']!='%' and metric['unit']!=ins[0]['unit']):issue(p,'差值输出单位错误')
            if op=='growth' and metric['unit']!='%':issue(p,'增长率单位为%')
            if op=='ratio' and metric['unit'] not in ('%','倍'):issue(p,'ratio输出限%或倍')
            if op=='ratio' and any(x['unit']!=ins[0]['unit'] for x in ins):issue(p,'ratio只允许同单位的无量纲比值')
            if op=='sum' and metric['unit']!=ins[0]['unit']:issue(p,'求和单位错误')
            if op=='sensitivity' and ('shock' not in metric or metric['unit']!=ins[0]['unit']):issue(p,'敏感性需明确相对shock且单位不变')
            if op=='product':
                dimensions={}
                for x in ins:
                    if not x['dimensions'].get('dimensions'):issue(p,'乘积需单位维度，例如money或quantity的幂')
                    for key,power in x['dimensions'].get('dimensions',{}).items():dimensions[key]=dimensions.get(key,0)+power
                dimensions={k:v for k,v in dimensions.items() if v}
                if dimensions!=dim.get('dimensions'):issue(p,'乘积输出单位维度不匹配')
    # Structural references are shared by all display surfaces.
    for group in ('claims','summary','articles','analyses','observations','actions','events'):
        for i,item in enumerate(d[group]):
            p=group+'.'+item.get('id',str(i))
            for key,target in [('fact_ids','facts'),('analysis_ids','analyses'),('claim_ids','claims'),('metric_ids','metrics'),('consensus_fact_ids','facts'),('evidence_ids','evidence')]:
                if key in item:refs(item[key],target,p+'.'+key)
            if group=='claims' and item['status']=='supported' and not (item['fact_ids'] or item['metric_ids']):issue(p,'有据主张需要事实或指标')
            if group in ('summary','articles') and not any(item[key] for key in ('fact_ids','analysis_ids','claim_ids')):issue(p,'正文/摘要需要可追溯的事实、判断或主张')
            if group=='articles' and not 1<=item['priority']<=7:issue(p,'新闻优先级必须1—7')
            if group=='observations' and item['kind']=='contrarian' and not item['consensus_fact_ids']:issue(p,'非共识缺少预期基准')
    if len(d['summary'])>3:issue('summary','摘要最多3项')
    for a in d['analyses']:
        p='analyses.'+a['id']
        if a['version']<1 or not 1<=a['priority']<=3:issue(p,'版本/优先级无效')
        for field,ids in a['field_claims'].items():
            if field not in FIELD_CLAIMS:issue(p+'.field_claims','未知分析字段: '+field)
            refs(ids,'claims',p+'.'+field)
        for h in a['horizons'].values():
            refs(h['claim_ids'],'claims',p+'.horizons');time_any(h['review_at'],p+'.horizons.review_at')
        for key in ('review_at','expires_at'):time_any(a[key],p+'.'+key)
        for e in a['mechanism']:
            refs(e['fact_ids'],'facts',p+'.mechanism')
            if e['basis']=='fact' and not e['fact_ids']:issue(p,'事实传导需依据')
            if e['basis']=='assumption' and not e['assumption'].strip():issue(p,'假设传导需说明假设')
        for l in a['leaders']:
            refs(l['fact_ids'],'facts',p+'.leaders');refs(l['claim_ids'],'claims',p+'.leaders')
            if l.get('series_id'):refs([l['series_id']],'series',p+'.leaders')
            for role in ('industry','trading'):
                refs(l['role_evidence'].get(role,[]),'facts',p+'.role_evidence')
                if l['role'] in (role,'both') and not l['role_evidence'].get(role):issue(p,'龙头角色缺证据')
            if l['role'] in ('industry','both') and not l.get('industry_basis'):issue(p,'产业龙头缺同业依据')
            if l.get('industry_basis'):refs(l['industry_basis']['fact_ids'],'facts',p+'.industry_basis')
        if a.get('update'):refs(a['update']['new_evidence_ids'],'evidence',p+'.update')
    for a in d['actions']:
        p='actions.'+a['id'];refs([a['analysis_id']],'analyses',p)
        if not 1<=a['priority']<=3:issue(p,'优先级需1—3')
        at=time_any(a['observe_at'],p+'.observe_at');end=time_any(a['expires_at'],p+'.expires_at')
        if at and end and (end<=cutoff or end<at):issue(p,'行动已过期或截止早于观察')
        if a.get('calendar_id'):refs([a['calendar_id']],'calendars',p)
    for e in d['events']:time_any(e['at'],'events.'+e['id'],True)
    for c in d['coverage']:
        p='coverage.'+c['id'];refs(c['source_ids'],'sources',p);refs(c['mapping_evidence_ids'],'evidence',p)
        if c['status']!='not_checked' and not c['checked_at']:issue(p,'需要实际访问或缓存获取时刻')
        if c['checked_at']:time_any(c['checked_at'],p)
        time_any(c['window_start'],p);time_any(c['window_end'],p)
        if c['method']=='search' and c['status']=='checked_none':issue(p,'搜索无结果不能证明官网无新增')
        if c['method']=='aggregate' and not c['mapping_evidence_ids']:issue(p,'聚合覆盖需范围映射证据')
    review=d['review']
    for key,target in [('checked_fact_ids','facts'),('checked_analysis_ids','analyses'),('checked_claim_ids','claims'),('evidence_ids','evidence')]:refs(review[key],target,'review.'+key)
    if review['status']=='independent_review' and (not review.get('independent_actor_id') or review.get('independent_actor_id')==m['author']):issue('review','独立审核需独立主体记录')
    for x in review['issues']:
        if x['resolved'] and not x.get('resolution'):issue('review.issues','已解决问题需解决说明')
    for group in ('claims','analyses'):
        for item in d[group]:
            for gap in item['limitations']:refs(gap.get('claim_ids',[]),'claims',group+'.'+item['id']+'.limitations')
    for change in d.get('evidence_differences',[]):refs(change['evidence_ids'],'evidence','evidence_differences')
    for previous in d['prior_reviews']:refs(previous['new_evidence_ids'],'evidence','prior_reviews')
    def walk(v,path):
        if isinstance(v,str):
            if '{metric:' in TOKEN.sub('',v):issue(path,'数值引用语法错误')
            refs(TOKEN.findall(v),'metrics',path)
        elif isinstance(v,list):
            for i,x in enumerate(v):walk(x,f'{path}[{i}]')
        elif isinstance(v,dict):
            for k,x in v.items():walk(x,path+'.'+k)
    walk(d,'root')
    validate_charts(d,maps,issue)
    if pack is not None:fixed_comparison(d,pack,issue,r)
    elif m['evidence_mode']=='fixed_pack':issue('evidence_pack','构建固定轮需要start保存的原包，单独声明hash不足')
    if r['errors']:return r
    r['values'],r['metric_details']=calculate(d,maps,issue)
    if r['errors']:return r
    assess(d,maps,r,contract,issue)
    r['document_sha256']=fingerprint(d)
    return r


def validate_charts(d,maps,issue):
    def need(c,keys):
        for k in keys:
            if k not in c:issue('charts.'+c['id']+'.'+k,'图表缺少字段')
        return all(k in c for k in keys)
    for c in d['charts']:
        typ=c['type'];p='charts.'+c['id'];ids=[];group='metrics'
        if c['placement']=='theme' and c.get('analysis_id') not in maps['analyses']:issue(p,'主题图需要已有analysis_id')
        if typ in ('breadth','bars') and need(c,['items']):
            ids=[x['metric_id'] for x in c['items']]
            if typ=='breadth' and (not c.get('scope') or len(c['items'])!=3 or {x.get('category') for x in c['items']}!={'up','flat','down'}):issue(p,'广度需完整三类；未知用null')
        elif typ=='heatmap' and need(c,['columns','rows','classification','scope']):
            for row in c['rows']:
                if len(row['metric_ids'])!=len(c['columns']):issue(p,'热力图列不匹配')
                ids+=row['metric_ids']
            for col in zip(*(x['metric_ids'] for x in c['rows'])):
                ms=[maps['metrics'][x] for x in col if x in maps['metrics']]
                if len({(m['op'],m.get('n'),m.get('window_basis'),m['unit']) for m in ms})>1:issue(p,'热力同列窗口/单位不一致')
                ss=[maps['series'][m['series_id']] for m in ms if m.get('series_id') in maps['series']]
                if any(m['op'] not in ('return','excess_return') for m in ms):issue(p,'强弱热力图需可计算收益率')
                if any(s['classification']!=c['classification'] for s in ss):issue(p,'热力图分类与源数据不同')
                if len({tuple(o['date'] for o in s['observations'][-ms[i].get('n',1)-1:]) for i,s in enumerate(ss)})>1:issue(p,'热力同列实际窗口不一致')
        elif typ=='scatter' and need(c,['points']):
            for point in c['points']:
                ids += [point['x_metric'],point['y_metric']]
                x=maps['metrics'].get(point['x_metric']);y=maps['metrics'].get(point['y_metric'])
                if not x or not y:continue
                if x['op']!='excess_return' or y['op']!='volume_ratio':issue(p,'散点需超额收益与量能比');continue
                sx=maps['series'].get(x.get('series_id'));sy=maps['series'].get(y.get('series_id'))
                if sx and sy:
                    if sx['entity_id']!=sy['entity_id']:issue(p,'同点横纵轴实体不一致；显示名相同无效')
                    if (x.get('n'),x.get('window_basis'))!=(y.get('n'),y.get('window_basis')):issue(p,'同点横纵轴窗口不一致')
                    if [o['date'] for o in sx['observations'][-x.get('n',1)-1:]] != [o['date'] for o in sy['observations'][-y.get('n',1)-1:]]:issue(p,'同点会话未对齐')
                    if any(sx[k]!=sy[k] for k in ('scope','market','provider','adjustment','classification')) and not mapping_valid(point.get('mapping_id'),[sx,sy],maps):issue(p,'同点跨源/范围不一致且无合法映射')
            xs=[maps['metrics'][pt['x_metric']] for pt in c['points'] if pt['x_metric'] in maps['metrics']]
            if len({(x.get('n'),x.get('window_basis'),x.get('benchmark_id')) for x in xs})>1:issue(p,'散点各点横轴窗口或基准不一致')
        elif typ=='line' and need(c,['series_ids','normalize']):
            ids=c['series_ids'];group='series'
            ss=[maps['series'][x] for x in ids if x in maps['series']]
            if not 1<=len(ss)<=4:issue(p,'折线需1—4序列')
            if c['normalize'] and any(s['basis']!='price' for s in ss):issue(p,'归一化仅用于价格')
            if not c['normalize'] and len({s['unit'] for s in ss})>1:issue(p,'不同单位不能共用纵轴')
        elif typ=='mechanism' and need(c,['analysis_id']):ids=[c['analysis_id']];group='analyses'
        elif typ=='timeline' and need(c,['event_ids']):ids=c['event_ids'];group='events'
        for x in ids:
            if x not in maps[group]:issue(p,'图表引用不存在: '+x)
        if typ in ('breadth','bars'):
            ms=[maps['metrics'][x] for x in ids if x in maps['metrics']]
            if len({x['unit'] for x in ms})>1 or len({x.get('as_of',x['dimensions']['period']) for x in ms})>1:issue(p,'截面单位/期间不一致')
            if typ=='breadth' and any(x['unit']!='家' or (x.get('value') is not None and (x['value']<0 or int(x['value'])!=x['value'])) for x in ms):issue(p,'广度需非负整数家数')


def fixed_comparison(d,pack,issue,r):
    changes=[]
    for group in ('sources','facts','series','metrics','evidence'):
        base={x['id']:x for x in pack.get(group,[])};current={x['id']:x for x in d.get(group,[])}
        for ident in sorted(set(base)|set(current)):
            old=base.get(ident);new=current.get(ident)
            if group=='metrics' and old is None and new['op']!='observed':continue
            if group=='sources':
                old={k:v for k,v in old.items() if k!='verification'} if old else None
                new={k:v for k,v in new.items() if k!='verification'} if new else None
            if old==new:continue
            change=dict(group=group,id=ident,kind='added' if old is None else 'excluded' if new is None else 'corrected',
                        before_sha256=fingerprint(old) if old is not None else None,after_sha256=fingerprint(new) if new is not None else None)
            changes.append(change)
            declared=next((x for x in d.get('evidence_differences',[]) if all(x.get(k)==v for k,v in change.items())),None)
            if not declared:issue('fixed_pack.'+group+'.'+ident,'证据层与原包不同且无精确差异记录')
    r['comparison']=dict(valid_same_input=not changes,changes=changes)


def assess(d,maps,r,contract,issue):
    critical_claims=set();important_facts=set();important_metrics=set()
    for item in d['summary']+d['actions']:
        critical_claims.update(item['claim_ids']);important_facts.update(item['fact_ids'])
    def text_metrics(value):
        if isinstance(value,str):important_metrics.update(TOKEN.findall(value))
        elif isinstance(value,list):
            for x in value:text_metrics(x)
        elif isinstance(value,dict):
            for x in value.values():text_metrics(x)
    for group in ('summary','articles','analyses','actions','observations'):text_metrics(d[group])
    analysis_claims={}
    for a in d['analyses']:
        cs={x for ids in a['field_claims'].values() for x in ids}
        cs.update(x for h in a['horizons'].values() for x in h['claim_ids'])
        cs.update(x for l in a['leaders'] for x in l['claim_ids'])
        analysis_claims[a['id']]=cs;critical_claims.update(cs);important_facts.update(a['fact_ids'])
        for edge in a['mechanism']:important_facts.update(edge['fact_ids'])
        for leader in a['leaders']:
            important_facts.update(leader['fact_ids'])
            important_facts.update(x for ids in leader['role_evidence'].values() for x in ids)
            important_facts.update(leader.get('industry_basis',{}).get('fact_ids',[]))
    for item in d['summary']+d['articles']:
        for aid in item['analysis_ids']:critical_claims.update(analysis_claims.get(aid,()))
        important_facts.update(item['fact_ids'])
        critical_claims.update(item['claim_ids'])
    important_metrics.update(d['meta'].get('featured_metrics',[]))
    for chart in d['charts']:
        if chart['placement']=='overview':
            important_metrics.update(x['metric_id'] for x in chart.get('items',[]))
            important_metrics.update(mid for row in chart.get('rows',[]) for mid in row['metric_ids'])
            important_metrics.update(x[k] for x in chart.get('points',[]) for k in ('x_metric','y_metric'))
    for cid in critical_claims:
        claim=maps['claims'].get(cid)
        if claim:important_facts.update(claim['fact_ids']);important_metrics.update(claim['metric_ids'])
    important_facts.update(x['id'] for x in d['facts'] if x['core'])
    def evidence_ok(ids):
        for eid in ids:
            e=maps['evidence'].get(eid)
            if e and e['read_method'] in ('original','cached'):
                source=maps['sources'].get(e['source_id'])
                if source and source['read_status'] in ('full','partial') and source['vintage']['available_at'] and source['vintage']['id']!='unknown':
                    return True
        return False
    badfacts={fid for fid in important_facts if fid in maps['facts'] and
              (not evidence_ok(maps['facts'][fid]['evidence_ids']) or not maps['facts'][fid]['available_at'] or maps['facts'][fid]['status'] in ('unverified','conflicted'))}
    badmetrics=set();seen=set()
    def metric_ok(mid):
        if mid in seen:return mid not in badmetrics
        seen.add(mid);metric=maps['metrics'].get(mid)
        if not metric:return False
        if metric['op']=='observed':good=evidence_ok(metric.get('evidence_ids',[])) and bool(metric.get('available_at'))
        elif metric['op'] in SERIES_OPS:
            good=True
            for key in ('series_id','benchmark_id'):
                if key in metric:
                    s=maps['series'].get(metric[key]);good=bool(s) and evidence_ok(s['evidence_ids']) and good
        else:good=all(metric_ok(x) for x in inputs(metric))
        if not good or r['values'].get(mid) is None:badmetrics.add(mid)
        return good
    for mid in important_metrics:metric_ok(mid)
    for fid in sorted(badfacts):issue('facts.'+fid,'重要结论依赖此事实，但原文片段/时点/真实性状态未就绪；core=false不豁免','insufficient_data')
    for mid in sorted(badmetrics):issue('metrics.'+mid,'重要数值证据未就绪','insufficient_data')
    obligations_list=contract['coverage_obligations'] if contract else obligations(d['meta']['profile'],d['meta']['scope'])
    obligations_map={x['id']:x for x in obligations_list}
    covered=set()
    for c in d['coverage']:
        from urllib.parse import urlsplit
        valid_mapping=True
        for oid in c['obligation_ids']:
            if oid not in obligations_map:issue('coverage.'+c['id'],'未知覆盖义务: '+oid);valid_mapping=False
            elif c['method']=='original_index' and obligations_map[oid]['url']:
                expected=urlsplit(obligations_map[oid]['url']).hostname.removeprefix('www.')
                actual=urlsplit(c['url']).hostname.removeprefix('www.')
                if actual!=expected and not actual.endswith('.'+expected):issue('coverage.'+c['id'],'原始入口域名与覆盖机构不一致；聚合入口需显式映射');valid_mapping=False
        if c['status'] in ('checked_new','checked_none') and c['method'] in ('original_index','aggregate'):
            if valid_mapping and iso(c['window_start'])<=iso(d['meta']['window_start']) and iso(c['window_end'])>=iso(d['meta']['cutoff']):
                covered.update(c['obligation_ids'])
    missing=[x for x in obligations_list if x['id'] not in covered]
    local={}
    for a in d['analyses']:
        reasons=[]
        if any(not a['field_claims'].get(k) for k in FIELD_CLAIMS):reasons.append('重要分析字段没有具体主张支持')
        if any(not h['claim_ids'] for h in a['horizons'].values()):reasons.append('三期限未分别建立证据')
        if set(a['fact_ids'])&badfacts:reasons.append('重要事实证据不足')
        if a['gaps'] or any(x['critical'] for x in a['limitations']):reasons.append('本主题存在关键缺口')
        for cid in analysis_claims[a['id']]:
            c=maps['claims'].get(cid)
            if c and (set(c['fact_ids'])&badfacts or set(c['metric_ids'])&badmetrics or any(g['critical'] for g in c['limitations'])):reasons.append('主张依赖或关键缺口未解决')
        local[a['id']]=dict(status='limited' if reasons else 'assessed',reasons=list(dict.fromkeys(reasons)))
    review=d['review'];review_ok=(review['status']!='not_reviewed' and important_facts<=set(review['checked_fact_ids'])
            and critical_claims<=set(review['checked_claim_ids']) and set(maps['analyses'])<=set(review['checked_analysis_ids'])
            and not any(x['severity']=='blocking' and not x['resolved'] for x in review['issues']))
    near=False
    for a in d['actions']:
        try:
            at=iso(a['observe_at']);cutoff=iso(d['meta']['cutoff'])
            # A next-calendar-day condition is necessarily within the next three
            # sessions. Longer spans require a sourced session calendar.
            if cutoff<=at<=cutoff+timedelta(days=1):near=True
            cal=maps['calendars'].get(a.get('calendar_id'))
            if cal:
                sessions=[s for s in cal['sessions'] if cutoff<=iso(s['close_at'])]
                if sessions and at<=iso(sessions[min(2,len(sessions)-1)]['close_at']) and at>=cutoff:near=True
        except ValueError:pass
    reasons=[]
    if missing:reasons.append('必查覆盖尚缺'+str(len(missing))+'项')
    if d['gaps']:reasons.append('全局资料缺口')
    if any(x['status']=='limited' for x in local.values()):reasons.append('部分主题未完成研究目标')
    if not d['analyses'] or not d['actions'] or not near:reasons.append('缺少完整主题研究或当日至3交易日观察条件')
    if badfacts or badmetrics:reasons.append('重要证据未就绪')
    if not review_ok:reasons.append('研究审阅尚未覆盖依赖闭包')
    if d['meta']['evidence_mode']=='fixed_pack':reasons.append('固定资料实验不代表独立联网完整覆盖')
    requested=d['meta']['requested_grade']
    grade='draft' if not review_ok or requested=='draft' else 'observation' if not d['analyses'] or not d['actions'] else 'limited' if reasons else 'full'
    if requested in ('limited','observation') and grade=='full':grade=requested
    r['delivery']=dict(grade=grade,requested_grade=requested,reasons=reasons,analysis_status=local,
                       coverage=dict(required=len(obligations_list),covered=len([x for x in obligations_list if x['id'] in covered]),missing=missing),
                       review_status=review['status'],review_scope_satisfied=review_ok,
                       visual_status=d.get('visual',{}).get('status','not_performed'),structural_pass=not r['errors'],
                       research_truth_certified=False)
    r['dependency_closure']=dict(claim_ids=sorted(critical_claims),fact_ids=sorted(important_facts),metric_ids=sorted(seen))
