#!/usr/bin/env python3
"""Public CLI and compatibility imports. Every build uses schema-v2 validation."""
from __future__ import annotations
import argparse
import copy
from datetime import datetime, timezone
from pathlib import Path
import sys
import time
from uuid import uuid4
sys.dont_write_bytecode = True

from common import ID, TOKEN, VERSION, canonical, fingerprint, iso, load, num, save, stamp
from validation import validate
from storage import snapshots


def source_ids(d, metric):
    by_id = {m['id']: m for m in d['metrics']}
    series = {s['id']: s for s in d['series']}
    seen = set()
    def visit(m):
        if m['id'] in seen:
            return []
        seen.add(m['id'])
        if m['op'] == 'observed':
            return m['source_ids']
        from calculations import inputs
        result = []
        for key in ('series_id', 'benchmark_id'):
            if key in m:
                result.extend(series[m[key]]['source_ids'])
        for key in inputs(m):
            result.extend(visit(by_id[key]))
        return result
    return list(dict.fromkeys(visit(metric)))


def metric_date(d, metric):
    if metric['op'] == 'observed':
        return metric['as_of']
    if metric.get('series_id'):
        s = next(s for s in d['series'] if s['id'] == metric['series_id'])
        return s['observations'][-1]['date'] if s['observations'] else ''
    return metric['dimensions']['period']


def display_document(d, checks):
    """Adapter for the established visual template, not a second validator."""
    from calculations import point_available
    result = copy.deepcopy(d)
    result['meta']['coverage_status'] = 'complete' if checks['delivery']['grade'] == 'full' else 'limited'
    result['review']['status'] = 'draft' if checks['delivery']['grade'] == 'draft' else 'reviewed'
    for s in result['sources']:
        s['accessed_at'] = s['retrieved_at']
    maps = {'calendars': {c['id']: c for c in result['calendars']}}
    for s in result['series']:
        for point in s['observations']:
            if not point_available(point, s, maps):
                point['value'] = None
    return result


def _build_validated(d, checks, root):
    """Build already validated input; timing excludes validation explicitly."""
    from render import render_report
    started = time.perf_counter()
    html = render_report(d, checks)
    if '{metric:' in html:
        raise ValueError('HTML仍有未替换数值引用')
    root = Path(root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    out = root / (d['meta']['date'] + '-' + d['meta']['run_id'])
    out.mkdir(exist_ok=False)
    save(out / 'briefing.json', d)
    save(out / 'theses.json', {'cutoff': d['meta']['cutoff'], 'items': snapshots(d, checks)})
    (out / 'briefing.html').write_text(html, encoding='utf-8')
    final = {**checks, 'built_at': stamp(), 'output': str(out/'briefing.html'),
             'build_status': 'built', 'build_excludes_validation_ms': (time.perf_counter()-started)*1000}
    save(out / 'checks.json', final)
    return out


def build(d, result, root, contract=None, pack=None):
    # Never accept caller-provided zero errors as a publication certificate.
    checks = validate(d, contract, pack)
    if checks['errors']:
        raise ValueError('输入校验失败: '+canonical(checks['errors'][:6]))
    return _build_validated(d, checks, root)


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    commands = p.add_subparsers(dest='command', required=True)
    for name in ('validate', 'build'):
        c = commands.add_parser(name)
        c.add_argument('--input', required=True)
        c.add_argument('--work-dir', help='Use locked contract, fixed pack and artifact root of this run')
        if name == 'build':
            c.add_argument('--output-dir', required=True)
    c = commands.add_parser('history')
    c.add_argument('--state-root', required=True)
    c.add_argument('--limit', type=int, default=12)
    c = commands.add_parser('schema')
    c.add_argument('--output', required=True)
    c = commands.add_parser('migrate')
    c.add_argument('--input', required=True)
    c.add_argument('--output', required=True)
    args = p.parse_args(argv)
    try:
        if args.command == 'schema':
            from schema import SCHEMA
            save(args.output, SCHEMA)
            print(canonical({'schema_version': 2, 'output': args.output}))
            return 0
        if args.command == 'migrate':
            from migration import migrate
            if Path(args.input).resolve() == Path(args.output).resolve() or Path(args.output).exists():
                raise ValueError('迁移必须写入新文件，原件不覆盖')
            save(args.output, migrate(load(args.input)), exclusive=True)
            print(canonical({'output': args.output, 'review': 'not_reviewed', 'note': '缺失时间、证据和日历不得自动认证；补齐或降级后再校验。'}))
            return 0
        if args.command == 'history':
            from storage import history
            print(canonical(history(args.state_root, min(50, max(1, args.limit)))))
            return 0
        contract = pack = None
        from storage import materialize
        root = Path(args.work_dir) if args.work_dir else Path(args.input).resolve().parent
        d = materialize(load(args.input), root)
        if args.work_dir:
            from workflow import read_state
            state = read_state(root)
            contract = state['contract']
            pack = load(root/'evidence-pack.json') if state.get('evidence_sha256') else None
        result = validate(d, contract, pack)
        if args.work_dir:
            from capabilities import enforce_delivery, summary as capability_summary
            runtime=state.get('preflight')
            enforce_delivery(result,d,runtime)
            if d['meta']['mode']!='teaching' and d['meta']['evidence_mode']!='fixed_pack':
                capability=capability_summary(runtime)
                if capability['status'] in ('awaiting_host_report','blocked'):
                    result['errors'].append(dict(path='runtime.capabilities',category='capability_unavailable',message=capability['next']))
                elif capability['status']=='limited_existing' and (not d['sources'] or not d['evidence']):
                    result['errors'].append(dict(path='runtime.capabilities',category='insufficient_data',message='缺少核心联网能力且无已有可核验资料'))
        if args.command == 'build' and not result['errors']:
            result['output'] = str(_build_validated(d, result, args.output_dir)/'briefing.html')
        save(root/'checks.json', result)
        print(canonical({'errors': result['errors'][:6], 'error_count': len(result['errors']),
                         'warning_count': len(result['warnings']), 'delivery': result.get('delivery'),
                         'output': result.get('output'), 'checks': str(root/'checks.json')}))
        return 2 if result['errors'] else 0
    except (ValueError, KeyError, OSError) as exc:
        print(canonical({'error': str(exc), 'status': 'blocked'}))
        return 2


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    raise SystemExit(main())
