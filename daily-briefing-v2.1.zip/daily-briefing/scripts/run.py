#!/usr/bin/env python3
"""Minimal portable runner: autonomous research belongs to the host's tools."""
import argparse
import json
from pathlib import Path
import sys
if sys.version_info < (3, 10):
    print(json.dumps({'status':'blocked','category':'capability_unavailable','capability':'python',
                      'error':'Python 3.10+ required; use an existing compatible interpreter, do not edit Skill sources.'}))
    raise SystemExit(3)
sys.dont_write_bytecode = True
from common import VERSION, canonical, load, save
from workflow import GUIDES, start, read_state, guide, finish, status
from capabilities import CapabilityError, read_json_output


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    commands=parser.add_subparsers(dest='command',required=True)
    p=commands.add_parser('start')
    p.add_argument('--work-dir',required=True)
    p.add_argument('--cutoff')
    p.add_argument('--date',help='Historical date without clock uses 08:00 in report timezone')
    p.add_argument('--preset',choices=['premarket'])
    p.add_argument('--timezone',default='Asia/Shanghai')
    p.add_argument('--window-start')
    p.add_argument('--profile',default='finance-ai')
    p.add_argument('--scope',nargs='+')
    p.add_argument('--mode',choices=['live','historical','teaching'],default='live')
    p.add_argument('--model',default='unknown')
    p.add_argument('--harness',default='unknown')
    p.add_argument('--reasoning',default='unknown')
    p.add_argument('--state-root')
    p.add_argument('--budget')
    p.add_argument('--capabilities',help='Small current host capability observation; no keys or provider configuration')
    p.add_argument('--evidence-pack',help='Explicit development comparison only')
    for command in ('guide','finish','status','resume','merge','import-series','inspect','compute','record','task','cache-put','cache-get','history','unlock','visual','describe','preflight'):
        p=commands.add_parser(command);p.add_argument('--work-dir',required=True)
        if command=='guide':
            p.add_argument('--name',choices=list(GUIDES),required=True)
            p.add_argument('--context-epoch',default='initial')
            p.add_argument('--recovery-reason',default='')
            p.add_argument('--ack')
            p.add_argument('--replay',action='store_true')
            p.add_argument('--page-chars',type=int)
        if command in ('merge','import-series','record','task','cache-put','visual','preflight'):p.add_argument('--input',required=True)
        if command=='import-series':p.add_argument('--metadata',required=True)
        if command=='inspect':
            p.add_argument('--group',required=True);p.add_argument('--id');p.add_argument('--offset',type=int,default=0);p.add_argument('--limit',type=int,default=10)
        if command=='describe':p.add_argument('--group',required=True)
        if command=='compute':p.add_argument('--ids',nargs='+')
        if command=='cache-get':p.add_argument('--id',required=True);p.add_argument('--triggers',nargs='*',default=[])
        if command=='unlock':p.add_argument('--reason',required=True)
        if command=='preflight':p.add_argument('--reason',required=True)
    args=parser.parse_args(argv)
    try:
        work=Path(args.work_dir).resolve()
        if args.command=='start':result=start(args,work);code=3 if result['phase']=='blocked' else 0
        else:
            from contextlib import nullcontext
            from storage import lock
            mutating=args.command not in ('status','resume','inspect','cache-get','history','unlock','describe')
            with lock(work) if mutating else nullcontext():
                state=read_state(work)
                if args.command=='guide':result=guide(args,work,state);code=0
                elif args.command in ('status','resume'):result=status(work,state);code=0
                elif args.command=='finish':result,code=finish(work,state)
                else:
                    import data_io
                    code=0
                    if state['phase']=='built' and args.command in ('merge','import-series'):raise ValueError('已发布输入不可覆盖，请开始新运行或修订')
                    if args.command=='merge':result=data_io.merge(work,read_json_output(args.input))
                    elif args.command=='import-series':result=data_io.import_series(work,args.input,args.metadata)
                    elif args.command=='inspect':result=data_io.inspect(work,args.group,args.id,args.offset,args.limit)
                    elif args.command=='describe':result=data_io.describe(args.group)
                    elif args.command=='compute':result=data_io.compute(work,state,args.ids)
                    elif args.command=='record':result=data_io.record(work,state,load(args.input))
                    elif args.command=='task':result=data_io.task(work,state,load(args.input))
                    elif args.command=='visual':
                        from workflow import visual_update
                        result=visual_update(work,state,read_json_output(args.input))
                    elif args.command=='preflight':
                        from workflow import update_preflight
                        result=update_preflight(work,state,args.input,args.reason)
                        code=3 if result['status']=='blocked' else 0
                    else:
                        import storage
                        root=state.get('state_root')
                        if args.command=='history':result=storage.history(root)
                        elif not root:raise ValueError('缓存/解锁需要start时显式指定 --state-root')
                        elif args.command=='cache-put':result={'path':storage.cache_put(root,load(args.input))}
                        elif args.command=='cache-get':result=storage.cache_get(root,args.id,state['contract']['initial_cutoff'],args.triggers)
                        elif args.command=='unlock':
                            path=Path(root)/'.writer.lock'
                            if path.exists():path.unlink()
                            result={'status':'unlocked','reason':args.reason}
        print(canonical(result));return code
    except CapabilityError as exc:
        from storage import lock
        from capabilities import observe_failure, summary as capability_summary
        from workflow import sync_info
        next_step='按已知宿主能力选择降级或有限重试；不调用未知API，不修改源码。'
        state_update_error=None
        try:
            if (work/'run-state.json').exists():
                with lock(work):
                    state=read_state(work)
                    if state['phase']!='built':
                        state['preflight']=observe_failure(state.get('preflight'),exc)
                        observation=capability_summary(state['preflight'])
                        state['next']=observation['next']
                        if observation['status']!='ready':
                            state['phase']={'limited_existing':'limited_research','awaiting_host_report':'needs_preflight','blocked':'blocked'}[observation['status']]
                        save(work/'run-state.json',state);sync_info(work,state)
                        next_step=state['next']
        except (ValueError,KeyError,OSError) as state_error:
            state_update_error=type(state_error).__name__+': '+str(state_error)[:200]
        if exc.capability=='structured_output':next_step='结构化通道失败；直接将单个JSON文本写入外部文件并merge，本地严格校验，不重试SDK或改源码。'
        elif exc.capability=='visual':next_step='关闭本轮视觉验收，记录not_performed；离线HTML仍可生成。'
        print(canonical(dict(status='blocked',category=exc.category,capability=exc.capability,
                             error=str(exc),next=next_step,state_update_error=state_update_error)))
        return 3
    except (ValueError,KeyError,OSError) as exc:
        print(canonical(dict(status='blocked',error=str(exc),next='按错误定位修正或保留现有状态；不重复无进展命令。')))
        return 3


if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    raise SystemExit(main())
