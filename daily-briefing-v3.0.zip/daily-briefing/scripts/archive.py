"""One local publication boundary; optional explicit host receipt handoff.

Supported atomicity: one machine, ordinary local filesystem, same-volume rename.
Catalog and index are projections; committed files are the source of truth.
"""
from __future__ import annotations
import copy
from datetime import datetime, time, timedelta, timezone, date
from html import escape
import os
from pathlib import Path
import re
import secrets
import socket
from uuid import uuid4
from common import InputError, canonical, digest, fingerprint, iso, load, localize, resolve_contract, save, stamp
from storage import lock, snapshots

FORMAT=1
SKILL=Path(__file__).resolve().parents[1]
CONFIG=Path.home()/'.daily-briefing/config.json'


def safe_path(root,relative=''):
    root=Path(root).absolute()
    rel=Path(relative)
    if rel.is_absolute() or '..' in rel.parts:raise InputError('path','路径不能绝对或越界')
    path=root/rel
    for component in path.parts:
        if component in ('/', '\\', path.anchor):continue
        if re.fullmatch(r'(?i)(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\..*)?',component) or component.endswith((' ','.')):
            raise InputError('path','路径含Windows保留组件')
    for parent in [path,*path.parents]:
        if parent.exists() and (parent.is_symlink() or getattr(parent.stat(follow_symlinks=False),'st_file_attributes',0)&1024):
            raise InputError('path','资料库路径不接受符号链接/重解析点')
    if not path.resolve().is_relative_to(root.resolve()):raise InputError('path','路径越界')
    if path.resolve().is_relative_to(SKILL.resolve()):raise InputError('archive_root','不能将Skill安装目录作为资料库')
    return path


def initialize(root,config=None,*,persistence=None,bind=False,fork=False,host_target=None):
    if persistence not in ('local_confirmed','host_handoff','ephemeral_only'):
        raise InputError('persistence','明确确认本地持久环境，或选择宿主交接/临时附件；写后读回不证明持久性','storage_required')
    root=safe_path(root);marker=safe_path(root,'.runtime/archive.json')
    if persistence=='host_handoff' and not bind:
        if not isinstance(host_target,dict) or not all(isinstance(host_target.get(k),str) and host_target[k] for k in ('archive_id','connector','directory_id','location','skill_locator','config_locator')):
            raise InputError('host_target','交接需archive_id/connector/directory_id/location/skill_locator/config_locator；不能假设远端存在','storage_required')
        if not re.fullmatch('[a-f0-9]{32}',host_target['archive_id']):raise InputError('host_target.archive_id','需32位hex')
    if marker.exists():
        archive=open_archive(root)
        if fork:
            with lock(root/'.runtime/locks',reason='explicit archive fork'):
                old=archive['archive_id'];archive.update(archive_id=uuid4().hex,forked_from=old,created_at=stamp())
                # Existing commits belong to the original identity. A fork is a fresh
                # logical namespace; copied historical data remains explicitly foreign.
                save(marker,archive)
                save(root/'.runtime/catalog.json',dict(archive_id=archive['archive_id'],publications=[]))
        elif not bind:raise InputError('archive_root','已初始化；使用configure绑定，不能重复初始化')
    else:
        if bind:raise InputError('archive_root','既有资料库标记缺失；不创建替代库','storage_required')
        if root.exists() and any(root.iterdir()):raise InputError('archive_root','初始化要求新/空目录；不覆盖未知数据')
        root.mkdir(parents=True,exist_ok=True)
        archive=dict(format_version=FORMAT,archive_id=uuid4().hex,persistence=persistence,created_at=stamp(),
                     concurrency='single_host_local' if persistence=='local_confirmed' else 'single_writer_host_confirmed')
        if host_target:archive.update(archive_id=host_target['archive_id'],host_target=host_target)
        save(marker,archive,exclusive=True)
        for name in ('runs','issues','locks','pending','cache'):safe_path(root,'.runtime/'+name).mkdir(parents=True,exist_ok=True)
        save(root/'.runtime/catalog.json',dict(archive_id=archive['archive_id'],publications=[]))
        write_index(root,[])
    if config:
        save(config,dict(config_version=1,archive_root=str(root.resolve()),archive_id=archive['archive_id'],persistence=archive['persistence']))
    return dict(status='configured',archive_root=str(root.resolve()),archive_id=archive['archive_id'],persistence=archive['persistence'],
                config=str(config) if config else None,cloud_restore_verified=False)


def open_archive(root,expected=None):
    root=safe_path(root);marker=safe_path(root,'.runtime/archive.json')
    if not root.is_dir() or not marker.is_file():raise InputError('archive_root','指定资料库不可访问或缺少archive.json；不回退cwd/临时目录','storage_required')
    data=load(marker)
    if not isinstance(data,dict) or data.get('format_version')!=FORMAT or not re.fullmatch('[a-f0-9]{32}',str(data.get('archive_id',''))):raise InputError(str(marker),'资料库标记无效')
    if expected and data['archive_id']!=expected:raise InputError('archive_id','配置与资料库身份冲突','version_conflict')
    return data


def resolve_root(args):
    if getattr(args,'archive_root',None) and getattr(args,'state_root',None) and Path(args.archive_root).resolve()!=Path(args.state_root).resolve():
        raise InputError('state_root','兼容参数与archive_root冲突；只能有一个资料库')
    explicit=getattr(args,'archive_root',None) or getattr(args,'state_root',None)
    cfgpath=Path(getattr(args,'config',None) or CONFIG)
    if explicit:
        root=Path(explicit).absolute();info=open_archive(root);return root,info
    if not cfgpath.exists():raise InputError(str(cfgpath),'没有持久资料库配置；先显式init，默认建议 '+str(Path.home()/'DailyBriefing'),'storage_required')
    cfg=load(cfgpath)
    if not isinstance(cfg,dict) or cfg.get('config_version')!=1 or not isinstance(cfg.get('archive_root'),str) or not cfg.get('archive_id'):raise InputError(str(cfgpath),'配置字段config_version/archive_root/archive_id无效')
    root=Path(cfg['archive_root'])
    if not root.is_absolute():raise InputError(str(cfgpath)+'.archive_root','必须为绝对路径，不依赖cwd')
    return root,open_archive(root,cfg['archive_id'])


def issue_contract(args,archive,now=None):
    started=iso(now or stamp());zone=args.timezone or 'Asia/Shanghai'
    edition=args.edition or ('morning' if getattr(args,'preset',None)=='premarket' else 'snapshot')
    scheduled=getattr(args,'scheduled_for',None)
    planned=localize(scheduled,zone) if scheduled else None
    target=getattr(args,'date',None) or (planned.date().isoformat() if planned else None)
    if getattr(args,'unattended',False) and edition=='morning' and not target:
        raise InputError('scheduled_for','无人值守早报须提供原计划时刻或目标日期；不猜跨日漏跑')
    cutoff=getattr(args,'cutoff',None)
    if edition=='morning':
        day=date.fromisoformat(target) if target else started.astimezone(localize(started.isoformat(),zone).tzinfo).date()
        morning=datetime.combine(day,time(8),tzinfo=localize(started.isoformat(),zone).tzinfo)
        if cutoff and localize(cutoff,zone)!=morning:raise InputError('cutoff','morning固定为目标日08:00；其他截止用snapshot新一期')
        cutoff=morning.isoformat()
    elif not cutoff:
        cutoff=(datetime.combine(date.fromisoformat(target),time(8),tzinfo=localize(started.isoformat(),zone).tzinfo).isoformat() if target else localize(started.isoformat(),zone).isoformat())
    mode=args.mode or ('historical' if target and edition!='morning' and not scheduled else 'live')
    if iso(cutoff)>started:
        return dict(status='not_due',information_cutoff=cutoff,started_at=started.isoformat(),next='目标信息截止尚未到来；立即生成需显式选择snapshot当前时点。')
    scope=sorted(set(x.strip() for x in (args.scope or ['A股','全球宏观','AI']) if x.strip()))
    profile=(args.profile or 'finance-ai').strip()
    c=resolve_contract(cutoff=cutoff,zone=zone,window=args.window_start,profile=profile,scope=scope,mode=mode,
                       evidence_mode='fixed_pack' if getattr(args,'evidence_pack',None) else 'independent')
    identity=dict(archive_id=archive['archive_id'],profile=profile,scope=scope,timezone=zone,edition=edition,
                  information_cutoff=c['initial_cutoff'],namespace=mode)
    c.update(identity,issue_key=fingerprint(identity))
    c['contract_fingerprint']=fingerprint(c)
    return dict(status='due',contract=c,started_at=started.isoformat(),scheduled_for=scheduled)


def run_path(root,run_id):
    if not re.fullmatch(r'run_[a-f0-9]{32}',str(run_id)):raise InputError('run_id','无效运行ID')
    return safe_path(root,'.runtime/runs/'+run_id)


def authenticate(state,token):
    if not isinstance(token,str) or not secrets.compare_digest(state.get('owner',{}).get('token_hash',''),fingerprint(token)):
        raise InputError('run_token','写命令需要本次拥有者token；新会话用resume --takeover --reason显式接管','ownership_conflict')


def claim(root,contract,*,revision=False,reason=None,session=None):
    recover(root)
    issue=contract['issue_key'];path=safe_path(root,'.runtime/issues/'+issue+'.json')
    with lock(root/'.runtime/locks',reason='claim issue'):
        host_history=root/'.runtime/host-history.json'
        if host_history.exists() and not revision:
            previous=[x for x in load(host_history)['entries'] if x['snapshot']['issue_contract']['issue_key']==issue]
            if previous:
                last=max(previous,key=lambda x:iso(x['committed_at']))
                if last['snapshot']['issue_contract']['contract_fingerprint']!=contract['contract_fingerprint']:raise InputError('contract','远端已发布契约不同，需显式修订','version_conflict')
                return dict(status='already_published_remote',file_id=last['file_id'],persistent_commit_id=last['persistent_commit_id'],
                            confirmed_by='host',next='使用宿主真实ID取回已提交报告，不猜链接。')
        entry=load(path) if path.exists() else dict(issue_key=issue,contract_fingerprint=contract['contract_fingerprint'],runs=[],publications=[])
        if entry['issue_key']!=issue:raise InputError('issue_key','完整期号碰撞','version_conflict')
        if entry.get('remote_receipts') and not revision:
            if entry['contract_fingerprint']!=contract['contract_fingerprint']:raise InputError('contract','远端已发布契约不同','version_conflict')
            return dict(status='already_published_remote',receipt=entry['remote_receipts'][-1],confirmed_by='host')
        if entry['publications'] and not revision:
            if entry['contract_fingerprint']!=contract['contract_fingerprint']:raise InputError('contract','同一期请求窗口/契约变化，需显式修订','version_conflict')
            publication=verify(root,entry['publications'][-1])
            return dict(status='already_published',publication=publication,archive_root=str(root),run_id=publication['run_id'])
        if entry['runs']:
            previous=run_path(root,entry['runs'][-1])
            if not (previous/'run-state.json').exists():
                return dict(status='initializing_or_interrupted',run_id=entry['runs'][-1],work_dir=str(previous),
                    next='已有一期初始化认领，不能并发重建。核对该执行；初始化中断需显式恢复，保留现场。')
            if (previous/'run-state.json').exists():
                st=load(previous/'run-state.json')
                if st['phase'] not in ('published','persistent_confirmed'):
                    if st['contract']['contract_fingerprint']!=contract['contract_fingerprint']:raise InputError('contract','未完成运行契约不同；不能重置预算','version_conflict')
                    return dict(status='resumable',run_id=st['run_id'],work_dir=str(previous),archive_root=str(root),next='返回原状态；显式resume接管后继续，不再次开始研究。')
        if revision and (not reason or not (entry['publications'] or entry.get('remote_receipts'))):raise InputError('revision','修订需已有发布及具体原因')
        rid='run_'+uuid4().hex;token='rt_'+secrets.token_urlsafe(24)
        owner=dict(token_hash=fingerprint(token),session_id=session,host=socket.gethostname(),claimed_at=stamp())
        work=run_path(root,rid);work.mkdir(parents=True,exist_ok=False)
        parent_revision=len(entry['publications'])+len(entry.get('remote_receipts',[]))
        save(work/'claim.json',dict(run_id=rid,contract=contract,owner=owner,parent_revision=parent_revision,
              revision_reason=reason,started_at=stamp(),scheduled_for=None,archive_root=str(root)),exclusive=True)
        entry['runs'].append(rid);entry['contract_fingerprint']=contract['contract_fingerprint'];save(path,entry)
        return dict(status='new',run_id=rid,run_token=token,owner=owner,work_dir=str(work),
                    parent_revision=parent_revision,revision_reason=reason)


def research_projection(d):
    data=copy.deepcopy(d)
    data.pop('visual',None);data.pop('charts',None)
    for k in ('run_id','title','author','section_titles','featured_metrics'):data['meta'].pop(k,None)
    return data


def definition(item):
    if 'definition' in item:return item['definition']
    horizons={key:{k:v for k,v in h.items() if k not in ('review_at','claim_ids','next_observation')} for key,h in item['horizons'].items()}
    return dict(conclusion=item['conclusion'],support=item['support'],invalidation=item['invalidation'],
                assumptions=item['assumptions'],expires_at=item['expires_at'],horizons=horizons)


def verify(root,relative):
    directory=safe_path(root,relative);commit=load(directory/'commit.json')
    if not isinstance(commit,dict) or commit.get('format_version')!=FORMAT:raise InputError('commit','提交结构无效')
    if not isinstance(commit.get('files'),dict) or set(commit['files'])!={'snapshot.json',commit.get('html_name')}:
        raise InputError('commit.files','提交必须包含且仅包含独立快照与HTML','archive_corrupt')
    for name,sha in commit['files'].items():
        if Path(name).name!=name or digest(safe_path(directory,name))!=sha:raise InputError('commit.files','归档字节损坏: '+name,'archive_corrupt')
    snapshot=load(directory/'snapshot.json')
    if snapshot['issue_contract']['issue_key']!=commit['issue_key'] or snapshot['research_hash']!=commit['research_hash']:raise InputError('commit','快照/提交身份不一致','archive_corrupt')
    return dict(commit,relative_path=relative)


def catalog(root):
    p=root/'.runtime/catalog.json'
    if not p.exists():raise InputError('catalog','目录缓存缺失；显式rebuild-index从受控提交目录重建','index_required')
    c=load(p)
    if c.get('archive_id')!=open_archive(root)['archive_id']:raise InputError('catalog','资料库身份不同','version_conflict')
    return c


def write_index(root,publications):
    rows=[];month=None
    for c in sorted(publications,key=lambda x:(x['date'],x['information_cutoff'],x['revision']),reverse=True):
        if c['date'][:7]!=month:
            month=c['date'][:7];rows.append('<h2>'+escape(month)+'</h2>')
        relative=c['relative_path']+'/'+c['html_name']
        from urllib.parse import quote
        label={'morning':'早报','snapshot':'即时简报'}[c['edition']]
        grade={'full':'完整研究（程序门槛）','limited':'有限覆盖','observation':'观察版','draft':'草稿'}[c['grade']]
        namespace={'live':'实时研究','historical':'历史重建','teaching':'合成教学'}[c['namespace']]
        rows.append('<p><a href="'+quote(relative,safe='/')+'">'+escape(c['date']+' '+label+' r'+str(c['revision']))+'</a> · '+namespace+' · 截止 '+escape(c['information_cutoff'])+' · 生成 '+escape(c['generated_at'])+' · '+grade+'<br>'+escape('；'.join(c['limitations']))+'</p>')
    content='<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>财经简报档案</title><style>body{max-width:1000px;margin:32px auto;padding:16px;font:16px/1.8 sans-serif}a{overflow-wrap:anywhere}p{border-bottom:1px solid #ddd;padding:12px}</style><h1>财经简报档案</h1>'+''.join(rows)+'</html>'
    temporary=root/('.index-'+uuid4().hex+'.tmp');temporary.write_text(content,encoding='utf-8');os.replace(temporary,root/'index.html')


def update_views(root,relative):
    committed=verify(root,relative)
    c=catalog(root)
    same=[x for x in c['publications'] if x['issue_key']==committed['issue_key'] and x['revision']==committed['revision']]
    if same and same[0]['files']!=committed['files']:raise InputError('catalog','同一期修订内容冲突','version_conflict')
    if not same:c['publications'].append(committed)
    save(root/'.runtime/catalog.json',c)
    ip=root/'.runtime/issues'/(committed['issue_key']+'.json')
    entry=load(ip) if ip.exists() else dict(issue_key=committed['issue_key'],runs=[],publications=[],contract_fingerprint=committed['contract_fingerprint'])
    if relative not in entry['publications']:entry['publications'].append(relative)
    entry['publications'].sort(key=lambda x:verify(root,x)['revision'])
    if committed['run_id'] not in entry['runs']:entry['runs'].append(committed['run_id'])
    save(ip,entry);write_index(root,c['publications'])


def recover(root):
    root=Path(root);open_archive(root)
    pending=root/'.runtime/pending'
    for path in sorted(pending.glob('*.json')):
        intent=load(path);target=safe_path(root,intent['target'])
        if target.exists():
            with lock(root/'.runtime/locks',reason='recover known pending commit'):
                update_views(root,intent['target']);path.unlink()


def rebuild(root):
    root=Path(root);a=open_archive(root)
    with lock(root/'.runtime/locks',reason='explicit rebuild views'):
        commits=[]
        for day in root.iterdir():
            if not day.is_dir() or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',day.name):continue
            for directory in day.iterdir():
                if directory.is_dir() and (directory/'commit.json').exists():
                    c=verify(root,directory.relative_to(root).as_posix())
                    if c['archive_id']==a['archive_id']:commits.append(c)
        save(root/'.runtime/catalog.json',dict(archive_id=a['archive_id'],publications=commits))
        for c in commits:update_views(root,c['relative_path'])
        write_index(root,commits)
    return dict(status='rebuilt',publications=len(commits),archive_root=str(root))


def historical(root,cutoff,namespace='live',limit=12,strict=True):
    recover(root);c=catalog(Path(root));point=iso(cutoff)
    commits=[x for x in c['publications'] if x['namespace']==namespace and iso(x['information_cutoff'])<=point
             and (not strict or iso(x['committed_at'])<=point)]
    host_snapshots={};hp=Path(root)/'.runtime/host-history.json'
    if hp.exists():
        hd=load(hp)
        for entry in hd['entries']:
            snap=entry['snapshot'];ic=snap['issue_contract']
            if ic['namespace']!=namespace or iso(ic['information_cutoff'])>point or (strict and iso(entry['committed_at'])>point):continue
            key='host:'+entry['persistent_commit_id'];host_snapshots[key]=snap
            commits.append(dict(namespace=namespace,information_cutoff=ic['information_cutoff'],committed_at=entry['committed_at'],revision=1,
                relative_path=key,history_status='projected',file_id=entry['file_id']))
    latest={};conflicts=[]
    # Information order, never mtime. Visual copies do not introduce new events.
    for commit in sorted(commits,key=lambda x:(x['information_cutoff'],x['committed_at'],x['revision'])):
        if commit['relative_path'] in host_snapshots:verified=commit;snap=host_snapshots[commit['relative_path']]
        else:verified=verify(root,commit['relative_path']);snap=load(safe_path(root,commit['relative_path'])/'snapshot.json')
        if commit['history_status']=='history_conflict':conflicts.extend(commit.get('history_conflicts',[]));continue
        if commit['history_status']=='historical_only':continue
        for item in snap['theses']:
            old=latest.get(item['thesis_id']);sig=fingerprint(definition(item));prior=item.get('update') or {}
            if old and old['definition_hash']==sig:
                if item['version']!=old['version']:conflicts.append(dict(thesis_id=item['thesis_id'],reason='相同定义不应推进语义版本'));continue
            elif old:
                if item['version']!=old['version']+1 or prior.get('previous_version')!=old['version'] or not prior.get('new_evidence_ids') or prior.get('status')=='maintained':
                    conflicts.append(dict(thesis_id=item['thesis_id'],publication=commit['relative_path'],reason='父版本/定义冲突，未应用'));continue
            elif item['version']!=1:conflicts.append(dict(thesis_id=item['thesis_id'],reason='缺少初始观点版本'));continue
            latest[item['thesis_id']]=dict(item,definition_hash=sig,publication=commit['relative_path'],committed_at=verified['committed_at'])
    active=[]
    for ident,item in latest.items():
        if item['status'] in ('retired','refuted'):continue
        active.append(dict(thesis_id=ident,version=item['version'],theme_id=item['theme_id'],conclusion=item['conclusion'][:600],
             support=item['support'][:400],invalidation=item['invalidation'][:400],publication=item['publication'],
             due=iso(item['review_at'])<=point,expired=iso(item['expires_at'])<=point,priority=item['priority']))
    active.sort(key=lambda x:(not x['due'],x['priority'],x['thesis_id']))
    return dict(cold_start=not commits,cutoff=cutoff,namespace=namespace,strict_recorded_time=strict,active=active[:limit],
                active_total=len(active),omitted=max(0,len(active)-limit),conflicts=conflicts[-limit:],
                recent=[dict(path=x['relative_path'],cutoff=x['information_cutoff']) for x in sorted(commits,key=lambda x:x['information_cutoff'],reverse=True)[:limit]],
                host_history_status='loaded_host_confirmed' if hp.exists() else 'not_restored' if open_archive(root)['persistence']=='host_handoff' else 'not_applicable')


def publish(root,work,state,d,checks,*,render_only=False):
    """Retry-safe staging then one same-filesystem directory rename."""
    root=Path(root);work=Path(work);a=open_archive(root,state['contract']['archive_id']);recover(root)
    current_hash=fingerprint(d);research_hash=fingerprint(research_projection(d));c=state['contract']
    if state.get('publication'):
        result=verify(root,state['publication'])
        if state['published_input_hash']!=current_hash:raise InputError('input','已发布输入被改变；显式修订，不换文件名绕过','version_conflict')
        return dict(status='published',publication=result,output=str(safe_path(root,state['publication'])/result['html_name']))
    prepared=work/'prepared.json'
    if prepared.exists():
        plan=load(prepared)
        if plan['input_hash']!=current_hash:raise InputError('prepared','已经锁定生成输入；归档重试不能改研究数据','version_conflict')
        checks=load(work/'validated-checks.json')
        if fingerprint(checks)!=plan['checks_hash']:raise InputError('prepared.checks','已锁定检查结果被修改','version_conflict')
    else:
        rev=state['parent_revision']+1;clock=iso(c['information_cutoff']).strftime('%H%M%S')
        relative=f"{c['date']}/{c['edition']}-{clock}-{c['issue_key'][:12]}-r{rev:03d}"
        name=f"{c['date']}_{'早报' if c['edition']=='morning' else '即时简报'}_{clock[:4]}_r{rev:03d}.html"
        plan=dict(input_hash=current_hash,research_hash=research_hash,checks_hash=fingerprint(checks),generated_at=stamp(),revision=rev,target=relative,html_name=name,
                  stage='.runtime/runs/'+state['run_id']+'/stage')
        save(work/'validated-checks.json',checks)
        save(prepared,plan,exclusive=True)
    stage=safe_path(root,plan['stage']);target=safe_path(root,plan['target'])
    # Commit may exist after response loss, before RunState was updated.
    if target.exists():
        existing=verify(root,plan['target'])
        if existing['issue_key']!=c['issue_key'] or existing['run_id']!=state['run_id'] or existing['input_hash']!=current_hash:raise InputError('publication','目标已有不同提交，保留冲突候选','version_conflict')
    else:
        stage.mkdir(parents=True,exist_ok=True)
        snapshot=dict(format_version=FORMAT,issue_contract=c,document=d,checks=checks,research_hash=research_hash,
                      recorded_at=plan['generated_at'],theses=snapshots(d,checks))
        if not (stage/'snapshot.json').exists():save(stage/'snapshot.json',snapshot)
        elif load(stage/'snapshot.json')!=snapshot:raise InputError('stage.snapshot','暂存快照与锁定输入不一致','version_conflict')
        if not (stage/plan['html_name']).exists():
            from render import render_report
            html=render_report(d,checks)
            temporary=stage/'report.tmp';temporary.write_text(html,encoding='utf-8');os.replace(temporary,stage/plan['html_name'])
        save(work/'publish-plan.json',dict(archive_id=a['archive_id'],issue_key=c['issue_key'],run_id=state['run_id'],
             revision=plan['revision'],research_hash=research_hash,target=plan['target'],files=[dict(name=n,sha256=digest(stage/n)) for n in ('snapshot.json',plan['html_name'])],
             persistence=a['persistence'],concurrency='single_writer_no_remote_CAS'))
        if a['persistence']!='local_confirmed':
            return dict(status='ephemeral_only' if a['persistence']=='ephemeral_only' else 'archive_unconfirmed',
                        publish_plan=str(work/'publish-plan.json'),output=str(stage/plan['html_name']),cloud_restore_verified=False)
        with lock(root/'.runtime/locks',reason='commit complete publication'):
            entry=load(root/'.runtime/issues'/(c['issue_key']+'.json'))
            if len(entry['publications'])!=state['parent_revision']:raise InputError('publication.parent_revision','提交基线已改变，保留候选不覆盖','version_conflict')
            if target.exists():raise InputError('publication','并发目标冲突','version_conflict')
            prior=historical_unlocked(root,c['initial_cutoff'],c['namespace'])
            # Conflicting semantic updates never make a valid report disappear.
            conflicts=semantic_conflicts(prior,snapshot['theses'])
            newer=[x for x in catalog(root)['publications'] if x['namespace']==c['namespace'] and iso(x['information_cutoff'])>iso(c['information_cutoff'])]
            commit=dict(format_version=FORMAT,archive_id=a['archive_id'],issue_key=c['issue_key'],contract_fingerprint=c['contract_fingerprint'],
                run_id=state['run_id'],revision=plan['revision'],parent_revision=state['parent_revision'],reason=state.get('revision_reason'),
                input_hash=current_hash,research_hash=research_hash,render_revision=plan['revision'],namespace=c['namespace'],date=c['date'],edition=c['edition'],
                information_cutoff=c['information_cutoff'],started_at=state['created_at'],scheduled_for=state.get('scheduled_for'),
                generated_at=plan['generated_at'],committed_at=stamp(),html_name=plan['html_name'],grade=checks['delivery']['grade'],
                limitations=checks['delivery']['reasons'],history_status='history_conflict' if conflicts else 'historical_only' if newer else 'projected',history_conflicts=conflicts,
                files={n:digest(stage/n) for n in ('snapshot.json',plan['html_name'])})
            save(stage/'commit.json',commit)
            save(root/'.runtime/pending'/(state['run_id']+'.json'),dict(target=plan['target'],run_id=state['run_id']))
            target.parent.mkdir(parents=True,exist_ok=True)
            os.rename(stage,target)
    try:
        with lock(root/'.runtime/locks',reason='project committed publication'):
            update_views(root,plan['target']);(root/'.runtime/pending'/(state['run_id']+'.json')).unlink(missing_ok=True)
        publication_status='published'
    except (OSError,ValueError):publication_status='published_index_pending'
    state.update(publication=plan['target'],published_input_hash=current_hash,phase='published',output=plan['target']+'/'+plan['html_name'])
    save(work/'run-state.json',state)
    return dict(status=publication_status,publication=verify(root,plan['target']),output=str(target/plan['html_name']),index=str(root/'index.html'))


def historical_unlocked(root,cutoff,namespace):
    """Small definitions read inside commit lock; no second history store."""
    records=catalog(root)['publications'];latest={}
    for c in sorted((x for x in records if x['namespace']==namespace and x['information_cutoff']<=cutoff),key=lambda x:(x['information_cutoff'],x['committed_at'])):
        if c['history_status']=='history_conflict':continue
        snap=load(safe_path(root,c['relative_path'])/'snapshot.json')
        for x in snap['theses']:latest[x['thesis_id']]=x
    return latest


def semantic_conflicts(previous,items):
    errors=[]
    for item in items:
        old=previous.get(item['thesis_id']);update=item.get('update') or {}
        if not old:
            if item['version']!=1:errors.append(dict(thesis_id=item['thesis_id'],reason='初始版本不是1'))
        elif definition(item)==definition(old):
            if item['version']!=old['version']:errors.append(dict(thesis_id=item['thesis_id'],reason='复核/展示变化不能推进语义版本'))
        elif update.get('status')=='maintained' or item['version']!=old['version']+1 or update.get('previous_version')!=old['version'] or not update.get('new_evidence_ids'):
            errors.append(dict(thesis_id=item['thesis_id'],reason='语义定义/父版本冲突；未应用历史'))
    return errors


def confirm_host(root,work,state,receipt):
    plan=load(Path(work)/'publish-plan.json')
    target=open_archive(root).get('host_target')
    if not target:raise InputError('host_target','未配置真实宿主持久目标','storage_required')
    if not isinstance(receipt,dict):raise InputError('receipt','回执需要对象')
    for key in ('archive_id','issue_key','run_id','revision'):
        if receipt.get(key)!=plan[key]:raise InputError('receipt.'+key,'回执身份不一致','version_conflict')
    if receipt.get('host_confirmed') is not True or not receipt.get('persistent_commit_id'):raise InputError('receipt','需要宿主真实持久提交ID及确认','archive_unconfirmed')
    if receipt.get('directory_id')!=target['directory_id']:raise InputError('receipt.directory_id','回执不是配置的持久目录','version_conflict')
    actual=receipt.get('files')
    if not isinstance(actual,list):raise InputError('receipt.files','缺少上传回执')
    if not all(isinstance(x,dict) and isinstance(x.get('file_id'),str) for x in actual) or len(actual)!=len(plan['files']) or len({x.get('file_id') for x in actual})!=len(actual):raise InputError('receipt.files','不完整或重复文件ID')
    for expected in plan['files']:
        found=[x for x in actual if isinstance(x,dict) and x.get('name')==expected['name']]
        if len(found)!=1 or found[0].get('sha256')!=expected['sha256'] or not found[0].get('file_id') or not found[0].get('actual_location'):
            raise InputError('receipt.files','必须绑定真实ID、实际定位（可能被重命名）及hash','archive_unconfirmed')
    old=Path(work)/'host-receipt.json'
    if old.exists() and load(old)!=receipt:raise InputError('receipt','已有不同回执；保留冲突，不最后写入胜','version_conflict')
    if not old.exists():save(old,receipt,exclusive=True)
    with lock(Path(root)/'.runtime/locks',reason='host confirmed publication projection'):
        ip=Path(root)/'.runtime/issues'/(state['contract']['issue_key']+'.json');entry=load(ip)
        existing=entry.setdefault('remote_receipts',[])
        same=[x for x in existing if x['revision']==receipt['revision']]
        if same and same[0]!=receipt:raise InputError('receipt','同一期远端提交冲突','version_conflict')
        if not same:existing.append(receipt)
        save(ip,entry)
    state.update(phase='persistent_confirmed',host_receipt='host-receipt.json');save(Path(work)/'run-state.json',state)
    return dict(status='persistent_confirmed',confirmed_by='host',receipt=receipt,remote_CAS=False,independent_cloud_restore_tested=False)

def restore_host(root,bundle):
    """Host-downloaded snapshots; no connector API or independent remote claim."""
    a=open_archive(root);target=a.get('host_target')
    if not target or not isinstance(bundle,dict) or bundle.get('archive_id')!=a['archive_id'] or bundle.get('directory_id')!=target['directory_id']:
        raise InputError('restore','恢复资料库/目录身份不一致')
    if bundle.get('listing_complete') is not True or bundle.get('next_cursor') is not None or not bundle.get('commit_baseline'):
        raise InputError('restore.listing','分页未完成或无提交基准，不能声称连续历史已恢复','archive_unconfirmed')
    entries=bundle.get('snapshots')
    if not isinstance(entries,list):raise InputError('restore.snapshots','需要已下载快照列表')
    validated=[]
    for e in entries:
        if not isinstance(e,dict) or not all(e.get(k) for k in ('file_id','local_file','sha256','committed_at','persistent_commit_id')):raise InputError('restore.snapshot','缺真实ID/hash/提交身份')
        if digest(e['local_file'])!=e['sha256']:raise InputError('restore.sha256','下载hash不符')
        snap=load(e['local_file'])
        if snap['issue_contract']['archive_id']!=a['archive_id']:raise InputError('restore.archive_id','快照属于其他库')
        from validation import validate
        result=validate(snap['document'],snap['issue_contract'])
        if result['errors']:raise InputError('restore.document','研究快照不合法')
        validated.append(dict(file_id=e['file_id'],persistent_commit_id=e['persistent_commit_id'],committed_at=e['committed_at'],snapshot=snap))
    save(Path(root)/'.runtime/host-history.json',dict(archive_id=a['archive_id'],listing_complete=True,commit_baseline=bundle['commit_baseline'],entries=validated,restored_at=stamp(),confirmed_by='host'))
    return dict(status='host_history_loaded',snapshots=len(validated),confirmed_by='host',independent_cloud_restore_tested=False)
