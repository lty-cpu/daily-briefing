#!/usr/bin/env python3
"""Archive-based research runner. No scheduler or provider API calls."""
import argparse
import json
from pathlib import Path
import secrets
import sys
if sys.version_info < (3,10):
    print(json.dumps({'status':'blocked','category':'capability_unavailable','error':'Python 3.10+ required'}));raise SystemExit(3)
sys.dont_write_bytecode=True
from common import InputError, VERSION, fingerprint, load, save, stamp
from workflow import GUIDES, start, read_state, guide, finish, status, sync_info
from capabilities import CapabilityError, read_json_output
import archive
from storage import lock


class InputParser(argparse.ArgumentParser):
    def error(self,message):raise InputError('arguments',message)


def main(argv=None):
    p=InputParser(description=__doc__);commands=p.add_subparsers(dest='command',required=True,parser_class=InputParser)
    for name in ('init','configure','start','resume','status','finish','guide','merge','import-series','inspect','compute','record','task','cache-put','cache-get','history','unlock','visual','describe','rebuild-index','confirm-archive','restore-archive','preflight'):
        q=commands.add_parser(name)
        q.add_argument('--archive-root');q.add_argument('--config');q.add_argument('--work-dir');q.add_argument('--state-root')
        q.add_argument('--run-id');q.add_argument('--run-token')
        if name in ('init','configure'):
            q.add_argument('--persistence',choices=['local_confirmed','host_handoff','ephemeral_only'])
            q.add_argument('--host-target');q.add_argument('--save-config',action='store_true');q.add_argument('--fork',action='store_true')
        if name=='start':
            q.add_argument('--edition',choices=['morning','snapshot']);q.add_argument('--cutoff');q.add_argument('--date')
            q.add_argument('--scheduled-for');q.add_argument('--unattended',action='store_true')
            q.add_argument('--timezone',default='Asia/Shanghai');q.add_argument('--window-start');q.add_argument('--profile')
            q.add_argument('--scope',nargs='+');q.add_argument('--mode',choices=['live','historical','teaching'])
            q.add_argument('--preset',choices=['premarket']);q.add_argument('--model',default='unknown');q.add_argument('--harness',default='unknown')
            q.add_argument('--reasoning',default='unknown');q.add_argument('--budget');q.add_argument('--capabilities');q.add_argument('--evidence-pack')
            q.add_argument('--revise',action='store_true');q.add_argument('--reason');q.add_argument('--session-id')
        if name=='resume':q.add_argument('--takeover',action='store_true');q.add_argument('--reason');q.add_argument('--session-id')
        if name=='guide':
            q.add_argument('--name',choices=list(GUIDES),required=True);q.add_argument('--context-epoch',default='initial')
            q.add_argument('--recovery-reason',default='');q.add_argument('--ack');q.add_argument('--replay',action='store_true');q.add_argument('--page-chars',type=int)
        if name in ('merge','import-series','record','task','cache-put','visual','confirm-archive','restore-archive','preflight'):q.add_argument('--input',required=True)
        if name=='import-series':q.add_argument('--metadata',required=True)
        if name in ('inspect','describe'):q.add_argument('--group',required=True)
        if name=='inspect':q.add_argument('--id');q.add_argument('--offset',type=int,default=0);q.add_argument('--limit',type=int,default=10)
        if name=='compute':q.add_argument('--ids',nargs='+')
        if name=='cache-get':q.add_argument('--id',required=True);q.add_argument('--triggers',nargs='*',default=[])
        if name=='history':q.add_argument('--cutoff',required=True);q.add_argument('--namespace',choices=['live','historical','teaching'],default='live')
        if name=='preflight':q.add_argument('--reason',required=True)
        if name=='unlock':q.add_argument('--lock-target',choices=['run','commit'],required=True);q.add_argument('--lock-id',required=True);q.add_argument('--reason',required=True)
    try:
        args=p.parse_args(argv)
        result,code=execute(args)
    except (InputError,CapabilityError) as exc:
        result=dict(status='blocked',category=exc.category,path=getattr(exc,'path',getattr(exc,'capability','runtime')),error=str(exc));code=3
    except (ValueError,KeyError,TypeError) as exc:
        result=dict(status='blocked',category='input_error',path='input',error=str(exc));code=2
    except OSError as exc:
        result=dict(status='blocked',category='infrastructure_error',error=str(exc),next='原状态保留；仅重试存储阶段，不重做研究。');code=3
    except KeyboardInterrupt:
        result=dict(status='interrupted',category='interrupted');code=130
    except Exception as exc:
        result=dict(status='blocked',category='program_defect',error=type(exc).__name__+': '+str(exc));code=4
    # Keep acknowledgement after page content. Canonical JSON is for hashes only.
    print(json.dumps(result,ensure_ascii=False,allow_nan=False));return code


def execute(args):
    cmd=args.command
    if cmd in ('init','configure'):
        root=Path(args.archive_root).absolute() if args.archive_root else Path.home()/'DailyBriefing'
        config=Path(args.config) if args.config else archive.CONFIG if args.save_config else None
        return archive.initialize(root,config,persistence=args.persistence or ('local_confirmed' if cmd=='configure' else None),bind=cmd=='configure',fork=args.fork,host_target=load(args.host_target) if args.host_target else None),0
    root,info=archive.resolve_root(args)
    if cmd=='rebuild-index':return archive.rebuild(root),0
    archive.recover(root)
    if cmd=='history':return archive.historical(root,args.cutoff,args.namespace),0
    if cmd=='start':
        if args.work_dir:
            work=Path(args.work_dir).resolve();old=read_state(work)
            if not work.is_relative_to(root/'.runtime/runs'):raise InputError('work_dir','兼容工作目录必须属于该资料库runtime；旧目录需要显式迁移')
            requested=archive.issue_contract(args,info)
            if requested.get('contract',{}).get('contract_fingerprint')!=old['contract']['contract_fingerprint']:raise InputError('contract','工作目录存在不同契约，不能静默恢复','version_conflict')
            return status(work,old),0
        if args.run_id:
            work=archive.run_path(root,args.run_id);st=read_state(work)
            if args.cutoff and args.cutoff!=st['contract']['initial_cutoff']:raise InputError('cutoff','重试不能改变截止','version_conflict')
            return status(work,st),0
        resolved=archive.issue_contract(args,info)
        if resolved['status']=='not_due':return resolved,0
        claimed=archive.claim(root,resolved['contract'],revision=args.revise,reason=args.reason,session=args.session_id)
        if claimed['status']!='new':
            if claimed['status']=='already_published':claimed['output']=str(archive.safe_path(root,claimed['publication']['relative_path'])/claimed['publication']['html_name'])
            return claimed,0
        initial=dict(claimed,**resolved,archive_root=str(root))
        args.cutoff=resolved['contract']['initial_cutoff'];args.mode=resolved['contract']['mode'];args.profile=resolved['contract']['profile'];args.scope=resolved['contract']['scope']
        result=start(args,Path(claimed['work_dir']),initial)
        result.update(run_id=claimed['run_id'],run_token=claimed['run_token'],issue_key=resolved['contract']['issue_key'],archive_root=str(root))
        return result,3 if result['phase']=='blocked' else 0
    if not args.run_id and not args.work_dir:raise InputError('run_id','需要start返回的run_id；不猜最近运行')
    work=archive.run_path(root,args.run_id) if args.run_id else Path(args.work_dir).resolve()
    if not work.is_relative_to(root/'.runtime/runs'):raise InputError('work_dir','工作目录不属于所选资料库')
    if not (work/'run-state.json').exists() and cmd=='resume' and args.takeover and args.reason:
        reservation=load(work/'claim.json');token='rt_'+secrets.token_urlsafe(24)
        reservation['owner']=dict(token_hash=fingerprint(token),session_id=args.session_id,claimed_at=stamp(),recovery_reason=args.reason)
        reservation['archive_root']=str(root)
        c=reservation['contract']
        recovery=argparse.Namespace(evidence_pack=None,cutoff=c['initial_cutoff'],date=None,preset=None,timezone=c['timezone'],
             window_start=c['requested_window_start'],profile=c['profile'],scope=c['scope'],mode=c['mode'],budget=None,
             state_root=str(root),capabilities=None,model='unknown',harness='unknown',reasoning='unknown')
        result=start(recovery,work,reservation);result.update(run_id=reservation['run_id'],run_token=token)
        return result,0
    state=read_state(work)
    if state['contract']['archive_id']!=info['archive_id']:raise InputError('archive_id','运行属于另一个资料库','version_conflict')
    # Root relocation is not a contract change; root itself never enters issue identity.
    state['state_root']=str(root)
    if cmd=='status':return status(work,state),0
    if cmd=='resume':
        if not args.takeover:return dict(status(work,state),next='需要写入时使用resume --takeover --reason明确认领'),0
        if not args.reason:raise InputError('reason','显式接管必须说明原执行已停止/迁移原因')
        with lock(work,reason='explicit owner takeover'):
            state=read_state(work);state['state_root']=str(root);state.setdefault('owners',[]).append(dict(previous=state['owner'],reason=args.reason,at=stamp()))
            token='rt_'+secrets.token_urlsafe(24);state['owner']=dict(token_hash=fingerprint(token),session_id=args.session_id,claimed_at=stamp());save(work/'run-state.json',state)
        return dict(status(work,state),run_id=state['run_id'],run_token=token),0
    if cmd=='unlock':
        from storage import unlock
        return unlock(work if args.lock_target=='run' else root/'.runtime/locks',args.lock_id,args.reason),0
    read_only=cmd in ('inspect','describe','cache-get')
    if not read_only:archive.authenticate(state,args.run_token)
    from contextlib import nullcontext
    with nullcontext() if read_only else lock(work,reason=cmd,owner=state['owner']['token_hash']):
        import data_io
        if cmd=='finish':return finish(work,state)
        if cmd=='guide':return guide(args,work,state),0
        if cmd=='confirm-archive':return archive.confirm_host(root,work,state,load(args.input)),0
        if cmd=='restore-archive':return archive.restore_host(root,load(args.input)),0
        if cmd=='preflight':
            from workflow import update_preflight
            result=update_preflight(work,state,args.input,args.reason);return result,3 if result['status']=='blocked' else 0
        if cmd=='visual':
            from workflow import visual_update
            return visual_update(work,state,read_json_output(args.input)),0
        if state['phase'] in ('published','persistent_confirmed') and cmd in ('merge','import-series'):raise InputError('input','已发布数据不可改，显式修订','version_conflict')
        if cmd=='merge':return data_io.merge(work,read_json_output(args.input)),0
        if cmd=='import-series':return data_io.import_series(work,args.input,args.metadata),0
        if cmd=='inspect':return data_io.inspect(work,args.group,args.id,args.offset,args.limit),0
        if cmd=='describe':return data_io.describe(args.group),0
        if cmd=='compute':
            result=data_io.compute(work,state,args.ids);return result,2 if result['error_count'] else 0
        if cmd=='record':return data_io.record(work,state,load(args.input)),0
        if cmd=='task':return data_io.task(work,state,load(args.input)),0
        import storage
        if cmd=='cache-put':return dict(path=storage.cache_put(root/'.runtime',load(args.input))),0
        if cmd=='cache-get':return storage.cache_get(root/'.runtime',args.id,state['contract']['initial_cutoff'],args.triggers),0
    raise InputError('command','未实现命令')


if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8');raise SystemExit(main())
