(() => {
  'use strict';
  const tip = document.querySelector('.chart-tip');
  document.querySelectorAll('[data-tip]').forEach(el => {
    el.setAttribute('tabindex', '0');
    el.setAttribute('aria-label', el.dataset.tip);
    el.addEventListener('focus', () => {
      const r = el.getBoundingClientRect();
      tip.textContent = el.dataset.tip; tip.hidden = false;
      tip.style.left = Math.max(8, Math.min(r.left, innerWidth - tip.offsetWidth - 10)) + 'px';
      tip.style.top = Math.max(8, Math.min(r.bottom + 8, innerHeight - tip.offsetHeight - 10)) + 'px';
    });
    el.addEventListener('blur', () => tip.hidden = true);
    el.addEventListener('keydown', e => { if (e.key === 'Escape') tip.hidden = true; });
    el.addEventListener('pointermove', e => {
      tip.textContent = el.dataset.tip; tip.hidden = false;
      tip.style.left = Math.max(8, Math.min(e.clientX + 12, innerWidth - tip.offsetWidth - 10)) + 'px';
      tip.style.top = Math.max(8, Math.min(e.clientY + 14, innerHeight - tip.offsetHeight - 10)) + 'px';
    });
    el.addEventListener('pointerleave', () => tip.hidden = true);
  });
  document.querySelectorAll('[data-print]').forEach(b => b.addEventListener('click', () => print()));
  document.querySelectorAll('[data-expand]').forEach(b => b.addEventListener('click', () => {
    const opened = b.getAttribute('aria-pressed') !== 'true';
    document.querySelectorAll('main details').forEach(d => d.open = opened);
    document.querySelectorAll('[data-expand]').forEach(x => { x.setAttribute('aria-pressed', String(opened)); x.textContent = opened ? '收起证据与数据' : '展开证据与数据'; });
  }));
  document.querySelectorAll('a[href^="#"]').forEach(a => a.addEventListener('click', () => {
    const target = document.getElementById(a.getAttribute('href').slice(1));
    let p = target;
    while (p) { if (p.tagName === 'DETAILS') p.open = true; p = p.parentElement; }
  }));
  let printState = [];
  addEventListener('beforeprint', () => { printState = [...document.querySelectorAll('details')].map(d => [d, d.open]); printState.forEach(([d]) => d.open = true); });
  addEventListener('afterprint', () => printState.forEach(([d, open]) => d.open = open));
})();
