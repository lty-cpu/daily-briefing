# 一期资料库、发布和恢复

## 本地初始化与定位

只在确认本地持久环境后执行`run.py init --persistence local_confirmed --save-config`。不传archive-root时使用并回显`Path.home()/DailyBriefing`，用户指定位置优先。自定根目录加`--archive-root <绝对路径>`；自定配置文件加`--config <绝对JSON路径>`。配置文件在Skill外，不能位于一次性沙箱。已初始化库用`configure --archive-root <现有库> --save-config`；标记缺失或挂载失联时不重新创建替代库。

优先级为本次archive-root、显式config、用户级config。配置绑定archive_id，换模型、cwd或Skill版本不改变它。搬家时停用旧写入口，复制整个库，再configure新位置。独立分叉要`configure --archive-root <副本> --fork --save-config`，产生新身份；原归档仍属于原身份，不混作同一事务库。不支持未经验证的同步盘跨机并写。

唯一正式布局为`<日期>/<版型>-<HHMMSS>-<短码>-rNNN/`，内含中文HTML文件名、snapshot.json及commit.json。工作输入、能力、预算、工件和恢复记录在`.runtime/runs/<run_id>/`。短码仅用于展示，冲突核对完整issue_key。index.html和.runtime/catalog.json可重建，不是事实来源。日期、截止和排序由契约决定，不用mtime。

## 身份与提交

- IssueContract锁定archive_id、规范化scope（去空格/去重/排序）、profile、timezone、edition、cutoff及命名空间。issue_key不含模型/路径/生成时间；contract_fingerprint另覆盖请求窗口。
- RunState记录执行、拥有者、输入修改、能力与预算。相同一期未结束只返回可恢复状态。明确同截止修订用`start --edition morning --date <日期> --revise --reason <原因>`，新截止必须新一期。
- ReportSnapshot保存规范化、自包含研究文档、计算/审阅/交付结果及冻结观点和复核事件。外部数组引用展开后删除引用，不能依赖可清理的工作文件。
- Publication的commit绑定期号、父修订、输入hash、research_hash、生成/提交时间及文件hash。research_hash不包含运行ID、生成时间、作者、图表与视觉注释；观点定义与展示版本分别处理。

finish先锁定输入并校验，在同卷暂存完整快照与HTML，短时提交锁内核对父修订及hash，再将目录整体重命名到正式目标。普通本地文件系统单机支持这一边界；不把多文件依次写入称为原子事务。没有无限掉电或硬件损坏保证；读取时继续核验hash。

目录提交前保留pending意图。提交后catalog/index失败返回published_index_pending，报告仍已归档；下次只核对已知目标、修投影视图，不重新研究。提交前失败保留stage，重试同一run时不改变generated_at。重复finish或响应丢失恢复不增加revision。完整提交以外的stage不进入首页或活动历史。

```text
python <skill>/scripts/run.py status --run-id <ID>
python <skill>/scripts/run.py resume --run-id <ID> --takeover --reason <确认旧执行已停止的原因>
python <skill>/scripts/run.py finish --run-id <ID> --run-token <返回的TOKEN>
python <skill>/scripts/run.py rebuild-index
python <skill>/scripts/run.py history --cutoff <含偏移ISO时刻> --namespace live
```

写命令必须run_token，普通start/status不会获取他人的写权限。工具调用之间用拥有者记录，不长持资料库锁；短时工作锁和提交锁同一协议，顺序为运行锁→提交锁。锁记录准确目标、lock_id、PID、主机及原因，不以TTL抢活锁。确知执行已停止后才用`unlock --run-id <ID> --lock-target run|commit --lock-id <准确ID> --reason <原因>`；不扫描盲删锁。无可靠死亡判断时由用户/宿主显式决定接管。

历史只接受合法提交，并同时检查information_cutoff与committed_at。今天重建过去报告不能在过去回放中出现。due/expired按传入cutoff，不取机器今天日期。旧报告晚提交不回滚当前观点；冲突报告保留但活动状态标unapplied/history_conflict。冷启动和教学/历史重建不污染live。没有自动删除旧报告或全部历史全文回灌。

## 临时网页宿主：显式交接

只有真实宿主工具可以上传远端文件，Python不调用隐藏连接器、不扫描密钥。不把/mnt/data、临时home或sandbox下载链接当长期资料库。没有已授权持久目标则storage_required；用户明确只要临时附件时才init选择ephemeral_only，并准确返回该状态。

配置host_handoff时提供`--host-target <JSON>`，字段为archive_id（稳定32位hex）、connector（实际宿主文件能力名称）、directory_id（已建立目录真实ID）、location、skill_locator、config_locator。目标未建立前不得虚构这些字段。任务正文必须能在下一独立环境定位Skill及这份持久配置，不能只保存在上一对话。

finish返回archive_unconfirmed及publish-plan.json。plan列issue_key/run_id/revision、逻辑路径和每个自包含payload的hash。宿主按当前工具真实schema上传全部文件；如果自动重命名，记录实际位置。上传一半不得保存完整持久commit。响应丢失时按已有真实ID/issue/hash查回，不重新研究或无限上传。

全部payload保存后，宿主保存持久commit并调用`confirm-archive --run-id <ID> --run-token <TOKEN> --input <receipt.json>`。receipt包括archive_id/issue_key/run_id/revision、host_confirmed=true、persistent_commit_id、directory_id及files数组。每项name为plan中的文件名，sha256匹配，file_id和actual_location必须为工具实际返回值。只有一致完整回执才persistent_confirmed；含义是“宿主执行并确认”，不是Python独立查验远端。重复相同回执幂等，不同回执报告冲突。

下一宿主通过真实持久配置列举提交，完成分页并按合法截止恢复相关快照。将下载快照的真实file_id/local_file/sha256/committed_at/persistent_commit_id，连同archive_id/directory_id/listing_complete=true/next_cursor=null/commit_baseline写入恢复清单，用`restore-archive --run-id <ID> --run-token <TOKEN> --input <清单>`导入。分页未完成不能声称连续历史完整；活动清单只是有提交基准的缓存，不永久丢弃较早活跃观点。脚本不会构造云端URL或把相对路径当远端网页导航。

远端没有CAS/互斥时只支持明确单写者，不能保证跨机exactly-once。模拟宿主测试不能证明真实连接器可用。迁移验收必须目标宿主手动成功保存一次，再由第二个独立运行实际找回并继承合法历史；未完成时标not_tested，不宣称网页任务已迁移。

## 未来任务正文（仅供用户之后采用）

使用已可访问的daily-briefing及明确可持久访问的资料库配置，生成宿主传入目标日期北京时间08:00信息截止的早报，自动按日期归档。沿用研究偏好、八栏目和三期限判断。延迟执行保留原目标期，重复执行恢复或返回同一期。start后继续研究到finish及必要持久确认，最后返回最多3条核心变化、局限和实际档案链接。缺权限/网络/存储不得伪称成功；不得修改Skill源码或其他任务。

调度意图由用户另行配置：每天08:00、Asia/Shanghai、周末照常，传scheduled_for；这是启动/信息截止，不是完成时刻保证。本次开发不创建、修改、停用任何现有任务。是否切换旧任务由用户在真实持久保存和独立恢复验收后决定。
