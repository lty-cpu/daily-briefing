"""Deterministic, unit-aware calculations; no eval and no data acquisition."""
from datetime import date
import statistics
from common import iso, num

SERIES_OPS = {'return','excess_return','volume_ratio','bp_change','difference'}
FINANCIAL_OPS = {'pair_difference','ratio','growth','product','sum','sensitivity'}


def inputs(metric):
    if metric['op'] == 'pair_difference':
        return [metric.get('from_metric'), metric.get('to_metric')]
    return metric.get('inputs', [])


def calculate(document, maps, issue):
    values, details, visiting = {}, {}, set()
    cutoff = iso(document['meta']['cutoff'])

    def window(metric, series):
        n = metric.get('n',20 if metric['op']=='volume_ratio' else 0)
        observations = series['observations'][-n-1:]
        if len(observations) < n+1:
            issue('metrics.'+metric['id'], '窗口观测不足，保持null', 'insufficient_data')
            return None
        basis = metric.get('window_basis')
        if basis == 'trading_sessions':
            calendar = maps['calendars'].get(series['calendar_id'])
            if series['frequency'] != 'daily' or not calendar or not calendar['complete'] or series['completeness'] != 'complete':
                issue('metrics.'+metric['id'], '不能证明连续交易会话；不得称交易日收益', 'input_error')
                return None
            dates=[o['date'] for o in observations]
            expected=[s['date'] for s in calendar['sessions'] if dates[0]<=s['date']<=dates[-1]]
            if dates != expected:
                issue('metrics.'+metric['id'], '窗口缺少交易会话；补显式missing/null记录或改为观测期指标', 'insufficient_data')
                return None
        elif basis != 'observations':
            issue('metrics.'+metric['id'], '必须明确trading_sessions或observations窗口', 'input_error')
            return None
        if any(p['value'] is None or p['status']!='traded' or not point_available(p,series,maps) for p in observations):
            issue('metrics.'+metric['id'], '窗口含停牌/缺失/可得性未知，保持null', 'insufficient_data')
            return None
        return observations

    def evaluate(mid):
        if mid in values: return values[mid]
        if mid in visiting:
            raise ValueError('指标依赖成环: '+mid)
        visiting.add(mid)
        m=maps['metrics'][mid];op=m['op'];value=None;used_sources=[];period=''
        if op=='observed':
            value=m['value'] if m['available_at'] is not None else None
            used_sources=m['source_ids'];period=m['as_of']
            if m['available_at'] is None: issue('metrics.'+mid,'公开时点未知，该观测不进入计算','insufficient_data')
        elif op in SERIES_OPS:
            s=maps['series'][m['series_id']];w=window(m,s)
            used_sources=list(s['source_ids']);period=s['observations'][-1]['date'] if s['observations'] else ''
            if w:
                a,b=w[0]['value'],w[-1]['value']
                if op=='volume_ratio':
                    denominator=statistics.median(p['value'] for p in w[:-1])
                    value=b/denominator if denominator>0 else None
                elif op=='difference':value=b-a
                elif op=='bp_change':value=(b-a)*100
                elif a>0:
                    value=(b/a-1)*100
                    if op=='excess_return':
                        base=maps['series'][m['benchmark_id']];bw=window(m,base);used_sources+=base['source_ids']
                        if not bw or [p['date'] for p in bw]!=[p['date'] for p in w]:
                            issue('metrics.'+mid,'基准窗口未对齐','insufficient_data');value=None
                        elif bw[0]['value']<=0:value=None
                        else:value-=(bw[-1]['value']/bw[0]['value']-1)*100
                if value is None:issue('metrics.'+mid,'无法计算的分母/基准，保持null','insufficient_data')
        else:
            deps=inputs(m);raw=[evaluate(x) for x in deps]
            used_sources=[s for x in deps for s in details[x]['source_ids']]
            period=m['dimensions']['period']
            if any(maps['metrics'][x]['dimensions']['period']=='unknown' for x in deps):
                issue('metrics.'+mid,'财务输入期间未知，不能证明可比，保持null','insufficient_data')
                raw=[None]*len(raw)
            if all(v is not None for v in raw):
                scaled=[v*maps['metrics'][x]['dimensions']['scale'] for x,v in zip(deps,raw)]
                scale=m['dimensions']['scale']
                if op=='pair_difference':
                    value=(scaled[1]-scaled[0])/scale
                    if m['unit']=='bp' and maps['metrics'][deps[0]]['unit']=='%':value*=100
                elif op=='ratio':value=(scaled[0]/scaled[1]*(100 if m['unit']=='%' else 1)) if scaled[1]!=0 else None
                elif op=='growth':value=(scaled[1]/scaled[0]-1)*100 if scaled[0]>0 else None
                elif op=='sum':value=sum(scaled)/scale
                elif op=='product':
                    value=1
                    for v in scaled:value*=v
                    value/=scale
                elif op=='sensitivity':value=scaled[0]*(1+m['shock'])/scale
                if value is None:issue('metrics.'+mid,'零/负分母不能计算，保持null','insufficient_data')
        visiting.remove(mid)
        if value is not None and not num(value):
            issue('metrics.'+mid,'派生结果非有限数；拒绝发布inf/NaN','input_error');value=None
        values[mid]=value
        details[mid]=dict(value=value,unit=m['unit'],dimensions=m['dimensions'],op=op,
                         source_ids=list(dict.fromkeys(used_sources)),as_of=period,dependencies=inputs(m),
                         series_ids=[m[k] for k in ('series_id','benchmark_id') if k in m],
                         window_basis=m.get('window_basis'),n=m.get('n'),formula=op)
        return value
    for mid in maps['metrics']:
        try:evaluate(mid)
        except (ValueError,KeyError,ZeroDivisionError,OverflowError) as exc:
            issue('metrics.'+mid,str(exc),'input_error')
    return values,details


def point_available(point,series,maps):
    if point['available_at']:return point['available_at']
    rule=series.get('release_rule')
    if rule and rule['kind']=='session_close':
        from datetime import timedelta
        cal=maps['calendars'].get(series['calendar_id'])
        session=maps.get('_sessions',{}).get(series['calendar_id'],{}).get(point['date'])
        if session is None and cal and '_sessions' not in maps:session=next((s for s in cal['sessions'] if s['date']==point['date']),None)
        if session:return (iso(session['close_at'])+timedelta(seconds=rule['delay_seconds'])).isoformat()
    return None


def mapping_valid(identifier, series, maps):
    mapping=maps['mappings'].get(identifier)
    if not mapping:return False
    return (set(s['id'] for s in series)<=set(mapping['series_ids']) and
            set(s['entity_id'] for s in series)<=set(mapping['entity_ids']) and
            set(x for s in series for x in s['source_ids'])<=set(mapping['source_ids']) and
            {'provider','market','adjustment','classification','scope'}<=set(mapping['aligned_fields']) and
            bool(mapping['evidence_ids']))
