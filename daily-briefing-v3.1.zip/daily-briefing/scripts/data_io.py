"""Incremental input edits, structured imports and bounded research telemetry."""
import copy
import csv
from io import StringIO
import json
from pathlib import Path
import time
from common import canonical, fingerprint, ID, load, loads, num, save, stamp, InputError
from schema import SCHEMA, check
from storage import materialize, put_artifact, cache_get, cache_put
from validation import validate

ARRAYS={k:s['items'] for k,s in SCHEMA['required'].items() if s['type']=='array'}


def describe(group):
    spec=SCHEMA['required'].get(group,SCHEMA['optional'].get(group))
    if not spec:raise ValueError('未知数据集合')
    return dict(schema_version=3,group=group,definition=spec,
                note='结构定义的单一来源；时间、单位、证据与交付语义仍需执行运行时校验。')


def merge(work,patch):
    work=Path(work);d=load(work/'briefing.json');before=fingerprint(d)
    existing_errors=check(d)
    if existing_errors:raise InputError(existing_errors[0]['path'],existing_errors[0]['message'])
    from capabilities import decode_json_output
    patch=decode_json_output(patch)
    if not isinstance(patch,dict) or set(patch)-set(SCHEMA['required'])-set(SCHEMA['optional']):
        raise ValueError('片段包含未知顶层字段')
    for group,items in patch.items():
        if group=='schema_version':raise ValueError('不能通过merge切换schema')
        if group=='meta':
            allowed={'title','window_start','window_adjustment_reason','requested_grade','featured_metrics','section_titles','market_dates'}
            if not isinstance(items,dict) or set(items)-allowed:raise ValueError('meta只能更新展示字段和有理由的研究回溯窗口；请求契约不可改')
            d['meta'].update(items)
        elif group in ARRAYS:
            if not isinstance(items,list):raise ValueError('集合需数组')
            existing=d[group]
            if 'id' in ARRAYS[group].get('required',{}):
                assigned=[]
                for item in items:
                    if not isinstance(item,dict):raise InputError(group,'条目必须为对象')
                    item=copy.deepcopy(item)
                    if 'id' not in item:item['id']=group[:2].upper()+'_'+fingerprint(item)[:16]
                    errors=check(item,ARRAYS[group],group)
                    if errors:raise ValueError(canonical(errors[:4]))
                    assigned.append(item)
                ids=[x['id'] for x in assigned]
                if len(ids)!=len(set(ids)):raise ValueError('片段含重复ID，拒绝含糊覆盖')
                updates={x['id']:x for x in assigned}
                d[group]=[updates.pop(x['id'],x) for x in existing]+list(updates.values())
            else:
                errors=check(items,SCHEMA['required'][group],group)
                if errors:raise ValueError(canonical(errors[:4]))
                d[group]=items
        else:
            spec=SCHEMA['required'].get(group,SCHEMA['optional'].get(group))
            errors=check(items,spec,group)
            if errors:raise ValueError(canonical(errors[:4]))
            d[group]=items
    errors=check(d)
    if errors:raise InputError(errors[0]['path'],errors[0]['message'])
    after=fingerprint(d)
    if after==before:return dict(status='unchanged',sha256=after)
    save(work/'input-edits'/(after+'.json'),dict(previous=before,current=after,patch=patch,recorded_at=stamp()))
    save(work/'briefing.json',d)
    return dict(status='merged',sha256=after,groups=list(patch),counts={k:len(d[k]) for k in patch if isinstance(d[k],list)})


def import_series(work,input_path,metadata_path):
    started=time.perf_counter();meta=load(metadata_path);raw=Path(input_path).read_bytes()
    if not isinstance(meta,dict):raise InputError('series.metadata','元数据必须为对象')
    if Path(input_path).suffix.lower()=='.csv':
        reader=csv.DictReader(StringIO(raw.decode('utf-8-sig')))
        if not reader.fieldnames or not {'date','value','available_at'}<=set(reader.fieldnames):
            raise ValueError('CSV需要date,value,available_at；空可得时间不等于已公开')
        points=[]
        for row in reader:
            if row['value'].strip():
                value=loads(row['value'])
                if not num(value):raise ValueError('CSV value需有限数值，bool无效')
            else:value=None
            point=dict(date=row['date'],value=value,available_at=row['available_at'] or None,
                       status=row.get('status') or ('missing' if value is None else 'traded'))
            if row.get('session_id'):point['session_id']=row['session_id']
            points.append(point)
    else:
        points=loads(raw.decode('utf-8-sig'))
        if not isinstance(points,list):raise ValueError('JSON序列导入需观测数组')
    if len(points)>200000:raise ValueError('单次导入超过200000点，请按对象分批')
    item=dict(meta,observations=points)
    if 'id' not in item:item['id']='SE_'+fingerprint(meta)[:16]
    errors=check(item,ARRAYS['series'],'series')
    if errors:raise ValueError(canonical(errors[:4]))
    # Retain both authorized original bytes and normalized, addressable points.
    original=put_artifact(work,raw,'.csv' if Path(input_path).suffix.lower()=='.csv' else '.json')
    normalized=put_artifact(work,canonical(points).encode('utf-8'),'.json')
    item.update(observations=[],artifact=normalized)
    result=merge(work,{'series':[item]})
    provenance=Path(work)/'imports'/ (fingerprint(dict(original=original,metadata=meta))+'.json')
    if not provenance.exists():save(provenance,dict(original=original,normalized=normalized,metadata=meta,
        imported_at=stamp(),record_count=len(points),wall_ms=(time.perf_counter()-started)*1000),exclusive=True)
    return dict(**result,series_id=item['id'],record_count=len(points),original=original,normalized=normalized)


def inspect(work,group,ident=None,offset=0,limit=10):
    d=load(Path(work)/'briefing.json')
    if group not in d or not isinstance(d[group],list):raise ValueError('仅可定向查看已知集合')
    rows=d[group]
    if ident:
        rows=[x for x in rows if isinstance(x,dict) and x.get('id')==ident]
    selected=rows[max(0,offset):max(0,offset)+min(30,max(1,limit))]
    result=[]
    for x in selected:
        if group=='series':
            x={k:v for k,v in x.items() if k!='observations'}|{'inline_points':len(x['observations'])}
        result.append(x)
    return dict(group=group,total=len(rows),items=result,next_offset=offset+len(selected) if offset+len(selected)<len(rows) else None)


def compute(work,state,ids=None):
    started=time.perf_counter();d=materialize(load(Path(work)/'briefing.json'),work)
    pack=load(Path(work)/'evidence-pack.json') if state.get('evidence_sha256') else None
    r=validate(d,state['contract'],pack)
    from capabilities import enforce_delivery
    enforce_delivery(r,d,state.get('preflight'));save(Path(work)/'checks.json',r)
    available=r['metric_details'];selected=ids or list(available)[:20]
    return dict(errors=r['errors'][:6],error_count=len(r['errors']),warning_count=len(r['warnings']),
                metrics={x:available[x] for x in selected if x in available},delivery=r.get('delivery'),
                wall_ms=(time.perf_counter()-started)*1000,total_metrics=len(available),
                note='计算结果和资料质量已落盘；不代表引文语义或因果验证。')


def record(work,state,event):
    allowed={'query','open','cache','import','compute','render','stage','recovery','usage'}
    if not isinstance(event,dict) or event.get('kind') not in allowed or not event.get('stage'):raise InputError('event','记录需对象、有效kind与stage')
    for key in ('wall_ms','input_tokens','output_tokens','cached_tokens','reasoning_tokens','cost'):
        if event.get(key) is not None and (not num(event[key]) or event[key]<0):raise ValueError('无效实测开销: '+key)
    usage_keys=('input_tokens','output_tokens','cached_tokens','reasoning_tokens','cost')
    for key in usage_keys[:-1]:
        if event.get(key) is not None and type(event[key]) is not int:raise ValueError('实测token数量需整数或null')
    if any(event.get(k) is not None for k in usage_keys) and event.get('measurement')!='host_reported':
        raise ValueError('token/成本只能记录宿主实际usage；字符数与估算单列')
    logged=dict(event,recorded_at=stamp())
    for key in usage_keys:logged.setdefault(key,None)
    state['telemetry']['events'].append(logged)
    if event['kind']=='usage':state['telemetry']['usage']={k:logged[k] for k in usage_keys}|{'measurement':'host_reported','currency':event.get('currency'),'scope':event.get('scope','unknown')}
    save(Path(work)/'run-state.json',state)
    return dict(recorded=True,events=len(state['telemetry']['events']),usage=state['telemetry']['usage'])


def task(work,state,item):
    required={'id','question','priority','target_evidence','current_conclusion','query_or_url','result','next','stop_reason','status'}
    if not isinstance(item,dict) or not required<=set(item) or not isinstance(item['id'],str) or not ID.fullmatch(item['id']):raise InputError('task','研究任务缺少问题、目标证据、结果或停止原因')
    if item['status'] not in ('planned','running','done','stopped') or type(item['priority']) is not int or not 1<=item['priority']<=3:raise ValueError('任务状态/优先级无效')
    old=next((x for x in state['tasks'] if x['id']==item['id']),None)
    if old==item:return dict(status='unchanged')
    if old:state['tasks'].remove(old)
    state['tasks'].append(item);state['next']=item['next']
    save(Path(work)/'run-state.json',state)
    return dict(status='recorded',next=item['next'])
