"""One edition policy for issue timing, research shape and delivery."""
from datetime import date, datetime, time
from common import InputError, fingerprint, iso

POLICY_VERSION = 1
POLICIES = {
    'morning': dict(label='早报', full=True, sections=('overview','news','ai','market','sectors','macro','observations','actions'),
                    budget=dict(soft_queries=40,hard_queries=80,reserved_verifications=12,timeout_seconds=2400)),
    'evening': dict(label='晚报', full=True, sections=('market','news','companies','sectors','macro','observations','actions'),
                    budget=dict(soft_queries=36,hard_queries=72,reserved_verifications=12,timeout_seconds=2400)),
    'intraday': dict(label='盘中观察', full=False, sections=('status','changes','market','next'),
                     budget=dict(soft_queries=12,hard_queries=28,reserved_verifications=8,timeout_seconds=600)),
    'snapshot': dict(label='即时完整研究', full=True, sections=('overview','news','ai','market','sectors','macro','observations','actions'),
                     budget=dict(soft_queries=40,hard_queries=80,reserved_verifications=12,timeout_seconds=2400)),
}


def policy(edition):
    if edition not in POLICIES:raise InputError('edition','需要明确早报、晚报或盘中观察；snapshot仅显式兼容使用')
    return dict(POLICIES[edition],id=edition,version=POLICY_VERSION)


def session(calendar, day, now):
    """No weekday/clock inference without an explicit, complete session calendar."""
    if not calendar or calendar.get('complete') is not True or calendar.get('synthetic') is True:
        return dict(status='unknown',phase='unknown',reason='缺少已核验的完整A股常规交易会话日历')
    if not calendar.get('source_ids') or not calendar.get('evidence_ids'):
        return dict(status='unknown',phase='unknown',reason='日历缺少来源与原文定位')
    if not calendar.get('valid_from','')<=day<=calendar.get('valid_to',''):
        return dict(status='unknown',phase='unknown',reason='目标日不在日历核验范围')
    matches=[s for s in calendar.get('sessions',[]) if s.get('date')==day]
    if len(matches)>1:return dict(status='unknown',phase='unknown',reason='交易会话冲突')
    if not matches:return dict(status='closed_day',phase='closed_day',reason='核验日历标记休市')
    close=iso(matches[0]['close_at']).astimezone(now.tzinfo)
    if close.date()!=now.date() or not (time(11,30)<=close.timetz().replace(tzinfo=None)<=time(16)):
        return dict(status='unknown',phase='unknown',reason='常规收盘时刻异常或跨日')
    clock=now.timetz().replace(tzinfo=None)
    phase=('closed' if now>=close else 'preopen' if clock<time(9,15) else 'auction' if clock<time(9,30) else
           'continuous' if clock<time(11,30) else 'lunch' if clock<time(13) else
           'continuous')
    return dict(status='session',phase=phase,close_at=close.isoformat(),calendar_id=calendar['id'],
                calendar_version=calendar['version'],calendar_hash=fingerprint(calendar))


def availability(edition, now, calendar=None, target=None):
    day=target or now.date().isoformat()
    if edition=='morning':
        due=datetime.combine(date.fromisoformat(day),time(8),tzinfo=now.tzinfo)
        return dict(available=now>=due,cutoff=due.isoformat(),reason='目标日08:00尚未到来' if now<due else '',session=session(calendar,day,now))
    if edition=='snapshot':return dict(available=True,cutoff=now.isoformat(),reason='',session=session(calendar,day,now))
    current=session(calendar,day,now)
    if edition=='intraday':ok=day==now.date().isoformat() and current['phase'] in ('auction','continuous','lunch')
    else:ok=day==now.date().isoformat() and current['phase']=='closed'
    return dict(available=ok,cutoff=now.isoformat(),session=current,
                reason='' if ok else '交易会话未核验或当前不在该版型时段')


def options(now, calendar=None, target=None):
    result=[]
    for number,edition in ((1,'morning'),(2,'intraday'),(3,'evening')):
        state=availability(edition,now,calendar,target)
        result.append(dict(number=number,id=edition,label=policy(edition)['label'],**state))
    return result
