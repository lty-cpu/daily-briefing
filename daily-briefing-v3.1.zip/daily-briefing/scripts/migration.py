"""Explicit v1 -> v2 draft migration; never asserts missing evidence is verified."""
import copy
from common import ID, iso


def dimensions(entity='unknown',period='unknown',measure='unknown'):
    return dict(entity_id=entity,currency='none',scale=1,period=period,segment='unknown',measure=measure)


def migrate(old):
    if old.get('schema_version')!=1:raise ValueError('只迁移schema 1；schema 2不需要迁移')
    d=copy.deepcopy(old);d['schema_version']=2;m=d['meta']
    m.pop('coverage_status',None)
    m.update(window_adjustment_reason='',requested_grade='draft',evidence_mode=m.get('evidence_mode','independent'),
             run_id=m.get('run_id','migrated'),migration_notes=['旧版缺失的时间、证据片段、日历和单位维度没有被自动认证。'])
    d.update(evidence=[],calendars=[],claims=[],mappings=[],prior_reviews=[])
    for key in ('events','observations','charts'):d.setdefault(key,[])
    for s in d['sources']:
        s['retrieved_at']=s.pop('accessed_at')
        s['vintage']=dict(id='unknown',available_at=None)
    for f in d['facts']:
        f.update(evidence_ids=[],kind='actual',available_at=None)
    for s in d['series']:
        s.update(entity_id=s['id'],frequency='irregular',calendar_id=None,completeness='unknown',scope=s['market'],
                 roll_policy='unknown',vintage=dict(id='unknown',available_at=None),evidence_ids=[])
        for o in s['observations']:
            o.update(available_at=o.get('available_at'),status='missing' if o['value'] is None else 'traded')
    for metric in d['metrics']:
        metric['dimensions']=dimensions(metric.get('series_id','unknown'),metric.get('as_of','unknown'),metric['label'])
        if metric['op']=='observed':metric.update(available_at=None,kind='actual',evidence_ids=[])
        elif metric['op']=='pair_difference':metric['comparison_evidence_ids']=[]
        else:
            metric.update(window_basis='observations',n=metric.get('n',20))
            metric['label']=metric['label'].replace('交易日','观测期')+'（观测期；交易日历未迁移）'
    for i,a in enumerate(d['analyses']):
        a.update(theme_id=a['id'],thesis_id=a['id'],version=1,entity_ids=[],priority=2,
                 priority_reason='迁移草稿：待重新确认研究优先级',materiality='迁移草稿：待核验量级',
                 assumptions=['原判断保留，未重新认证'],review_at=m['cutoff'],expires_at=m['cutoff'],
                 field_claims={},limitations=[dict(message='旧版证据闭包未建立',impact='不得声明完整研究',critical=True)],
                 horizons={k:dict(conclusion=a['conclusion'],direction='unknown',claim_ids=[],earnings_channel=a['earnings'],
                     valuation_channel='迁移待复核',base_case='迁移待复核',counter_case=a['alternative'],next_observation=a['support'],
                     review_at=m['cutoff'],confidence='unknown') for k in ('intraday','short','medium')})
        for j,l in enumerate(a['leaders']):l.update(entity_id='migrated_entity_'+str(i)+'_'+str(j),claim_ids=[])
    for group in ('summary','articles','observations','actions'):
        for x in d[group]:x['claim_ids']=[]
    for a in d['actions']:a['observe_at']=m['cutoff']
    for c in d['charts']:c['placement']='theme' if c['type']=='mechanism' else 'overview'
    for i,c in enumerate(d['coverage']):
        c.update(id='coverage_'+str(i),obligation_ids=[],method='search' if c['status']!='not_checked' else 'not_attempted',
                 mapping_evidence_ids=[],window_start=m['window_start'],window_end=m['cutoff'],checked_at=c.get('checked_at'))
        if c['status']=='checked_none':c['status']='not_checked';c['note']+='；旧版未保存入口覆盖证据，待复核'
    d['review'].update(status='not_reviewed',checked_claim_ids=[],evidence_ids=[],checked_fact_ids=[],checked_analysis_ids=[])
    return d
