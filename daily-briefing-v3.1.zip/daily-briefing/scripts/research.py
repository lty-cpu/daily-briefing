"""Compact cumulative research state within each committed report snapshot."""
import re
import unicodedata
from datetime import timedelta
from common import fingerprint, iso

STATE_VERSION=1
MAX_EVENTS=200


def event_key(entity,subject,family,release_id):
    """Stable identity fields, never a headline, local F/C id or URL."""
    parts=[]
    for value in (entity,subject,family,release_id):
        normalized=unicodedata.normalize('NFKC',value).casefold().strip()
        normalized=re.sub(r'[^\w-]+','-',normalized,flags=re.UNICODE).strip('-')
        if not normalized:raise ValueError('事件身份字段不能为空')
        parts.append(normalized)
    return ':'.join(parts)


def candidate_matches(candidate,known):
    """Surface possible aliases for human review; ambiguity is never auto-merged."""
    identity=(candidate['entity'],candidate['subject'],candidate['family'])
    aliases=set(candidate.get('aliases',[]))
    return [event['event_key'] for event in known if
            (event['entity'],event['subject'],event['family'])==identity and
            (event['event_key']==candidate['event_key'] or aliases.intersection(event.get('aliases',[])))]


def scan_windows(contract,previous=None):
    """Bounded overlap, by independently successful source role; not a search result."""
    end=iso(contract['initial_cutoff'])
    requested=iso(contract['requested_window_start'])
    roles=(previous or {}).get('coverage',{})
    windows=[]
    for entry in contract['coverage_obligations']:
        if not entry['url']:continue
        last=roles.get(entry['id'])
        overlap=iso(last)-timedelta(hours=24) if last else requested
        start=max(requested,min(overlap,end))
        windows.append(dict(source_id=entry['id'],channel=entry.get('channel','official_index'),url=entry['url'],
                            start=start.isoformat(),end=end.isoformat(),prior_success=last,
                            required=entry['critical']))
    return windows


def evidence_refs(events,publication_id):
    return [dict(item,source_refs=[dict(publication_id=publication_id,id=source_id) for source_id in item['source_ids']],
                 evidence_refs=[dict(publication_id=publication_id,id=evidence_id) for evidence_id in item['evidence_ids']])
            for item in events]


def compare(events,previous,cutoff):
    old={x['event_key']:x for x in (previous or {}).get('events',[])}
    changes={}
    for event in events:
        prior=old.get(event['event_key'])
        if not prior:
            changes[event['event_key']]='late_discovery' if previous and event['published_at'] and iso(event['published_at'])<iso(previous['cutoff']) else 'new'
        elif event['status'] in ('corrected','withdrawn') and (prior['status']!=event['status'] or prior['attributes']!=event['attributes']):
            changes[event['event_key']]='correction'
        elif event['attributes']!=prior['attributes'] or event['status']!=prior['status'] or event['version']!=prior['version']:
            changes[event['event_key']]='progress'
        elif not prior.get('reported_version') and event.get('reported'):
            changes[event['event_key']]='late_discovery'
    return changes


def project(previous,document,publication_id,checks):
    old=(previous or {}).get('events',[])
    state={event['event_key']:event for event in old}
    for event in evidence_refs(document.get('research_events',[]),publication_id):
        prior=state.get(event['event_key'])
        if prior:
            event['first_seen_at']=prior['first_seen_at']
            if not event.get('reported'):
                event['reported_version']=prior.get('reported_version')
                event['last_reported_at']=prior.get('last_reported_at')
        if event.get('reported'):
            event['reported_version']=fingerprint((event['version'],event['attributes'],event['status']))
            event['last_reported_at']=document['meta']['cutoff']
        state[event['event_key']]=event
    ordered=sorted(state.values(),key=lambda x:(x.get('importance',0),x.get('last_verified_at') or ''),reverse=True)
    coverage=dict((previous or {}).get('coverage',{}))
    accepted=set(checks['delivery']['coverage']['covered_ids'])
    for entry in document['coverage']:
        if entry['status'] in ('checked_new','checked_none') and entry['method'] in ('original_index','aggregate'):
            for obligation in entry['obligation_ids']:
                if obligation in accepted:
                    coverage[obligation]=entry['window_end']
    return dict(version=STATE_VERSION,date=document['meta']['date'],cutoff=document['meta']['cutoff'],
                events=ordered[:MAX_EVENTS],coverage=coverage,omitted=max(0,len(ordered)-MAX_EVENTS),
                baseline=publication_id)
