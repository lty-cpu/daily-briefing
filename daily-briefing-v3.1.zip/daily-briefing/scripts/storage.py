"""External append-only research history and content-addressed artifacts."""
from __future__ import annotations
import copy
from datetime import datetime, timezone
from pathlib import Path
from contextlib import contextmanager
import hashlib
import os
from common import TOKEN, canonical, fingerprint, load, save, stamp


@contextmanager
def lock(root, reason='local mutation', owner=None):
    import socket
    from uuid import uuid4
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    path=root/'.writer.lock'
    record=dict(lock_id=uuid4().hex,target=str(root.resolve()),owner=owner or 'local-process',
                pid=os.getpid(),host=socket.gethostname(),reason=reason,created_at=stamp())
    try:fd=os.open(path,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    except FileExistsError as exc:raise OSError('准确锁目标被占用: '+str(path)+'；不按TTL偷锁，需核对原所有者后显式unlock') from exc
    created_inode=os.fstat(fd).st_ino;complete=False;failed=False
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as stream:
            stream.write(canonical(record));stream.flush();os.fsync(stream.fileno())
        complete=True
        yield
    except BaseException:
        failed=True
        raise
    finally:
        try:
            if path.exists() and (load(path).get('lock_id')==record['lock_id'] if complete else path.stat().st_ino==created_inode):path.unlink()
        except (OSError,ValueError,TypeError):
            if not failed:raise


def unlock(root, lock_id, reason):
    if not reason:raise ValueError('解锁需确认原写入已停止及原因')
    path=Path(root)/'.writer.lock'
    if not path.exists():return dict(status='not_locked')
    current=load(path)
    if current.get('lock_id')!=lock_id:raise ValueError('锁身份变化，不能盲删')
    save(Path(root)/('recovered-lock-'+lock_id+'.json'),dict(previous=current,reason=reason,recovered_at=stamp()),exclusive=True)
    path.unlink()
    return dict(status='unlocked',target=str(path))


def freeze(text, details):
    def replace(match):
        m=details[match.group(1)]
        return ('未知' if m['value'] is None else format(m['value'],'.10g'))+m['unit']
    return TOKEN.sub(replace,text)


def snapshots(d, checks):
    result=[];details=checks['metric_details']
    for a in d['analyses']:
        claims={x for ids in a['field_claims'].values() for x in ids}
        claims.update(x for h in a['horizons'].values() for x in h['claim_ids'])
        cs=[x for x in d['claims'] if x['id'] in claims]
        facts=set(a['fact_ids'])|{x for c in cs for x in c['fact_ids']}
        mids={x for c in cs for x in c['metric_ids']}
        def scan(value):
            if isinstance(value,str):mids.update(TOKEN.findall(value))
            elif isinstance(value,list):
                for v in value:scan(v)
            elif isinstance(value,dict):
                for v in value.values():scan(v)
        scan(a)
        def expand(mid):
            if mid not in details:return
            for x in details[mid]['dependencies']:
                if x not in mids:mids.add(x);expand(x)
        for mid in list(mids):expand(mid)
        sourceids={s for f in d['facts'] if f['id'] in facts for s in f['source_ids']}
        sourceids.update(s for mid in mids for s in details.get(mid,{}).get('source_ids',[]))
        item=dict(thesis_id=a['thesis_id'],theme_id=a['theme_id'],entity_ids=a['entity_ids'],version=a['version'],
                  first_proposed=d['meta']['date'],as_of=d['meta']['cutoff'],
                  conclusion=freeze(a['conclusion'],details),support=freeze(a['support'],details),
                  invalidation=freeze(a['invalidation'],details),assumptions=a['assumptions'],priority=a['priority'],
                  expires_at=a['expires_at'],review_at=a['review_at'],horizons=copy.deepcopy(a['horizons']),
                  status=a.get('update',{}).get('status','new'),update=a.get('update'),
                  facts=[copy.deepcopy(f) for f in d['facts'] if f['id'] in facts],
                  metrics={mid:details[mid] for mid in mids if mid in details},
                  sources=[copy.deepcopy(s) for s in d['sources'] if s['id'] in sourceids],
                  evidence=[copy.deepcopy(e) for e in d['evidence'] if e['source_id'] in sourceids],
                  claims=copy.deepcopy(cs),run_id=d['meta']['run_id'],delivery=checks['delivery']['grade'])
        # Freeze every narrative, not just top-level conclusions.
        def frozen(v):
            if isinstance(v,str):return freeze(v,details)
            if isinstance(v,list):return [frozen(x) for x in v]
            if isinstance(v,dict):return {k:frozen(x) for k,x in v.items()}
            return v
        result.append(frozen(item))
        semantic={k:copy.deepcopy(a[k]) for k in ('conclusion','support','invalidation','assumptions','expires_at')}
        semantic['mechanism']=[{k:e[k] for k in ('from','to','basis','assumption')} for e in a['mechanism']]
        semantic['horizons']={key:{k:v for k,v in h.items() if k not in ('claim_ids','review_at','next_observation')} for key,h in a['horizons'].items()}
        result[-1]['definition']=frozen(semantic)
    return result


def put_artifact(root, raw, suffix):
    root=Path(root);digest=hashlib.sha256(raw).hexdigest()
    path=root/'artifacts'/(digest+suffix)
    path.parent.mkdir(parents=True,exist_ok=True)
    if not path.exists():path.write_bytes(raw)
    elif path.read_bytes()!=raw:raise ValueError('工件哈希冲突')
    return dict(path=str(path.relative_to(root)),sha256=digest,format={'.json':'json','.csv':'csv','.txt':'text'}[suffix])


def resolve_artifact(root,artifact):
    root=Path(root).resolve();path=(root/artifact['path']).resolve()
    if not path.is_relative_to(root):raise ValueError('工件路径越界')
    raw=path.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=artifact['sha256']:raise ValueError('工件哈希不一致')
    return raw


def materialize(d,root):
    from schema import check
    errors=check(d)
    if errors:
        from common import InputError
        raise InputError(errors[0]['path'],errors[0]['message'])
    result=copy.deepcopy(d)
    for s in result['series']:
        if s.get('artifact'):
            from common import loads
            if s['observations']:raise ValueError('外部序列工件不能同时含内联观测')
            s['observations']=loads(resolve_artifact(root,s['artifact']).decode('utf-8-sig'))
            del s['artifact']
    for e in result['evidence']:
        if e.get('artifact'):
            resolve_artifact(root,e['artifact'])
            del e['artifact']
    errors=check(result)
    if errors:
        from common import InputError
        raise InputError(errors[0]['path'],errors[0]['message'])
    return result


def cache_put(root,entry):
    for key in ('id','layer','source_url','retrieved_at','vintage_at','valid_until','recheck_triggers','data'):
        if key not in entry:raise ValueError('缓存缺少字段: '+key)
    from common import ID, iso, safe_url
    if not ID.fullmatch(entry['id']) or entry['layer'] not in ('news','market','fundamental','thesis') or not safe_url(entry['source_url']):raise ValueError('缓存标识/来源无效')
    for key in ('retrieved_at','vintage_at','valid_until'):iso(entry[key])
    if iso(entry['retrieved_at'])<iso(entry['vintage_at']) or iso(entry['valid_until'])<iso(entry['vintage_at']):raise ValueError('缓存获取/适用期限与版本矛盾')
    if not isinstance(entry['recheck_triggers'],list) or not entry['recheck_triggers']:raise ValueError('缓存需失效触发条件')
    path=Path(root)/'cache'/entry['id']/(fingerprint(entry)+'.json')
    if not path.exists():save(path,entry,exclusive=True)
    return str(path)


def cache_get(root,identifier,cutoff,triggers=()):
    from common import ID, iso
    if not ID.fullmatch(identifier):raise ValueError('无效缓存ID')
    base=Path(root)/'cache'/identifier;matches=[]
    # Explicit one key only; never recursively scans research or workspace roots.
    for path in base.glob('*.json'):
        e=load(path)
        if iso(e['vintage_at'])<=iso(cutoff)<=iso(e['valid_until']) and not set(triggers)&set(e['recheck_triggers']):matches.append(e)
    if not matches:return dict(status='miss',reason='没有符合截止、版本和失效条件的缓存')
    e=max(matches,key=lambda x:iso(x['vintage_at']))
    return dict(status='cache_reused',actual_retrieved_at=e['retrieved_at'],entry=e,
                note='缓存命中不表示本轮重新访问；新闻官方覆盖仍需本轮扫描。')
