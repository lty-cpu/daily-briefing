"""Compact cumulative research state within each committed report snapshot."""
import copy
import re
import unicodedata
from datetime import timedelta
from common import fingerprint, iso

STATE_VERSION=2
MAX_EVENTS=200


def event_key(entity,subject,family,release_id):
    """Stable identity fields, never a headline, local F/C id or URL."""
    parts=[]
    for value in (entity,subject,family,release_id):
        normalized=unicodedata.normalize('NFKC',value).casefold().strip()
        normalized=re.sub(r'[^\w-]+','-',normalized,flags=re.UNICODE).strip('-')
        if not normalized:raise ValueError('事件身份字段不能为空')
        parts.append(normalized)
    return ':'.join(parts)


def candidate_matches(candidate,known):
    """Surface possible aliases for human review; ambiguity is never auto-merged."""
    identity=(candidate['entity'],candidate['subject'],candidate['family'])
    aliases=set(candidate.get('aliases',[]))
    return [event['event_key'] for event in known if
            (event['entity'],event['subject'],event['family'])==identity and
            (event['event_key']==candidate['event_key'] or aliases.intersection(event.get('aliases',[])))]


def scan_windows(contract,previous=None):
    """Bounded overlap, by independently successful source role; not a search result."""
    end=iso(contract['initial_cutoff'])
    requested=iso(contract['requested_window_start'])
    roles=(previous or {}).get('coverage',{})
    windows=[]
    for entry in contract['coverage_obligations']:
        if not entry['url']:continue
        last=roles.get(entry['id'])
        overlap=iso(last)-timedelta(hours=24) if last else requested
        start=max(requested,min(overlap,end))
        windows.append(dict(source_id=entry['id'],channel=entry.get('channel','official_index'),url=entry['url'],
                            start=start.isoformat(),end=end.isoformat(),prior_success=last,
                            required=entry['critical']))
    return windows


def evidence_refs(events,publication_id):
    return [dict(item,source_refs=[dict(publication_id=publication_id,id=source_id) for source_id in item['source_ids']],
                 evidence_refs=[dict(publication_id=publication_id,id=evidence_id) for evidence_id in item['evidence_ids']])
            for item in events]


def event_signature(event):
    return dict(version=event['version'],attributes=event['attributes'],status=event['status'])


def has_report_reference(document,event):
    reference=event.get('report_ref')
    if not isinstance(reference,dict):return False
    item_id=reference.get('item_id')
    if reference.get('section')=='change':
        item=next((x for x in document.get('changes',[]) if x.get('event_key')==item_id),None)
    elif reference.get('section')=='article':
        item=next((x for x in document.get('articles',[]) if x.get('id')==item_id),None)
    else:return False
    return bool(item and set(event.get('claim_ids',[])) & set(item.get('claim_ids',[])))


def compare(events,previous,cutoff):
    old={x['event_key']:x for x in (previous or {}).get('events',[])}
    changes={}
    for event in events:
        prior=old.get(event['event_key'])
        if not prior:
            changes[event['event_key']]='late_discovery' if previous and event['published_at'] and iso(event['published_at'])<iso(previous['cutoff']) else 'new'
            continue
        reported=prior.get('reported_snapshot')
        if reported is None and prior.get('reported_version'):
            legacy_signature=event_signature(prior)
            if prior['reported_version']==fingerprint((legacy_signature['version'],legacy_signature['attributes'],legacy_signature['status'])):
                reported=legacy_signature
        if reported is None:
            changes[event['event_key']]='late_discovery'
            continue
        current=event_signature(event)
        if current==reported:continue
        if event['status'] in ('corrected','withdrawn') and (reported['status']!=event['status'] or reported['attributes']!=event['attributes']):
            changes[event['event_key']]='correction'
        else:
            changes[event['event_key']]='progress'
    return changes


def project(previous,document,publication_id,checks):
    old=(previous or {}).get('events',[])
    state={event['event_key']:event for event in old}
    for event in evidence_refs(document.get('research_events',[]),publication_id):
        event.setdefault('reported',False)
        prior=state.get(event['event_key'])
        if prior:
            if prior.get('first_seen_at'):
                event['first_seen_at']=prior['first_seen_at']
            else:
                event['observation_integrity']='legacy_first_seen_unknown'
            reported=prior.get('reported_snapshot')
            if reported is None and prior.get('reported_version'):
                legacy_signature=event_signature(prior)
                if prior['reported_version']==fingerprint((legacy_signature['version'],legacy_signature['attributes'],legacy_signature['status'])):
                    reported=legacy_signature
                    event['reported_integrity']='legacy_consistent'
                else:
                    event['reported_integrity']='legacy_unknown'
            elif reported is not None:
                event['reported_integrity']=prior.get('reported_integrity','verified')
            if reported is not None:
                event['reported_snapshot']=copy.deepcopy(reported)
                event['reported_version']=fingerprint((reported['version'],reported['attributes'],reported['status']))
                event['last_reported_at']=prior.get('last_reported_at')
        observed=event_signature(event)
        event['latest_observed']=copy.deepcopy(observed)
        event['latest_signature']=fingerprint(observed)
        event['reported']=bool(event.get('reported') and has_report_reference(document,event))
        if event['reported']:
            event['reported_snapshot']=event_signature(event)
            event['reported_integrity']='verified'
            event['reported_version']=fingerprint((event['version'],event['attributes'],event['status']))
            event['last_reported_at']=document['meta']['cutoff']
        state[event['event_key']]=event
    ordered=sorted(state.values(),key=lambda x:(
        bool(x.get('importance',0)>=5 and x.get('reported_snapshot')!=event_signature(x)),
        x.get('importance',0),x.get('last_verified_at') or ''),reverse=True)
    coverage=dict((previous or {}).get('coverage',{}))
    accepted=set(checks['delivery']['coverage']['covered_ids'])
    for entry in document['coverage']:
        if entry['status'] in ('checked_new','checked_none') and entry['method'] in ('original_index','aggregate'):
            for obligation in entry['obligation_ids']:
                if obligation in accepted:
                    coverage[obligation]=entry['window_end']
    important_pending=[x for x in ordered if x.get('importance',0)>=5 and x.get('reported_snapshot')!=event_signature(x)]
    important_keys={x['event_key'] for x in important_pending}
    remaining=[x for x in ordered if x['event_key'] not in important_keys]
    selected=important_pending+remaining[:max(0,MAX_EVENTS-len(important_pending))]
    omitted=max(0,len(ordered)-len(selected))
    overflow_important=max(0,len(important_pending)-MAX_EVENTS)
    return dict(version=STATE_VERSION,date=document['meta']['date'],cutoff=document['meta']['cutoff'],
                events=selected,coverage=coverage,omitted=omitted,
                omitted_important=0,overflow_important=overflow_important,
                overflow_notice='重要未报事件超过常规上限，已保留全部待报项' if overflow_important else None,
                baseline=publication_id)
