"""Escaped, deterministic HTML/SVG renderer. Never fetches external resources."""
from __future__ import annotations
from datetime import date, datetime
from html import escape
from pathlib import Path
import math
import re
from briefing import TOKEN, metric_date, source_ids

PALETTE=['#245b83','#26817c','#b7793b','#805b91']
ROLE={'industry':'产业龙头','trading':'交易龙头','both':'产业与交易龙头','representative':'代表性公司','watch':'观察对象'}
STATUS={'confirmed':'已确认','reported':'来源声明','conflicted':'来源冲突','unverified':'待核实','supported':'有据判断','watch':'待验证','contrarian':'非共识观察','expected':'预计'}
STATUS['expected']='已公告计划'

def esc(v): return escape(str(v),quote=True)
def fmt(value,unit='',signed=False):
    if value is None: return '—'
    digits=0 if unit in ('家','台','艘') else 2
    s=f'{value:+,.{digits}f}' if signed else f'{value:,.{digits}f}'
    return s+unit
def short(value):
    if abs(value)>=10000: return f'{value/10000:.1f}万'
    if abs(value)>=1000: return f'{value/1000:.1f}k'
    return f'{value:.2f}'.rstrip('0').rstrip('.')
def signclass(v): return 'neutral' if v is None or v==0 else ('pos' if v>0 else 'neg')
def table(headers,rows,classes='',header_text=esc):
    return '<div class="table-wrap"><table class="'+classes+'"><thead><tr>'+''.join('<th>'+header_text(h)+'</th>' for h in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td data-label="'+header_text(headers[i])+'">'+c+'</td>' for i,c in enumerate(r))+'</tr>' for r in rows)+'</tbody></table></div>'

class Renderer:
    def __init__(self,d,checks):
        self.d=d; self.values=checks['values']; self.checks=checks
        self.facts={x['id']:x for x in d['facts']}; self.sources={x['id']:x for x in d['sources']}; self.metrics={x['id']:x for x in d['metrics']}; self.series={x['id']:x for x in d['series']}; self.analyses={x['id']:x for x in d['analyses']}; self.events={x['id']:x for x in d.get('events',[])}
        self.fnums={k:i+1 for i,k in enumerate(self.facts)}
        self.cnums={item['id']:index+1 for index,item in enumerate(d['claims'])}
    def plain(self,value):
        value=re.sub(r'\*\*([^*\n]+)\*\*',r'\1',str(value))
        return esc(TOKEN.sub(lambda m: self.metric(m.group(1)),value))
    def text(self,value):
        def replace(m):
            metric=self.metrics[m.group(1)]; v=self.values[m.group(1)]
            signed=metric.get('signed',metric['op'] in ('return','excess_return','bp_change','difference','pair_difference'))
            return '<span class="metric '+(signclass(v) if signed else 'neutral')+'">'+esc(fmt(v,metric['unit'],signed))+'</span>'
        safe=esc(value)
        safe=re.sub(r'\*\*([^*\n]+)\*\*',r'<strong>\1</strong>',safe)
        safe=re.sub(r'\[risk:([^\]\n]+)\]',r'<mark class="risk">\1</mark>',safe)
        return TOKEN.sub(replace,safe).replace('\n','<br>')
    def refs(self,ids):
        return '<span class="refs">'+''.join(f'<a href="#f-{self.plain(fid)}" aria-label="证据{self.fnums[fid]}">[{self.fnums[fid]}]</a>' for fid in dict.fromkeys(ids) if fid in self.facts)+'</span>'
    def analysis_refs(self, ids):
        return '<span class="refs">'+''.join('<a href="#a-'+self.plain(x)+'" aria-label="查看关联研究">研究</a>' for x in dict.fromkeys(ids))+'</span>'
    def claim_refs(self, ids):
        return '<span class="refs">'+''.join('<a href="#c-'+self.plain(x)+'" aria-label="查看主张证据链">〔'+str(self.cnums.get(x,'?'))+'〕</a>' for x in dict.fromkeys(ids))+'</span>'
    def evidence_refs(self, ids):
        return '<span class="refs">'+''.join('<a href="#e-'+self.plain(x)+'">原文片段 '+self.plain(x)+'</a>' for x in dict.fromkeys(ids))+'</span>'
    def source_links(self,ids):
        return ' · '.join('<a href="'+self.plain(self.sources[x]['url'])+'" target="_blank" rel="noopener noreferrer">'+self.plain(self.sources[x]['publisher'])+'</a>' for x in dict.fromkeys(ids) if x in self.sources)
    def metric(self,mid):
        m=self.metrics[mid]; v=self.values[mid]
        return fmt(v,m['unit'],m.get('signed',m['op'] in ('return','excess_return','bp_change','difference','pair_difference')))
    def chain(self,a):
        out='<div class="chain">'
        for e in a['mechanism']:
            assumption=e['basis']=='assumption'
            out+='<div class="chain-row '+('assumption' if assumption else '')+'">'+self.text(e['from'])+'<span class="arrow">→</span>'+self.text(e['to'])+self.refs(e['fact_ids'])
            out+='<small>'+('假设环节：'+self.text(e['assumption']) if assumption else '事实联系；因果含义需结合正文解释')+'</small></div>'
        return out+'</div>'
    def spark(self,sid):
        s=self.series[sid]; obs=s['observations'][-21:]
        vals=[p['value'] for p in obs if p['value'] is not None]
        if len(vals)<2: return ''
        lo,hi=min(vals),max(vals); span=hi-lo or max(abs(lo)*.01,1)
        paths=[]; path=''
        for i,p in enumerate(obs):
            if p['value'] is None:
                if path: paths.append(path); path=''
            else:
                x=4+i/max(1,len(obs)-1)*292; y=44-(p['value']-lo)/span*38
                path+=('M' if not path else 'L')+f'{x:.2f},{y:.2f} '
        if path: paths.append(path)
        return '<svg class="spark" viewBox="0 0 300 48" role="img" aria-label="'+self.plain(s['label']+'实际历史序列，缺失处断开')+'">'+''.join('<path d="'+p+'" fill="none" stroke="#26817c" stroke-width="2"/>' for p in paths)+'</svg>'
    def chart(self,c):
        typ=c['type']; body=''; data=[]; headers=[]; sids=[]
        if typ in ('breadth','bars'):
            items=[(i['label'],i['metric_id'],self.values[i['metric_id']]) for i in c['items']]
            headers=['对象','数值','所属日期']; data=[[self.plain(label),self.plain(self.metric(mid)),self.plain(metric_date(self.d,self.metrics[mid]))] for label,mid,v in items]
            for _,mid,_ in items: sids+=source_ids(self.d,self.metrics[mid])
            if typ=='breadth':
                total=sum(v for _,_,v in items if v is not None)
                if any(v is None for _,_,v in items) or total<=0: body='<p class="empty">数据不完整，保留原始表格，未绘制占比。</p>'
                else:
                    colors=[{'up':'#b73737','flat':'#94a3b2','down':'#18704b'}[i['category']] for i in c['items']]
                    body='<div class="breadth-track" role="img" aria-label="'+self.plain('；'.join(label+' '+str(v)+'家' for label,mid,v in items))+'">'
                    for j,(label,mid,v) in enumerate(items): body+=f'<span style="width:{v/total*100:.5f}%;--s:{colors[j%3]}" data-tip="{self.plain(label+" "+self.metric(mid)+" / "+fmt(v/total*100,"%"))}"></span>'
                    body+='</div><div class="legend">'+''.join(f'<span><i class="swatch" style="--s:{colors[j%3]}"></i>{self.plain(label)} <b>{self.plain(self.metric(mid))}</b></span>' for j,(label,mid,v) in enumerate(items))+'</div>'
            else:
                vals=[v for _,_,v in items if v is not None]; low=min(vals+[0]); high=max(vals+[0]); span=high-low or 1; zero=-low/span*100
                for label,mid,v in items:
                    color='#b73737' if v is not None and v>=0 else '#18704b'
                    fill='' if v is None else f'<span class="bar-fill" style="left:{min(zero,((v-low)/span*100)):.3f}%;width:{abs(v)/span*100:.3f}%;--s:{color}"></span>'
                    body+='<div class="bar-row"><span>'+self.plain(label)+'</span><div class="bar-track">'+f'<span class="bar-zero" style="left:{zero:.3f}%"></span>'+fill+'</div><span class="bar-value '+signclass(v)+'">'+self.plain(self.metric(mid))+'</span></div>'
        elif typ=='heatmap':
            headers=['对象']+c['columns']; data=[]
            body='<div class="table-wrap"><table class="heatmap"><thead><tr>'+''.join('<th>'+self.plain(x)+'</th>' for x in headers)+'</tr></thead><tbody>'
            for row in c['rows']:
                body+='<tr><th>'+self.plain(row['label'])+'</th>'; r=[self.plain(row['label'])]
                for mid in row['metric_ids']:
                    v=self.values[mid]; intensity=min(abs(v)/10,.8) if v is not None else 0
                    color=f'rgba(183,55,55,{.04+intensity*.22:.3f})' if v is not None and v>0 else (f'rgba(24,112,75,{.04+intensity*.22:.3f})' if v is not None and v<0 else '#f3f5f7')
                    value=self.metric(mid); body+='<td class="'+signclass(v)+'" style="background:'+color+'">'+self.plain(value)+'</td>'; r.append(self.plain(value)); sids+=source_ids(self.d,self.metrics[mid])
                body+='</tr>'; data.append(r)
            body+='</tbody></table></div>'
        elif typ=='line':
            sets=[self.series[x] for x in c['series_ids']]
            for s in sets: sids+=s['source_ids']
            body,data,headers=self.line(sets,c['normalize'])
        elif typ=='scatter':
            pts=c['points']; valid=[p for p in pts if self.values[p['x_metric']] is not None and self.values[p['y_metric']] is not None]
            headers=['对象','超额收益','量能比']; data=[[self.plain(p['label']),self.plain(self.metric(p['x_metric'])),self.plain(self.metric(p['y_metric']))] for p in pts]
            for p in pts:
                for k in ('x_metric','y_metric'): sids+=source_ids(self.d,self.metrics[p[k]])
            if valid:
                xs=[self.values[p['x_metric']] for p in valid]; ys=[self.values[p['y_metric']] for p in valid]
                xmin,xmax=min(xs+[0]),max(xs+[0]); ymin,ymax=min(ys+[1,0]),max(ys+[1]); xp=(xmax-xmin)*.15 or 1; yp=(ymax-ymin)*.15 or .2
                xmin-=xp;xmax+=xp;ymin=max(0,ymin-yp);ymax+=yp
                X=lambda x:80+(x-xmin)/(xmax-xmin)*510; Y=lambda y:220-(y-ymin)/(ymax-ymin)*180
                body='<svg viewBox="0 0 640 275" role="img" aria-label="相对强弱和量能，不能解释为资金净流入"><title>横轴超额收益（百分点），纵轴量能比（倍）</title>'
                for y in (ymin,(ymin+ymax)/2,ymax): body+=f'<line class="grid" x1="80" x2="590" y1="{Y(y):.2f}" y2="{Y(y):.2f}"/><text x="65" y="{Y(y)+5:.2f}" text-anchor="end">{short(y)}</text>'
                for x in (xmin,0,xmax): body+=f'<text x="{X(x):.2f}" y="252" text-anchor="middle">{short(x)}</text>'
                body+=f'<line class="refline" x1="{X(0):.2f}" x2="{X(0):.2f}" y1="40" y2="220"/><line class="refline" x1="80" x2="590" y1="{Y(1):.2f}" y2="{Y(1):.2f}"/>'
                for j,p in enumerate(valid):
                    x,y=X(self.values[p['x_metric']]),Y(self.values[p['y_metric']]); tip=p['label']+'：'+self.metric(p['x_metric'])+' / '+self.metric(p['y_metric'])
                    body+=f'<circle cx="{x:.2f}" cy="{y:.2f}" r="9" fill="{PALETTE[j%4]}" data-tip="{self.plain(tip)}"><title>{self.plain(tip)}</title></circle>'
                body+='</svg><div class="legend">横轴：同期超额收益（百分点） · 纵轴：量能比（倍）</div>'
                body+='<div class="legend">'+''.join('<span><i class="swatch" style="--s:'+PALETTE[j%4]+'"></i>'+self.plain(p['label'])+'</span>' for j,p in enumerate(valid))+'</div>'
            else: body='<p class="empty">缺少可比的价格与成交额窗口，未绘制散点。</p>'
        elif typ=='mechanism':
            a=self.analyses[c['analysis_id']]; body=self.chain(a)
            for fid in a['fact_ids']: sids+=self.facts[fid]['source_ids']
        elif typ=='timeline':
            body='<ol class="timeline">'
            for e in sorted((self.events[i] for i in c['event_ids']),key=lambda e:e['at']):
                body+='<li><time>'+self.plain(e['at'].replace('T',' '))+'</time><b>'+self.plain(e['label'])+'</b> <span class="status">'+STATUS[e['status']]+'</span><p>'+self.text(e['detail'])+self.refs(e['fact_ids'])+'</p></li>'
                for f in e['fact_ids']: sids+=self.facts[f]['source_ids']
            body+='</ol>'
        content='<figure class="chart '+('wide' if typ in ('mechanism','timeline') else '')+'" id="chart-'+self.plain(c['id'])+'"><h3>'+self.plain(c['title'])+'</h3><p class="takeaway">'+self.text(c['takeaway'])+'</p>'+body
        formulas=[self.metrics[item['metric_id']].get('formula') for item in c.get('items',[]) if self.metrics[item['metric_id']].get('formula')]
        content+='<figcaption class="chart-note">'+self.text(c['note'])+(' · 派生：'+self.text('；'.join(formulas)) if formulas else '')+'<br>'+self.source_links(sids)+'</figcaption>'
        if data: content+='<details><summary>查看数据与口径</summary>'+table(headers,data,header_text=self.plain)+'</details>'
        return content+'</figure>'
    def line(self,sets,normalize):
        lookup=[{p['date']:p['value'] for p in s['observations']} for s in sets]
        all_dates=sorted(set().union(*(m.keys() for m in lookup)))
        if not all_dates: return '<p class="empty">无历史序列。</p>',[],[]
        common=sorted(set.intersection(*(set(k for k,v in m.items() if v is not None and v>0) for m in lookup))) if normalize else []
        if normalize and not common: return '<p class="empty">无共同有效基准日，未归一化。</p>',[],[]
        if normalize:
            first=common[0]; all_dates=[day for day in all_dates if day>=first]
            lookup=[{k:(v/m[first]*100 if v is not None and k>=first else None) for k,v in m.items()} for m in lookup]
        vals=[v for m in lookup for k,v in m.items() if k in all_dates and v is not None]
        rows=[[self.plain(day)]+[self.plain(fmt(m.get(day),'',False)) for m in lookup] for day in all_dates]
        headers=['日期']+[s['label']+(' (基期=100)' if normalize else ' ('+s['unit']+')') for s in sets]
        if len(all_dates)<2 or not vals: return '<p class="empty">至少需要两个观测日期，原始数据见下表。</p>',rows,headers
        lo,hi=min(vals),max(vals); pad=(hi-lo)*.15 or max(abs(lo)*.01,1);lo-=pad;hi+=pad
        ords=[date.fromisoformat(x).toordinal() for x in all_dates];start,end=ords[0],ords[-1]
        X=lambda day:80+(date.fromisoformat(day).toordinal()-start)/(end-start)*510
        Y=lambda value:215-(value-lo)/(hi-lo)*175
        svg='<svg viewBox="0 0 640 265" role="img" aria-label="'+self.plain('；'.join(headers[1:]))+'"><title>'+self.plain('真实观测序列，缺失点断开；'+('共同基期归一化' if normalize else '原始单位'))+'</title>'
        for y in (lo,(lo+hi)/2,hi): svg+=f'<line class="grid" x1="80" x2="590" y1="{Y(y):.2f}" y2="{Y(y):.2f}"/><text x="65" y="{Y(y)+5:.2f}" text-anchor="end">{short(y)}</text>'
        for i in sorted({0,len(all_dates)//2,len(all_dates)-1}):
            day=all_dates[i]; anchor='start' if i==0 else ('end' if i==len(all_dates)-1 else 'middle')
            svg+=f'<text x="{X(day):.2f}" y="247" text-anchor="{anchor}">{self.plain(day[5:])}</text>'
        for j,m in enumerate(lookup):
            path=''; segments=[]
            for day in all_dates:
                v=m.get(day)
                if v is None:
                    if path: segments.append(path);path=''
                else: path+=('M' if not path else 'L')+f'{X(day):.2f},{Y(v):.2f} '
            if path: segments.append(path)
            for path in segments: svg+='<path d="'+path+'" fill="none" stroke="'+PALETTE[j%4]+'" stroke-width="2.8"/>'
            for day in all_dates:
                if m.get(day) is not None:
                    tip=sets[j]['label']+' '+day+' '+fmt(m[day],'基期点' if normalize else sets[j]['unit'])
                    svg+=f'<circle cx="{X(day):.2f}" cy="{Y(m[day]):.2f}" r="5" fill="{PALETTE[j%4]}" data-tip="{self.plain(tip)}"><title>{self.plain(tip)}</title></circle>'
        svg+='</svg><div class="legend">'+''.join('<span><i class="swatch" style="--s:'+PALETTE[j%4]+'"></i>'+self.plain(s['label'])+'</span>' for j,s in enumerate(sets))+'</div>'
        svg+='<div class="chart-note">'+self.plain(('共同基期 '+all_dates[0]+' = 100' if normalize else '纵轴单位：'+sets[0]['unit'])+' · '+all_dates[0]+' 至 '+all_dates[-1])+'</div>'
        return svg,rows,headers
    def articles(self,section,show_empty=True):
        from common import get_zone, iso
        out=''
        for a in sorted((a for a in self.d['articles'] if self.plan['articles'][a['id']]==section),key=lambda x:x['priority']):
            kind={'fact':'事实更新','analysis':'分析判断','watch':'待验证'}[a['kind']]
            zone=get_zone(self.d['meta']['timezone']);cutoff=iso(self.d['meta']['cutoff'])
            announced=any(self.facts[fid]['kind']=='event' and any(self.facts[fid].get(key) and iso(self.facts[fid][key],date_only=True,tz=zone)>cutoff for key in ('event_at','effective_at')) for fid in a['fact_ids'] if fid in self.facts)
            if announced:kind='已公告计划 · '+kind
            out+='<article class="article" id="article-'+self.plain(a['id'])+'"><div class="article-meta">'+kind+' · 优先级 '+str(a['priority'])+'</div><h3>'+self.plain(a['title'])+'</h3><p>'+self.text(a['text'])+self.refs(a['fact_ids'])+self.analysis_refs(a['analysis_ids'])+self.claim_refs(a['claim_ids'])+'</p>'
            if a.get('company'):
                company=a['company']
                out+='<div class="company-baseline"><b>'+self.plain(company['name']+' · '+company['ticker'])+'</b><p>财务基准：'+self.text(company['financial_baseline'])+'</p><p>履约条件：'+self.text(company['conditions'])+'</p></div>'
            out+='</article>'
        return out or (self.empty(section) if show_empty else '')
    def empty(self,section):
        task_id={'news':'official','ai':'official','companies':'companies','macro':'macro','market':'market','sectors':'themes'}.get(section)
        task=next((item for item in self.checks.get('research_completion',{}).get('tasks',[]) if item['id']==task_id),{})
        status=task.get('status','planned')
        message={'planned':'尚未调查','running':'研究尚未完成','verified_none':'已查指定窗口，未发现重要事项','blocked':'调查受阻','budget_stop':'到限停止，研究未完成','user_stop':'按用户要求停止','done':'已有研究内容，本栏目无适用事项'}.get(status,'状态未知')
        return '<p class="empty">'+self.plain(message+'。'+task.get('stop_reason',''))+'</p>'
    def analysis(self,a):
        out='<article class="analysis" id="a-'+self.plain(a['id'])+'"><span class="status">'+self.plain(a['sector'])+'</span><span class="status">'+self.plain(a.get('horizon','三个期限'))+'</span><span class="status '+('watch' if a['status']=='watch' else '')+'">'+STATUS[a['status']]+'</span><h3>'+self.plain(a['title'])+'</h3><p class="lead">'+self.text(a['conclusion'])+self.refs(a['fact_ids'])+'</p><p class="materiality"><b>量级与条件</b> '+self.text(a['materiality'])+self.claim_refs(a['field_claims'].get('materiality',[]))+'</p><details class="research-detail"><summary>事实基线、传导与竞争解释</summary><div class="fields">'
        for key,label in [('novelty','新增变化'),('earnings','利润传导'),('distribution','利益分配'),('pricing','市场反应'),('expectation','预期基准'),('alternative','竞争性解释'),('counterevidence','反证与脆弱环节')]:
            if key not in a:continue
            out+='<div class="field '+('full' if key=='counterevidence' else '')+'"><span class="label">'+label+'</span><p>'+self.text(a[key])+self.claim_refs(a['field_claims'].get(key,[]))+'</p></div>'
        out+='</div><p><b>研究优先级 P'+str(a['priority'])+'：</b>'+self.text(a['priority_reason'])+'</p></details>'
        state=self.checks['delivery']['analysis_status'].get(a['id'],{})
        if state.get('reasons'):out+='<div class="notice">本主题有限覆盖：'+self.text('；'.join(state['reasons']))+'</div>'
        out+='<div class="horizon-grid">'
        for key,label in [('intraday','当日至3个交易日'),('short','1—4周'),('medium','1—3个月')]:
            h=a['horizons'][key]
            out+='<div class="horizon"><h4>'+label+'</h4><p class="horizon-conclusion">'+self.text(h['conclusion'])+self.claim_refs(h['claim_ids'])+'</p>'
            for key,caption in (('earnings_channel','盈利'),('valuation_channel','估值'),('base_case','基本情景'),('counter_case','反向情景'),('uncertainty','不确定性')):
                if key in h:out+='<p>'+caption+'：'+self.text(h[key])+'</p>'
            out+='<p>下一观察：'+self.text(h['next_observation'])+'<br>复核：'+self.plain(h['review_at'])+'</p></div>'
        out+='</div><div class="verification"><div><b>支持判断的条件</b>'+self.text(a['support'])+'</div><div><b>削弱或推翻的条件</b>'+self.text(a['invalidation'])+'</div></div>'
        if a.get('update'):out+='<p>跨期变化：'+self.plain(a['update']['status'])+' · '+self.text(a['update']['reason'])+'</p>'
        out+=''.join(self.chart(c) for c in self.plan['charts'] if self.plan['routes'][c['id']]=='analysis:'+a['id'])
        if a['leaders']:
            out+='<h4>龙头与代表对象对照</h4><div class="leader-grid">'
            for l in a['leaders']:
                out+='<div class="leader"><h4>'+self.plain(l['name'])+'</h4><span class="ticker">'+self.plain(l['ticker']+' · '+l['market'])+'</span> <span class="status">'+ROLE[l['role']]+'</span>'+self.refs(l['fact_ids'])
                if l.get('series_id'): out+=self.spark(l['series_id'])
                out+='<dl>'
                for k,label in [('exposure','业务敞口'),('realization','兑现阶段'),('performance','市场表现'),('catalyst','下一催化'),('risk','主要风险')]: out+='<dt>'+label+'</dt><dd>'+self.text(l[k])+'</dd>'
                if l.get('industry_basis'):
                    b=l['industry_basis']
                    out+='<dt>产业地位比较依据</dt><dd>'+self.text(b['scope']+' · '+b['period']+' · '+b['comparison'])+self.refs(b['fact_ids'])+'</dd>'
                out+='</dl></div>'
            out+='</div>'
        out+='<details><summary>展开传导环节与研究缺口</summary>'+self.chain(a)
        out+=('<ul>'+''.join('<li>'+self.text(x)+'</li>' for x in a['gaps'])+'</ul>' if a['gaps'] else '<p>本条未记录额外资料缺口；仍需跟踪上述验证条件。</p>')+'</details></article>'
        return out
    def observation(self,o):
        out='<article class="obs"><span class="status '+('watch' if o['kind']=='watch' else '')+'">'+STATUS[o['kind']]+'</span><h3>'+self.plain(o['title'])+'</h3><div class="pair"><div><b>已有预期／讨论基准</b>'+self.text(o['expectation'])+self.refs(o['consensus_fact_ids'])+'</div><div><b>偏离证据</b>'+self.text(o['divergence'])+self.refs(o['fact_ids'])+'</div></div>'
        for k,label in [('mechanism','解释机制'),('materiality','为什么重要'),('opposition','最强反方'),('test','如何区分')]: out+='<p><b>'+label+'：</b>'+self.text(o[k])+'</p>'
        return out+self.claim_refs(o['claim_ids'])+'</article>'
    def action(self,a):
        out='<article class="action"><div class="priority">P'+str(a['priority'])+'</div><div><div class="action-when">'+self.plain(a['when'])+'</div><h3>'+self.text(a['target'])+'</h3><div class="action-grid">'
        for k,label in [('baseline','当前基准'),('support','支持条件'),('invalidation','否定条件'),('rule_basis','条件依据')]: out+='<div><b>'+label+'</b>'+self.text(a[k])+'</div>'
        out+='</div><p class="implication">'+self.text(a['implication'])+self.claim_refs(a['claim_ids'])+'</p><div class="meta"><span>有效至 '+self.plain(a['expires_at'].replace('T',' '))+'</span><a href="#a-'+self.plain(a['analysis_id'])+'">关联研究</a>'+self.refs(a['fact_ids'])+'</div></div></article>'
        return out
    def appendix(self):
        from research import coverage_view
        d=self.d; out='<details><summary>覆盖范围与数据缺口</summary>'
        out+='<ul>'+''.join('<li>'+self.text(g)+'</li>' for g in d['gaps'])+'</ul>' if d['gaps'] else '<p>本期没有记录全局数据缺口。</p>'
        labels={'checked_new':'已查·有新增','checked_none':'已查·未发现新增','failed':'访问失败','not_checked':'未检查','cache_reused':'复用缓存·非本轮访问'}
        out+=table(['来源范围','实际状态','说明'],[[self.plain(c['name']),labels[c['status']]+(' · 定向检索' if c['method']=='search' else ''),self.text(c['note'])+'<small>'+self.plain(c.get('content_scope','窗口范围未声明'))+'</small>'] for c in coverage_view(d['coverage'],d['meta']['window_start'],d['meta']['cutoff'])],'coverage-table')+'</details>'
        out+='<details id="evidence"><summary>事实与引用（'+str(len(d['facts']))+'项）</summary><ol class="evidence">'
        for f in d['facts']:
            role='公司自述' if any(self.sources[sid]['kind']=='company' for sid in f['source_ids']) else '官方声明' if any(self.sources[sid]['kind']=='official' for sid in f['source_ids']) else '媒体报道'
            label=role if f['status']=='reported' else STATUS[f['status']]
            out+='<li id="f-'+self.plain(f['id'])+'"><span class="status">'+label+'</span> '+self.text(f['statement'])+self.evidence_refs(f['evidence_ids'])+'<small>观测期：'+self.plain(f['as_of'])+' · 可得：'+self.plain(f['available_at'] or '未知')+' · '+self.text(f['locator'])+'</small><small>'+self.source_links(f['source_ids'])+'</small></li>'
        out+='</ol></details><details><summary>来源目录（'+str(len(d['sources']))+'项）</summary><ol class="source-list">'
        for s in d['sources']:
            prefix='包内读取记录' if d['meta'].get('evidence_mode')=='fixed_pack' else '来源读取记录'
            out+='<li><a href="'+self.plain(s['url'])+'" target="_blank" rel="noopener noreferrer">'+self.plain(s['title'])+'</a><br>'+self.plain(s['publisher']+' · 发布 '+s['published_at'])+'<br>'+self.plain(prefix+'：'+s['read_status']+' · '+s['accessed_at']+' · 同源组 '+s['origin_group'])
            v=s.get('verification')
            if v:
                labels={'verified':'完成原文核验','partial':'部分读取','failed':'访问失败','not_attempted':'未尝试'}
                out+='<br>'+self.plain('本轮复核：'+labels[v['status']]+' · '+v.get('checked_at','核验时间未记录'))+'<br>'+self.text(v['note'])
                if v.get('url'): out+=' · <a href="'+self.plain(v['url'])+'" target="_blank" rel="noopener noreferrer">实际访问地址</a>'
            out+='</li>'
        pairs=[m for m in d['metrics'] if m['op']=='pair_difference']
        if pairs:
            out+='</ol></details><details><summary>数值比较的计算依据</summary><ul>'
            for m in pairs:
                a=self.metrics[m['from_metric']]; b=self.metrics[m['to_metric']]
                out+='<li>'+self.plain(m['label'])+'：'+self.plain(self.metric(m['id']))+'<br>'+self.text(m['comparison_basis'])+'<br>'+self.plain(b['label']+' '+self.metric(b['id'])+' − '+a['label']+' '+self.metric(a['id'])+('；百分点差 × 100 转为基点' if m['unit']=='bp' and a['unit']=='%' else ''))+'<br>'+self.source_links(source_ids(d,m))+'</li>'
            out+='</ul>'
        else: out+='</ol>'
        out+='</details><details><summary>上期判断复核</summary>'
        if d.get('prior_reviews'):
            for p in d['prior_reviews']: out+='<p><b>'+self.plain(p['thesis_id'])+' v'+str(p['previous_version'])+'</b><br>'+self.plain(p['status'])+'：'+self.text(p['explanation'])+'</p>'
        else: out+='<p>本期没有可读取的上期判断记录，不作历史一致性声明。</p>'
        out+='</details><details><summary>审阅记录与计算检查</summary><p>'+self.plain(d['review']['reviewer'])+' · '+self.text(d['review']['method'])+'</p><p>结构与计算校验不证明来源真实性或经济因果。</p>'
        for issue in d['review']['issues']: out+='<p>'+('已解决：' if issue['resolved'] else '待处理：')+self.text(issue['message'])+((' · '+self.text(issue['resolution'])) if issue.get('resolved') else '')+'</p>'
        if self.checks['warnings']: out+='<ul>'+''.join('<li>'+self.plain(w['path']+'：'+w['message'])+'</li>' for w in self.checks['warnings'])+'</ul>'
        out+='</details><details id="claims"><summary>主张到证据的引用链</summary>'
        for c in d['claims']:
            out+='<p id="c-'+self.plain(c['id'])+'"><b>'+self.plain(c['id'])+' · '+self.plain(c['status'])+'</b> '+self.text(c['text'])+self.refs(c['fact_ids'])
            out+=' '.join('<a href="#m-'+self.plain(mid)+'">数值 '+self.plain(mid)+'</a>' for mid in c['metric_ids'])+'</p>'
            if c['limitations']:out+='<p class="notice">'+self.text('；'.join(g['message']+'：'+g['impact'] for g in c['limitations']))+'</p>'
        for mid,metric in self.metrics.items():
            detail=self.checks['metric_details'][mid]
            out+='<p id="m-'+self.plain(mid)+'">'+self.plain(metric['label'])+'：'+self.plain(self.metric(mid))+' · '+self.plain(detail['as_of'])+' · '+self.source_links(detail['source_ids'])+'</p>'
        for e in d['evidence']:
            out+='<blockquote id="e-'+self.plain(e['id'])+'">'+self.text(e['quote'])+'<small>'+self.text(e['context'])+' · '+self.text(e['locator'])+' · '+self.source_links([e['source_id']])+'</small></blockquote>'
        return out+'</details>'

def display_plan(d,checks):
    from common import fingerprint
    from validation import validate_charts
    edition=d['meta'].get('edition','snapshot');charts=list(d['charts']);omitted=[]
    if d['schema_version']>=4:
        qualified=[]
        for chart in charts:
            metric_ids=[item['metric_id'] for item in chart.get('items',[])]+[mid for row in chart.get('rows',[]) for mid in row['metric_ids']]+[item[key] for item in chart.get('points',[]) for key in ('x_metric','y_metric')]
            if set(metric_ids)&set(checks.get('unready_metrics',[])):omitted.append(dict(group=chart['id'],reason='数值或证据未就绪，未绘图；保留原值与局部限制'))
            else:qualified.append(chart)
        charts=qualified
    maps={group:{item['id']:item for item in d[group]} for group in ('metrics','series','analyses','events')}
    groups={};evidence={item['id']:item for item in d['evidence']};sources={item['id']:item for item in d['sources']}
    mentioned={item['metric_id'] for chart in charts for item in chart.get('items',[])}
    for metric in d['metrics']:
        eligible=metric['op']=='observed' and checks['values'].get(metric['id']) is not None and metric.get('chart_group') and metric.get('chart_takeaway') and metric.get('scope')
        eligible=eligible and bool(metric.get('evidence_ids')) and all(evidence.get(eid,{}).get('read_method') in ('original','cached') and sources.get(evidence[eid]['source_id'],{}).get('read_status') in ('full','partial') and sources.get(evidence[eid]['source_id'],{}).get('vintage',{}).get('available_at') for eid in metric.get('evidence_ids',[]))
        if eligible and metric['id'] not in mentioned:
            key=(metric['chart_group'],metric['unit'],metric['dimensions']['currency'],metric['dimensions']['scale'],metric['dimensions']['measure'],metric['as_of'],metric['scope'])
            groups.setdefault(key,[]).append(metric)
    for key,metrics in groups.items():
        if len(metrics)<2:
            omitted.append(dict(group=key[0],reason='不足两个同口径可比数值，保留数值卡/原值'))
            continue
        if len(charts)>=5:
            omitted.append(dict(group=key[0],reason='自动候选图超过阅读预算；保留原值'))
            continue
        chart=dict(id='auto_'+fingerprint(key)[:16],type='bars',title=key[0],takeaway=metrics[0]['chart_takeaway'],
                   note='单日截面 · '+key[5]+' · '+key[6]+' · 单位 '+key[1]+'；柱形含零轴，原值及来源可展开。',
                   placement='macro' if metrics[0]['dimensions']['measure'] in ('yield','fx','commodity') else 'market',
                   items=[dict(label=metric['label'],metric_id=metric['id']) for metric in metrics],generated=True,scope=key[6])
        errors=[];validate_charts(dict(d,charts=[chart]),maps,lambda *args:errors.append(args))
        if errors:omitted.append(dict(group=key[0],reason=str(errors)))
        else:charts.append(chart)
    def slot(placement,analysis=None):
        if edition=='intraday':return 'market' if placement=='market' else 'changes'
        if placement=='theme':return 'analysis:'+analysis
        if edition=='evening':return {'overview':'hero','ai':'macro'}.get(placement,placement)
        return {'companies':'news'}.get(placement,placement)
    routes={chart['id']:slot(chart['placement'],chart.get('analysis_id')) for chart in charts}
    if len(routes)!=len(charts):raise ValueError('展示计划存在重复图表ID')
    featured=d['meta'].get('featured_metrics',[])
    if not featured:
        featured=[metric['id'] for metric in d['metrics'] if metric['op']=='observed' and metric.get('scope') and checks['values'].get(metric['id']) is not None][:6]
    featured=[mid for mid in featured if checks['values'].get(mid) is not None]
    return dict(charts=charts,routes=routes,articles={article['id']:slot(article['section']) for article in d['articles']},
                summary='hero' if edition=='evening' else 'status' if edition=='intraday' else 'overview',featured=featured,
                omitted=omitted,accounting=dict(summary=len(d['summary']),metrics=len(featured),charts=len(charts),articles=len(d['articles'])))


def render_report(d,checks=None):
    from briefing import display_document
    from validation import validate
    from common import fingerprint
    if checks is None or checks.get('document_sha256')!=fingerprint(d):checks=validate(d)
    if checks['errors']:raise ValueError('渲染前校验未通过')
    return _render_display(display_document(d,checks),checks)


def _render_display(d,checks):
    r=Renderer(d,checks); meta=d['meta']
    r.plan=display_plan(d,checks)
    from edition import policy
    edition=meta.get('edition','snapshot')
    if edition=='intraday':
        titles=[('status','01','本轮状态'),('changes','02','重要新增与变动'),('market','03','盘面与原观察条件'),('next','04','下一观察'),('sources','05','来源与复核')]
    elif edition=='evening':
        titles=[('market','01','今日市场观察'),('news','02','今日中国官方重要信息'),('companies','03','收盘后重要公司公告'),
                ('sectors','04','重点板块跟踪'),('macro','05','海外市场与宏观传导 · AI'),('observations','06','非共识与待验证观察'),
                ('actions','07','明日 / 下一交易日重点观察'),('sources','08','来源与复核')]
    else:
        titles=[('overview','01','今日总览'),('news','02','昨日 / 夜间重要消息'),('ai','03','AI / ChatGPT / Codex'),('market','04','A股整体表现'),('sectors','05','板块深度分析'),('macro','06','美股与宏观'),('observations','07','非共识与待验证观察'),('actions','08','今日行动提示'),('sources','09','来源与复核')]
    section_labels=policy(edition).get('section_labels',())
    if section_labels:
        titles=[(section,f'{index:02}',label) for index,(section,label) in enumerate(section_labels,1)]
    # Explicit title overrides support other topics while keeping content slots stable.
    overrides=meta.get('section_titles',{})
    titles=[(i,n,overrides.get(i,t)) for i,n,t in titles]
    nav='<nav aria-label="报告目录">'+''.join('<a href="#'+i+'">'+n+' '+r.plain(t)+'</a>' for i,n,t in titles)+'</nav>'
    tools='<div class="tools"><button type="button" data-expand aria-pressed="false">展开证据与数据</button><button type="button" data-print>打印 / 存为PDF</button></div>'
    content='<header><div class="eyebrow">DAILY BRIEFING · '+r.plain(meta['date'])+'</div><h1>'+r.plain(meta['title'])+'</h1><div class="meta"><span>截至 '+r.plain(meta['cutoff'].replace('T',' '))+'</span><span>'+r.plain(meta['timezone'])+'</span><span>'+r.plain(' / '.join(meta['scope']))+'</span></div>'
    if meta.get('market_dates'): content+='<div class="meta">'+''.join('<span>'+r.plain(k+'行情：'+v)+'</span>' for k,v in meta['market_dates'].items())+'</div>'
    if meta['mode']!='live': content+='<span class="status">'+('教学测试数据' if meta['mode']=='teaching' else '历史时点回放')+'</span>'
    if meta.get('evidence_mode')=='fixed_pack': content+='<span class="status">固定资料对照 · 包内证据与本轮复核分别记录</span>'
    if checks.get('comparison',{}).get('valid_same_input') is False:content+='<div class="notice">本轮已声明证据层差异，不再属于完全相同输入的对照；详见检查记录。</div>'
    if checks.get('delta',{}).get('overflow_notice'):content+='<div class="notice">'+r.plain(checks['delta']['overflow_notice'])+'</div>'
    if d['review']['status']=='draft': content+='<div class="notice">草稿 · 尚未完成研究审阅，不应作为已核验结论使用。</div>'
    delivery=checks['delivery']
    grade_label={'full':'完整研究（程序门槛）','limited':'有限覆盖','observation':'观察版','draft':'草稿','incremental_verified':'增量核验完成','first_observation':'首次观察','partial_coverage':'部分覆盖'}[delivery['grade']]
    content+='<p class="delivery-status">'+grade_label+(' · '+r.text(d['gaps'][0] if d['gaps'] else '；'.join(delivery['reasons'][:2])) if delivery['reasons'] else '')+' <a href="#sources">查看研究边界</a></p>'
    if d['summary']:
        lead=d['summary'][0]
        content+='<p class="hero-judgment">'+r.text(lead['text'])+r.refs(lead['fact_ids'])+r.claim_refs(lead['claim_ids'])+'</p>'
        for key,label in (('priority_object','优先对象'),('change','相对基线'),('key_risk','关键风险')):
            if lead.get(key):content+='<p class="hero-note"><b>'+label+'：</b>'+r.text(lead[key])+'</p>'
    content+='<details class="mobile-nav"><summary>报告目录与工具</summary>'+nav+tools+'</details></header>'
    def section(key,body):
        _,n,t=next(x for x in titles if x[0]==key)
        return '<section id="'+key+'"><h2><span class="sec-num">'+n+'</span>'+r.plain(t)+'</h2>'+body+'</section>'
    summary='<div class="summary-grid">'
    for i,s in enumerate(d['summary'][1:]): summary+='<div class="summary-item"><div class="number">'+f'{i+2:02}'+'</div><p>'+r.text(s['text'])+r.refs(s['fact_ids'])+r.analysis_refs(s['analysis_ids'])+r.claim_refs(s['claim_ids'])+('<br><b>优先对象：</b>'+r.text(s['priority_object']) if s.get('priority_object') else '')+('<br><b>较前期：</b>'+r.text(s['change']) if s.get('change') else '')+('<br><b>证伪风险：</b>'+r.text(s['key_risk']) if s.get('key_risk') else '')+'</p></div>'
    summary+='</div>'
    def deferred_candidates():
        pending=[event for event in d.get('research_events',[])
                 if event.get('importance',0)>=5 and not event.get('reported') and event.get('reporting_disposition')]
        if not pending:return ''
        items=[]
        for event in pending:
            disposition='保留待报' if event['reporting_disposition']=='retained_pending' else '明确排除'
            identity=' · '.join(event.get(key,'') for key in ('entity','subject','family'))
            items.append('<li><b>'+r.plain(disposition+'：'+identity)+'</b> — '+r.text(event['reporting_reason'])+
                         r.claim_refs(event['claim_ids'])+'</li>')
        return '<div class=notice><b>重大候选处理</b><ul>'+''.join(items)+'</ul></div>'
    feature=r.plan['featured']
    if feature:
        summary+='<div class="stats">'
        for mid in feature:
            m=r.metrics[mid]; summary+='<div class="stat"><div class="label">'+r.plain(m['label'])+'</div><div class="value">'+r.plain(r.metric(mid))+'</div><small>'+r.plain(metric_date(d,m))+'</small></div>'
        summary+='</div>'
    def section_charts(key):return '<div class="chart-grid">'+''.join(r.chart(c) for c in r.plan['charts'] if r.plan['routes'][c['id']]==key)+'</div>'
    summary+=section_charts(r.plan['summary'])
    if edition=='intraday':
        baseline=checks.get('delta',{}).get('baseline')
        state=('比较：'+baseline['publication_id']+'，截至 '+baseline['cutoff'] if baseline else '本日首次观察；无已提交的同日可比基线')
        content+=section('status','<p>'+r.plain(state)+'；本轮截止 '+r.plain(meta['cutoff'])+'。</p>'+summary)
        changes=d['changes']
        event_changes=[c for c in changes if c['kind'] not in ('market','trigger')]
        market_changes=[c for c in changes if c['kind'] in ('market','trigger')]
        def change_card(change):
            from common import get_zone, iso
            event=next((item for item in d['research_events'] if item['event_key']==change['event_key']),None)
            cutoff=iso(meta['cutoff']);zone=get_zone(meta['timezone'])
            announced=bool(event and any(event.get(key) and iso(event[key],date_only=True,tz=zone)>cutoff for key in ('event_at','effective_at')))
            label='<span class=planned>已公告计划</span> ' if announced else ''
            return '<article class=change-item>'+label+'<h3>'+r.plain(change['text'])+'</h3><p>'+r.text(change['why'])+' → '+r.text(change['impact'])+r.claim_refs(change['claim_ids'])+'</p></article>'
        content+=section('changes',(''.join(change_card(c) for c in event_changes) or '<p class="empty">在已核验覆盖内未发现重大新增；未查或失败的入口不包含在此结论中。</p>')+r.articles('changes',False)+section_charts('changes'))
        content+=section('market',(''.join(change_card(c) for c in market_changes) or '<p class="empty">本轮没有已核实的可比盘面或原条件变化。</p>')+r.articles('market',False)+section_charts('market'))
        content+=section('next',''.join('<p>'+r.text(c['next_observation'])+'</p>' for c in changes if c.get('next_observation')) or '<p class="empty">暂无新增观察条件。</p>')
    elif edition=='evening':
        content+='<div class="hero-content" aria-label="综合判断与关键数字">'+summary+'</div>'
        content+=section('market',r.articles('market')+section_charts('market'))
        content+=section('news',r.articles('news')+section_charts('news'))
        content+=section('companies',r.articles('companies')+section_charts('companies'))
        content+=section('sectors',''.join(r.analysis(a) for a in d['analyses']) or '<p class="empty">暂无达到证据要求的重点板块。</p>')
        content+=section('macro',r.articles('macro')+section_charts('macro'))
        content+=section('observations',''.join(r.observation(o) for o in d['observations']) or '<p class="empty">暂无可证实的非共识观察。</p>')
        content+=section('actions',''.join(r.action(a) for a in sorted(d['actions'],key=lambda a:a['priority'])) or '<p class="empty">暂无新增条件。</p>')
    else:
        content+=section('overview',summary)+section('news',r.articles('news')+section_charts('news'))+section('ai',r.articles('ai')+section_charts('ai'))+section('market',r.articles('market')+section_charts('market'))
        content+=section('sectors',''.join(r.analysis(a) for a in d['analyses']) or '<p class="empty">本期没有达到深度分析证据要求的板块。</p>')
        content+=section('macro',r.articles('macro')+section_charts('macro'))
        content+=section('observations',''.join(r.observation(o) for o in d['observations']) or '<p class="empty">本期暂无达到证据要求的新增观察。</p>')
        content+=section('actions',''.join(r.action(a) for a in sorted(d['actions'],key=lambda a:a['priority'])) or '<p class="empty">本期没有新增可复核行动条件。</p>')
    completion=checks.get('research_completion',{})
    audit='<details><summary>交付、任务与展示记录</summary><p>'+r.text('；'.join(delivery['reasons']))+'</p><p>审阅：'+r.plain(delivery['review_status'])+' · 视觉：'+r.plain(delivery['visual_status'])+'。程序不证明事实或经济因果真实。</p>'
    audit+=''.join('<p>'+r.plain(item['id']+' · '+item['status']+' · '+item['stop_reason'])+'</p>' for item in completion.get('tasks',[]))
    audit+=''.join('<p>'+r.plain(item['group']+'：'+item['reason'])+'</p>' for item in r.plan['omitted'])+'</details>'
    content+=section('sources',deferred_candidates()+audit+r.appendix())
    for chart in r.plan['charts']:
        if content.count('id="chart-'+r.plain(chart['id'])+'"')!=1:raise ValueError('图表必须恰好展示一次：'+chart['id'])
    for article in d['articles']:
        if content.count('id="article-'+r.plain(article['id'])+'"')!=1:raise ValueError('正文必须恰好展示一次：'+article['id'])
    content+='<footer class="footer">'+r.plain(meta['title'])+' · 截至 '+r.plain(meta['cutoff'])+' 的研究快照。图表来自本报告资料；页面不自动更新行情。<br>作者/运行环境：'+r.plain(meta['author'])+' · 数据与审阅记录随报告保存。</footer>'
    assets=Path(__file__).resolve().parent.parent/'assets'
    css=(assets/'report.css').read_text(encoding='utf-8'); js=(assets/'report.js').read_text(encoding='utf-8')
    return '<!doctype html>\n<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light"><title>'+r.plain(meta['title'])+'</title><style>'+css+'</style></head><body><div class="shell"><aside class="side"><div class="brand">DAILY BRIEFING</div>'+nav+'<small>证据 · 机制 · 验证<br>'+r.plain(meta['date'])+'</small>'+tools+'</aside><main>'+content+'</main></div><div class="chart-tip" role="tooltip" hidden></div><script>'+js+'</script></body></html>\n'
