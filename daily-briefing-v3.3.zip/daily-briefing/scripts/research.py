"""Compact cumulative research state within each committed report snapshot."""
import copy
import re
import unicodedata
from datetime import timedelta
from common import fingerprint, iso

STATE_VERSION=2
MAX_EVENTS=200

WORK_PACKAGES=(
    ('market','先取得本期指数、成交额和口径明确的广度；再查少量重点对象历史','market 数值表',1),
    ('companies','先读取本期交易所公告候选，再核验金额或盈利影响最大的公司及最近财务基准','company 公告与基准，或有证据的窗口无重要公告',1),
    ('official','扫描中国官方指定栏目及重大地缘/Fed/AI入口；重要候选逐条处置','event 原文与 window 窗口记录',2),
    ('macro','取得本期利率、汇率或大宗变量并解释传导，不用AI新闻代替','market 宏观数值及 event 传导解释',2),
    ('themes','比较重点对象、业务敞口、量级、竞争解释及三个期限差异','thesis 逐项判断与证据',2),
    ('synthesis','形成综合判断、验证条件，复核证据并选择图表','review 摘要、证据审阅与展示选择',3),
)


def task_plan(contract):
    if contract.get('edition')=='intraday':
        packages=[('sentinel','扫描重大事件入口及相对同日已报基线的变化；无变化需窗口证据','window / event；复用 changes 协议',1),
                  ('synthesis','复核本轮变化与下一观察，保持简短','review',2)]
    else:
        packages=list(WORK_PACKAGES)
        scope=contract.get('scope',[])
        if contract.get('profile')!='finance-ai':
            packages=[item for item in packages if item[0] not in ('market','companies','macro') or
                      (item[0] in ('market','companies') and 'A股' in scope) or (item[0]=='macro' and any(value in scope for value in ('宏观','全球宏观')))]
    return [dict(id=key,question=question,priority=priority,target_evidence=product,current_conclusion='',
                 next=question,stop_reason='',status='planned',attempts=[],evidence_ids=[],product_ids=[])
            for key,question,product,priority in packages]


def coverage_attempts(entries):
    return [attempt for entry in entries for attempt in entry.get('attempts',[entry])]


def coverage_view(entries,window_start=None,window_end=None):
    groups={}
    for entry in entries:
        for obligation in entry['obligation_ids']:
            key=(obligation,entry.get('role','discovery'),window_start or entry['window_start'],window_end or entry['window_end'])
            group=groups.setdefault(key,[])
            for attempt in entry.get('attempts',[entry]):
                item=copy.deepcopy(attempt)
                item.pop('attempts',None);item.pop('role',None)
                item['obligation_ids']=[obligation]
                if item not in group:group.append(item)
    result=[]
    for key,attempts in groups.items():
        attempted=[item for item in attempts if item['status']!='not_checked']
        attempts=attempted or attempts
        representative=max(attempts,key=lambda item:(item['checked_at'] or '',item['status']=='failed'))
        row=copy.deepcopy(representative)
        row.update(id='cov_'+fingerprint(key)[:16],role=key[1],attempts=attempts)
        states={item['status'] for item in attempts}
        if len(states)>1:row['note']='多次尝试并存：'+ '；'.join(dict.fromkeys(item['note'] for item in attempts))
        result.append(row)
    return result


def task_progress(document,contract):
    tasks=document.get('tasks',[])
    if document.get('schema_version',2)<4:return dict(complete=True,tasks=[],pending=[],stop_reasons=[],next_actions=[])
    by_id={item['id']:item for item in tasks}
    evidence={item['id']:item for item in document['evidence']}
    sources={item['id']:item for item in document['sources']}
    def grounded(ids):
        return bool(ids) and all(ident in evidence and evidence[ident]['read_method'] in ('original','cached') and
                                sources.get(evidence[ident]['source_id'],{}).get('read_status') in ('full','partial') for ident in ids)
    def usable(metric):
        available=metric.get('available_at')
        return metric.get('value') is not None and available and iso(available)<=iso(contract['initial_cutoff']) and grounded(metric['evidence_ids'])
    products={item['id']:item for group in ('articles','metrics','analyses','coverage','changes') for item in document[group] if 'id' in item}
    result=[]
    for planned in task_plan(contract):
        item=copy.deepcopy(by_id.get(planned['id'],planned))
        key=item['id'];ids=item['product_ids'];reason=''
        attempts=item['attempts']
        recorded=bool(attempts) and all(attempt.get('query_or_url') and attempt.get('result') for attempt in attempts)
        completed=item['status'] in ('done','verified_none')
        if completed:
            if not recorded or not grounded(item['evidence_ids']):reason='完成声明缺少可核验尝试与原文记录'
            elif key in ('market','macro') and item['status']=='done':
                numeric=[products[ident] for ident in ids if ident in products and products[ident].get('op')=='observed' and products[ident].get('value') is not None]
                if not numeric or not all(usable(metric) for metric in numeric):reason='缺少截止时已可得、可核验的本期数值'
                elif key=='market' and not {'index_change','turnover','breadth'}<=set(metric['dimensions']['measure'] for metric in numeric):reason='需指数变化、成交额与明确范围的广度；受阻项须写明限制'
                elif key=='macro' and not any(article['section']=='macro' for article in document['articles']):reason='宏观数值还需传导解释'
            elif key=='companies' and item['status']=='done':
                companies=[products[ident] for ident in ids if ident in products and products[ident].get('company')]
                if not companies:reason='无公司实体/公告标识；政策文章不满足公司研究'
                elif not all(article['company'].get('financial_baseline') for article in companies):reason='缺少最近公开财务规模基准'
                elif not all(any(usable(metric) and metric['dimensions']['entity_id']==article['company']['entity_id'] and metric['dimensions']['measure'] in ('revenue','profit','net_profit','cash_flow','assets','total_assets','backlog','capex') for metric in document['metrics'] if metric['op']=='observed') for article in companies):reason='财务基准需要同实体可得的收入/利润/现金流等数值及其来源，不能只写已核验'
            elif key=='themes' and not any(analysis['id'] in ids for analysis in document['analyses']):reason='缺少三期限比较研究'
            elif key in ('official','sentinel') and item['status']=='done':
                required_ids={entry['id'] for entry in contract['coverage_obligations'] if entry['critical']}
                attempted_ids={oid for entry in coverage_attempts(document['coverage']) if entry['status']!='not_checked' and entry['checked_at'] for oid in entry['obligation_ids']}
                if required_ids-attempted_ids:reason='尚有未尝试的指定窗口；继续扫描或记录有依据的受阻/到限状态'
            elif key=='synthesis' and (document['review']['status']=='not_reviewed' or (contract.get('edition')!='intraday' and (not document['summary'] or not document['actions']))):reason='缺少摘要/验证条件或真实审阅'
            if item['status']=='verified_none':
                scans=[attempt for attempt in coverage_attempts(document['coverage']) if attempt['status']=='checked_none' and
                       attempt['method'] in ('original_index','aggregate') and attempt.get('content_scope') and grounded(attempt['mapping_evidence_ids']) and
                       iso(attempt['window_start'])<=iso(contract['requested_window_start']) and iso(attempt['window_end'])>=iso(contract['initial_cutoff'])]
                if key=='companies':
                    scans=[scan for scan in scans if set(scan['obligation_ids']) & {'sse','szse','bse'} and '公告' in scan['content_scope']]
                    required_exchanges={entry['id'] for entry in contract['coverage_obligations']} & {'sse','szse','bse'}
                    if required_exchanges-{oid for scan in scans for oid in scan['obligation_ids']}:reason='公司无重要公告需要目标范围内交易所候选窗口，不能只查一个入口'
                if not scans:reason='无重要新增需要指定入口完整窗口证据，搜索空结果不足'
                if key not in ('companies','official','sentinel'):reason='本任务需要本期数值或比较判断，不能用无新增替代研究'
        elif item['status']=='blocked' and (not recorded or not item['stop_reason'] or not any(attempt['status'] in ('failed','restricted') for attempt in attempts)):reason='受阻状态缺少实际失败尝试/错误'
        elif item['status'] in ('budget_stop','user_stop') and not item['stop_reason']:reason='停止需要具体原因'
        if reason:item.update(status='running',next=reason)
        item['product_check']=reason or '符合可见记录约束；程序不证明工具记录真实性'
        result.append(item)
    pending=[item for item in result if item['status'] not in ('done','verified_none','blocked','budget_stop','user_stop')]
    stops=[item for item in result if item['status'] in ('blocked','budget_stop','user_stop')]
    actions=[dict(task_id=item['id'],action=item['next'],input=dict(task=item['id'],kind='market' if item['id']=='market' else 'company' if item['id']=='companies' else 'window' if item['id'] in ('official','sentinel') else 'thesis' if item['id']=='themes' else 'review' if item['id']=='synthesis' else 'event'))
             for item in sorted(pending,key=lambda item:(len(item['attempts'])>0,item['priority']))[:3]]
    return dict(complete=not pending and not stops,tasks=result,pending=[item['id'] for item in pending],
                stop_reasons=[dict(task_id=item['id'],status=item['status'],reason=item['stop_reason']) for item in stops],next_actions=actions)


def event_key(entity,subject,family,release_id):
    """Stable identity fields, never a headline, local F/C id or URL."""
    parts=[]
    for value in (entity,subject,family,release_id):
        normalized=unicodedata.normalize('NFKC',value).casefold().strip()
        normalized=re.sub(r'[^\w-]+','-',normalized,flags=re.UNICODE).strip('-')
        if not normalized:raise ValueError('事件身份字段不能为空')
        parts.append(normalized)
    return ':'.join(parts)


def candidate_matches(candidate,known):
    """Surface possible aliases for human review; ambiguity is never auto-merged."""
    identity=(candidate['entity'],candidate['subject'],candidate['family'])
    aliases=set(candidate.get('aliases',[]))
    return [event['event_key'] for event in known if
            (event['entity'],event['subject'],event['family'])==identity and
            (event['event_key']==candidate['event_key'] or aliases.intersection(event.get('aliases',[])))]


def scan_windows(contract,previous=None):
    """Bounded overlap, by independently successful source role; not a search result."""
    end=iso(contract['initial_cutoff'])
    requested=iso(contract['requested_window_start'])
    roles=(previous or {}).get('coverage',{})
    windows=[]
    for entry in contract['coverage_obligations']:
        if not entry['url']:continue
        last=roles.get(entry['id'])
        overlap=iso(last)-timedelta(hours=24) if last else requested
        start=max(requested,min(overlap,end))
        windows.append(dict(source_id=entry['id'],channel=entry.get('channel','official_index'),url=entry['url'],
                            start=start.isoformat(),end=end.isoformat(),prior_success=last,
                            required=entry['critical']))
    return windows


def evidence_refs(events,publication_id):
    return [dict(item,source_refs=[dict(publication_id=publication_id,id=source_id) for source_id in item['source_ids']],
                 evidence_refs=[dict(publication_id=publication_id,id=evidence_id) for evidence_id in item['evidence_ids']])
            for item in events]


def event_signature(event):
    return dict(version=event['version'],attributes=event['attributes'],status=event['status'])


def has_report_reference(document,event):
    reference=event.get('report_ref')
    if not isinstance(reference,dict):return False
    item_id=reference.get('item_id')
    if reference.get('section')=='change':
        item=next((x for x in document.get('changes',[]) if x.get('event_key')==item_id),None)
    elif reference.get('section')=='article':
        item=next((x for x in document.get('articles',[]) if x.get('id')==item_id),None)
    else:return False
    return bool(item and set(event.get('claim_ids',[])) & set(item.get('claim_ids',[])))


def compare(events,previous,cutoff):
    old={x['event_key']:x for x in (previous or {}).get('events',[])}
    changes={}
    for event in events:
        prior=old.get(event['event_key'])
        if not prior:
            changes[event['event_key']]='late_discovery' if previous and event['published_at'] and iso(event['published_at'])<iso(previous['cutoff']) else 'new'
            continue
        reported=prior.get('reported_snapshot')
        if reported is None and prior.get('reported_version'):
            legacy_signature=event_signature(prior)
            if prior['reported_version']==fingerprint((legacy_signature['version'],legacy_signature['attributes'],legacy_signature['status'])):
                reported=legacy_signature
        if reported is None:
            changes[event['event_key']]='late_discovery'
            continue
        current=event_signature(event)
        if current==reported:continue
        if event['status'] in ('corrected','withdrawn') and (reported['status']!=event['status'] or reported['attributes']!=event['attributes']):
            changes[event['event_key']]='correction'
        else:
            changes[event['event_key']]='progress'
    return changes


def project(previous,document,publication_id,checks):
    old=(previous or {}).get('events',[])
    state={event['event_key']:event for event in old}
    for event in evidence_refs(document.get('research_events',[]),publication_id):
        event.setdefault('reported',False)
        prior=state.get(event['event_key'])
        if prior:
            if prior.get('first_seen_at'):
                event['first_seen_at']=prior['first_seen_at']
            else:
                event['observation_integrity']='legacy_first_seen_unknown'
            reported=prior.get('reported_snapshot')
            if reported is None and prior.get('reported_version'):
                legacy_signature=event_signature(prior)
                if prior['reported_version']==fingerprint((legacy_signature['version'],legacy_signature['attributes'],legacy_signature['status'])):
                    reported=legacy_signature
                    event['reported_integrity']='legacy_consistent'
                else:
                    event['reported_integrity']='legacy_unknown'
            elif reported is not None:
                event['reported_integrity']=prior.get('reported_integrity','verified')
            if reported is not None:
                event['reported_snapshot']=copy.deepcopy(reported)
                event['reported_version']=fingerprint((reported['version'],reported['attributes'],reported['status']))
                event['last_reported_at']=prior.get('last_reported_at')
        observed=event_signature(event)
        event['latest_observed']=copy.deepcopy(observed)
        event['latest_signature']=fingerprint(observed)
        event['reported']=bool(event.get('reported') and has_report_reference(document,event))
        if event['reported']:
            event['reported_snapshot']=event_signature(event)
            event['reported_integrity']='verified'
            event['reported_version']=fingerprint((event['version'],event['attributes'],event['status']))
            event['last_reported_at']=document['meta']['cutoff']
        state[event['event_key']]=event
    ordered=sorted(state.values(),key=lambda x:(
        bool(x.get('importance',0)>=5 and x.get('reported_snapshot')!=event_signature(x)),
        x.get('importance',0),x.get('last_verified_at') or ''),reverse=True)
    coverage=dict((previous or {}).get('coverage',{}))
    accepted=set(checks['delivery']['coverage']['covered_ids'])
    for entry in coverage_attempts(document['coverage']):
        if entry['status'] in ('checked_new','checked_none') and entry['method'] in ('original_index','aggregate'):
            for obligation in entry['obligation_ids']:
                if obligation in accepted:
                    coverage[obligation]=entry['window_end']
    important_pending=[x for x in ordered if x.get('importance',0)>=5 and x.get('reported_snapshot')!=event_signature(x)]
    important_keys={x['event_key'] for x in important_pending}
    remaining=[x for x in ordered if x['event_key'] not in important_keys]
    selected=important_pending+remaining[:max(0,MAX_EVENTS-len(important_pending))]
    omitted=max(0,len(ordered)-len(selected))
    overflow_important=max(0,len(important_pending)-MAX_EVENTS)
    return dict(version=STATE_VERSION,date=document['meta']['date'],cutoff=document['meta']['cutoff'],
                events=selected,coverage=coverage,omitted=omitted,
                omitted_important=0,overflow_important=overflow_important,
                overflow_notice='重要未报事件超过常规上限，已保留全部待报项' if overflow_important else None,
                baseline=publication_id)
