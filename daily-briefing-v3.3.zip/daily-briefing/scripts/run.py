#!/usr/bin/env python3
"""Archive-based research runner. No scheduler or provider API calls."""
import argparse
import json
from pathlib import Path
import secrets
import sys
if sys.version_info < (3,10):
    print(json.dumps({'status':'blocked','category':'capability_unavailable','error':'Python 3.10+ required'}));raise SystemExit(3)
sys.dont_write_bytecode=True
from common import InputError, VERSION, fingerprint, load, save, stamp
from workflow import GUIDES, start, read_state, guide, finish, status, sync_info
from capabilities import CapabilityError, read_json_output
import archive
from storage import lock


def check_retry(args,state):
    contract=state['contract']
    if args.revise or args.reason or getattr(args,'independent',False):
        raise InputError('revise','指定旧run只能恢复原契约；修订需按同一期重新start','version_conflict')
    if args.preset is not None and contract.get('edition')!='morning':
        raise InputError('preset','盘前预设与旧版型冲突','version_conflict')
    pairs={'edition':'edition','date':'date','timezone':'timezone','profile':'profile','mode':'mode',
           'window_start':'requested_window_start','cutoff':'initial_cutoff'}
    for field,key in pairs.items():
        value=getattr(args,field,None)
        if value is not None and value!=contract.get(key):raise InputError(field,'重试不能更改已冻结研究契约','version_conflict')
    if args.scope is not None and sorted(set(x.strip() for x in args.scope if x.strip()))!=contract['scope']:
        raise InputError('scope','重试范围与已冻结契约冲突','version_conflict')
    if args.scheduled_for is not None and args.scheduled_for!=state.get('scheduled_for'):
        raise InputError('scheduled_for','重试计划时刻冲突','version_conflict')
    if args.calendar is not None and fingerprint(load(args.calendar))!=contract.get('session',{}).get('calendar_hash'):
        raise InputError('calendar','重试日历版本冲突','version_conflict')
    if args.evidence_pack is not None:
        from common import digest
        if digest(args.evidence_pack)!=state.get('evidence_sha256'):raise InputError('evidence_pack','重试固定资料包冲突','version_conflict')
    if args.budget is not None:
        supplied=load(args.budget)
        if any(state['budget'].get(k)!=v for k,v in supplied.items()):raise InputError('budget','重试预算冲突','version_conflict')


class InputParser(argparse.ArgumentParser):
    def error(self,message):raise InputError('arguments',message)


def main(argv=None):
    p=InputParser(description=__doc__);commands=p.add_subparsers(dest='command',required=True,parser_class=InputParser)
    for name in ('init','configure','options','start','resume','status','finish','guide','merge','submit','import-series','inspect','compute','record','task','cache-put','cache-get','history','unlock','visual','describe','rebuild-index','confirm-archive','restore-archive','preflight'):
        q=commands.add_parser(name)
        q.add_argument('--archive-root');q.add_argument('--config');q.add_argument('--work-dir');q.add_argument('--state-root')
        q.add_argument('--run-id');q.add_argument('--run-token')
        if name in ('init','configure'):
            q.add_argument('--persistence',choices=['local_confirmed','host_handoff','ephemeral_only'])
            q.add_argument('--host-target');q.add_argument('--save-config',action='store_true');q.add_argument('--fork',action='store_true')
        if name=='options':
            q.add_argument('--calendar');q.add_argument('--select',choices=['1','2','3','morning','intraday','evening']);q.add_argument('--menu-date')
            q.add_argument('--date')
        if name=='start':
            q.add_argument('--edition',choices=['morning','evening','intraday','snapshot']);q.add_argument('--calendar');q.add_argument('--cutoff');q.add_argument('--date')
            q.add_argument('--scheduled-for');q.add_argument('--unattended',action='store_true')
            q.add_argument('--timezone');q.add_argument('--window-start');q.add_argument('--profile')
            q.add_argument('--scope',nargs='+');q.add_argument('--mode',choices=['live','historical','teaching'])
            q.add_argument('--preset',choices=['premarket']);q.add_argument('--model',default='unknown');q.add_argument('--harness',default='unknown')
            q.add_argument('--reasoning',default='unknown');q.add_argument('--budget');q.add_argument('--capabilities');q.add_argument('--evidence-pack')
            q.add_argument('--revise',action='store_true');q.add_argument('--independent',action='store_true');q.add_argument('--reason');q.add_argument('--session-id')
        if name=='resume':q.add_argument('--takeover',action='store_true');q.add_argument('--reason');q.add_argument('--session-id')
        if name=='guide':
            q.add_argument('--name',choices=list(GUIDES),required=True);q.add_argument('--context-epoch',default='initial')
            q.add_argument('--recovery-reason',default='');q.add_argument('--ack');q.add_argument('--replay',action='store_true');q.add_argument('--page-chars',type=int)
        if name in ('merge','submit','import-series','record','task','cache-put','visual','confirm-archive','restore-archive','preflight'):q.add_argument('--input',required=True)
        if name=='finish':q.add_argument('--preview',action='store_true')
        if name=='import-series':q.add_argument('--metadata',required=True)
        if name in ('inspect','describe'):q.add_argument('--group',required=True)
        if name=='inspect':q.add_argument('--id');q.add_argument('--offset',type=int,default=0);q.add_argument('--limit',type=int,default=10)
        if name=='compute':q.add_argument('--ids',nargs='+')
        if name=='cache-get':q.add_argument('--id',required=True);q.add_argument('--triggers',nargs='*',default=[])
        if name=='history':
            q.add_argument('--cutoff',required=True);q.add_argument('--namespace',choices=['live','historical','teaching'],default='live')
            q.add_argument('--limit',type=int,default=12);q.add_argument('--offset',type=int,default=0)
            q.add_argument('--thesis-id');q.add_argument('--projection-version')
        if name=='preflight':q.add_argument('--reason',required=True)
        if name=='unlock':q.add_argument('--lock-target',choices=['run','commit'],required=True);q.add_argument('--lock-id',required=True);q.add_argument('--reason',required=True)
    try:
        args=p.parse_args(argv)
        result,code=execute(args)
    except (InputError,CapabilityError) as exc:
        result=dict(status='missing_publication' if exc.category=='missing_publication' else 'blocked',category=exc.category,path=getattr(exc,'path',getattr(exc,'capability','runtime')),error=str(exc));code=3
    except (ValueError,KeyError,TypeError) as exc:
        result=dict(status='blocked',category='input_error',path='input',error=str(exc));code=2
    except OSError as exc:
        result=dict(status='blocked',category='infrastructure_error',error=str(exc),next='原状态保留；仅重试存储阶段，不重做研究。');code=3
    except KeyboardInterrupt:
        result=dict(status='interrupted',category='interrupted');code=130
    except Exception as exc:
        result=dict(status='blocked',category='program_defect',error=type(exc).__name__+': '+str(exc));code=4
    # Keep acknowledgement after page content. Canonical JSON is for hashes only.
    print(json.dumps(result,ensure_ascii=False,allow_nan=False));return code


def execute(args):
    cmd=args.command
    if cmd=='options':
        from edition import options
        from common import localize
        now=localize(stamp(),'Asia/Shanghai');calendar=load(args.calendar) if args.calendar else None
        target=args.date or now.date().isoformat()
        choices=options(now,calendar,target)
        selected=next((x for x in choices if str(x['number'])==args.select or x['id']==args.select),None) if args.select else None
        if args.select and (args.menu_date!=now.date().isoformat() or selected is None or not selected['available']):
            return dict(status='selection_expired',date=now.date().isoformat(),target_date=target,options=choices,next='菜单生成日期已过期或目标会话不可用；按目标日期重新选择。'),0
        return dict(status='selected' if selected else 'action_required',date=now.date().isoformat(),target_date=target,options=choices,
                    selected_id=selected['id'] if selected else None,next='选择后用start --edition <ID>；start会再次核验会话。'),0
    if cmd in ('init','configure'):
        root=Path(args.archive_root).absolute() if args.archive_root else Path.home()/'DailyBriefing'
        config=Path(args.config) if args.config else archive.CONFIG if args.save_config else None
        return archive.initialize(root,config,persistence=args.persistence or ('local_confirmed' if cmd=='configure' else None),bind=cmd=='configure',fork=args.fork,host_target=load(args.host_target) if args.host_target else None),0
    root,info=archive.resolve_root(args)
    if cmd=='rebuild-index':return archive.rebuild(root),0
    if cmd=='unlock':
        from storage import unlock
        target=archive.run_path(root,args.run_id) if args.lock_target=='run' else root/'.runtime/locks'
        return unlock(target,args.lock_id,args.reason),0
    archive.recover(root)
    if cmd=='history':return archive.historical(root,args.cutoff,args.namespace,limit=args.limit,offset=args.offset,
        thesis_id=args.thesis_id,projection_version=args.projection_version),0
    if cmd=='restore-archive':return archive.restore_host(root,load(args.input)),0
    if cmd=='start':
        if args.work_dir:
            work=Path(args.work_dir).resolve();old=read_state(work)
            if not work.is_relative_to(root/'.runtime/runs'):raise InputError('work_dir','兼容工作目录必须属于该资料库runtime；旧目录需要显式迁移')
            check_retry(args,old)
            return status(work,old),0
        if args.run_id:
            work=archive.run_path(root,args.run_id);st=read_state(work)
            check_retry(args,st)
            return status(work,st),0
        resolved=archive.issue_contract(args,info)
        if resolved['status']=='not_due':return resolved,0
        from workflow import start_inputs
        start_inputs(args,resolved['contract']['edition'])
        claimed=archive.claim(root,resolved['contract'],revision=args.revise,reason=args.reason,session=args.session_id,
                              scheduled_for=args.scheduled_for,independent=args.independent)
        if claimed['status']!='new':
            if claimed['status']=='already_published':claimed['output']=str(archive.safe_path(root,claimed['publication']['relative_path'])/claimed['publication']['html_name'])
            return claimed,0
        initial=dict(resolved,**claimed,archive_root=str(root))
        args.cutoff=resolved['contract']['initial_cutoff'];args.mode=resolved['contract']['mode'];args.profile=resolved['contract']['profile'];args.scope=resolved['contract']['scope']
        result=start(args,Path(claimed['work_dir']),initial)
        result.update(run_id=claimed['run_id'],run_token=claimed['run_token'],issue_key=claimed['contract']['issue_key'],archive_root=str(root))
        return result,3 if result['phase']=='blocked' else 0
    if not args.run_id and not args.work_dir:raise InputError('run_id','需要start返回的run_id；不猜最近运行')
    work=archive.run_path(root,args.run_id) if args.run_id else Path(args.work_dir).resolve()
    if not work.is_relative_to(root/'.runtime/runs'):raise InputError('work_dir','工作目录不属于所选资料库')
    if not (work/'run-state.json').exists() and cmd=='resume' and args.takeover and args.reason:
        reservation=load(work/'claim.json');token='rt_'+secrets.token_urlsafe(24)
        reservation['owner']=dict(token_hash=fingerprint(token),session_id=args.session_id,claimed_at=stamp(),recovery_reason=args.reason)
        reservation['archive_root']=str(root)
        c=reservation['contract']
        recovery=argparse.Namespace(evidence_pack=None,cutoff=c['initial_cutoff'],date=None,preset=None,timezone=c['timezone'],
             window_start=c['requested_window_start'],profile=c['profile'],scope=c['scope'],mode=c['mode'],budget=None,
             state_root=str(root),capabilities=None,model='unknown',harness='unknown',reasoning='unknown')
        result=start(recovery,work,reservation);result.update(run_id=reservation['run_id'],run_token=token)
        return result,0
    state=read_state(work)
    if state['contract']['archive_id']!=info['archive_id']:raise InputError('archive_id','运行属于另一个资料库','version_conflict')
    # Root relocation is not a contract change; root itself never enters issue identity.
    state['state_root']=str(root)
    if cmd=='status':return status(work,state),0
    if cmd=='resume':
        if not args.takeover:return dict(status(work,state),next='需要写入时使用resume --takeover --reason明确认领'),0
        if not args.reason:raise InputError('reason','显式接管必须说明原执行已停止/迁移原因')
        with lock(work,reason='explicit owner takeover'):
            state=read_state(work);state['state_root']=str(root);state.setdefault('owners',[]).append(dict(previous=state['owner'],reason=args.reason,at=stamp()))
            token='rt_'+secrets.token_urlsafe(24);state['owner']=dict(token_hash=fingerprint(token),session_id=args.session_id,claimed_at=stamp());save(work/'run-state.json',state)
        return dict(status(work,state),run_id=state['run_id'],run_token=token),0
    read_only=cmd in ('inspect','describe','cache-get')
    if not read_only and cmd!='unlock':archive.authenticate(state,args.run_token)
    from contextlib import nullcontext
    with nullcontext() if read_only else lock(work,reason=cmd,owner=state['owner']['token_hash']):
        if not read_only:
            state=read_state(work);state['state_root']=str(root)
            archive.authenticate(state,args.run_token)
        import data_io
        if cmd=='finish':return finish(work,state,preview=args.preview)
        if cmd=='guide':return guide(args,work,state),0
        if cmd=='confirm-archive':return archive.confirm_host(root,work,state,load(args.input)),0
        if (work/'prepared.json').exists() and state['phase'] not in ('published','persistent_confirmed') and cmd in ('merge','submit','import-series','preflight','compute','cache-put','record','task'):
            raise InputError('input','prepared后研究输入已冻结；不得半接受修改','version_conflict')
        if cmd=='preflight':
            from workflow import update_preflight
            result=update_preflight(work,state,args.input,args.reason);return result,3 if result['status']=='blocked' else 0
        if cmd=='visual':
            from workflow import visual_update
            return visual_update(work,state,read_json_output(args.input)),0
        if state['phase'] in ('published','persistent_confirmed') and cmd in ('merge','submit','import-series','task'):raise InputError('input','已发布数据不可改，显式修订','version_conflict')
        if cmd=='merge':return data_io.merge(work,read_json_output(args.input)),0
        if cmd=='submit':return data_io.submit(work,state,read_json_output(args.input)),0
        if cmd=='import-series':return data_io.import_series(work,args.input,args.metadata),0
        if cmd=='inspect':return data_io.inspect(work,args.group,args.id,args.offset,args.limit),0
        if cmd=='describe':return data_io.describe(args.group),0
        if cmd=='compute':
            result=data_io.compute(work,state,args.ids);return result,2 if result['error_count'] else 0
        if cmd=='record':return data_io.record(work,state,load(args.input)),0
        if cmd=='task':return data_io.task(work,state,load(args.input)),0
        import storage
        if cmd=='cache-put':return dict(path=storage.cache_put(root/'.runtime',load(args.input))),0
        if cmd=='cache-get':return storage.cache_get(root/'.runtime',args.id,state['contract']['initial_cutoff'],args.triggers),0
    raise InputError('command','未实现命令')


if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8');raise SystemExit(main())
