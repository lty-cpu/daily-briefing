"""Small shared contracts: strict JSON, clocks, hashing and atomic local writes."""
from __future__ import annotations
from datetime import date, datetime, time, timedelta, timezone
import hashlib
import json
import math
from pathlib import Path
import re
from urllib.parse import urlsplit
from uuid import uuid4
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
ZONE_TYPE = ZoneInfo

VERSION = '3.4'
SCHEMA_VERSION = 5
ID = re.compile(r'^[A-Za-z][A-Za-z0-9_-]{0,95}$')
TOKEN = re.compile(r'\{metric:([A-Za-z][A-Za-z0-9_-]*)\}')


def num(value):
    return type(value) in (int, float) and math.isfinite(value)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def fingerprint(value):
    return hashlib.sha256(canonical(value).encode('utf-8')).hexdigest()


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def loads(text):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError('重复JSON键: ' + key)
            result[key] = value
        return result
    def bad(value):
        raise ValueError('非法JSON数字: ' + value)
    return json.loads(text, object_pairs_hook=pairs, parse_constant=bad)


def load(path):
    return loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value, exclusive=False):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n'
    if exclusive:
        with path.open('x', encoding='utf-8', newline='\n') as stream:
            stream.write(text)
        return
    temp = path.with_name(path.name + '.' + uuid4().hex + '.tmp')
    try:
        temp.write_text(text, encoding='utf-8', newline='\n')
        temp.replace(path)
    finally:
        if temp.exists():
            temp.unlink()


def stamp():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


class InputError(ValueError):
    def __init__(self, path, message, category='input_error'):
        super().__init__(message)
        self.path, self.category = path, category


def actual_time(value, available, cutoff, zone, *, period_end=False):
    """Return one controlled violation; a date denotes a day, never invented 00:00."""
    cutoff=iso(cutoff) if isinstance(cutoff,str) else cutoff
    av=iso(available) if available else None
    tz=get_zone(zone)
    if re.fullmatch(r'\d{4}-\d{2}-\d{2}',value):
        day=date.fromisoformat(value)
        if day>cutoff.astimezone(tz).date():return '实绩观测日期晚于截止'
        if av and day>av.astimezone(tz).date():return '数据公开早于观测日期'
        if period_end and av and iso(value,True,tz)>av:return '期间实绩在期间结束前公开'
    else:
        observed=iso(value)
        if observed>cutoff:return '实绩时点晚于截止；同日也不能穿越'
        if av and observed>av:return '实绩发生晚于声明的公开时刻'
    if av and av>cutoff:return '数据在截止后公开'
    return None


def get_zone(name):
    if not isinstance(name, str) or not name or name.startswith(('/', '.')):
        raise ValueError('需要有效IANA时区名称')
    try:
        return ZoneInfo(name)
    except (ZoneInfoNotFoundError, ValueError) as exc:
        # Explicit and narrowly scoped fallback, not a fabricated DST database.
        if name in ('UTC', 'Etc/UTC'):
            return timezone.utc
        if name == 'Asia/Shanghai':
            return timezone(timedelta(hours=8), 'Asia/Shanghai (post-1991 fallback)')
        raise ValueError('时区无效或本机缺少IANA数据: '+name+'；提供系统时区数据库后重试，或显式新建UTC运行。不能用固定偏移冒充夏令时规则。') from exc


def iso(value, date_only=False, tz=timezone.utc):
    if not isinstance(value, str):
        raise ValueError('时间必须为ISO文本')
    if date_only and re.fullmatch(r'\d{4}-\d{2}-\d{2}', value):
        return datetime.combine(date.fromisoformat(value), time.max, tzinfo=tz)
    result = datetime.fromisoformat(value.replace('Z', '+00:00'))
    if result.tzinfo is None or result.utcoffset() is None:
        raise ValueError('时间需要明确UTC偏移')
    return result


def localize(value, zone):
    result = iso(value).astimezone(get_zone(zone))
    if zone == 'Asia/Shanghai' and not isinstance(result.tzinfo, ZONE_TYPE) and result.year < 1992:
        raise ValueError('1992年前上海历史时间需要真实IANA时区数据库')
    return result


def safe_url(value):
    if not isinstance(value, str) or any(ord(c) < 32 for c in value) or '{metric:' in value:
        return False
    try:
        u = urlsplit(value)
        return u.scheme in ('https', 'http') and bool(u.hostname) and not u.username and not u.password
    except ValueError:
        return False


def period_bounds(value):
    """Finite, explicit fiscal labels; fiscal calendars need mapped ISO ranges."""
    if value == 'unknown':return None
    if '/' in value:
        a,b=value.split('/',1)
        start=date.fromisoformat(a);end=date.fromisoformat(b)
    elif re.fullmatch(r'\d{4}-?Q[1-4]',value):
        year=int(value[:4]);quarter=int(value[-1]);month=(quarter-1)*3+1
        start=date(year,month,1)
        end=(date(year+1,1,1) if month==10 else date(year,month+3,1))-timedelta(days=1)
    elif re.fullmatch(r'\d{4}-\d{2}',value):
        year,month=map(int,value.split('-'));start=date(year,month,1)
        end=(date(year+1,1,1) if month==12 else date(year,month+1,1))-timedelta(days=1)
    elif re.fullmatch(r'\d{4}',value):start=date(int(value),1,1);end=date(int(value),12,31)
    else:start=end=date.fromisoformat(value)
    if end<start:raise ValueError('期间结束早于开始')
    return start,end


OFFICIAL = [
    ('gov','国务院','gov.cn'), ('scio','国新办','scio.gov.cn'), ('pbc','央行','pbc.gov.cn'),
    ('csrc','证监会','csrc.gov.cn'), ('sse','上交所','sse.com.cn'), ('szse','深交所','szse.cn'),
    ('bse','北交所','bse.cn'), ('ndrc','发改委','ndrc.gov.cn'), ('miit','工信部','miit.gov.cn'),
    ('mof','财政部','mof.gov.cn'), ('mofcom','商务部','mofcom.gov.cn'), ('stats','统计局','stats.gov.cn'),
    ('nfra','金融监管总局','nfra.gov.cn'), ('sasac','国资委','sasac.gov.cn'), ('nea','能源局','nea.gov.cn'),
    ('nhsa','医保局','nhsa.gov.cn'), ('samr','市场监管总局','samr.gov.cn'), ('fmprc','外交部','fmprc.gov.cn')]


AI_CHANNELS = (
    dict(id='openai_news',name='OpenAI正式发布',publisher='OpenAI',channel='official_news',url='https://openai.com/news/',critical=True),
    dict(id='openai_social',name='@OpenAI官方社交',publisher='OpenAI',channel='official_social',url='https://x.com/OpenAI',critical=True),
    dict(id='anthropic_news',name='Anthropic正式发布',publisher='Anthropic',channel='official_news',url='https://www.anthropic.com/news',critical=True),
    dict(id='anthropic_social',name='@AnthropicAI官方社交',publisher='Anthropic',channel='official_social',url='https://x.com/AnthropicAI',critical=True),
)
AI_DEEP_DIVE = (
    dict(id='openai_product',name='OpenAI产品/API/Codex/价格',publisher='OpenAI',channel='product_developer',url='https://platform.openai.com/docs/',critical=False),
    dict(id='anthropic_product',name='Anthropic产品/开发者/价格',publisher='Anthropic',channel='product_developer',url='https://docs.anthropic.com/',critical=False),
)


def legacy_obligations(profile,scope):
    result=[]
    if profile=='finance-ai' or 'A股' in scope:
        result.extend(dict(id=key,name=name,url='https://www.'+domain+'/',critical=True) for key,name,domain in OFFICIAL)
    if profile=='finance-ai' or any(value in scope for value in ('全球宏观','宏观')):
        result.extend(dict(id=key,name=name,url=url,critical=True) for key,name,url in (
            ('global_risk','地缘与能源','https://www.eia.gov/'),
            ('fed_macro','Fed及海外宏观','https://www.federalreserve.gov/'),
            ('market_data','市场与行业数据','https://www.sse.com.cn/')))
    if profile=='finance-ai' or 'AI' in scope:
        result.append(dict(id='ai_industry',name='AI与产业公告',url='https://www.sec.gov/',critical=True))
    return result or [dict(id='scope_'+str(index),name=value,url='',critical=True) for index,value in enumerate(scope)]


def obligations(profile, scope, edition=None):
    if edition is None:
        return legacy_obligations(profile,scope)
    result = []
    if profile == 'finance-ai' or 'A股' in scope:
        result.extend(dict(id=k, name=n, url='https://www.'+domain+'/', critical=True) for k,n,domain in OFFICIAL)
    if profile == 'finance-ai' or any(x in scope for x in ('全球宏观','宏观')):
        result.extend(dict(id=k, name=n, url=url, critical=True) for k,n,url in (
            ('global_risk','地缘与能源','https://www.eia.gov/'),
            ('fed_macro','Fed及海外宏观','https://www.federalreserve.gov/'),
            ('market_data','市场与行业数据','https://www.sse.com.cn/')))
    if profile == 'finance-ai' or 'AI' in scope:
        result.extend(dict(x) for x in AI_CHANNELS)
        result.extend(dict(x) for x in AI_DEEP_DIVE)
        result.append(dict(id='ai_filings',name='AI公司披露',url='https://www.sec.gov/',channel='filings',critical=False))
    if not result:
        result = [dict(id='scope_'+str(i), name=x, url='', critical=True) for i,x in enumerate(scope)]
    if edition=='intraday':
        sentinels={'gov','pbc','csrc','sse','szse','global_risk','fed_macro','market_data',
                   'openai_news','openai_social','anthropic_news','anthropic_social'}
        result=[entry for entry in result if entry['id'] in sentinels or entry['id'].startswith('scope_')]
    return result


def resolve_contract(*, cutoff=None, report_date=None, preset=None, zone='Asia/Shanghai', window=None,
                     profile='finance-ai', scope=None, mode='live', evidence_mode='independent', edition=None):
    tz = get_zone(zone)
    if cutoff:
        point = localize(cutoff, zone)
        basis = 'explicit_offset_timestamp'
    elif report_date:
        day = date.fromisoformat(report_date)
        point = datetime.combine(day, time(8), tzinfo=tz)
        basis = 'date_only_local_08:00'
        mode = 'historical'
    else:
        point = datetime.now(tz).replace(microsecond=0)
        basis = 'run_start_clock'
        if preset == 'premarket':
            point = point.replace(hour=8, minute=0, second=0)
            basis = 'explicit_premarket_08:00'
    if zone == 'Asia/Shanghai' and not isinstance(tz, ZONE_TYPE) and point.year < 1992:
        raise ValueError('该历史日期需要IANA时区数据库')
    if report_date and point.date().isoformat() != report_date:
        raise ValueError('日期与截止在报告时区不一致')
    start = localize(window, zone) if window else point - timedelta(days=1)
    if start > point:
        raise ValueError('窗口晚于截止')
    scope = scope or ['A股','全球宏观','AI']
    return dict(initial_cutoff=point.isoformat(), timezone=zone, date=point.date().isoformat(),
                scope=scope, profile=profile, mode=mode, evidence_mode=evidence_mode,
                requested_window_start=start.isoformat(), resolution_basis=basis,
                timezone_basis='iana' if isinstance(tz,ZONE_TYPE) else 'documented_fixed_zone_fallback',
                coverage_obligations=obligations(profile,scope,edition))
