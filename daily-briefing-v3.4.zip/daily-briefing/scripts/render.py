"""Escaped, deterministic HTML/SVG renderer. Never fetches external resources."""
from __future__ import annotations
from datetime import date, datetime
from html import escape
from pathlib import Path
import math
import re
from briefing import TOKEN, metric_date, source_ids

PALETTE=['#5a46c8','#007d83','#a04773','#835716','#4969a5']
ROLE={'industry':'产业龙头','trading':'交易龙头','both':'产业与交易龙头','representative':'代表性公司','watch':'观察对象'}
STATUS={'confirmed':'已确认','reported':'来源声明','conflicted':'来源冲突','unverified':'待核实','supported':'有据判断','watch':'待验证','contrarian':'非共识观察','expected':'预计'}
STATUS['expected']='已公告计划'

def esc(v): return escape(str(v),quote=True)
def fmt(value,unit='',signed=False,precision=None,approximate=False):
    if value is None: return '—'
    if precision is not None and precision<0:value=round(value,precision)
    digits=0 if unit in ('家','只','个','台','艘') else max(0,precision) if precision is not None else 2
    s=f'{value:+,.{digits}f}' if signed else f'{value:,.{digits}f}'
    return ('约' if approximate else '')+s+unit
def short(value):
    if abs(value)>=10000: return f'{value/10000:.1f}万'
    if abs(value)>=1000: return f'{value/1000:.1f}k'
    return f'{value:.2f}'.rstrip('0').rstrip('.')
def signclass(v): return 'neutral' if v is None or v==0 else ('pos' if v>0 else 'neg')


def metric_color(metric,value):
    if metric.get('category') in ('up','down','flat'):return {'up':'pos','down':'neg','flat':'neutral'}[metric['category']]
    return signclass(value) if metric.get('signed') or metric['op'] in ('return','excess_return','daily_change','growth','bp_change','difference','pair_difference') else 'neutral'
def table(headers,rows,classes='',header_text=esc):
    return '<div class="table-wrap"><table class="'+classes+'"><thead><tr>'+''.join('<th>'+header_text(h)+'</th>' for h in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td data-label="'+header_text(headers[i])+'">'+c+'</td>' for i,c in enumerate(r))+'</tr>' for r in rows)+'</tbody></table></div>'

class Renderer:
    def __init__(self,d,checks):
        self.d=d; self.values=checks['values']; self.checks=checks
        self.facts={x['id']:x for x in d['facts']}; self.sources={x['id']:x for x in d['sources']}; self.metrics={x['id']:x for x in d['metrics']}; self.series={x['id']:x for x in d['series']}; self.analyses={x['id']:x for x in d['analyses']}; self.events={x['id']:x for x in d.get('events',[])}
        self.fnums={k:i+1 for i,k in enumerate(self.facts)}
        self.cnums={item['id']:index+1 for index,item in enumerate(d['claims'])}
        self.enums={item['id']:index+1 for index,item in enumerate(d['evidence'])}
    def plain(self,value):
        value=re.sub(r'\*\*([^*\n]+)\*\*',r'\1',str(value))
        return esc(TOKEN.sub(lambda m: self.metric(m.group(1)),value))
    def text(self,value):
        def replace(m):
            metric=self.metrics[m.group(1)]; v=self.values[m.group(1)]
            signed=metric.get('signed',metric['op'] in ('return','excess_return','bp_change','difference','pair_difference'))
            return '<span class="metric '+metric_color(metric,v)+'">'+esc(self.metric(metric['id']))+'</span>'
        safe=esc(value)
        safe=re.sub(r'\*\*([^*\n]+)\*\*',r'<strong>\1</strong>',safe)
        safe=re.sub(r'\[risk:([^\]\n]+)\]',r'<mark class="risk">\1</mark>',safe)
        return TOKEN.sub(replace,safe).replace('\n','<br>')
    def refs(self,ids):
        return '<span class="refs">'+''.join(f'<a href="#f-{self.plain(fid)}" aria-label="证据{self.fnums[fid]}">[{self.fnums[fid]}]</a>' for fid in dict.fromkeys(ids) if fid in self.facts)+'</span>'
    def analysis_refs(self, ids):
        return '<span class="refs">'+''.join('<a href="#a-'+self.plain(x)+'" aria-label="查看关联研究">研究</a>' for x in dict.fromkeys(ids))+'</span>'
    def claim_refs(self, ids):
        return '<span class="refs">'+''.join('<a href="#c-'+self.plain(x)+'" aria-label="查看主张证据链">〔'+str(self.cnums.get(x,'?'))+'〕</a>' for x in dict.fromkeys(ids))+'</span>'
    def evidence_refs(self, ids):
        return '<span class="refs">'+''.join('<a href="#e-'+self.plain(x)+'">原文 '+str(self.enums.get(x,'?'))+'</a>' for x in dict.fromkeys(ids))+'</span>'
    def source_links(self,ids):
        return ' · '.join('<a href="'+self.plain(self.sources[x]['url'])+'" target="_blank" rel="noopener noreferrer">'+self.plain(self.sources[x]['publisher'])+'</a>' for x in dict.fromkeys(ids) if x in self.sources)
    def metric(self,mid):
        m=self.metrics[mid]; v=self.values[mid]
        if self.d['schema_version']>=5 and mid in self.checks.get('unready_metrics',[]):return '—（待核 / 数据不足）'
        detail=self.checks.get('metric_details',{}).get(mid,{})
        return fmt(v,m['unit'],m.get('signed',m['op'] in ('return','excess_return','daily_change','growth','bp_change','difference','pair_difference')),detail.get('precision',m.get('precision')),detail.get('approximate',m.get('approximate',False)))
    def chain(self,a):
        out='<div class="chain">'
        for e in a['mechanism']:
            assumption=e['basis']=='assumption'
            out+='<div class="chain-row '+('assumption' if assumption else '')+'">'+self.text(e['from'])+'<span class="arrow">→</span>'+self.text(e['to'])+self.refs(e['fact_ids'])
            out+='<small>'+('假设环节：'+self.text(e['assumption']) if assumption else '事实联系；因果含义需结合正文解释')+'</small></div>'
        return out+'</div>'
    def spark(self,sid):
        s=self.series[sid]; obs=s['observations'][-21:]
        vals=[p['value'] for p in obs if p['value'] is not None]
        if len(vals)<2: return ''
        lo,hi=min(vals),max(vals); span=hi-lo or max(abs(lo)*.01,1)
        paths=[]; path=''
        for i,p in enumerate(obs):
            if p['value'] is None:
                if path: paths.append(path); path=''
            else:
                x=4+i/max(1,len(obs)-1)*292; y=44-(p['value']-lo)/span*38
                path+=('M' if not path else 'L')+f'{x:.2f},{y:.2f} '
        if path: paths.append(path)
        return '<svg class="spark" viewBox="0 0 300 48" role="img" aria-label="'+self.plain(s['label']+'实际历史序列，缺失处断开')+'">'+''.join('<path d="'+p+'" fill="none" stroke="#26817c" stroke-width="2"/>' for p in paths)+'</svg>'
    def chart(self,c):
        typ=c['type']; body=''; data=[]; headers=[]; sids=[]
        if typ in ('breadth','bars','comparison_table'):
            items=[(i['label'],i['metric_id'],self.values[i['metric_id']]) for i in c['items']]
            headers=['对象','数值','所属日期']; data=[[self.plain(label),self.plain(self.metric(mid)),self.plain(metric_date(self.d,self.metrics[mid]))] for label,mid,v in items]
            for _,mid,_ in items: sids+=source_ids(self.d,self.metrics[mid])
            if typ=='comparison_table':body=table(headers,data,header_text=self.plain);data=[]
            elif typ=='breadth':
                total=sum(v for _,_,v in items if v is not None)
                if any(v is None for _,_,v in items) or total<=0: body='<p class="empty">数据不完整，保留原始表格，未绘制占比。</p>'
                else:
                    colors=[{'up':'var(--up)','flat':'var(--muted)','down':'var(--down)'}[i['category']] for i in c['items']]
                    body='<div class="breadth-track" role="img" aria-label="'+self.plain('；'.join(label+' '+str(v)+'家' for label,mid,v in items))+'">'
                    for j,(label,mid,v) in enumerate(items): body+=f'<span style="width:{v/total*100:.5f}%;--s:{colors[j%3]}" data-tip="{self.plain(label+" "+self.metric(mid)+" / "+fmt(v/total*100,"%"))}"></span>'
                    body+='</div><div class="legend">'+''.join(f'<span><i class="swatch" style="--s:{colors[j%3]}"></i>{self.plain(label)} <b>{self.plain(self.metric(mid))}</b></span>' for j,(label,mid,v) in enumerate(items))+'</div>'
            else:
                vals=[v for _,_,v in items if v is not None]; low=min(vals+[0]); high=max(vals+[0]); span=high-low or 1; zero=-low/span*100
                for label,mid,v in items:
                    tone=metric_color(self.metrics[mid],v)
                    color={'pos':'var(--up)','neg':'var(--down)','neutral':'var(--brand)'}[tone]
                    fill='' if v is None else f'<span class="bar-fill" style="left:{min(zero,((v-low)/span*100)):.3f}%;width:{abs(v)/span*100:.3f}%;--s:{color}"></span>'
                    body+='<div class="bar-row"><span>'+self.plain(label)+'</span><div class="bar-track">'+f'<span class="bar-zero" style="left:{zero:.3f}%"></span>'+fill+'</div><span class="bar-value '+tone+'">'+self.plain(self.metric(mid))+'</span></div>'
        elif typ=='heatmap':
            headers=['对象']+c['columns']; data=[]
            body='<div class="table-wrap"><table class="heatmap"><thead><tr>'+''.join('<th>'+self.plain(x)+'</th>' for x in headers)+'</tr></thead><tbody>'
            for row in c['rows']:
                body+='<tr><th>'+self.plain(row['label'])+'</th>'; r=[self.plain(row['label'])]
                for mid in row['metric_ids']:
                    v=self.values[mid]; intensity=min(abs(v)/10,.8) if v is not None else 0
                    color=f'rgba(183,55,55,{.04+intensity*.22:.3f})' if v is not None and v>0 else (f'rgba(24,112,75,{.04+intensity*.22:.3f})' if v is not None and v<0 else 'var(--card)')
                    value=self.metric(mid); body+='<td class="'+signclass(v)+'" style="background:'+color+'">'+self.plain(value)+'</td>'; r.append(self.plain(value)); sids+=source_ids(self.d,self.metrics[mid])
                body+='</tr>'; data.append(r)
            body+='</tbody></table></div>'
        elif typ=='line':
            sets=[self.series[x] for x in c['series_ids']]
            for s in sets: sids+=s['source_ids']
            if c.get('window'):
                import copy
                windows=[]
                for count in (20,60):
                    from calculations import history_window_ready
                    ready=all(history_window_ready(self.d,series,count) for series in sets)
                    windows.append((count,ready))
                chosen=max(count for count,ready in windows if ready) if any(ready for count,ready in windows) else None
                body='<div class="window-controls" role="group" aria-label="真实历史窗口" data-enhancement hidden>'+''.join('<button type="button" data-window="'+str(count)+'" aria-pressed="'+str(count==chosen).lower()+'" '+('' if ready else 'disabled title="连续会话不足"')+'>'+str(count)+'会话'+('' if ready else ' · 不足')+'</button>' for count,ready in windows)+'</div>'
                for count,ready in windows:
                    if ready:
                        subset=copy.deepcopy(sets)
                        for series in subset:series['observations']=series['observations'][-count-1:]
                        chart,window_data,window_headers=self.line(subset,c['normalize'])
                        body+='<div data-window-panel="'+str(count)+'"'+(' hidden' if count!=chosen else '')+'>'+chart+'<details><summary>窗口原始值</summary>'+table(window_headers,window_data,header_text=self.plain)+'</details></div>'
            else:body,data,headers=self.line(sets,c['normalize'])
        elif typ=='scatter':
            pts=c['points']; valid=[p for p in pts if self.values[p['x_metric']] is not None and self.values[p['y_metric']] is not None]
            headers=['对象','超额收益','量能比']; data=[[self.plain(p['label']),self.plain(self.metric(p['x_metric'])),self.plain(self.metric(p['y_metric']))] for p in pts]
            for p in pts:
                for k in ('x_metric','y_metric'): sids+=source_ids(self.d,self.metrics[p[k]])
            if valid:
                xs=[self.values[p['x_metric']] for p in valid]; ys=[self.values[p['y_metric']] for p in valid]
                xmin,xmax=min(xs+[0]),max(xs+[0]); ymin,ymax=min(ys+[1,0]),max(ys+[1]); xp=(xmax-xmin)*.15 or 1; yp=(ymax-ymin)*.15 or .2
                xmin-=xp;xmax+=xp;ymin=max(0,ymin-yp);ymax+=yp
                X=lambda x:80+(x-xmin)/(xmax-xmin)*510; Y=lambda y:220-(y-ymin)/(ymax-ymin)*180
                body='<svg viewBox="0 0 640 275" role="img" aria-label="相对强弱和量能，不能解释为资金净流入"><title>横轴超额收益（百分点），纵轴量能比（倍）</title>'
                for y in (ymin,(ymin+ymax)/2,ymax): body+=f'<line class="grid" x1="80" x2="590" y1="{Y(y):.2f}" y2="{Y(y):.2f}"/><text x="65" y="{Y(y)+5:.2f}" text-anchor="end">{short(y)}</text>'
                for x in (xmin,0,xmax): body+=f'<text x="{X(x):.2f}" y="252" text-anchor="middle">{short(x)}</text>'
                body+=f'<line class="refline" x1="{X(0):.2f}" x2="{X(0):.2f}" y1="40" y2="220"/><line class="refline" x1="80" x2="590" y1="{Y(1):.2f}" y2="{Y(1):.2f}"/>'
                for j,p in enumerate(valid):
                    x,y=X(self.values[p['x_metric']]),Y(self.values[p['y_metric']]); tip=p['label']+'：'+self.metric(p['x_metric'])+' / '+self.metric(p['y_metric'])
                    body+=f'<circle cx="{x:.2f}" cy="{y:.2f}" r="9" fill="{PALETTE[j%4]}" data-tip="{self.plain(tip)}"><title>{self.plain(tip)}</title></circle>'
                body+='</svg><div class="legend">横轴：同期超额收益（百分点） · 纵轴：量能比（倍）</div>'
                body+='<div class="legend">'+''.join('<span><i class="swatch" style="--s:'+PALETTE[j%4]+'"></i>'+self.plain(p['label'])+'</span>' for j,p in enumerate(valid))+'</div>'
            else: body='<p class="empty">缺少可比的价格与成交额窗口，未绘制散点。</p>'
        elif typ=='mechanism':
            a=self.analyses[c['analysis_id']]; body=self.chain(a)
            for fid in a['fact_ids']: sids+=self.facts[fid]['source_ids']
        elif typ=='timeline':
            body='<ol class="timeline">'
            for e in sorted((self.events[i] for i in c['event_ids']),key=lambda e:e['at']):
                body+='<li><time>'+self.plain(e['at'].replace('T',' '))+'</time><b>'+self.plain(e['label'])+'</b> <span class="status">'+STATUS[e['status']]+'</span><p>'+self.text(e['detail'])+self.refs(e['fact_ids'])+'</p></li>'
                for f in e['fact_ids']: sids+=self.facts[f]['source_ids']
            body+='</ol>'
        content='<figure class="chart '+('wide' if typ in ('mechanism','timeline') else '')+'" id="chart-'+self.plain(c['id'])+'"><h3>'+self.plain(c['title'])+'</h3><p class="takeaway">'+self.text(c['takeaway'])+'</p>'+body
        formulas=[self.metrics[item['metric_id']].get('formula') for item in c.get('items',[]) if self.metrics[item['metric_id']].get('formula')]
        content+='<figcaption class="chart-note">'+self.text(c['note'])+(' · 派生：'+self.text('；'.join(formulas)) if formulas else '')+'<br>'+self.source_links(sids)+'</figcaption>'
        if data: content+='<details><summary>查看数据与口径</summary>'+table(headers,data,header_text=self.plain)+'</details>'
        return content+'</figure>'
    def line(self,sets,normalize):
        lookup=[{p['date']:p['value'] for p in s['observations']} for s in sets]
        all_dates=sorted(set().union(*(m.keys() for m in lookup)))
        if not all_dates: return '<p class="empty">无历史序列。</p>',[],[]
        common=sorted(set.intersection(*(set(k for k,v in m.items() if v is not None and v>0) for m in lookup))) if normalize else []
        if normalize and not common: return '<p class="empty">无共同有效基准日，未归一化。</p>',[],[]
        if normalize:
            first=common[0]; all_dates=[day for day in all_dates if day>=first]
            lookup=[{k:(v/m[first]*100 if v is not None and k>=first else None) for k,v in m.items()} for m in lookup]
        vals=[v for m in lookup for k,v in m.items() if k in all_dates and v is not None]
        rows=[[self.plain(day)]+[self.plain(fmt(m.get(day),'',False)) for m in lookup] for day in all_dates]
        headers=['日期']+[s['label']+(' (基期=100)' if normalize else ' ('+s['unit']+')') for s in sets]
        if len(all_dates)<2 or not vals: return '<p class="empty">至少需要两个观测日期，原始数据见下表。</p>',rows,headers
        lo,hi=min(vals),max(vals); pad=(hi-lo)*.15 or max(abs(lo)*.01,1);lo-=pad;hi+=pad
        ords=[date.fromisoformat(x).toordinal() for x in all_dates];start,end=ords[0],ords[-1]
        X=lambda day:80+(date.fromisoformat(day).toordinal()-start)/(end-start)*510
        Y=lambda value:215-(value-lo)/(hi-lo)*175
        svg='<svg viewBox="0 0 640 265" role="img" aria-label="'+self.plain('；'.join(headers[1:]))+'"><title>'+self.plain('真实观测序列，缺失点断开；'+('共同基期归一化' if normalize else '原始单位'))+'</title>'
        for y in (lo,(lo+hi)/2,hi): svg+=f'<line class="grid" x1="80" x2="590" y1="{Y(y):.2f}" y2="{Y(y):.2f}"/><text x="65" y="{Y(y)+5:.2f}" text-anchor="end">{short(y)}</text>'
        for i in sorted({0,len(all_dates)//2,len(all_dates)-1}):
            day=all_dates[i]; anchor='start' if i==0 else ('end' if i==len(all_dates)-1 else 'middle')
            svg+=f'<text x="{X(day):.2f}" y="247" text-anchor="{anchor}">{self.plain(day[5:])}</text>'
        for j,m in enumerate(lookup):
            path=''; segments=[]
            for day in all_dates:
                v=m.get(day)
                if v is None:
                    if path: segments.append(path);path=''
                else: path+=('M' if not path else 'L')+f'{X(day):.2f},{Y(v):.2f} '
            if path: segments.append(path)
            for path in segments: svg+='<path d="'+path+'" fill="none" stroke="'+PALETTE[j%4]+'" stroke-width="2.8"/>'
            for day in all_dates:
                if m.get(day) is not None:
                    tip=sets[j]['label']+' '+day+' '+fmt(m[day],'基期点' if normalize else sets[j]['unit'])
                    svg+=f'<circle cx="{X(day):.2f}" cy="{Y(m[day]):.2f}" r="5" fill="{PALETTE[j%4]}" data-tip="{self.plain(tip)}"><title>{self.plain(tip)}</title></circle>'
        svg+='</svg><div class="legend">'+''.join('<span><i class="swatch" style="--s:'+PALETTE[j%4]+'"></i>'+self.plain(s['label'])+'</span>' for j,s in enumerate(sets))+'</div>'
        svg+='<div class="chart-note">'+self.plain(('共同基期 '+all_dates[0]+' = 100' if normalize else '纵轴单位：'+sets[0]['unit'])+' · '+all_dates[0]+' 至 '+all_dates[-1])+'</div>'
        return svg,rows,headers
    def articles(self,section,show_empty=True):
        from common import get_zone, iso
        out=''
        for a in sorted((a for a in self.d['articles'] if self.plan['articles'][a['id']]==section),key=lambda x:(x.get('primary_entity',''),x.get('content_role')=='baseline',x['priority'])):
            kind={'fact':'事实更新','analysis':'分析判断','watch':'待验证'}[a['kind']]
            zone=get_zone(self.d['meta']['timezone']);cutoff=iso(self.d['meta']['cutoff'])
            announced=any(self.facts[fid]['kind']=='event' and any(self.facts[fid].get(key) and iso(self.facts[fid][key],date_only=True,tz=zone)>cutoff for key in ('event_at','effective_at')) for fid in a['fact_ids'] if fid in self.facts)
            if announced:kind='已公告计划 · '+kind
            if a.get('content_role')=='baseline':kind='财务基线 · 非本期新消息'
            if a.get('content_role')=='background':kind='延续背景 · 非本期新发布'
            out+='<article class="article" id="article-'+self.plain(a['id'])+'"><div class="article-meta">'+kind+' · 优先级 '+str(a['priority'])+'</div><h3>'+self.plain(self.plan['article_titles'][a['id']])+'</h3><p>'+self.text(a['text'])+self.refs(a['fact_ids'])+self.analysis_refs(a['analysis_ids'])+self.claim_refs(a['claim_ids'])+'</p>'
            if a.get('disposition')=='pending':out+='<p class="notice"><b>待核验：</b>'+self.text(a['disposition_reason'])+'</p>'
            interpretation=a.get('interpretation')
            if interpretation:
                out+='<p class="takeaway"><strong>'+self.text(interpretation['judgment'])+'</strong></p><p class="risk-line"><b>风险 / 下一观察：</b>'+self.text(interpretation['risk_next'])+'</p><details><summary>相对基准、传导与量级</summary>'
                for field,label in (('change','真正变化'),('channel','经济渠道'),('scale_conditions','量级及执行条件')):out+='<p><b>'+label+'：</b>'+self.text(interpretation[field])+'</p>'
                out+='</details>'
            if a.get('company'):
                company=a['company']
                out+='<div class="company-baseline"><b>'+self.plain(company['name']+' · '+company['ticker'])+'</b><p>财务基准：'+self.text(company['financial_baseline'])+'</p><p>履约条件：'+self.text(company['conditions'])+'</p></div>'
            out+='</article>'
        return '<div class="article-grid">'+out+'</div>' if out else self.empty(section) if show_empty else ''
    def empty(self,section):
        task_id={'news':'official','ai':'official','news-companies':'companies','companies':'companies','macro':'macro','market':'market','sectors':'themes','observations':'themes','actions':'synthesis'}.get(section)
        task=next((item for item in self.checks.get('research_completion',{}).get('tasks',[]) if item['id']==task_id),{})
        status=task.get('status','planned')
        message={'planned':'尚未调查','running':'研究尚未完成','verified_none':'已查指定窗口，未发现重要事项','blocked':'调查受阻','budget_stop':'到限停止，研究未完成','user_stop':'按用户要求停止','done':'已有研究内容，本栏目无适用事项'}.get(status,'状态未知')
        return '<p class="empty">'+self.plain(message+'。'+task.get('stop_reason',''))+'</p>'
    def analysis(self,a):
        out='<article class="analysis" id="a-'+self.plain(a['id'])+'"><span class="status">'+self.plain(a['sector'])+'</span><span class="status">'+self.plain(a.get('horizon','三个期限'))+'</span><span class="status '+('watch' if a['status']=='watch' else '')+'">'+STATUS[a['status']]+'</span><h3>'+self.plain(a['title'])+'</h3><p class="lead">'+self.text(a['conclusion'])+self.refs(a['fact_ids'])+'</p><p class="materiality"><b>量级与条件</b> '+self.text(a['materiality'])+self.claim_refs(a['field_claims'].get('materiality',[]))+'</p><details class="research-detail"><summary>事实基线、传导与竞争解释</summary><div class="fields">'
        for key,label in [('novelty','新增变化'),('earnings','利润传导'),('distribution','利益分配'),('pricing','市场反应'),('expectation','预期基准'),('alternative','竞争性解释'),('counterevidence','反证与脆弱环节')]:
            if key not in a:continue
            out+='<div class="field '+('full' if key=='counterevidence' else '')+'"><span class="label">'+label+'</span><p>'+self.text(a[key])+self.claim_refs(a['field_claims'].get(key,[]))+'</p></div>'
        out+='</div><p><b>研究优先级 P'+str(a['priority'])+'：</b>'+self.text(a['priority_reason'])+'</p></details>'
        state=self.checks['delivery']['analysis_status'].get(a['id'],{})
        if state.get('reasons'):out+='<div class="notice">本主题有限覆盖：'+self.text('；'.join(state['reasons']))+'</div>'
        out+='<div class="horizon-grid">'
        for key,label in [('intraday','当日至3个交易日'),('short','1—4周'),('medium','1—3个月')]:
            h=a['horizons'][key]
            out+='<div class="horizon"><h4>'+label+'</h4><p class="horizon-conclusion">'+self.text(h['conclusion'])+self.claim_refs(h['claim_ids'])+'</p>'
            for key,caption in (('earnings_channel','盈利'),('valuation_channel','估值'),('base_case','基本情景'),('counter_case','反向情景'),('uncertainty','不确定性')):
                if key in h:out+='<p>'+caption+'：'+self.text(h[key])+'</p>'
            out+='<p>下一观察：'+self.text(h['next_observation'])+'<br>复核：'+self.plain(h['review_at'])+'</p></div>'
        out+='</div><div class="verification"><div><b>支持判断的条件</b>'+self.text(a['support'])+'</div><div><b>削弱或推翻的条件</b>'+self.text(a['invalidation'])+'</div></div>'
        if a.get('update'):out+='<p>跨期变化：'+self.plain(a['update']['status'])+' · '+self.text(a['update']['reason'])+'</p>'
        out+=''.join(self.chart(c) for c in self.plan['charts'] if self.plan['routes'][c['id']]=='analysis:'+a['id'])
        if a['leaders']:
            out+='<h4>龙头与代表对象对照</h4><div class="leader-grid">'
            for l in a['leaders']:
                out+='<div class="leader"><h4>'+self.plain(l['name'])+'</h4><span class="ticker">'+self.plain(l['ticker']+' · '+l['market'])+'</span> <span class="status">'+ROLE[l['role']]+'</span>'+self.refs(l['fact_ids'])
                if l.get('series_id'): out+=self.spark(l['series_id'])
                out+='<dl>'
                for k,label in [('exposure','业务敞口'),('realization','兑现阶段'),('performance','市场表现'),('catalyst','下一催化'),('risk','主要风险')]: out+='<dt>'+label+'</dt><dd>'+self.text(l[k])+'</dd>'
                if l.get('industry_basis'):
                    b=l['industry_basis']
                    out+='<dt>产业地位比较依据</dt><dd>'+self.text(b['scope']+' · '+b['period']+' · '+b['comparison'])+self.refs(b['fact_ids'])+'</dd>'
                out+='</dl></div>'
            out+='</div>'
        out+='<details><summary>展开传导环节与研究缺口</summary>'+self.chain(a)
        out+=('<ul>'+''.join('<li>'+self.text(x)+'</li>' for x in a['gaps'])+'</ul>' if a['gaps'] else '<p>本条未记录额外资料缺口；仍需跟踪上述验证条件。</p>')+'</details></article>'
        return out
    def observation(self,o):
        out='<article class="obs"><span class="status '+('watch' if o['kind']=='watch' else '')+'">'+STATUS[o['kind']]+'</span><h3>'+self.plain(o['title'])+'</h3><div class="pair"><div><b>已有预期／讨论基准</b>'+self.text(o['expectation'])+self.refs(o['consensus_fact_ids'])+'</div><div><b>偏离证据</b>'+self.text(o['divergence'])+self.refs(o['fact_ids'])+'</div></div>'
        for k,label in [('mechanism','解释机制'),('materiality','为什么重要'),('opposition','最强反方'),('test','如何区分')]: out+='<p><b>'+label+'：</b>'+self.text(o[k])+'</p>'
        return out+self.claim_refs(o['claim_ids'])+'</article>'
    def action(self,a):
        out='<article class="action"><div class="priority">P'+str(a['priority'])+'</div><div><div class="action-when">'+self.plain(a['when'])+'</div><h3>'+self.text(a['target'])+'</h3><div class="action-grid">'
        for k,label in [('baseline','当前基准'),('support','支持条件'),('invalidation','否定条件'),('rule_basis','条件依据')]: out+='<div><b>'+label+'</b>'+self.text(a[k])+'</div>'
        out+='</div><p class="implication">'+self.text(a['implication'])+self.claim_refs(a['claim_ids'])+'</p><div class="meta"><span>有效至 '+self.plain(a['expires_at'].replace('T',' '))+'</span><a href="#a-'+self.plain(a['analysis_id'])+'">关联研究</a>'+self.refs(a['fact_ids'])+'</div></div></article>'
        return out
    def appendix(self):
        from research import coverage_view
        d=self.d; out='<details><summary>覆盖范围与数据缺口</summary>'
        out+='<ul>'+''.join('<li>'+self.text(g)+'</li>' for g in d['gaps'])+'</ul>' if d['gaps'] else '<p>本期没有记录全局数据缺口。</p>'
        labels={'checked_new':'已查·有新增','checked_none':'已查·未发现新增','failed':'访问失败','not_checked':'未检查','cache_reused':'复用缓存·非本轮访问'}
        out+=table(['来源范围','实际状态','说明'],[[self.plain(c['name']),labels[c['status']]+(' · 定向检索' if c['method']=='search' else ''),self.text(c['note'])+'<small>'+self.plain(c.get('content_scope','窗口范围未声明'))+'</small>'] for c in coverage_view(d['coverage'],d['meta']['window_start'],d['meta']['cutoff'])],'coverage-table')+'</details>'
        out+='<details id="evidence"><summary>事实与引用（'+str(len(d['facts']))+'项）</summary><ol class="evidence">'
        for f in d['facts']:
            role='公司自述' if any(self.sources[sid]['kind']=='company' for sid in f['source_ids']) else '官方声明' if any(self.sources[sid]['kind']=='official' for sid in f['source_ids']) else '媒体报道'
            label=role if f['status']=='reported' else STATUS[f['status']]
            out+='<li id="f-'+self.plain(f['id'])+'"><span class="status">'+label+'</span> '+self.text(f['statement'])+self.evidence_refs(f['evidence_ids'])+'<small>观测期：'+self.plain(f['as_of'])+' · 可得：'+self.plain(f['available_at'] or '未知')+' · '+self.text(f['locator'])+'</small><small>'+self.source_links(f['source_ids'])+'</small></li>'
        out+='</ol></details><details><summary>来源目录（'+str(len(d['sources']))+'项）</summary><ol class="source-list">'
        for s in d['sources']:
            prefix='包内读取记录' if d['meta'].get('evidence_mode')=='fixed_pack' else '来源读取记录'
            out+='<li><a href="'+self.plain(s['url'])+'" target="_blank" rel="noopener noreferrer">'+self.plain(s['title'])+'</a><br>'+self.plain(s['publisher']+' · 发布 '+s['published_at'])+'<br>'+self.plain(prefix+'：'+s['read_status']+' · '+s['accessed_at']+' · 同源组 '+s['origin_group'])
            v=s.get('verification')
            if v:
                labels={'verified':'完成原文核验','partial':'部分读取','failed':'访问失败','not_attempted':'未尝试'}
                out+='<br>'+self.plain('本轮复核：'+labels[v['status']]+' · '+v.get('checked_at','核验时间未记录'))+'<br>'+self.text(v['note'])
                if v.get('url'): out+=' · <a href="'+self.plain(v['url'])+'" target="_blank" rel="noopener noreferrer">实际访问地址</a>'
            out+='</li>'
        pairs=[m for m in d['metrics'] if m['op']=='pair_difference']
        if pairs:
            out+='</ol></details><details><summary>数值比较的计算依据</summary><ul>'
            for m in pairs:
                a=self.metrics[m['from_metric']]; b=self.metrics[m['to_metric']]
                out+='<li>'+self.plain(m['label'])+'：'+self.plain(self.metric(m['id']))+'<br>'+self.text(m.get('formula',m['comparison_basis']))+'<br>'+self.plain(b['label']+' '+self.metric(b['id'])+' − '+a['label']+' '+self.metric(a['id'])+('；百分点差 × 100 转为基点' if m['unit']=='bp' and a['unit']=='%' else ''))+'<br>'+self.source_links(source_ids(d,m))+'</li>'
            out+='</ul>'
        else: out+='</ol>'
        out+='</details><details><summary>上期判断复核</summary>'
        if d.get('prior_reviews'):
            for p in d['prior_reviews']: out+='<p><b>'+self.plain(p['thesis_id'])+' v'+str(p['previous_version'])+'</b><br>'+self.plain(p['status'])+'：'+self.text(p['explanation'])+'</p>'
        else: out+='<p>本期没有可读取的上期判断记录，不作历史一致性声明。</p>'
        out+='</details><details><summary>审阅记录与计算检查</summary><p>'+self.plain(d['review']['reviewer'])+' · '+self.text(d['review']['method'])+'</p><p>结构与计算校验不证明来源真实性或经济因果。</p>'
        for issue in d['review']['issues']: out+='<p>'+('已解决：' if issue['resolved'] else '待处理：')+self.text(issue['message'])+((' · '+self.text(issue['resolution'])) if issue.get('resolved') else '')+'</p>'
        if self.checks['warnings']: out+='<ul>'+''.join('<li>'+self.plain(w['path']+'：'+w['message'])+'</li>' for w in self.checks['warnings'])+'</ul>'
        out+='</details><details id="claims"><summary>主张到证据的引用链</summary>'
        for c in d['claims']:
            out+='<p id="c-'+self.plain(c['id'])+'"><b>'+self.plain(c['id'])+' · '+self.plain(c['status'])+'</b> '+self.text(c['text'])+self.refs(c['fact_ids'])
            out+=' '.join('<a href="#m-'+self.plain(mid)+'">数值 '+self.plain(mid)+'</a>' for mid in c['metric_ids'])+'</p>'
            if c['limitations']:out+='<p class="notice">'+self.text('；'.join(g['message']+'：'+g['impact'] for g in c['limitations']))+'</p>'
        for mid,metric in self.metrics.items():
            detail=self.checks['metric_details'][mid]
            out+='<p id="m-'+self.plain(mid)+'">'+self.plain(metric['label'])+'：'+self.plain(self.metric(mid))+' · '+self.plain(detail['as_of'])+' · '+self.source_links(detail['source_ids'])+'</p>'
        for e in d['evidence']:
            out+='<blockquote id="e-'+self.plain(e['id'])+'">'+self.text(e['quote'])+'<small>'+self.text(e['context'])+' · '+self.text(e['locator'])+' · '+self.source_links([e['source_id']])+'</small></blockquote>'
        return out+'</details>'

def display_plan(d,checks):
    from common import fingerprint
    from validation import validate_charts
    from edition import route, sections
    from calculations import comparison_errors
    from urllib.parse import urlsplit
    edition=d['meta'].get('edition','snapshot');charts=[];omitted=[]
    maps={group:{item['id']:item for item in d[group]} for group in ('metrics','series','analyses','events')}
    groups={};evidence={item['id']:item for item in d['evidence']};sources={item['id']:item for item in d['sources']}
    claims={item['id']:item for item in d['claims']};facts={item['id']:item for item in d['facts']}
    def article_domain(article):
        if article.get('domain'):return article['domain']
        if article.get('company'):return 'company'
        source_list=[sources[source_id] for fact_id in article['fact_ids'] if fact_id in facts for source_id in facts[fact_id]['source_ids'] if source_id in sources]
        if any((urlsplit(source['url']).hostname or '').endswith('.gov.cn') for source in source_list):return 'cn_official'
        return {'macro':'overseas','ai':'ai','market':'cn_market','companies':'company'}.get(article['section'],'cn_official')
    def placement(domain):return {'overseas':'macro','cn_official':'news','ai':'ai','company':'companies','cn_market':'market'}.get(domain,'market')
    def metric_domain(metric):
        if metric.get('domain'):return metric['domain']
        related=[article_domain(article) for article in d['articles'] if any(metric['id'] in claims.get(ident,{}).get('metric_ids',[]) for ident in article['claim_ids'])]
        return related[0] if related else 'cn_market'
    def title(text,fallback):
        return text if re.search(r'[\u3400-\u9fff]',text) else fallback
    for chart in d['charts']:
        metric_ids=[item['metric_id'] for item in chart.get('items',[])]+[mid for row in chart.get('rows',[]) for mid in row['metric_ids']]+[item[key] for item in chart.get('points',[]) for key in ('x_metric','y_metric')]
        if set(metric_ids)&set(checks.get('unready_metrics',[])):omitted.append(dict(group=chart['title'],reason='数值支持尚待复核；保留原始记录，不画成已核验图形'))
        else:charts.append(chart)
    mentioned={item['metric_id'] for chart in charts for item in chart.get('items',[])}
    qualified=[]
    for metric in d['metrics']:
        eligible=checks['values'].get(metric['id']) is not None and metric['id'] not in checks.get('unready_metrics',[])
        if metric['op']=='observed':eligible=eligible and bool(metric.get('evidence_ids')) and all(evidence.get(ident,{}).get('read_method') in ('original','cached') for ident in metric.get('evidence_ids',[]))
        if eligible:qualified.append(metric)
        if eligible and metric['op']=='observed' and metric.get('chart_group') and metric.get('chart_takeaway') and metric['id'] not in mentioned:
            key=(metric['chart_group'],metric_domain(metric),metric['unit'],metric['dimensions']['currency'],metric['dimensions']['scale'],metric['dimensions']['measure'],metric['as_of'],metric['dimensions']['period'],metric.get('price_basis'),metric.get('return_type'))
            groups.setdefault(key,[]).append(metric)
    for key,metrics in groups.items():
        if len(metrics)<2:continue
        categories={metric.get('category') for metric in metrics}
        breadth=categories in ({'up','down'},{'up','down','flat'})
        comparison='parts_of_whole' if breadth else 'cross_entity_same_measure'
        known_sample=breadth and 'flat' not in categories
        if comparison_errors(metrics,comparison,known_sample):continue
        if len(charts)>=(2 if edition=='intraday' else 5):continue
        chart=dict(id='auto_'+fingerprint(key)[:16],type='breadth' if breadth else 'bars',title='已知涨跌样本' if known_sample else title(key[0],'同类指标比较'),takeaway=metrics[0]['chart_takeaway'],
                   note='同日截面 · '+key[6]+' · '+'；'.join(dict.fromkeys(metric.get('scope','') for metric in metrics))+' · 单位 '+key[2]+('；只含已知涨跌样本，不代表全市场。' if known_sample else '；原始值与各对象样本范围保留。'),
                   placement=placement(key[1]),items=[dict(label=metric['label'],metric_id=metric['id'],**({'category':metric['category']} if breadth else {})) for metric in metrics],generated=True,
                   scope=metrics[0].get('scope','各自对象'),comparison_kind=comparison,known_sample=known_sample)
        errors=[];validate_charts(dict(d,schema_version=5,charts=[chart]),maps,lambda *args:errors.append(args))
        if errors:omitted.append(dict(group=key[0],reason=str(errors)))
        else:charts.append(chart)
    used_series={ident for chart in charts for ident in chart.get('series_ids',[])}
    heat_groups={}
    if edition!='intraday':
        for metric in qualified:
            series=maps['series'].get(metric.get('series_id'))
            if not series or metric['op']!='return' or metric.get('n') not in (20,60):continue
            key=tuple(series.get(field) for field in ('market','provider','classification','adjustment','frequency','calendar_id','domain'))
            heat_groups.setdefault(key,{}).setdefault(series['id'],{})[metric['n']]=metric['id']
        for key,rows in heat_groups.items():
            if len(rows)<2 or len(charts)>=5:continue
            windows=sorted(set.intersection(*(set(row) for row in rows.values())))
            if not windows:continue
            chart=dict(id='auto_heat_'+fingerprint(key)[:12],type='heatmap',title='宽基 / 同类对象历史比较',takeaway='同窗收益用于描述历史差异，不代表独立超额收益能力。',
                note='只显示各对象均已核验的连续窗口；成分范围各自保留，未满足的窗口不补数。',placement=placement(key[-1] or 'cn_market'),classification=key[2],scope='各自对象成分范围',
                columns=[str(window)+'会话收益' for window in windows],rows=[dict(label=maps['series'][identifier]['label'],metric_ids=[metrics[window] for window in windows]) for identifier,metrics in rows.items()],generated=True)
            errors=[];validate_charts(dict(d,schema_version=5,charts=[chart]),maps,lambda *args:errors.append(args))
            if not errors:charts.append(chart)
    for series in d['series']:
        if edition=='intraday' or len(charts)>=5:break
        from calculations import history_window_ready
        ready=series['basis']=='price' and history_window_ready(d,series,20)
        if not ready or series['id'] in used_series:continue
        charts.append(dict(id='auto_line_'+fingerprint(series['id'])[:12],type='line',title=series['label']+' · 实际历史',
            takeaway='已取得连续会话；历史表现不代表未来收益或盈利趋势。',note=series['scope']+' · '+series['adjustment'],
            placement=placement(series.get('domain','cn_market')),series_ids=[series['id']],normalize=True,window=60,generated=True))
        used_series.add(series['id'])
    def slot(placement,analysis=None):
        if placement=='theme':return 'analysis:'+analysis
        return route(edition,placement)
    routes={chart['id']:slot(chart['placement'],chart.get('analysis_id')) for chart in charts}
    if len(routes)!=len(charts):raise ValueError('展示计划存在重复图表ID')
    featured=d['meta'].get('featured_metrics',[])
    if not featured:
        featured=[metric['id'] for metric in qualified if metric['op']=='observed'][:6]
    featured=[mid for mid in featured if checks['values'].get(mid) is not None and mid not in checks.get('unready_metrics',[])][:6]
    article_routes={};article_titles={};reused={};baselines={}
    for article in d['articles']:
        article_titles[article['id']]=title(article.get('display_title',article['title']),re.split(r'[。；\n]',article['text'])[0][:40] or '研究内容 · 标题待复核')
        target=slot(placement(article_domain(article)))
        if article.get('disposition')=='excluded':target='excluded';reused[article['id']]=article.get('disposition_reason','明确排除')
        key=article.get('baseline_key')
        if key and key in baselines:target='reused';reused[article['id']]='复用财务基线 '+baselines[key]
        elif key:baselines[key]=article['id']
        article_routes[article['id']]=target
    displayed=set(featured)|{item['metric_id'] for chart in charts for item in chart.get('items',[])}|{mid for chart in charts for row in chart.get('rows',[]) for mid in row['metric_ids']}
    tables={}
    for metric in qualified:
        if metric['id'] not in displayed:tables.setdefault(slot(placement(metric_domain(metric))),[]).append(metric['id'])
    return dict(charts=charts,routes=routes,articles=article_routes,article_titles=article_titles,tables=tables,reused=reused,sections=sections(edition),
                summary='hero' if edition=='evening' else 'status' if edition=='intraday' else 'overview',featured=featured,
                omitted=omitted,accounting=dict(summary=len(d['summary']),metrics=len(featured),charts=len(charts),articles=len(d['articles']),reused=len(reused),tables=sum(map(len,tables.values()))))


def render_report(d,checks=None):
    from briefing import display_document
    from validation import validate
    from common import fingerprint
    if checks is None or checks.get('document_sha256')!=fingerprint(d):checks=validate(d)
    if checks['errors']:raise ValueError('渲染前校验未通过')
    return _render_display(display_document(d,checks),checks)


def _render_display(d,checks):
    from edition import policy
    from common import iso
    from research import near_action
    renderer=Renderer(d,checks);meta=d['meta'];renderer.plan=display_plan(d,checks)
    plan=renderer.plan;edition=meta.get('edition','snapshot')
    titles=plan['sections'];overrides=meta.get('section_titles',{})
    nav='<nav data-section-nav aria-label="报告目录">'+''.join('<a data-section-link="'+item['id']+'" href="#'+item['id']+'"'+(' class="subnav"' if item['parent'] else '')+'><span>'+item['number']+'</span>'+renderer.plain(overrides.get(item['id'],item['title']))+'</a>' for item in titles)+'</nav>'
    tools='<div class="tools" data-enhancement hidden><button type="button" data-theme aria-pressed="false">切换深色</button><button type="button" data-expand aria-pressed="false">展开证据</button><button type="button" data-print>打印</button></div>'
    delivery=checks['delivery']
    labels={'full':'完整研究 · 程序门槛','limited':'有限研究','observation':'观察版','draft':'草稿','incremental_verified':'增量核验完成','first_observation':'首次观察','partial_coverage':'部分覆盖'}
    lead=d['summary'][0] if d['summary'] else None
    headline=meta['title']
    if lead and headline.startswith('每日关注简报'):
        headline=re.split(r'[。；\n]',lead['text'].replace('**',''))[0]
    generated=d.get('publication',{}).get('generated_at') or checks.get('generated_at')
    content='<div class="topbar"><span>'+renderer.plain(meta['date']+' · '+policy(edition)['label'])+' / 研究快照</span>'+tools+'</div>'
    content+='<header class="hero"><div class="hero-main"><div class="eyebrow">DAILY BRIEFING · '+renderer.plain(meta['date']+' '+policy(edition)['label'])+'</div><h1>'+renderer.text(headline)+'</h1>'
    if lead:content+='<p class="hero-judgment">'+renderer.text(lead['text'])+renderer.refs(lead['fact_ids'])+renderer.claim_refs(lead['claim_ids'])+'</p>'
    content+='<div class="hero-meta"><span>信息截止 '+renderer.plain(meta['cutoff'].replace('T',' '))+'</span><span>范围 '+renderer.plain(' / '.join(meta['scope']))+'</span>'
    if generated:content+='<span>实际生成 '+renderer.plain(generated.replace('T',' '))+'</span>'
    if generated and meta['mode']=='live' and (iso(generated)-iso(meta['cutoff'])).total_seconds()>3600:content+='<span>延后生成 · 信息截止未顺延</span>'
    content+='</div><p class="delivery-status">'+labels[delivery['grade']]+' · <a href="#sources">查看证据与研究边界</a></p>'
    if delivery['reasons']:content+='<p class="hero-note">'+renderer.text('；'.join(delivery['reasons'][:3]))+'</p>'
    if meta['mode']!='live':content+='<p class="hero-note">'+('合成测试 · 非市场事实' if meta['mode']=='teaching' else '历史时点重建 · 非准时交付记录')+'</p>'
    content+='</div><div class="hero-cues">'
    for position,summary in enumerate(d['summary'][:3],1):
        if position==1 and not summary.get('priority_object'):continue
        content+='<div class="hero-cue"><span>'+f'{position:02}'+'</span><div><strong>'+renderer.text(summary.get('priority_object') or summary['text'])+'</strong>'
        if summary.get('key_risk'):content+='<small>关键风险：'+renderer.text(summary['key_risk'])+'</small>'
        content+='</div></div>'
    content+='</div></header><div class="mobile-nav">'+nav+'</div>'
    def section(key,body):
        item=next(item for item in titles if item['id']==key)
        tag='h3' if item['parent'] else 'h2'
        return '<section data-report-section id="'+key+'"><'+tag+' tabindex="-1"><span class="sec-num">'+item['number']+' /</span>'+renderer.plain(overrides.get(key,item['title']))+'</'+tag+'>'+body+'</section>'
    def visuals(key):
        output='<div class="chart-grid">'+''.join(renderer.chart(chart) for chart in plan['charts'] if plan['routes'][chart['id']]==key)+'</div>'
        metric_ids=plan['tables'].get(key,[])
        if metric_ids:
            rows=[]
            for identifier in metric_ids:
                metric=renderer.metrics[identifier]
                rows.append([renderer.plain(metric['label']),'<b>'+renderer.plain(renderer.metric(identifier))+'</b>',renderer.plain(metric_date(d,metric)),renderer.plain(metric.get('scope',metric['dimensions']['segment']))])
            output+='<div class="metric-table"><h3>关键数值与口径</h3>'+table(['指标','数值','观测时点 / 期间','范围'],rows)+'</div>'
        return output
    def stats():
        cards=[]
        for identifier in plan['featured']:
            metric=renderer.metrics[identifier];formatted=renderer.metric(identifier);unit=metric['unit']
            value=renderer.plain(formatted[:-len(unit)])+'<span class="unit">'+renderer.plain(unit)+'</span>' if unit and formatted.endswith(unit) else renderer.plain(formatted)
            observed=metric_date(d,metric).replace('T',' ')
            cards.append('<div class="stat"><div class="label">'+renderer.plain(metric['label'])+'</div><div class="value '+metric_color(metric,checks['values'].get(identifier))+'">'+value+'</div><small>'+renderer.plain(observed)+'</small></div>')
        return '<div class="stats">'+''.join(cards)+'</div>'
    def themes():
        cards='<div class="theme-grid">'
        for position,analysis in enumerate(d['analyses']):
            cards+='<a class="theme-card tone-'+str(position%3)+'" href="#a-'+renderer.plain(analysis['id'])+'"><small>研究主线 '+str(position+1)+' · '+renderer.plain(analysis['sector'])+'</small><h3>'+renderer.plain(analysis['title'])+'</h3><p>'+renderer.text(analysis['conclusion'])+'</p><b>量级与条件</b><p>'+renderer.text(analysis['materiality'])+'</p><span>查看三期限与证伪条件 →</span></a>'
        cards+='</div>'
        return cards+''.join(renderer.analysis(analysis) for analysis in d['analyses']) if d['analyses'] else renderer.empty('sectors')
    def observations():
        if d['observations']:return ''.join(renderer.observation(item) for item in d['observations'])
        review=d.get('observation_review',{})
        labels={'checked_none':'已检查，未发现达到标准的非共识判断','hypotheses':'仅有待验证假设；不声称市场错误定价','blocked':'相关研究受阻','not_checked':'相关研究尚未完成'}
        return '<p class="empty">'+renderer.plain(labels.get(review.get('status'),'相关研究尚未完成；不能推断没有非共识机会')+'。'+review.get('reason',''))+renderer.evidence_refs(review.get('evidence_ids',[]))+'</p>'
    def actions():
        near=[];medium=[]
        for action in sorted(d['actions'],key=lambda item:item['priority']):
            (near if near_action(action,d) else medium).append(action)
        output='<h3>当日至3会话</h3>'+(''.join(renderer.action(action) for action in near) or '<p class="empty">尚无经会话日历确认的近期观察时点；中期计划不代替今日观察。</p>')
        if medium:output+='<h3>中期复核 / 日历待确认</h3>'+''.join(renderer.action(action) for action in medium)
        return output
    if edition=='intraday':
        baseline=checks.get('delta',{}).get('baseline')
        state='相对前一正式报告的增量' if baseline else '无已锁定的可比基线；首次观察或历史范围受限'
        content+=section('status','<p>'+state+'</p>'+stats()+visuals('status'))
        for key,kinds in (('changes',{'new','progress','correction','late_discovery'}),('market',{'market','trigger'})):
            changes=[item for item in d['changes'] if item['kind'] in kinds]
            cards=''.join('<article class="change-item"><h3>'+renderer.text(item['text'])+'</h3><p>'+renderer.text(item['why'])+'</p><p><strong>'+renderer.text(item['impact'])+'</strong>'+renderer.claim_refs(item['claim_ids'])+'</p></article>' for item in changes)
            content+=section(key,(cards or '<p class="empty">在已核验窗口内未发现重大新增；未查或失败入口不代表无新增。</p>')+renderer.articles(key,False)+visuals(key))
        content+=section('next',''.join('<p>'+renderer.text(item['next_observation'])+'</p>' for item in d['changes'] if item.get('next_observation')) or '<p class="empty">沿用已冻结观察条件；没有新增条件。</p>')
    else:
        if edition=='evening':content+='<div class="hero-content">'+stats()+visuals('hero')+'</div>'
        for item in titles:
            key=item['id']
            if key=='sources' or item['parent']:continue
            if key=='overview':body=stats()+visuals('overview')
            elif key=='sectors':body=themes()+visuals(key)
            elif key=='observations':body=observations()
            elif key=='actions':body=actions()
            elif key=='news' and edition in ('morning','snapshot'):
                body='<h3>中国官方与重大事件</h3>'+renderer.articles('news')+visuals('news')+'<div id="news-companies"><h3>重要公司公告与相关基线</h3>'+renderer.articles('news-companies')+visuals('news-companies')+'</div>'
            else:body=renderer.articles(key)+visuals(key)
            if key=='macro' and edition=='evening':body+=section('ai',renderer.articles('ai')+visuals('ai'))
            content+=section(key,body)
    pending=[event for event in d.get('research_events',[]) if event.get('importance',0)>=5 and not event.get('reported') and event.get('reporting_disposition')=='retained_pending']
    audit=''
    if pending:audit+='<div class="notice"><b>重要事项尚待核验</b>'+''.join('<p>'+renderer.text(event.get('reporting_reason','待补证'))+renderer.claim_refs(event['claim_ids'])+'</p>' for event in pending)+'</div>'
    coverage=delivery['coverage']
    audit+='<p class="coverage-strip">核心窗口 '+str(coverage['covered'])+' / '+str(coverage['required'])+' 已认可；这是覆盖边界，不是研究质量得分。</p>'
    audit+='<details><summary>交付、任务与展示记录</summary><p>'+renderer.text('；'.join(delivery['reasons']) or '通过当前程序门槛；不证明全部事实或经济因果。')+'</p>'
    audit+=''.join('<p>'+renderer.plain(item['group']+'：'+item['reason'])+'</p>' for item in plan['omitted'])
    audit+=''.join('<p>'+renderer.plain(reason)+'</p>' for reason in plan['reused'].values())+'</details>'
    content+=section('sources',audit+renderer.appendix())
    for chart in plan['charts']:
        if content.count('id="chart-'+renderer.plain(chart['id'])+'"')!=1:raise ValueError('图表必须恰好展示一次：'+chart['id'])
    for article in d['articles']:
        if article['id'] not in plan['reused'] and content.count('id="article-'+renderer.plain(article['id'])+'"')!=1:raise ValueError('正文必须恰好展示一次：'+article['id'])
    content+='<footer>信息截至 '+renderer.plain(meta['cutoff'])+'。离线快照，不自动刷新；事实、判断与情景分开复核。<br>作者 / 环境：'+renderer.plain(meta['author'])+'</footer>'
    assets=Path(__file__).resolve().parent.parent/'assets'
    css=(assets/'report.css').read_text(encoding='utf-8');script=(assets/'report.js').read_text(encoding='utf-8')
    return '<!doctype html>\n<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light dark"><title>'+renderer.plain(meta['title'])+'</title><style>'+css+'</style></head><body><a class="skip" href="#'+titles[0]['id']+'">跳到研究正文</a><div class="shell"><aside class="side"><div class="brand">每日关注<small>DAILY BRIEFING</small></div>'+nav+'<p class="side-note">证据 · 机制 · 验证<br>离线快照 / 非实时行情</p></aside><main>'+content+'</main></div><div class="chart-tip" role="tooltip" hidden></div><script>'+script+'</script></body></html>\n'
