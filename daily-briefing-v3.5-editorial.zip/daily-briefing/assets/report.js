(() => {
  'use strict';
  const all = selector => [...document.querySelectorAll(selector)];
  const sections = all('[data-report-section]');
  const links = all('[data-section-link]');
  const mobile = document.querySelector('.mobile-nav');
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const tip = document.querySelector('.chart-tip');
  let frame = null, pending = null, anchored = null, quiet = null, printStates = [];
  all('[data-enhancement]').forEach(element => element.hidden = false);
  function offset() {
    return mobile && mobile.getClientRects().length ? mobile.getBoundingClientRect().height + 12 : 28;
  }
  function highlight(identifier) {
    links.forEach(link => {
      const selected = link.dataset.sectionLink === identifier;
      link.classList.toggle('active', selected);
      if (selected) link.setAttribute('aria-current', 'location');
      else link.removeAttribute('aria-current');
    });
    const scroller = mobile && mobile.querySelector('nav');
    const link = scroller && scroller.querySelector('[aria-current]');
    if (link && scroller.getClientRects().length) {
      if (link.offsetLeft < scroller.scrollLeft) scroller.scrollLeft = link.offsetLeft;
      else if (link.offsetLeft + link.offsetWidth > scroller.scrollLeft + scroller.clientWidth) scroller.scrollLeft = link.offsetLeft + link.offsetWidth - scroller.clientWidth;
    }
  }
  function visible(element) {
    if (!element || !element.getClientRects().length) return false;
    const bounds = element.getBoundingClientRect();
    return bounds.bottom > offset() && bounds.top < innerHeight;
  }
  function measure() {
    frame = null;
    if (pending && performance.now() - pending.started < 1300) { highlight(pending.identifier); return; }
    pending = null;
    if (anchored && Math.abs(scrollY - anchored.position) < 2 && visible(document.getElementById(anchored.identifier))) {
      highlight(anchored.identifier); return;
    }
    anchored = null;
    const candidates = sections.filter(section => section.getClientRects().length);
    if (!candidates.length) return highlight(null);
    let current = candidates[0];
    if (scrollY + innerHeight >= document.documentElement.scrollHeight - 3) current = candidates[candidates.length - 1];
    else for (const section of candidates) if (section.getBoundingClientRect().top <= offset() + 5) current = section;
    highlight(current.id);
    if (location.hash !== '#' + current.id) history.replaceState(null, '', '#' + current.id);
  }
  function schedule() { if (frame === null) frame = requestAnimationFrame(measure); }
  function settle() {
    if (pending && visible(document.getElementById(pending.identifier))) anchored = {identifier: pending.identifier, position: scrollY};
    pending = null; schedule();
  }
  function release() { pending = null; anchored = null; clearTimeout(quiet); schedule(); }
  function resolve(hash) {
    try { return document.getElementById(decodeURIComponent(hash.slice(1))); }
    catch { return null; }
  }
  function go(target, push = false, focus = false, instant = false) {
    for (let parent = target; parent; parent = parent.parentElement) if (parent.tagName === 'DETAILS') parent.open = true;
    const section = target.closest('[data-report-section]');
    if (!section) return;
    if (push && location.hash !== '#' + target.id) history.pushState(null, '', '#' + encodeURIComponent(target.id));
    anchored = null; pending = {identifier: section.id, started: performance.now()}; highlight(section.id);
    window.scrollTo({top: Math.max(0, target.getBoundingClientRect().top + scrollY - offset()), behavior: instant || reduced.matches ? 'instant' : 'smooth'});
    if (focus) {
      const heading = target.matches('h1,h2,h3,summary') ? target : target.querySelector('h1,h2,h3,summary') || target;
      if (!heading.hasAttribute('tabindex')) heading.setAttribute('tabindex', '-1');
      heading.focus({preventScroll: true});
    }
    clearTimeout(quiet); quiet = setTimeout(settle, instant || reduced.matches ? 30 : 220);
  }
  document.addEventListener('click', event => {
    const link = event.target.closest('a[href^="#"]');
    if (!link || event.button !== 0 || event.ctrlKey || event.metaKey || event.altKey || event.shiftKey) return;
    const target = resolve(link.getAttribute('href'));
    if (!target) return;
    event.preventDefault(); go(target, true, event.detail === 0);
  });
  addEventListener('scroll', () => { schedule(); clearTimeout(quiet); quiet = setTimeout(settle, 160); }, {passive: true});
  addEventListener('wheel', release, {passive: true});
  addEventListener('touchmove', release, {passive: true});
  addEventListener('pointerdown', event => { if (!event.target.closest('a,button,summary')) release(); });
  addEventListener('keydown', event => {
    if (['ArrowUp','ArrowDown','PageUp','PageDown','Home','End',' '].includes(event.key) && !event.target.closest('input,textarea,select,button,summary')) release();
  });
  addEventListener('resize', release);
  document.addEventListener('toggle', schedule, true);
  if (typeof ResizeObserver !== 'undefined') new ResizeObserver(schedule).observe(document.querySelector('main'));
  function fromHash() { const target = resolve(location.hash); if (target) go(target, false, false, true); else release(); }
  addEventListener('hashchange', fromHash);
  addEventListener('popstate', fromHash);
  all('[data-theme]').forEach(button => button.addEventListener('click', () => {
    const dark = document.body.classList.toggle('dark');
    all('[data-theme]').forEach(control => { control.setAttribute('aria-pressed', String(dark)); control.textContent = dark ? '切换浅色' : '切换深色'; });
    schedule();
  }));
  all('[data-expand]').forEach(button => button.addEventListener('click', () => {
    const opened = button.getAttribute('aria-pressed') !== 'true';
    all('main details').forEach(details => details.open = opened);
    all('[data-expand]').forEach(control => { control.setAttribute('aria-pressed', String(opened)); control.textContent = opened ? '收起证据' : '展开证据'; });
    schedule();
  }));
  all('[data-window]').forEach(button => button.addEventListener('click', () => {
    const chart = button.closest('figure');
    chart.querySelectorAll('[data-window]').forEach(control => control.setAttribute('aria-pressed', String(control === button)));
    chart.querySelectorAll('[data-window-panel]').forEach(panel => panel.hidden = panel.dataset.windowPanel !== button.dataset.window);
    schedule();
  }));
  all('[data-print]').forEach(button => button.addEventListener('click', () => print()));
  all('[data-tip]').forEach(element => {
    element.setAttribute('tabindex', '0'); element.setAttribute('aria-label', element.dataset.tip);
    const show = () => {
      const bounds = element.getBoundingClientRect();
      tip.textContent = element.dataset.tip; tip.hidden = false;
      tip.style.left = Math.max(8, Math.min(bounds.left, innerWidth - tip.offsetWidth - 10)) + 'px';
      tip.style.top = Math.max(8, Math.min(bounds.bottom + 8, innerHeight - tip.offsetHeight - 10)) + 'px';
    };
    element.addEventListener('focus', show); element.addEventListener('pointerenter', show);
    element.addEventListener('blur', () => tip.hidden = true); element.addEventListener('pointerleave', () => tip.hidden = true);
    element.addEventListener('keydown', event => { if (event.key === 'Escape') tip.hidden = true; });
  });
  addEventListener('beforeprint', () => { printStates = all('details').map(details => [details, details.open]); printStates.forEach(([details]) => details.open = true); });
  addEventListener('afterprint', () => { printStates.forEach(([details, opened]) => details.open = opened); schedule(); });
  fromHash(); schedule();
})();
