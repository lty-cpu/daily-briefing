# 有界历史补齐

路径优先级：用户本次提供的行情/导出文件 → 已明确授权且当前宿主可用的Tushare或同花顺等连接 → 公开原始区间资料/批量文件。公开路径也由Agent搜集，不要求用户每天备资料包。用同一series/metadata/cache入口接入；不用供应商名称推断有权限，不读取未知密钥。Tushare可用下述可选适配；同花顺使用已有宿主连接或其导出文件，没有连接时不猜私有API。用户数据缺字段只问缺失的来源/口径/日期，不重新索要完整报告。所有路径都受相同会话、单位、复权和截止检查；失败切下一条合法路径并记录盲区，不降校验。

先取得当期截面。需要20/60会话趋势时，以现有calendar/series/metrics和资料库缓存补齐，不增加数据库或后台。`history-data --run-id <ID> --run-token <TOKEN> --input <清单.json>`。只给本期需要的宽基和少量重点对象：默认候选上证、深证成指、创业板、科创50、沪深300；不要逐日网页取305点。

默认provider=files。先用宿主已授权数据工具一次范围请求或分页取得文件，再将实际来源及日历通过原协议登记。清单结构：

```json
{"provider":"files","objects":[{"metadata":{"id":"可省略的序列ID","label":"真实指数名","unit":"点","basis":"price","market":"CN-A","provider":"真实提供方","adjustment":"index_price","classification":"真实分类版本","source_ids":["来源ID"],"evidence_ids":["片段ID"],"entity_id":"稳定实体ID","frequency":"daily","calendar_id":"已核验日历ID","completeness":"complete","scope":"指数成分范围","roll_policy":"not_applicable","vintage":{"id":"真实数据版本","available_at":"带偏移的可得时间"},"observations":[],"domain":"cn_market","asset_type":"index"},"pages":["绝对路径到范围数据.json"]}]}
```

文件是观测数组或`{observations:[...]}`；每点有date,value,available_at,status（traded/missing/suspended）。无值null，有依据的零保留0。读取失败只影响对应序列，已成功分页入缓存；同一数据版本补缺日，不重复拉满窗口。缓存键含提供方、对象、频率、单位、复权、分类/换月、成分版本、来源vintage；缓存不改原获取时间，不声称今天重新访问。

清单里已经有pages时优先读用户文件，即使另有供应商配置；provider省略时也默认为files。Tushare返回不含每点公开钟点，使用已声明、有证据的整批vintage.available_at作为保守可得上界，不伪造为交易日当天15:00；无已知上界就不能把后来下载的新版本用于历史截止。来源元数据与清单由Agent根据真实工具回执整理，不要求用户手写。

20会话收益要21个连续真实会话收盘，60要61个。21个可先启用20，不能填充60。周频、缺日、停牌、未来/未知可得时间不构成交易日收益。股票历史必须明确复权方式及因子可得时间；除权日日变化使用除权参考昨收而非原始昨天收盘。range_position是窗口区间位置，不是长期估值分位。relative_nav是双方归一化后的比值，不等于累计百分点超额；量能比的历史中位数不含当期，也不能用未完成盘中额除以全日中位数。

脚本可选provider=tushare，仅支持指数index_daily范围批量及其成交额，需用户已授权`authorized:true`和指定`credential_env`环境变量名。只读这个已授权变量，不能搜索密钥、创建配置、改权限或调度；固定HTTPS端点不跟随重定向。参考官方[指数日线](https://tushare.pro/document/2?doc_id=95)：接口成交额单位千元，按输出scale换算；指数成分成交额不冒充全市场。账户接口权限须用户已有。**该连接实现未经本次真实账户/云端端到端验收；不得把合成适配器测试写成真实取数成功。** 没有授权则不调用，回到已取得文件或局部缺口。

一轮共用deadline：history_seconds默认90，单请求request_timeout_seconds默认12，history_retries默认2，reserved_seconds默认90，并受总任务剩余时间约束。分页最多8；超时有界重试，认证/权限错误立即冷却，除非配置版本变化或用户明确explicit_retry，不再次撞同一权限。没有后台残留。status返回已取点数、缺口、20/60可用性及失败类；usage未知仍null。先交付当期可核验内容，不因首次60会话补齐失败中止公司/事件研究。
