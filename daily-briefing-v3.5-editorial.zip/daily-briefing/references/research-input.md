# 按任务提交研究资料

先start，再按status的next推进。通常先market、companies，再official、macro、themes，最后synthesis。每个工作包保留问题、产物、证据、尝试、状态和下一步。市场/公司/复核合计至少预留一半计划研究时间；查询数仅能约束已记录的宿主调用。总时限由start的budget配置，timeout_seconds默认完整期报2400、盘中600，均未经成本校准。用record记录query/open/import/compute/render/recovery各阶段真实耗时；usage只能来自宿主，不估填。

正常写入：`python <skill>/scripts/run.py submit --run-id <ID> --run-token <TOKEN> --input <UTF-8文件>`。`--input -`从UTF-8标准输入读取。对象形式和包含JSON文本的能力回执使用同一解码路径。`{"packets":[...]}`可原子提交小批量；出错不改变briefing.json，回执给最小字段错误、生成ID和剩余审阅列表。别名使用简短ASCII，返回ID稳定；市场packet引用其已登记数值主张。packet是临时资料，规范化归档保存本期事实。重复相同输入幂等。

Windows建议宿主原生文件写入，或PowerShell `[IO.File]::WriteAllText($path,$json,[Text.UTF8Encoding]::new($false))`。用`ConvertTo-Json -InputObject $packet -Depth 30`保留嵌套与单元素数组；读取明确`Get-Content -Raw -Encoding UTF8`。长资料放文件，不放巨型命令参数。PowerShell管道须明确UTF-8输出编码，不能只改显示代码页。遵守宿主的文件工具要求；两次失败就切换已支持路径，不修补隐藏执行器。

以下均为字段示例，数值和来源须由本次研究取得，不可照抄示例生成财经事实。

## 公共来源与尝试

新运行使用schema6；一个packet可同时登记事件、正文、数值和任务产物，不再手工维护平行事件账本。只读栏目列表时用kind=index（不产生财经事实）。内部alias不是显示标题；中文title/display_title必须表明主体与事件。

event / market / company 的source是如下对象，或以前提交成功的packet别名：

```json
{"title":"真实原文标题","publisher":"发布机构","url":"https://example.org/original","published_at":"2026-09-22","published_timezone":"+08:00","available_at":null,"version":"页面实际版本标识","retrieved_at":"2026-09-24T09:00:00+08:00","kind":"official","read_status":"partial","read_method":"original","locator":"正文段落/表格行","quote":"实际读到的片段","context":"必要上下文及局限"}
```

kind为official/company/media/data，read_method为original/cached/search_summary。只读摘要就写search_summary；full表示实际全文读取。公开钟点未知保留YYYY-MM-DD，不伪填UTC−12。若有依据证明截止前已可得，可声明available_at为保守上界并写availability_basis依据；上界不是实际发布时刻。比如已核验的中国旧财报公告日期及当地时区可支持当日结束上界，须写明依据，不填虚构发布钟点。日期级来源没有可得界限则数值保持待核。period只接受ISO日期/范围、YYYY-MM、YYYY、YYYY-Qn；半年报用YYYY-01-01/YYYY-06-30，不用YYYYH1。

任何packet可带`attempt:{at,query_or_url,result,status,evidence_ids,tool_ref}`；at是实际尝试时刻，status为ok/empty/failed/restricted，工具引用可选但有则保存。程序自动附加本packet证据。`result:{status,current_conclusion,next,stop_reason}`记录工作包结果。status=running/done/verified_none/blocked/budget_stop/user_stop；后两者必须是可见预算到限/用户明确停止。blocked需真实失败记录，verified_none需已读完整指定窗口，不能以空搜索证明无公告。单独更新任务也用submit的kind=task和嵌套attempt/result，不使用旧版平铺query_or_url。程序只检查记录，不证明工具真实访问。进入预留核验时间后优先处理status.next与必要日历，不以整理日志替代未完成的近端观察；只有真实到限才是budget_stop。

## 市场数值表

```json
{"task":"market","kind":"market","alias":"close","source":"先前真实来源别名","rows":[{"alias":"index_change","entity_id":"CN_SSE_COMP","label":"上证指数日涨跌","value":0,"unit":"%","currency":"none","scale":1,"period":"2026-09-23","as_of":"2026-09-23T15:00:00+08:00","scope":"上证指数","measure":"index_change","signed":true,"chart_group":"主要指数单日涨跌","chart_takeaway":"基于实际截面的结论"}]}
```

日度市场至少有index_change、turnover、breadth三类measure；scope具体说明沪深/沪深北、指数或成分范围。0是合法数值，缺失必须null。每行可指定已提交source别名。可带title/text/section=market或macro解释；宏观任务提交利率、汇率或大宗及传导正文。同日同定义的跨指数截面允许各指数有自己的成分scope；不是要求成分池相同。相同单位但不同经济含义不得同图。

每行按适用性写domain(cn_market/cn_official/company/overseas/ai)、metric_kind、frequency(daily等)、price_basis、return_type、universe_id/universe_version、precision、approximate。元/千元/万元/亿元/万亿元的scale必须一致。广度同一universe，category=up/down/flat；下降家数仍是正整数但用下跌类别色，缺失平盘只显示已知涨跌样本。指数点位/成交额/利率水平不用涨跌色。图候选须同chart_group且有chart_takeaway；日期、期间、收益定义不可混合。

财务as_of是统计期末，published_at/available_at另属来源。合并/母公司/分部用segment明确。每个数值自己的证据要能找到对应表格行；旧schema的自动匹配只检查数值出现；schema6默认待核，不以裸数出现证明会计语义。换单位、负号、表格转换等需人工核对时提供support={status:reviewed,locator,quote,note}，quote必须属于实际片段，note说明转换。未匹配值保持待核，不删缺口或改成0。

财务差值/增长/规模参考可用calculations数组：每项alias、label、op(pair_difference/growth/ratio)、inputs(两个数值别名)、unit、scope、comparison_basis。op=ratio的跨期规模参考须另写scale_reference=true，明确合同执行期相对哪年收入，不能写成当年增长预测。严守同币种/实体/单位；复杂计算按需使用原merge协议。正文引用回执的`{metric:ID}`，不要复写派生值。

取数路径：先用宿主已授权行情工具批量取截面；没有行情连接时，以交易所当日统计表/收盘文件为原始来源，或可读取财经媒体原始收盘表并标角色。搜索用于定位，必须打开表格核对；表格打不开就记录错误，用另一条可读原始表或停止该数值分支。先拿截面，再为少量重点对象取历史。历史文件保存包外，`import-series --input <CSV/JSON> --metadata <来源口径.json>`；CSV列date,value,available_at，空值留空。连续交易日需已核验日历；缺日、复权未知或跨源未映射不能写交易日收益。缓存按版本、截止和修订触发条件复核。

## 事件与公司公告

event：同company的最小消息骨架，但提供section(news/ai/macro/market)、entity_id、subject。status可取confirmed/reported/unverified/conflicted，默认reported；proposition=publication/occurrence区分发布声明和事项发生，确认时verification_at保留实际核验时刻。事件状态自动从证据推导，不能默认confirmed。未来计划用event_at/effective_at与fact_kind=event/forecast，不写未来实绩。

content_role使用news/continuing_event/context/financial_baseline，旧baseline/background只按显式兼容解释。普通消息根据entity_id、subject（公司用announcement_type）、来源生成临时事件身份；有稳定业务身份时提供event_identity={entity,subject,family,release_id,version,attributes,importance,next_check,aliases?}。importance为1—7，5以上重大，version取实际来源版本。通过aliases显式对齐已知event_key，不因新来源/确认状态生成另一事件。disposition=retained是正式显示，pending是已见待报，excluded需理由；待证消息如果已经整理可报道，用retained配合unverified而非pending。

所有保留的重要新闻须interpretation={change,channel,scale_conditions,judgment,risk_next}：分别写增量、传导变量、量级/兑现条件、当前判断、风险/下一观察。没有金额就写有根据的影响范围，不硬造数字。深度主题预算不是事件解读的上限。domain决定正文/图表路由，国内政策不能借macro槽位跑到海外。

company：正常消息最小字段task、kind=company、alias、name、entity_id、announcement_type、title、text、source、relevance、unknowns；as_of可从发布日派生。ticker/announcement_id/financial_baseline/conditions可缺。media和public_account是合法身份，不能伪装official。source_basis区分named/anonymous/denial/correction；official_response记录回应。无公告号程序给临时事件身份，后续event_identity.aliases显式对齐。深研究再补财务/分部/期限。详见[统一编辑规则](editorial.md)。

## 窗口结果

新schema额外要求index_scan={complete,boundary,checked_through,latest_item_at?,limitation?}。boundary写实际读完的页码/起止条目/检索条件；checked_through是核验覆盖边界，不是最新新闻日期。刚读过陈旧首页不证明已覆盖当前窗口。完整新鲜列表可合法无新增；403、索引陈旧、分页未完必须保留限制。来源列表用kind=index登记，再refs该别名。

kind=window，task、alias、obligations（契约ID数组）、url、status(checked_new/checked_none/partial/failed/not_checked/cache_reused)、method(original_index/aggregate/search/cache)、checked_at、window_start/window_end、content_scope、note、refs（原文证据别名）。content_scope写具体栏目、页码/检索条件及覆盖边界。聚合映射多个入口需可核验映射证据。direct_access=available/restricted/failed，必要时另写fallback_method/access_failure/blind_spot。定向检索可记录有界尝试，不能写checked_none或冒充完整窗口。官网正式发布可独立支撑官方声明，Reuters/AP是有界交叉验证，未跟进不阻止纳入官网事实；官方与社交同步不等于独立评测。

## 主题与三个期限

kind=thesis，task=themes，alias、sector、title、theme、thesis（稳定业务身份）、entity_ids、priority、review_at、expires_at。

blocks包含conclusion、novelty、earnings、pricing、expectation、alternative、support、invalidation、priority_reason、materiality。每个block只写`{text,refs}`及必要status/limitations；每项据其引用生成自己的主张，不复制同一泛化claim填满问卷。共享事实引用同一别名；查不到一致预期就写明没有共识证据，仍给当前有依据的判断。

horizons包含intraday/short/medium，各填conclusion、direction(positive/negative/mixed/neutral/unknown)、refs、next_observation、review_at、confidence，可另填uncertainty。仅写各期限差异，不复制共享机制。action可含when、observe_at、expires_at、target、baseline、support、invalidation、implication、rule_basis；会编译为既有行动协议。leaders/mechanism沿用原规范，仅在需要代表公司对比/传导图时使用。未公开、情景不确定性写uncertainty/非关键limitations；未调查或数据冲突不能伪装合理未来未知。

## 综合与审阅

近端action必须有calendar_id指向文档内带来源证据的真实会话日历，observe_at落在截止日至未来3个已核验会话内；start门槛日历不自动代替原文证据。中期horizon=medium另列。dynamic_rules可在thesis中按support/invalidation声明{rule,metric_ids}，动态均线等冻结规则而不是冻结每天变化的计算值；规则改变须显式revision，固定阈值不得漂移。kind=review可附prior_reviews沿用原状态迁移协议。

review可附observation_review={status,reason,evidence_ids}，status为checked_none/hypotheses/blocked/not_checked；已检查要有真实证据。零深度主题需selection_review={reason,evidence_ids}说明已扫描范围及候选取舍，以themes done提交；不能把未扫描范围说成无机会；仍保留所有重要消息独立解读。workflow_terminal表示执行有限结束，不是research_goals_met，更不是研究质量得分。

kind=review、task=synthesis、reviewer、method、reviewed（实际审过的别名或回执列出的事实/主张/分析/证据ID），status=self_review或真实independent_review。summary最多三项`{text,refs,priority_object?,key_risk?}`；featured为最多六个数值别名。不得批量勾选没有审阅的项。回执review_needed列出尚未覆盖的ID，可inspect定向读取。charts可选，沿用既有图表协议；程序先生成合格候选，Agent选重点并给takeaway。正文允许`**关键短语**`、`[risk:风险短语]`与metric引用，其他HTML始终转义。

compute检查数值与证据；status查看任务/下一步；finish发布，needs_research则继续。预览用finish --preview，预览不归档。原schema2/3/4/5快照按原协议读取；新start生成schema6，不原地升级旧档案。跨期修订和独立重做保留同一个发布机制。[有界历史补齐](history-data.md)只在存在授权数据路径时按需执行；先完成截面和主体研究，不能因未到齐61点让整份报告等待。

## schema6 的短消息与数值

content_role 使用 news/continuing_event/context/financial_baseline；novelty 单独写 new/continuing/first_discovery/correction/historical，stage写拟议/获批/执行等。不要把政策背景写财务基线。完整interpretation是可选的深解读；普通消息只需relevance和unknowns。

数值仍用rows，新增support={status:"reviewed",locator,quote,note}须人工核对实际引文中的主体/单位/表头/期间；没核好保持needs_review。conversion={raw_value,raw_unit,raw_scale,evidence_id,entity,period,measure}中的entity/period/measure是实际片段定位词，目标尺度仍由dimensions.scale决定。value_identity=official/reported/conditional；带条件输入只支持条件情景，计算不改变身份。

kind=observation：task、alias、title、expectation、divergence、mechanism、materiality、opposition、test、refs；observation_kind默认watch，不要求付费共识。contrarian才需consensus_refs。review.summary可3—5项，少时不凑数；summary.text会默认显示。
