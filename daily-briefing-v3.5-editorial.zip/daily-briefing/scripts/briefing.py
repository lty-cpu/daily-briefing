#!/usr/bin/env python3
"""Public CLI and compatibility imports. Every build uses schema-v2 validation."""
from __future__ import annotations
import argparse
import copy
from datetime import datetime, timezone
from pathlib import Path
import sys
import time
from uuid import uuid4
sys.dont_write_bytecode = True

from common import ID, TOKEN, VERSION, canonical, fingerprint, iso, load, num, save, stamp, digest
from validation import validate
from storage import snapshots


def source_ids(d, metric):
    by_id = {m['id']: m for m in d['metrics']}
    series = {s['id']: s for s in d['series']}
    seen = set()
    def visit(m):
        if m['id'] in seen:
            return []
        seen.add(m['id'])
        if m['op'] == 'observed':
            return m['source_ids']
        from calculations import inputs
        result = []
        for key in ('series_id', 'benchmark_id'):
            if key in m:
                result.extend(series[m[key]]['source_ids'])
        for key in inputs(m):
            result.extend(visit(by_id[key]))
        return result
    return list(dict.fromkeys(visit(metric)))


def metric_date(d, metric):
    if metric['op'] == 'observed':
        return metric['as_of']
    if metric.get('series_id'):
        s = next(s for s in d['series'] if s['id'] == metric['series_id'])
        return s['observations'][-1]['date'] if s['observations'] else ''
    return metric['dimensions']['period']


def display_document(d, checks):
    """Adapter for the established visual template, not a second validator."""
    from calculations import point_available
    result = copy.deepcopy(d)
    result['meta']['coverage_status'] = 'complete' if not checks['delivery']['coverage']['missing'] else 'limited'
    result['review']['status'] = 'draft' if checks['delivery']['grade'] == 'draft' else 'reviewed'
    for s in result['sources']:
        s['accessed_at'] = s['retrieved_at']
    maps = {'calendars': {c['id']: c for c in result['calendars']}}
    for s in result['series']:
        for point in s['observations']:
            if not point_available(point, s, maps):
                point['value'] = None
    return result


def main(argv=None):
    parser=argparse.ArgumentParser(description='Data inspection and explicit migration only; production publishing uses run.py finish.')
    sub=parser.add_subparsers(dest='command',required=True)
    for name in ('validate','migrate'):
        p=sub.add_parser(name);p.add_argument('--input',required=True)
        if name=='migrate':p.add_argument('--output',required=True)
        else:
            p.add_argument('--archive-root');p.add_argument('--run-id')
    args=parser.parse_args(argv)
    try:
        d=load(args.input)
        if args.command=='migrate':
            from migration import migrate
            if Path(args.output).exists() or Path(args.input).resolve()==Path(args.output).resolve():raise ValueError('输出必须为新文件')
            save(args.output,migrate(d),exclusive=True);print(canonical({'status':'migrated_draft','output':args.output}));return 0
        if isinstance(d,dict) and 'document' in d:d=d['document']
        from storage import materialize
        d=materialize(d,Path(args.input).resolve().parent)
        if d.get('schema_version',0)>=3 and d.get('meta',{}).get('run_id') and not (args.archive_root and args.run_id):
            raise ValueError('带run_id的schema 3文档需同时提供 --archive-root 与 --run-id，按锁定基线校验')
        if bool(args.archive_root)!=bool(args.run_id):raise ValueError('--archive-root 与 --run-id 必须同时提供')
        if args.archive_root or args.run_id:
            if not args.archive_root or not args.run_id:raise ValueError('独立校验需同时提供 --archive-root 与 --run-id')
            from archive import open_archive, run_path, validate_document
            from workflow import read_state
            root=Path(args.archive_root).absolute();open_archive(root)
            work=run_path(root,args.run_id);state=read_state(work)
            if Path(state['state_root']).resolve()!=root.resolve():raise ValueError('run-id不属于指定归档')
            pack=load(work/'evidence-pack.json') if state.get('evidence_sha256') else None
            if pack is not None and digest(work/'evidence-pack.json')!=state['evidence_sha256']:raise ValueError('固定资料包哈希不匹配')
            result=validate_document(root,d,state['contract'],pack)
        else:result=validate(d)
        print(canonical({'errors':result['errors'][:6],'error_count':len(result['errors']),'delivery':result.get('delivery')}))
        return 2 if result['errors'] else 0
    except (ValueError,KeyError,TypeError,OSError) as exc:
        print(canonical({'status':'blocked','category':'input_error','error':str(exc)}));return 2

if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8');raise SystemExit(main())
