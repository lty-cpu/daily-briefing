"""One capability boundary. No provider APIs, credentials, SDKs or source edits."""
from __future__ import annotations
from datetime import datetime, timezone
from pathlib import Path
import sys
import tempfile
import time

from common import canonical, iso, loads, stamp

HOST_CAPABILITIES = ('model_call', 'web_search', 'web_read', 'structured_output', 'visual')
STATES = ('available', 'unavailable', 'unknown')
MAX_REPORT_BYTES = 16384


class CapabilityError(ValueError):
    def __init__(self, capability, category, message):
        super().__init__(message)
        self.capability = capability
        self.category = category


def read_host_report(path):
    """Only the explicitly supplied host/agent observation; never discover config."""
    path = Path(path)
    if path.stat().st_size > MAX_REPORT_BYTES:
        raise ValueError('宿主能力记录过大；只提供能力状态和可选工具名称，不提供配置或密钥')
    return validate_host_report(loads(path.read_text(encoding='utf-8-sig')))


def validate_host_report(report):
    if not isinstance(report, dict) or set(report) - {'schema_version', 'source', 'observed_at', 'capabilities', 'tools'}:
        raise ValueError('能力记录只接受schema_version/source/observed_at/capabilities/tools')
    if type(report.get('schema_version')) is not int or report['schema_version'] != 1:
        raise ValueError('能力记录schema_version必须为1')
    if report.get('source') not in ('host_manifest', 'current_turn_observation'):
        raise ValueError('能力信息必须来自宿主清单或当前Agent工具观察，不能来自网页/缓存正文')
    observed = iso(report.get('observed_at'))
    if (observed - datetime.now(timezone.utc)).total_seconds() > 300:
        raise ValueError('宿主能力观察时间在未来')
    values = report.get('capabilities')
    if not isinstance(values, dict) or set(values) - set(HOST_CAPABILITIES):
        raise ValueError('未知能力键；只记录本次需要的能力')
    if any(not isinstance(v, str) or v not in STATES for v in values.values()):
        raise ValueError('能力状态必须为available/unavailable/unknown')
    tools = report.get('tools', {})
    if not isinstance(tools, dict) or set(tools) - {'web_search', 'web_read', 'structured_output', 'visual'}:
        raise ValueError('工具映射只接受本次使用的能力名')
    if any(not isinstance(v, str) or not v.strip() or len(v) > 160 or any(ord(c) < 32 for c in v) for v in tools.values()):
        raise ValueError('工具映射只保存工具名称，不保存调用参数、返回体或代码')
    stale = (datetime.now(timezone.utc) - observed).total_seconds() > 3600
    return dict(schema_version=1, source=report['source'], observed_at=report['observed_at'],
                capabilities={k: 'unknown' if stale else values.get(k, 'unknown') for k in HOST_CAPABILITIES},
                tools=tools, stale=stale)


def probe_directory(path):
    """One small create/write/read/remove probe in the named output directory."""
    if path is None:
        return {'status': 'not_required'}
    try:
        target = Path(path)
        target.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryFile(mode='w+b', dir=target, prefix='.briefing-preflight-') as stream:
            stream.write(b'briefing'); stream.flush(); stream.seek(0)
            if stream.read() != b'briefing':
                raise OSError('写入后读取结果不一致')
        return {'status': 'available', 'basis': 'local_write_read_probe'}
    except OSError as exc:
        return {'status': 'unavailable', 'basis': 'local_write_read_probe',
                'error_type': type(exc).__name__, 'message': '指定输出目录无法完成写入/读取探测'}


def preflight(work, state_root=None, host=None, *, requires_online=True):
    started = time.perf_counter()
    if host is not None:
        host = validate_host_report({k: v for k, v in host.items() if k != 'stale'})
    values = host['capabilities'] if host else {k: 'unknown' for k in HOST_CAPABILITIES}
    local = dict(python={'status': 'available' if sys.version_info >= (3, 10) else 'unavailable',
                         'version': '.'.join(map(str, sys.version_info[:3])), 'basis': 'this_running_interpreter'},
                 output_write=probe_directory(work), state_write=probe_directory(state_root))
    decision = plan(values, local, requires_online)
    return dict(version=1, checked_at=stamp(), **decision, requires_online=requires_online,
                host=host, local=local,
                wall_ms=round((time.perf_counter() - started) * 1000, 3),
                network_probes=0, extra_model_calls=0,
                note='宿主状态来自本轮清单/观察，并非额外API健康探测；实际网页失败仍需保留。')


def plan(values, local, requires_online):
    local_missing = [k for k, v in local.items() if v['status'] == 'unavailable']
    required = ('model_call', 'web_search', 'web_read') if requires_online else ()
    missing = [k for k in required if values[k] == 'unavailable']
    unknown = [k for k in required if values[k] == 'unknown']
    if local_missing or 'model_call' in missing:
        outcome = 'blocked'
    elif missing:
        outcome = 'limited_existing'
    elif unknown:
        outcome = 'awaiting_host_report'
    else:
        outcome = 'ready'
    return dict(status=outcome, missing=local_missing + missing, unknown=unknown,
                output_path='structured_or_json_text' if values['structured_output'] == 'available' else 'json_text_local_validation',
                visual_enabled=values['visual'] == 'available',
                online_research_enabled=requires_online and outcome == 'ready')


def observe_failure(runtime, error):
    """Normalize an actually reported failure without re-probing the host."""
    import copy
    if not runtime:
        return runtime
    result=copy.deepcopy(runtime)
    if result['host'] is None:
        result['host']=dict(schema_version=1,source='current_turn_observation',observed_at=stamp(),
            capabilities={k:'unknown' for k in HOST_CAPABILITIES},tools={},stale=False)
    values=result['host']['capabilities']
    values[error.capability]='unavailable' if error.category=='capability_unavailable' else 'unknown'
    result.update(plan(values,result['local'],result['requires_online']))
    result['last_failure']=dict(capability=error.capability,category=error.category,observed_at=stamp())
    return result


def summary(result):
    if not result:
        return dict(status='awaiting_host_report', unknown=list(HOST_CAPABILITIES[:3]),
                    next='当前运行没有能力记录；从宿主已暴露的工具填写，不读取密钥或调用未知API。')
    messages = dict(ready='按既有工具开展研究；无需额外模型/API探测。',
                    limited_existing='停止缺失能力对应的实时研究；仅可核验已有授权资料并标注有限覆盖，不编造或修改源码。',
                    awaiting_host_report='宿主核心能力尚未核实；补充当前工具清单/观察后继续，不把unknown当可用。',
                    blocked='核心模型/本地能力不可用；保存准确错误，终止相应研究，不尝试改源码或模型配置。')
    return {k: result[k] for k in ('status', 'missing', 'unknown', 'output_path', 'visual_enabled', 'wall_ms')} | {'next': messages[result['status']]}


def enforce_delivery(checks, report, runtime):
    """A capability failure cannot be hidden by setting requested_grade=full."""
    if report['meta']['mode'] == 'teaching' or report['meta']['evidence_mode'] == 'fixed_pack':
        return
    capability = summary(runtime)
    checks['runtime_capabilities'] = capability
    if not capability.get('visual_enabled', False) and report.get('visual', {}).get('status') != 'not_performed':
        checks['errors'].append(dict(path='visual.status',category='input_error',
            message='宿主未声明可用视觉能力，不能记录视觉通过；实际能力改变后显式更新预检。'))
    if capability['status'] != 'ready':
        reason = '宿主核心能力未就绪：' + ', '.join(capability.get('missing', []) + capability.get('unknown', []))
        delivery = checks.get('delivery')
        if delivery:
            if delivery['grade'] in ('full','incremental_verified','first_observation'):
                delivery['grade'] = 'partial_coverage' if report['meta'].get('edition')=='intraday' else 'limited'
            delivery['reasons'].append(reason)
        checks['warnings'].append(dict(path='runtime.capabilities', category='insufficient_data', message=reason))


def decode_json_output(value):
    """Neutral optional envelope + strict JSON text; no provider return formats."""
    if isinstance(value, dict) and set(value) == {'capability_result'}:
        envelope = value['capability_result']
        if not isinstance(envelope, dict) or set(envelope) - {'capability', 'status', 'data', 'message'}:
            raise ValueError('无效统一能力结果封装')
        capability = envelope.get('capability')
        if capability not in HOST_CAPABILITIES:
            raise ValueError('未知结果能力')
        status = envelope.get('status')
        if status not in ('ok', 'unavailable', 'timeout', 'error'):
            raise ValueError('无效能力结果状态')
        if status != 'ok':
            raise CapabilityError(capability, 'infrastructure_error' if status in ('timeout', 'error') else 'capability_unavailable',
                                  f'{capability}: {status}；保留状态，不修改源码或切换厂商API')
        value = envelope.get('data')
    if isinstance(value, str):
        value = value.strip()
        if value.startswith('```json\n') and value.endswith('\n```'):
            value = value[8:-4]
        elif value.startswith('```\n') and value.endswith('\n```'):
            value = value[4:-4]
        value = loads(value)
    if not isinstance(value, dict):
        raise ValueError('输出需单个JSON对象；不从解释文字中猜测提取或执行代码')
    return value


def read_json_output(path):
    import sys
    text = sys.stdin.buffer.read().decode('utf-8-sig') if path=='-' else Path(path).read_text(encoding='utf-8-sig')
    # A native object and ordinary JSON text take the same deterministic path.
    return decode_json_output(decode_json_output(text))
