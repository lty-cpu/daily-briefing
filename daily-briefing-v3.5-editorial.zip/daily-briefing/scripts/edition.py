"""One edition policy for issue timing, research shape and delivery."""
from datetime import date, datetime, time
from common import InputError, fingerprint, get_zone, iso

POLICY_VERSION = 2
ASIA_SHANGHAI = 'Asia/Shanghai'
SUPPORTED_A_SHARE_MARKETS = frozenset({
    'A股', '中国A股', '沪深北A股', 'A股市场', 'CN-A', 'CN A-shares',
    'China A-shares', 'A-shares', 'A-Shares', 'SSE/SZSE/BSE',
})
POLICIES = {
    'morning': dict(label='早报', full=True,
                    budget=dict(soft_queries=40,hard_queries=80,reserved_verifications=12,timeout_seconds=2400)),
    'evening': dict(label='晚报', full=True,
                    budget=dict(soft_queries=36,hard_queries=72,reserved_verifications=12,timeout_seconds=2400)),
    'intraday': dict(label='盘中观察', full=False,
                     budget=dict(soft_queries=12,hard_queries=28,reserved_verifications=8,timeout_seconds=600)),
    'snapshot': dict(label='即时完整研究', full=True,
                     budget=dict(soft_queries=40,hard_queries=80,reserved_verifications=12,timeout_seconds=2400)),
}
SECTION_LABELS = {
    'morning': (('overview','今日总览'),('news','昨日 / 夜间重要消息'),('ai','AI / ChatGPT / Codex'),
        ('market','A股整体表现'),('sectors','板块深度分析'),('macro','美股与宏观'),
        ('observations','非共识与待验证观察'),('actions','今日行动提示'),('sources','来源与复核')),
    'evening': (('market','今日市场观察'),('news','今日中国官方重要信息'),('companies','收盘后重要公司公告'),
        ('sectors','重点板块跟踪'),('macro','海外市场与宏观传导'),('observations','非共识与待验证观察'),
        ('actions','明日 / 下一交易日重点观察'),('sources','来源与复核')),
    'intraday': (('status','本轮状态'),('changes','重要新增与变动'),('market','盘面与原观察条件'),
        ('next','下一观察'),('sources','来源与复核')),
    'snapshot': (('overview','今日总览'),('news','昨日 / 夜间重要消息'),('ai','AI / ChatGPT / Codex'),
        ('market','A股整体表现'),('sectors','板块深度分析'),('macro','美股与宏观'),
        ('observations','非共识与待验证观察'),('actions','今日行动提示'),('sources','来源与复核')),
}
for edition_id, labels in SECTION_LABELS.items():
    POLICIES[edition_id]['sections']=tuple(section for section,label in labels if section!='sources')


def sections(edition):
    labels=list(SECTION_LABELS[edition])
    if edition=='evening':labels.insert(4,('ai','AI / ChatGPT / Codex'))
    return [dict(id=key,title=title,number=f'{index:02}',parent=None) for index,(key,title) in enumerate(labels,1)]


def route(edition,section):
    if edition=='intraday':return 'market' if section=='market' else 'changes'
    if edition=='evening' and section=='overview':return 'hero'
    if edition in ('morning','snapshot') and section=='companies':return 'news-companies'
    return section


def policy(edition):
    if edition not in POLICIES:raise InputError('edition','需要明确早报、晚报或盘中观察；snapshot仅显式兼容使用')
    return dict(POLICIES[edition],id=edition,version=POLICY_VERSION,section_labels=SECTION_LABELS[edition])


def section_ids(edition):
    return frozenset(item['id'] for item in sections(edition))


def session(calendar, day, now):
    """No weekday/clock inference without an explicit, complete session calendar."""
    if not calendar or calendar.get('complete') is not True or calendar.get('synthetic') is True:
        return dict(status='unknown',phase='unknown',reason='缺少已核验的完整A股常规交易会话日历')
    if calendar.get('market') not in SUPPORTED_A_SHARE_MARKETS:
        return dict(status='unknown',phase='unknown',reason='日历市场不是明确支持的沪深北/A股标识')
    if calendar.get('timezone') != ASIA_SHANGHAI:
        return dict(status='unknown',phase='unknown',reason='A股交易日历必须使用Asia/Shanghai时区')
    if not calendar.get('source_ids') or not calendar.get('evidence_ids'):
        return dict(status='unknown',phase='unknown',reason='日历缺少来源与原文定位')
    if not calendar.get('valid_from','')<=day<=calendar.get('valid_to',''):
        return dict(status='unknown',phase='unknown',reason='目标日不在日历核验范围')
    matches=[s for s in calendar.get('sessions',[]) if s.get('date')==day]
    if len(matches)>1:return dict(status='unknown',phase='unknown',reason='交易会话冲突')
    if not matches:return dict(status='closed_day',phase='closed_day',reason='核验日历标记休市')
    try:
        zone=get_zone(calendar['timezone'])
        close=iso(matches[0]['close_at']).astimezone(zone)
        local_now=now.astimezone(zone)
    except (KeyError,TypeError,ValueError):
        return dict(status='unknown',phase='unknown',reason='日历时区或收盘时刻无效')
    if close.date().isoformat()!=day or close.time().replace(tzinfo=None)!=time(15):
        return dict(status='unknown',phase='unknown',reason='日历不符合A股常规15:00收盘语义')
    clock=local_now.timetz().replace(tzinfo=None)
    phase=('closed' if now>=close else 'preopen' if clock<time(9,15) else 'auction' if clock<time(9,30) else
           'continuous' if clock<time(11,30) else 'lunch' if clock<time(13) else
           'continuous')
    return dict(status='session',phase=phase,close_at=close.isoformat(),calendar_id=calendar['id'],
                calendar_version=calendar['version'],calendar_hash=fingerprint(calendar))


def availability(edition, now, calendar=None, target=None):
    day=target or now.date().isoformat()
    if edition=='morning':
        due=datetime.combine(date.fromisoformat(day),time(8),tzinfo=now.tzinfo)
        return dict(available=now>=due,cutoff=due.isoformat(),reason='目标日08:00尚未到来' if now<due else '',session=session(calendar,day,now))
    if edition=='snapshot':return dict(available=True,cutoff=now.isoformat(),reason='',session=session(calendar,day,now))
    current=session(calendar,day,now)
    if edition=='intraday':ok=day==now.date().isoformat() and current['phase'] in ('auction','continuous','lunch')
    else:ok=day<=now.date().isoformat() and current['phase']=='closed'
    cutoff=datetime.combine(date.fromisoformat(day),time(23,59),tzinfo=now.tzinfo).isoformat() if edition=='evening' and day<now.date().isoformat() else now.isoformat()
    return dict(available=ok,cutoff=cutoff,session=current,
                reason='' if ok else '交易会话未核验或当前不在该版型时段')


def options(now, calendar=None, target=None):
    result=[]
    for number,edition in ((1,'morning'),(2,'intraday'),(3,'evening')):
        state=availability(edition,now,calendar,target)
        result.append(dict(number=number,id=edition,label=policy(edition)['label'],**state))
    return result
