"""Bounded range acquisition into the existing cache and series representation."""
from datetime import timedelta
from pathlib import Path
import os
import time
import urllib.error
import urllib.request
from common import InputError, canonical, fingerprint, iso, load, loads, num, save, stamp
from schema import SERIES, check
from storage import cache_get, cache_put

BENCHMARKS=(('000001.SH','上证指数'),('399001.SZ','深证成指'),('399006.SZ','创业板指'),('000688.SH','科创50'),('000300.SH','沪深300'))


class AcquisitionFailure(ValueError):
    def __init__(self,category):
        super().__init__(category)
        self.category=category


def cache_identity(metadata):
    fields=('provider','entity_id','frequency','basis','unit','currency','scale','adjustment','classification','roll_policy','universe_id','universe_version')
    return 'H_'+fingerprint([{key:metadata.get(key) for key in fields},metadata['vintage']['id']])[:24]


def fetch_page(config,item,start,end,cursor,timeout):
    if item.get('pages') or config.get('provider','files')=='files':
        pages=item.get('pages',[])
        position=int(cursor or 0)
        if position>=len(pages):return dict(observations=[],next=None)
        path=Path(pages[position])
        if not path.is_file() or path.stat().st_size>16000000:raise AcquisitionFailure('invalid_file')
        data=load(path)
        rows=data if isinstance(data,list) else data['observations']
        return dict(observations=[row for row in rows if start<=row['date']<=end],next=position+1 if position+1<len(pages) else None)
    if config.get('provider')!='tushare' or config.get('authorized') is not True:raise AcquisitionFailure('not_configured')
    name=config.get('credential_env')
    if not isinstance(name,str) or not name.isidentifier():raise AcquisitionFailure('credential_not_configured')
    credential=os.environ.get(name)
    if not credential:raise AcquisitionFailure('authentication')
    if cursor is not None:raise AcquisitionFailure('unsupported_pagination')
    metadata=item['metadata']
    if metadata.get('asset_type')!='index' or metadata['basis'] not in ('price','turnover'):raise AcquisitionFailure('unsupported_product')
    payload=dict(api_name='index_daily',token=credential,params=dict(ts_code=item['code'],start_date=start.replace('-',''),end_date=end.replace('-','')),fields='ts_code,trade_date,close,amount')
    request=urllib.request.Request('https://api.tushare.pro',data=canonical(payload).encode('utf-8'),headers={'Content-Type':'application/json'})
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self,*args,**kwargs):raise AcquisitionFailure('redirect_refused')
    try:
        with urllib.request.build_opener(NoRedirect).open(request,timeout=timeout) as response:
            raw=response.read(16000001)
        if len(raw)>16000000:raise AcquisitionFailure('response_limit')
        result=loads(raw.decode('utf-8'))
    except urllib.error.HTTPError as error:
        raise AcquisitionFailure('authentication' if error.code in (401,403) else 'rate_limit' if error.code==429 else 'transient') from None
    except (OSError,TimeoutError):raise AcquisitionFailure('timeout') from None
    if result.get('code')!=0:raise AcquisitionFailure('permission_or_quota')
    data=result.get('data') or {};rows=[dict(zip(data.get('fields',[]),row)) for row in data.get('items',[])]
    observations=[]
    for row in rows:
        if row.get('ts_code')!=item['code']:raise AcquisitionFailure('wrong_entity')
        raw_day=str(row['trade_date']);day=raw_day[:4]+'-'+raw_day[4:6]+'-'+raw_day[6:8]
        value=row['close'] if metadata['basis']=='price' else row['amount']
        if metadata['basis']=='turnover' and value is not None:value=value*1000/metadata.get('scale',1)
        observations.append(dict(date=day,value=value,available_at=metadata['vintage']['available_at'],status='missing' if value is None else 'traded',vintage=metadata['vintage']))
    return dict(observations=observations,next=None)


def acquire(work,state,config,fetcher=fetch_page,clock=time.monotonic):
    from data_io import merge
    from archive import validate_document
    from storage import materialize
    from workflow import remaining
    work=Path(work);root=Path(state['state_root']);document=load(work/'briefing.json')
    items=config.get('objects',[])
    if not isinstance(items,list) or len(items)>12:raise InputError('history.objects','单轮最多12个明确数据产品，不初始化全A股')
    if not items:return dict(status='not_configured',benchmarks=[dict(code=code,label=label) for code,label in BENCHMARKS],next='使用已授权宿主区间取数或公开原始文件；缺少路径不循环诊断')
    started=clock();budget=state['budget'];elapsed_used=state.get('history_elapsed_seconds',0)
    allowance=max(0,min(budget.get('history_seconds',90)-elapsed_used,remaining(state)['seconds_remaining']-budget.get('reserved_seconds',90)))
    deadline=started+allowance;cutoff=state['contract']['initial_cutoff'];rows=[];requests=0;retries=0;cache_hits=0
    provider_key='HSTATE_'+fingerprint([config.get('provider'),config.get('config_revision','1'),config.get('credential_env')])[:24]
    state_path=root/'.runtime/cache'/provider_key/'acquisition.json'
    prior=load(state_path) if state_path.exists() else {}
    blocked=prior.get('failure_class') in ('authentication','permission_or_quota','credential_not_configured','not_configured')
    cooling=prior.get('next_retry_after') and iso(prior['next_retry_after'])>iso(stamp())
    permit_retry=config.get('explicit_retry') is True
    try:
        for item in items:
            metadata=dict(item['metadata']);identifier=cache_identity(metadata);metadata.setdefault('id',identifier)
            calendar=next((value for value in document['calendars'] if value['id']==metadata.get('calendar_id')),None)
            expected=[session['date'] for session in (calendar or {}).get('sessions',[]) if iso(session['close_at'])<=iso(cutoff)][-61:]
            if not calendar or not calendar['complete'] or not expected:
                rows.append(dict(entity_id=metadata['entity_id'],status='calendar_unavailable',missing_sessions=[],return20=None,return60=None));continue
            cached=cache_get(root/'.runtime',identifier,cutoff)
            cached_data=cached.get('entry',{}).get('data',{})
            points={point['date']:point for point in cached_data.get('observations',[]) if point['date'] in expected}
            if points:cache_hits+=1
            missing=[day for day in expected if day not in points or points[day]['status']=='missing']
            failure=None;cursor=None;page_count=0;retrieved=cached.get('actual_retrieved_at')
            file_input=bool(item.get('pages')) or config.get('provider','files')=='files'
            if missing and (blocked or cooling) and not permit_retry and not file_input:failure=prior.get('failure_class','cooldown')
            if missing and not failure:
                start=min(missing);end=max(missing)
                while page_count<8 and clock()<deadline:
                    page=None
                    for attempt in range(min(budget.get('history_retries',2),3)+1):
                        timeout=min(budget.get('request_timeout_seconds',12),deadline-clock())
                        if timeout<=0:break
                        try:
                            requests+=1
                            page=fetcher(config,item,start,end,cursor,timeout)
                            if clock()>deadline:failure='deadline'
                            break
                        except AcquisitionFailure as error:
                            failure=error.category
                            if failure not in ('timeout','transient','rate_limit'):break
                            if attempt<min(budget.get('history_retries',2),3):retries+=1
                        except (OSError,TimeoutError):failure='timeout'
                    if page is None:break
                    incoming=page.get('observations',[])
                    if len(incoming)>10000:raise InputError('history','单页超过10000条，拒绝无界数据')
                    for point in incoming:
                        if point['date'] not in expected:raise InputError('history.date','返回观测不属于所请求的已结束会话')
                        errors=check(point,SERIES['required']['observations']['items'],'history.point')
                        if errors:raise InputError(errors[0]['path'],errors[0]['message'])
                        points[point['date']]=point
                    retrieved=stamp();page_count+=1
                    if failure=='deadline':break
                    failure=None;cursor=page.get('next')
                    if cursor is None:break
                if cursor is not None and not failure:failure='page_limit' if page_count>=8 else 'deadline'
                if clock()>=deadline and missing and not points:failure='deadline'
            observations=[points[day] for day in sorted(points)]
            missing=[day for day in expected if day not in points or points[day]['status']!='traded' or points[day]['value'] is None]
            series=dict(metadata,observations=observations,completeness='partial' if missing else 'complete')
            errors=check(series,SERIES,'history.series')
            if errors:raise InputError(errors[0]['path'],errors[0]['message'])
            quality=dict(coverage_start=observations[0]['date'] if observations else None,coverage_end=observations[-1]['date'] if observations else None,
                expected_sessions=expected,missing_sessions=missing,last_attempt=stamp(),failure_class=failure,next_retry_after=None)
            trial=dict(document,series=[value for value in document['series'] if value['id']!=series['id']]+[series])
            metrics=[]
            for count in (20,60):
                if series['basis']!='price':continue
                metrics.append(dict(id='R_'+fingerprint([series['id'],count])[:24],label=series['label']+f' · {count}会话收益',op='return',unit='%',series_id=series['id'],n=count,window_basis='trading_sessions',signed=True,
                    dimensions=dict(entity_id=series['entity_id'],currency='none',scale=1,period=expected[-1],segment='all',measure='return'),domain=series.get('domain','cn_market'),price_basis=series['adjustment'],return_type='price_return',frequency='daily'))
            trial['metrics']=[value for value in document['metrics'] if value['id'] not in {metric['id'] for metric in metrics}]+metrics
            checks=validate_document(root,materialize(trial,work),state['contract'])
            if checks['errors']:raise InputError(checks['errors'][0]['path'],checks['errors'][0]['message'])
            if observations:
                source=next((source for source in document['sources'] if source['id'] in series['source_ids']),None)
                if source is None:raise InputError('history.source','批量原数据仍需来源与窗口读取证据')
                cache_put(root/'.runtime',dict(id=identifier,layer='market',source_url=source['url'],retrieved_at=retrieved or stamp(),vintage_at=series['vintage']['available_at'],
                    valid_until=(iso(cutoff)+timedelta(days=370)).isoformat(),recheck_triggers=['provider_revision','basis_change'],data=dict(observations=observations,metadata=metadata,quality=quality)))
                merge(work,dict(series=[series],metrics=metrics));document=load(work/'briefing.json')
            from calculations import point_available
            quality['unknown_availability']=[point['date'] for point in observations if not point_available(point,series,dict(calendars={calendar['id']:calendar}))]
            quality['status']='complete' if not missing and not quality['unknown_availability'] and len(expected)>=61 and all(checks['values'].get(metric['id']) is not None for metric in metrics) else 'partial'
            quality.update(entity_id=series['entity_id'],label=series['label'],points=len(observations),current=observations[-1]['value'] if observations and observations[-1]['date']==expected[-1] else None,
                return20=checks['values'].get(metrics[0]['id']) if metrics else None,return60=checks['values'].get(metrics[1]['id']) if metrics else None)
            rows.append(quality)
            if failure:
                next_retry=None if failure in ('authentication','permission_or_quota','not_configured','credential_not_configured') else (iso(stamp())+timedelta(minutes=15)).isoformat()
                save(state_path,dict(last_attempt=stamp(),failure_class=failure,next_retry_after=next_retry))
                if failure in ('authentication','permission_or_quota','not_configured','credential_not_configured'):blocked=True;prior=dict(failure_class=failure)
    finally:
        elapsed=clock()-started;state['history_elapsed_seconds']=elapsed_used+elapsed
        state['telemetry']['events'].append(dict(kind='import',stage='history_initialization',wall_ms=elapsed*1000,requests=requests,retries=retries,cache_hits=cache_hits,recorded_at=stamp()))
        save(work/'run-state.json',state)
    result=dict(status='complete' if rows and all(row['status']=='complete' for row in rows) else 'partial',objects=rows,requests=requests,retries=retries,cache_hits=cache_hits,seconds=elapsed,background_tasks=0)
    save(work/'history-status.json',result)
    return result
