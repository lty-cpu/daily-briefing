# 正常研究输入（schema7）

执行顺序是 `start → 按 status 的 task_plan 搜集并 submit 小批量 → compute → 一次综合 review → finish`。完整期报共享首次请求起点的25分钟预算，20分钟开始收尾。市场、中国官方/地缘、公司、海外金融变量、AI五域先做有界发现；重大候选及时登记去向，再选择通常约2条深主题。`status` 的剩余时间与具体下一步优先于重复读规范。命令为 `python <skill>/scripts/run.py submit --run-id <ID> --run-token <TOKEN> --input <UTF-8 JSON文件>`；`{"packets":[...]}` 原子提交，失败不部分写入。回执别名引用生成对象，全文审阅清单按需 `inspect`。

## 来源、消息与窗口

每个来源登记可识别发布者、原始链接、真实发布时间或日期、实际读取时间、实际已见的片段和定位。`published_at` 是来源发布时间，`available_at` 是有证据的截止前可得上界，`retrieved_at` 是实际读取时间，不能互相替代。日期级公开时间未知保留日期精度；不能把事后读到的资料说成截止前已知。来源 kind 用 official/company/media/data/public_account，`read_method` 用 original/cached/search_summary；只读搜索摘要就标搜索摘要。以下形状示例不得当成真实新闻复用：

```json
{"task":"official","kind":"event","alias":"policy_notice","section":"news","entity_id":"ORG_X","subject":"政策事项","title":"机构X公布政策事项","fact_text":"机构X公布了拟议政策事项，尚待审批。","text":"机构X公布拟议政策，实施仍取决于后续审批。","status":"confirmed","proposition":"publication","stage":"拟议","unknowns":"核对正式批准及生效文件","source":{"title":"政策原文标题","publisher":"机构X","url":"https://example.org/notice","published_at":"2026-09-24T10:00:00+08:00","retrieved_at":"2026-09-24T11:00:00+08:00","version":"首版","kind":"official","read_status":"full","read_method":"original","locator":"正文第2段","quote":"拟议事项须经审批后实施","context":"该段说明的是计划，不是已执行结果"}}
```

`fact_text` 是证据支持的事实命题，`text` 是读者看到的事件解释，不能把推断放进事实。确认“官方发布计划”不等于确认计划执行；事项发生须在同一原文确实支持时写 `proposition:"occurrence", occurrence_evidence:"current", verification_at:<实际核验时间>`，程序将 current 绑定本条证据ID。媒体已报道但原公告未取得时可用 `reported` 与清楚的来源归因，不能冒充官方确认。可报道性与网站窗口完整性分开；全站索引未查全仍可保留已找到的有出处消息，窗口保持 partial。高重要候选应在 event 或 task 中说明采用、待核或排除及原因。

同一事件后续确认、更正、否认用稳定 `event_identity={entity,subject,family,release_id,version,attributes,importance,next_check,aliases?}`；新来源不能仅因URL或标题变化生成另一个业务事件。改正时用 `novelty:"correction"` 和来源 `source_basis:"correction"`（否认用 `denial`），旧表述保留在可展开历史，主文显示当前版本。`content_role` 是 news/continuing_event/context/financial_baseline；旧财报用 financial_baseline，不能伪装本期新闻。`domain` 独立于 `section`；国内央行是 cn_official，海外变量明确写 overseas，AI 明确写 ai。

官方入口覆盖用 `kind:"window"`，包含 `obligations,url,status,method,checked_at,window_start,window_end,content_scope,note,refs`。读完新鲜指定索引才可 `checked_none`；定向检索、陈旧首页、403、分页未完保留 partial/failed 和真实边界。`kind:"index"` 来源只代表已读列表，不自动创造财经事实。任务结果 `result:{status,current_conclusion,next,stop_reason?}`；`verified_none` 要有已核验窗口，`blocked` 要有失败尝试，`budget_stop` 只在真实预算到限时用。每次工具尝试可附 `attempt:{at,query_or_url,result,status,evidence_ids,tool_ref}`。

## 数值与更正

`kind:"market"` 的 `rows` 每行写 entity_id、label、value（缺失用 null，0 不等于缺失）、unit、currency、scale、period、as_of、scope、measure、alias。每个观测引用实际 source/evidence，图表只用同口径有效值。市场同一观测的身份由主体、指标、期间/时点、样本与价格口径决定，换 packet alias 不生成第二张卡。不同来源值冲突不能自动并入确定值；核实后用 `update:"correction"`、`correction_reason` 和新的证据提交，保留旧版更正记录。`support:{status:"reviewed",locator,quote,note}` 需说明主体、期间、单位/表头和数值；程序绑定本值、单位、指标、证据版本，改值或改证据后须重新核对。单位转换用 `conversion:{raw_value,raw_unit,raw_scale,evidence_id,entity,period,measure}`，原值须在真实片段中；原表行与表头可由 context 辅助，不用捏造单行全包含。

取行情先使用宿主已有授权的批量数据能力；没有就读交易所或明确标注的可读取收盘表。搜索是定位手段，不能只凭摘要确认数值。市场至少尽力取得指数日变动、成交额、同一明确定义样本的涨跌广度；宏观任务独立取得海外利率、汇率或能源变量。没有授权历史路径无需补61点，单日数据可以形成诚实的截面。长序列按[有界历史补齐](history-data.md)处理。

## 深主题、观察和综合编辑

普通重要消息写短解释；深主题才使用 `kind:"thesis"`。正常聚焦格式只需 `blocks` 的 `judgment,mechanism,alternative,support,invalidation`，每项 `{text,refs}`，另写 `why_this`。必须给 `horizons.intraday/short/medium`，各写 `conclusion,direction,refs,next_observation,review_at,confidence`；各期限只写差异，不复制共同机制。重点要比消息多出同业/财务/量价/条件比较，资料不足可以少选并在 `selection_review` 说明取舍。旧十字段 compact 格式仅供旧运行与特殊迁移，不是正常表单。

有效近期观察随主题用 `observe:{trigger,target,baseline,decision_if}` 一次登记：未公布日程可用事件触发，不能编日期；需要确定交易日才使用带来源和证据的已校验 calendar_id。行动栏引用同一观察，不重写另一份。当本期没有合格观察，review 中说明未能设置的具体原因。非共识问题使用 `kind:"observation"`，没有共识证据只写 watch，不宣称已推翻市场共识。

最后用一份 `kind:"review",task:"synthesis"` 提交 `headline`、通常3—5条不同的 `summary:[{text,refs}]`、实际已审的 `reviewed`、`reviewer,method,status`。`featured` 可引用已登记指标，图表仅用合格数据。摘要、消息和主题各承担不同内容：消息说变化，主题给新增比较，行动说下一验证；逐字重复可由程序提示，语义重复在这一次综合编辑中消除。执行自审写 self_review，不虚构独立审阅。`finish --preview` 不占正式尝试；正式归档用 `finish`。如报 needs_research，按最重要缺口局部补证；真实到限或受阻如实有限交付。
