"""One verified calendar input for the edition gate and saved research document."""
from common import InputError, fingerprint, iso
from schema import CALENDAR, SCHEMA, check


def normalize(raw, day=None, allow_unresolved=False):
    """Accept a standalone calendar with provenance or a sources/evidence/calendars bundle."""
    if not isinstance(raw, dict):
        raise InputError('calendar', '期望单个日历对象或 {sources,evidence,calendars} 资料包')
    if 'calendars' in raw:
        path = 'calendar.calendars'
        calendars = raw['calendars']
        sources = raw.get('sources', [])
        evidence = raw.get('evidence', [])
    else:
        path = 'calendar'
        calendars = [raw]
        sources = raw.get('sources', [])
        evidence = raw.get('evidence', [])
    if not isinstance(calendars, list) or not calendars:
        raise InputError(path, '需要至少一个日历对象；整包请使用 calendars:[...]')
    if not isinstance(sources, list) or not isinstance(evidence, list):
        raise InputError('calendar.sources/evidence', '来源与原文记录需为数组')
    cleaned = []
    for index, item in enumerate(calendars):
        if not isinstance(item, dict):
            raise InputError(f'{path}[{index}]', '期望日历对象，包含市场、范围及会话')
        calendar = {k:v for k,v in item.items() if k not in ('sources', 'evidence')}
        errors = check(calendar, CALENDAR, f'{path}[{index}]')
        if errors:
            raise InputError(errors[0]['path'], errors[0]['message'])
        cleaned.append(calendar)
    for label, rows, spec in (('sources',sources,SCHEMA['required']['sources']['items']),
                              ('evidence',evidence,SCHEMA['required']['evidence']['items'])):
        for index, item in enumerate(rows):
            errors = check(item, spec, f'calendar.{label}[{index}]')
            if errors:
                raise InputError(errors[0]['path'], errors[0]['message'])
    by_source = {s['id']:s for s in sources}
    by_evidence = {e['id']:e for e in evidence}
    if len(by_source)!=len(sources) or len(by_evidence)!=len(evidence):
        raise InputError('calendar.sources/evidence', '引用ID重复；请保留唯一原文记录')
    for index, item in enumerate(cleaned):
        if allow_unresolved and not sources and not evidence:
            continue
        for sid in item['source_ids']:
            if sid not in by_source:
                raise InputError(f'{path}[{index}].source_ids', f'{sid} 未在 sources 中；单日历也需附 sources/evidence')
        for eid in item['evidence_ids']:
            record = by_evidence.get(eid)
            if not record or record['source_id'] not in item['source_ids']:
                raise InputError(f'{path}[{index}].evidence_ids', f'{eid} 缺失或未连接所列来源')
        if not item['source_ids'] or not item['evidence_ids']:
            raise InputError(f'{path}[{index}]', '需有实际来源与原文定位；source_ids/evidence_ids 不能为空')
    eligible = [c for c in cleaned if day is None or c['valid_from']<=day<=c['valid_to']]
    if len(eligible)!=1:
        raise InputError(path, f'目标日 {day or "未指定"} 匹配 {len(eligible)} 个日历；请只提供唯一适用日历')
    selected = eligible[0]
    return dict(calendar=selected, sources=sources, evidence=evidence,
                calendars=[selected], fingerprint=fingerprint(selected),
                bundle_fingerprint=fingerprint(dict(calendar=selected,sources=sources,evidence=evidence)),
                unresolved=bool(allow_unresolved and not sources and not evidence))
