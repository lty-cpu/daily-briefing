"""Incremental input edits, structured imports and bounded research telemetry."""
import copy
import csv
from io import StringIO
import json
from pathlib import Path
import time
from common import canonical, fingerprint, ID, load, loads, num, save, stamp, InputError, digest
from schema import SCHEMA, check
from storage import materialize, put_artifact, cache_get, cache_put

ARRAYS={k:s['items'] for k,s in SCHEMA['required'].items() if s['type']=='array'}


def describe(group):
    spec=SCHEMA['required'].get(group,SCHEMA['optional'].get(group))
    if not spec:raise ValueError('未知数据集合')
    return dict(schema_version=__import__('common').SCHEMA_VERSION,group=group,definition=spec,
                note='结构定义的单一来源；时间、单位、证据与交付语义仍需执行运行时校验。')


def merge(work,patch):
    work=Path(work);d=load(work/'briefing.json');before=fingerprint(d)
    existing_errors=check(d)
    if existing_errors:raise InputError(existing_errors[0]['path'],existing_errors[0]['message'])
    from capabilities import decode_json_output
    patch=decode_json_output(patch)
    if not isinstance(patch,dict) or set(patch)-set(SCHEMA['required'])-set(SCHEMA['optional']):
        raise ValueError('片段包含未知顶层字段')
    for group,items in patch.items():
        if group=='schema_version':raise ValueError('不能通过merge切换schema')
        if group=='meta':
            allowed={'title','window_start','window_adjustment_reason','requested_grade','featured_metrics','section_titles','market_dates'}
            if not isinstance(items,dict) or set(items)-allowed:raise ValueError('meta只能更新展示字段和有理由的研究回溯窗口；请求契约不可改')
            d['meta'].update(items)
        elif group in ARRAYS:
            if not isinstance(items,list):raise ValueError('集合需数组')
            existing=d[group]
            if 'id' in ARRAYS[group].get('required',{}):
                assigned=[]
                for item in items:
                    if not isinstance(item,dict):raise InputError(group,'条目必须为对象')
                    item=copy.deepcopy(item)
                    if 'id' not in item:item['id']=group[:2].upper()+'_'+fingerprint(item)[:16]
                    errors=check(item,ARRAYS[group],group)
                    if errors:raise ValueError(canonical(errors[:4]))
                    assigned.append(item)
                ids=[x['id'] for x in assigned]
                if len(ids)!=len(set(ids)):raise ValueError('片段含重复ID，拒绝含糊覆盖')
                updates={x['id']:x for x in assigned}
                d[group]=[updates.pop(x['id'],x) for x in existing]+list(updates.values())
            else:
                errors=check(items,SCHEMA['required'][group],group)
                if errors:raise ValueError(canonical(errors[:4]))
                d[group]=items
        else:
            spec=SCHEMA['required'].get(group,SCHEMA['optional'].get(group))
            errors=check(items,spec,group)
            if errors:raise ValueError(canonical(errors[:4]))
            d[group]=items
    if d['schema_version']>=4 and 'coverage' in patch:
        from research import coverage_view
        d['coverage']=coverage_view(d['coverage'],d['meta']['window_start'],d['meta']['cutoff'])
    errors=check(d)
    if errors:raise InputError(errors[0]['path'],errors[0]['message'])
    after=fingerprint(d)
    if after==before:return dict(status='unchanged',sha256=after)
    save(work/'input-edits'/(after+'.json'),dict(previous=before,current=after,patch=patch,recorded_at=stamp()))
    save(work/'briefing.json',d)
    return dict(status='merged',sha256=after,groups=list(patch),counts={k:len(d[k]) for k in patch if isinstance(d[k],list)})


def submit(work,state,packet):
    from archive import validate_document
    from research import coverage_view, task_progress
    started=time.perf_counter();work=Path(work)
    document=load(work/'briefing.json');before=fingerprint(document)
    if not isinstance(packet,dict):raise InputError('packet','需要JSON对象或含packets数组的对象')
    if document['schema_version']<4:raise InputError('schema_version','旧运行保留merge协议；新版packet请开启新一期或独立重做')
    batches=packet.get('packets',[packet])
    if not isinstance(batches,list) or not batches or len(batches)>60:raise InputError('packets','需要1—60个小型研究packet的数组')
    aliases=document.setdefault('packet_aliases',{});receipts=[]
    def required(item,key):
        if key not in item or item[key] is None or item[key]=='':raise InputError(key,'缺少字段：'+key)
        return item[key]
    def identifier(prefix,value):return prefix+'_'+fingerprint(value)[:20]
    def put(group,item):
        old=next((index for index,value in enumerate(document[group]) if value['id']==item['id']),None)
        if old is None:document[group].append(item)
        else:document[group][old]=item
        return item['id']
    def references(values):
        if not isinstance(values,list):raise InputError('refs','需引用别名或ID的数组；单元素也必须是数组')
        result=dict(fact_ids=[],metric_ids=[],evidence_ids=[])
        for value in values:
            if value in aliases:
                for field,group in (('fact','fact_ids'),('metric','metric_ids'),('evidence','evidence_ids')):
                    if field in aliases[value]:result[group].append(aliases[value][field])
                linked=next((item for item in document['claims'] if item['id']==aliases[value].get('claim')),None)
                if linked:
                    for group in result:result[group].extend(linked[group])
            else:
                found=False
                for group,key in (('facts','fact_ids'),('metrics','metric_ids'),('evidence','evidence_ids')):
                    if any(item['id']==value for item in document[group]):result[key].append(value);found=True
                if not found:raise InputError('refs','未知引用：'+str(value))
        return {key:list(dict.fromkeys(values)) for key,values in result.items()}
    def source_record(item,alias):
        source=required(item,'source')
        if not isinstance(source,(str,dict)):raise InputError('source','来源需对象或已有别名')
        if isinstance(source,str):
            bundle=aliases.get(source,{})
            if not {'source','evidence'}<=set(bundle):raise InputError('source','未知来源别名')
            return bundle['source'],bundle['evidence']
        public=required(source,'published_at');retrieved=required(source,'retrieved_at')
        if not isinstance(public,str) or not isinstance(retrieved,str):raise InputError('source.time','发布及读取时间需ISO文本')
        version=required(source,'version');available=source.get('available_at')
        if available is None and len(public)>10:available=public
        sid=identifier('S',[required(source,'url'),version,public])
        record=dict(id=sid,title=required(source,'title'),publisher=required(source,'publisher'),url=source['url'],
                    published_at=public,retrieved_at=retrieved,kind=required(source,'kind'),read_status=required(source,'read_status'),
                    origin_group=source.get('origin_group',source['publisher']),vintage=dict(id=version,available_at=available),
                    published_granularity='date' if len(public)==10 else 'timestamp')
        for key in ('published_timezone','availability_basis','identity_note','source_basis','official_response'):
            if key in source:record[key]=source[key]
        if document['schema_version']>=6:record['usage']='discovery' if item.get('kind')=='index' else 'content'
        eid=identifier('E',[sid,required(source,'locator'),required(source,'quote'),retrieved])
        evidence=dict(id=eid,source_id=sid,locator=source['locator'],quote=source['quote'],context=required(source,'context'),
                      read_method=required(source,'read_method'),retrieved_at=retrieved)
        put('sources',record);put('evidence',evidence)
        return sid,eid
    def claim(text,refs,key,kind='inference',status='hypothesis',limitations=None):
        dependencies=references(refs)
        if not dependencies['fact_ids'] and not dependencies['metric_ids']:raise InputError('refs','判断需要事实或数值基线')
        if document['schema_version']>=7:
            supported=set(dependencies['evidence_ids'])
            for group,ids in (('facts',dependencies['fact_ids']),('metrics',dependencies['metric_ids'])):
                supported.update(eid for item in document[group] if item['id'] in ids for eid in item.get('evidence_ids',[]))
            dependencies['evidence_ids']=list(dict.fromkeys(dependencies['evidence_ids']+sorted(supported)))
        cid=identifier('C',key)
        put('claims',dict(id=cid,text=text,kind=kind,status=status,**dependencies,assumptions=[],limitations=limitations or []))
        return cid,dependencies
    for item in batches:
        if not isinstance(item,dict):raise InputError('packet','需要对象')
        kind=required(item,'kind');task_id=required(item,'task');alias=item.get('alias',task_id)
        if not isinstance(alias,str) or not ID.fullmatch(alias):raise InputError('alias','需短ASCII别名')
        task_item=next((value for value in document['tasks'] if value['id']==task_id),None)
        if task_item is None:raise InputError('task','任务ID不属于本版型')
        bundle={};products=[];evidence_ids=[]
        if kind in ('event','market','company','index'):
            sid,eid=source_record(item,alias);bundle.update(source=sid,evidence=eid);evidence_ids.append(eid)
            aliases[alias]=bundle
            source=next(value for value in document['sources'] if value['id']==sid)
            if kind in ('event','company'):
                role=item.get('content_role','news');identity=copy.deepcopy(item.get('event_identity'))
                if identity is not None and not isinstance(identity,dict):raise InputError('event_identity','事件身份需对象')
                modern=document['schema_version']>=6
                if modern:
                    from editorial import identity as derive_identity
                    excerpt=next(value for value in document['evidence'] if value['id']==eid)
                    occurrence_ref=item.get('occurrence_evidence')
                    occurrence_verified=bool(occurrence_ref and item.get('verification_at'))
                    if occurrence_verified and occurrence_ref not in (eid,'current'):
                        raise InputError('occurrence_evidence','事项发生的确认用 current 引用本条实际已见原文证据')
                    event_status=derive_identity(source,excerpt,item.get('status','reported'),(identity or {}).get('status'),item.get('proposition','publication'),
                        occurrence_verified=occurrence_verified)
                    if item.get('proposition')=='occurrence' and event_status=='confirmed' and item.get('stage') in ('拟议','计划','待审批','待执行'):
                        raise InputError('stage','拟议或计划阶段不能确认事项已发生')
                    if (identity or {}).get('status') and identity['status']!=event_status:raise InputError('event_identity.status','事件状态与来源/事实命题不一致；请修正证据身份而非单独提高状态')
                    if (identity or {}).get('status')=='confirmed' and event_status!='confirmed':raise InputError('event_identity.status','证据不支持confirmed；确认报道存在不等于事项实绩')
                    if item.get('status')=='confirmed' and event_status!='confirmed':raise InputError('status','只有对应原文及明确命题才能确认')
                    item=dict(item)
                    item.setdefault('as_of',source['published_at'])
                    if role in ('background','baseline'):role='context' if role=='background' else 'financial_baseline'
                    if role in ('news','continuing_event') and not identity:
                        entity=required(item,'entity_id')
                        subject=item.get('announcement_type') or required(item,'subject')
                        release=item.get('announcement_id') or 'provisional-'+fingerprint([entity,subject,source['origin_group'],source['published_at'][:10]])[:16]
                        identity=dict(entity=entity,subject=subject,family=item.get('family','company_announcement' if kind=='company' else 'event'),release_id=release,version=source['vintage']['id'],attributes=item.get('attributes',{}),importance=item.get('importance',5),next_check=item.get('next_check') or item.get('interpretation',{}).get('risk_next') or item.get('conditions') or required(item,'unknowns'))
                    if identity:
                        identity.setdefault('importance',item.get('importance',5));identity.setdefault('next_check',item.get('next_check') or item.get('unknowns','核对来源后续回应'))
                        identity.setdefault('version',source['vintage']['id'])
                        from research import event_key
                        from archive import baseline_snapshot
                        prior_snapshot=baseline_snapshot(Path(state['state_root']),state['contract'])
                        known=document['research_events']+(prior_snapshot or {}).get('comparison_state',{}).get('events',[])
                        requested_aliases=identity.get('aliases',[])
                        matches={e['event_key']:e for e in known if e['event_key'] in requested_aliases}
                        if len(matches)>1:raise InputError('event_identity.aliases','别名同时指向多个事件，需明确对齐')
                        if matches:
                            aligned=next(iter(matches.values()))
                            if aligned['entity']!=identity['entity'] or aligned['family']!=identity['family']:raise InputError('event_identity.aliases','不能跨实体或事件族合并')
                            identity['canonical_key']=aligned['event_key']
                    if role in ('financial_baseline','context'):
                        item.setdefault('period',item['as_of'][:10])
                event_role=role in ('news','continuing_event')
                business_key=[task_id,alias]
                if document['schema_version']>=5:
                    if kind=='company' and not identity and role=='news':
                        identity=dict(entity=required(item,'entity_id'),subject=required(item,'announcement_type'),family='company_announcement',
                            release_id=required(item,'announcement_id'),version=source['vintage']['id'],attributes=item.get('attributes',dict(conditions=required(item,'conditions'),observations=fingerprint([{key:row.get(key) for key in ('entity_id','measure','value','unit','period','as_of','scope','segment')} for row in item.get('rows',[])]))),
                            importance=item.get('importance',5),next_check=item.get('next_check',item.get('conditions','核对公告执行条件')))
                    if event_role and not identity:raise InputError('event_identity','请补充事件身份：entity、subject、family、release_id、version、attributes、importance、next_check；不是标题或转载URL')
                    if not event_role:
                        business_key=[required(item,'entity_id'),required(item,'period'),source['vintage']['id'],role]
                    else:
                        business_key=[required(identity,field) for field in ('entity','subject','family','release_id')]
                        if modern:business_key=identity.get('canonical_key') or event_key(*business_key)
                statement=item.get('fact_text') or required(item,'text')
                if modern and state['contract'].get('research_workflow_version',0)>=3 and state['contract'].get('mode')!='teaching' and not item.get('fact_text'):
                    raise InputError('fact_text','本期消息需独立事实摘要；text仅作为读者表述，不自动升级为事实')
                fid=identifier('F',[business_key,sid,statement] if document['schema_version']>=7 else business_key)
                fact_kind=item.get('fact_kind','actual' if role=='baseline' else 'event')
                fact=dict(id=fid,statement=statement,source_ids=[sid],evidence_ids=[eid],status=item.get('status','reported'),core=True,
                          kind=fact_kind,as_of=required(item,'as_of'),available_at=source['vintage']['available_at'],locator=next(value['locator'] for value in document['evidence'] if value['id']==eid))
                for key in ('effective_at','event_at'):
                    if key in item:fact[key]=item[key]
                if modern:
                    if event_status=='pending':fact['status']='unverified'
                    fact['proposition']=item.get('proposition','publication')
                    if item.get('verification_at'):fact['verification_at']=item['verification_at']
                    if occurrence_verified:fact['occurrence_evidence_id']=eid
                put('facts',fact);bundle['fact']=fid
                cid,_=claim(statement,[alias],[fid,'fact'],'fact','supported' if fact['status'] not in ('unverified','conflicted') and (not modern or event_status not in ('lead','pending','conflicted')) else 'unknown')
                bundle['claim']=cid
                section='companies' if kind=='company' else required(item,'section')
                article=dict(id=identifier('AR',business_key),section=section,title=required(item,'title'),text=item.get('text',statement),
                             kind='fact',fact_ids=[fid],analysis_ids=[],claim_ids=[cid],priority=item.get('priority',2))
                previous_article=next((value for value in document['articles'] if value['id']==article['id']),None)
                if document['schema_version']>=7:
                    segment=dict(text=article['text'],fact_ids=[fid],claim_ids=[cid],source_ids=[sid])
                    earlier=copy.deepcopy(previous_article.get('segments',[])) if previous_article else []
                    is_correction=source.get('source_basis') in ('denial','correction') or item.get('novelty')=='correction'
                    if is_correction:
                        for earlier_segment in earlier:
                            if all(earlier_segment.get(key)==segment[key] for key in ('text','fact_ids','claim_ids','source_ids')):
                                earlier_segment.pop('superseded',None)
                            else:earlier_segment['superseded']=True
                    article['segments']=earlier+[segment] if segment not in earlier else earlier
                    if previous_article:
                        article['fact_ids']=list(dict.fromkeys(previous_article['fact_ids']+[fid]))
                        article['claim_ids']=list(dict.fromkeys(previous_article['claim_ids']+[cid]))
                        article['text']='；'.join(value['text'] for value in article['segments'] if not value.get('superseded'))
                if document['schema_version']>=5:
                    article.update(content_role=role,domain=item.get('domain','company' if kind=='company' else {'ai':'ai','market':'cn_market'}.get(section,'cn_official')),
                        primary_entity=item.get('entity_id') or (identity or {}).get('entity',''),display_title=item.get('display_title',article['title']),
                        disposition=item.get('disposition','retained'))
                    for field in ('interpretation','disposition_reason','novelty','stage','relevance','unknowns'):
                        if field in item:article[field]=item[field]
                    if role in ('baseline','financial_baseline'):article['baseline_key']=fingerprint(business_key)
                if kind=='company':
                    if not modern and (source['kind'] not in ('company','official') or source['read_status']=='unavailable'):raise InputError('company.source','公司公告需可读取的公司/交易所原文')
                    article['company']={key:required(item,key) for key in (('name','entity_id','announcement_type') if modern else ('name','ticker','entity_id','announcement_type','announcement_id','conditions','financial_baseline'))}
                    if modern:article['company'].update({key:item[key] for key in ('ticker','announcement_id','conditions','financial_baseline') if item.get(key)})
                put('articles',article);products.append(article['id']);bundle['article']=article['id']
                if identity and event_role:
                    from research import event_key, compare
                    from archive import baseline_snapshot
                    key=identity.get('canonical_key') or event_key(*(required(identity,field) for field in ('entity','subject','family','release_id')))
                    event=dict(event_key=key,entity=identity['entity'],subject=identity['subject'],family=identity['family'],
                               version=required(identity,'version'),attributes=identity.get('attributes',{}),status=event_status if modern else identity.get('status','confirmed'),
                               importance=required(identity,'importance'),source_ids=[sid],evidence_ids=[eid],claim_ids=[cid],aliases=identity.get('aliases',[]) if modern else [],
                               event_at=item.get('event_at'),effective_at=item.get('effective_at'),published_at=source['published_at'],updated_at=identity.get('updated_at'),
                               first_seen_at=source['retrieved_at'],last_verified_at=item.get('verification_at') if modern and event_status in ('confirmed','corrected','withdrawn') else None if modern else source['retrieved_at'],last_reported_at=None,
                               next_check=required(identity,'next_check'),reported=article.get('disposition','retained')=='retained',report_ref=dict(section='article',item_id=article['id']))
                    if modern:
                        event.update(proposition=item.get('proposition','publication'),stage=item.get('stage','未说明阶段'))
                        prior_event=next((e for e in document['research_events'] if e['event_key']==key),None)
                        if prior_event:
                            event['first_seen_at']=prior_event['first_seen_at']
                            if document['schema_version']>=7:
                                for field in ('source_ids','evidence_ids','claim_ids'):
                                    event[field]=list(dict.fromkeys(prior_event[field]+event[field]))
                        event['aliases']=[a for a in event['aliases'] if a!=key]
                        raw_key=event_key(*(required(identity,field) for field in ('entity','subject','family','release_id')))
                        if raw_key!=key:event['aliases'].append(raw_key)
                    if document['schema_version']>=5:article['event_key']=key
                    if not event['reported']:
                        event.pop('report_ref',None)
                        event.update(reporting_disposition='excluded' if article['disposition']=='excluded' else 'retained_pending',
                            reporting_reason=required(item,'disposition_reason'))
                    baseline=baseline_snapshot(Path(state['state_root']),state['contract'])
                    previous=baseline.get('comparison_state') if baseline else None
                    if state['contract'].get('edition')=='intraday':
                        detected=compare([event],previous,state['contract']['initial_cutoff'])
                        document['articles']=[value for value in document['articles'] if value['id']!=article['id']]
                        if key in detected:
                            change=required(item,'change')
                            record=dict(event_key=key,kind=detected[key],text=statement,why=required(change,'why'),impact=required(change,'impact'),claim_ids=[cid],next_observation=event['next_check'])
                            document['changes']=[value for value in document['changes'] if value['event_key']!=key]+[record]
                            event['report_ref']=dict(section='change',item_id=key)
                        else:
                            event.update(reported=False)
                            event.pop('report_ref',None)
                    document['research_events']=[value for value in document['research_events'] if value['event_key']!=key]+[event]
            rows=item.get('rows',[])
            if kind=='market' and not rows:raise InputError('rows','市场packet需要数值行')
            if not isinstance(rows,list):raise InputError('rows','需要数组')
            for row in rows:
                row_alias=required(row,'alias');mid=identifier('M',[task_id,alias,row_alias])
                row_source=aliases.get(row['source']) if 'source' in row else bundle
                if not row_source or not {'source','evidence'}<=set(row_source):raise InputError('rows.source','未知数值来源别名；不能回退为其他来源')
                row_sid=row_source['source'];row_eid=row_source['evidence']
                row_public=next(value['vintage']['available_at'] for value in document['sources'] if value['id']==row_sid)
                if 'value' not in row:raise InputError('value','必须显式提供数值或null；不补零')
                metric=dict(id=mid,label=required(row,'label'),op='observed',value=row['value'],unit=required(row,'unit'),
                            as_of=required(row,'as_of'),available_at=row.get('available_at',row_public),kind=row.get('kind','actual'),
                            source_ids=[row_sid],evidence_ids=[row_eid],scope=required(row,'scope'),
                            dimensions=dict(entity_id=required(row,'entity_id'),currency=required(row,'currency'),scale=required(row,'scale'),
                                            period=required(row,'period'),segment=row.get('segment','all'),measure=required(row,'measure')))
                for field in ('chart_group','chart_takeaway','signed','metric_kind','domain','frequency','price_basis','return_type','universe_id','universe_version','category','precision','approximate','support','session','conversion','value_identity'):
                    if field in row:metric[field]=row[field]
                if document['schema_version']>=5:
                    metric.setdefault('metric_kind',row['measure'])
                    metric.setdefault('domain',item.get('domain','company' if kind=='company' else 'overseas' if item.get('section')=='macro' else 'cn_market'))
                    metric.setdefault('frequency','period' if metric['dimensions']['period']!=metric['as_of'][:10] else 'daily')
                    metric.setdefault('price_basis','not_applicable' if row['measure'] not in ('price','close','index_change','return') else 'unspecified')
                    metric.setdefault('return_type','unspecified' if row['measure'] in ('index_change','return') else 'not_applicable')
                    metric.setdefault('universe_id',row['entity_id']);metric.setdefault('universe_version','unspecified')
                    source_version=next(value['vintage']['id'] for value in document['sources'] if value['id']==row_sid)
                    mid=identifier('M',[metric['dimensions'],metric['as_of'],metric['unit'],metric['price_basis'],metric['universe_id'],metric.get('category')]
                        if document['schema_version']>=7 else [metric['dimensions'],metric['as_of'],metric['unit'],metric['price_basis'],metric['universe_id'],metric.get('category'),source_version])
                    metric['id']=mid
                    from research import metric_support
                    if not metric.get('support'):
                        excerpt=next(value for value in document['evidence'] if value['id']==row_eid)
                        metric['support']=dict(status='matched' if document['schema_version']<6 and metric_support(metric,{row_eid:excerpt}) else 'needs_review',locator=excerpt['locator'],quote=excerpt['quote'])
                    if document['schema_version']>=7 and metric['support']['status']=='reviewed':
                        if not metric['support'].get('note') or len(metric['support']['note'].strip())<8:
                            raise InputError('rows.support.note','复核需说明表头/数据行的主体、期间、单位或换算依据')
                        excerpt=next(value for value in document['evidence'] if value['id']==row_eid)
                        metric['support']['audit']=dict(value=metric['value'],unit=metric['unit'],
                            entity_id=metric['dimensions']['entity_id'],period=metric['dimensions']['period'],
                            measure=metric['dimensions']['measure'],evidence_hash=fingerprint(excerpt))
                    if document['schema_version']>=6 and metric.get('conversion'):
                        metric['support']['status']='reviewed'
                        metric['support']['note']='程序按原单位、主体、期间、指标及转换链核对'
                if document['schema_version']>=6:
                    origin=next(value for value in document['sources'] if value['id']==row_sid)
                    metric.setdefault('value_identity','conditional' if origin.get('source_basis')=='anonymous' or item.get('status')=='unverified' else 'reported' if origin['kind'] in ('media','public_account') else 'official')
                previous_metric=next((value for value in document['metrics'] if value['id']==mid),None)
                if previous_metric and document['schema_version']>=7 and previous_metric!=metric:
                    if previous_metric['value']!=metric['value']:
                        if row.get('update')!='correction' or not row.get('correction_reason'):
                            raise InputError('rows.update','同一观测值冲突；明确 correction 与来源更正理由，或另存待核冲突')
                        old_sources=[value for value in document['sources'] if value['id'] in previous_metric['source_ids']]
                        new_source=next(value for value in document['sources'] if value['id']==row_sid)
                        if new_source.get('source_basis')!='correction' or not any(
                            value['publisher']==new_source['publisher'] or value['url']==new_source['url'] for value in old_sources):
                            raise InputError('rows.update','冲突来源不能覆盖既有观测；仅原发布者或原链接的明确更正可更新，独立分歧保留待核')
                        document.setdefault('metric_revisions',[]).append(dict(metric_id=mid,previous=copy.deepcopy(previous_metric),
                            current=copy.deepcopy(metric),reason=row['correction_reason'],recorded_at=stamp()))
                    elif row.get('update')!='correction':
                        metric=previous_metric
                put('metrics',metric);products.append(mid);evidence_ids.append(row_eid)
                aliases[row_alias]=dict(metric=mid,source=row_sid,evidence=row_eid)
            if kind=='company':article['company']['metric_ids']=[ident for ident in products if any(value['id']==ident for value in document['metrics'])]
            for calculation in item.get('calculations',[]):
                deps=references(required(calculation,'inputs'));inputs=deps['metric_ids']
                if len(inputs)!=2:raise InputError('calculations.inputs','当前小输入支持两个同实体数值的差值、增长或规模比')
                first=next(value for value in document['metrics'] if value['id']==inputs[0])
                second=next(value for value in document['metrics'] if value['id']==inputs[1])
                op=required(calculation,'op')
                if op not in ('pair_difference','growth','ratio'):raise InputError('op','差值、增长或规模比；其他计算使用既有merge协议')
                alias_key=required(calculation,'alias');mid=identifier('M',[alias,alias_key])
                metric=dict(id=mid,label=required(calculation,'label'),op=op,unit=required(calculation,'unit'),
                            dimensions=dict(second['dimensions']),comparison_basis=required(calculation,'comparison_basis'),
                            comparison_evidence_ids=deps['evidence_ids'],scope=required(calculation,'scope'))
                if op=='pair_difference':metric.update(from_metric=inputs[0],to_metric=inputs[1])
                else:metric['inputs']=inputs
                if op in ('ratio','growth'):metric['dimensions'].update(currency='none',scale=1)
                if calculation.get('period'):metric['dimensions']['period']=calculation['period']
                metric['formula']=('后值 − 前值' if op=='pair_difference' else '分子 / 分母 × 100%' if op=='ratio' and metric['unit']=='%' else '分子 / 分母' if op=='ratio' else '(后值 / 前值 − 1) × 100%')+'；'+metric['comparison_basis']
                if calculation.get('scale_reference'):
                    if op!='ratio':raise InputError('scale_reference','规模参考仅适用于ratio')
                    metric['comparison_kind']='scale_reference'
                if document['schema_version']>=6:
                    from editorial import metric_identity
                    states=[metric_identity(document,operand) for operand in (first,second)]
                    metric['value_identity']='conditional' if 'conditional' in states else 'reported' if 'reported' in states else 'official'
                put('metrics',metric);products.append(mid);aliases[alias_key]=dict(metric=mid,evidence=eid,source=sid)
            if kind=='market' and item.get('text'):
                refs=[row['alias'] for row in rows];cid,dependencies=claim(item['text'],refs,[sorted(x for x in products if x.startswith('M_')),'interpretation'] if document['schema_version']>=7 else [alias,'interpretation'])
                article=dict(id=identifier('AR',[task_id,sorted(x for x in products if x.startswith('M_'))] if document['schema_version']>=7 else [task_id,alias]),section=item.get('section','market'),title=required(item,'title'),text=item['text'],
                             kind='analysis',fact_ids=dependencies['fact_ids'],analysis_ids=[],claim_ids=[cid],priority=2)
                put('articles',article);bundle.update(article=article['id'],claim=cid)
        elif kind=='window':
            ids=required(item,'obligations');status=required(item,'status')
            refs=references(item.get('refs',[]));evidence_ids=refs['evidence_ids']
            source_ids=list(dict.fromkeys(value['source_id'] for value in document['evidence'] if value['id'] in evidence_ids))
            obligations={value['id']:value for value in state['contract']['coverage_obligations']}
            for oid in ids:
                if oid not in obligations:raise InputError('obligations','未知覆盖义务：'+str(oid))
                cov=dict(id=identifier('W',[alias,oid,item]),name=obligations[oid]['name'],url=required(item,'url'),status=status,
                         checked_at=required(item,'checked_at'),note=required(item,'note'),source_ids=source_ids,obligation_ids=[oid],
                         method=required(item,'method'),mapping_evidence_ids=evidence_ids,window_start=required(item,'window_start'),window_end=required(item,'window_end'),
                         content_scope=required(item,'content_scope'))
                for field in ('direct_access','access_failure','fallback_method','blind_spot','index_scan'):
                    if field in item:cov[field]=item[field]
                if document['schema_version']>=6 and cov.get('direct_access')=='available' and cov.get('index_scan',{}).get('complete') is False:cov['status']='partial'
                document['coverage'].append(cov);products.append(cov['id'])
        elif kind=='thesis':
            aid=identifier('A',[state['contract'].get('research_attempt',''),alias]);blocks=required(item,'blocks')
            focused=document['schema_version']>=7 and set(blocks)=={'judgment','mechanism','alternative','support','invalidation'}
            fields=('conclusion','novelty','earnings','pricing','expectation','alternative','support','invalidation','priority_reason','materiality')
            block_names={'conclusion':'judgment','materiality':'mechanism','alternative':'alternative','support':'support','invalidation':'invalidation'} if focused else {field:field for field in fields}
            analysis=dict(id=aid,format='focused' if focused else 'compact',sector=required(item,'sector'),title=required(item,'title'),status=item.get('status','supported'),
                          theme_id=identifier('TH',required(item,'theme')),thesis_id=identifier('THESIS',[state['contract'].get('research_attempt',''),required(item,'thesis')]),
                          version=item.get('version',1),entity_ids=item.get('entity_ids',[]),priority=item.get('priority',1),
                          review_at=required(item,'review_at'),expires_at=required(item,'expires_at'),assumptions=item.get('assumptions',[]),
                          gaps=item.get('gaps',[]),limitations=item.get('limitations',[]),leaders=item.get('leaders',[]),mechanism=item.get('mechanism',[]),
                          field_claims={},fact_ids=[],horizons={})
            if focused:analysis['priority_reason']=required(item,'why_this')
            for field in (block_names if focused else fields):
                block=required(blocks,block_names[field]);text=required(block,'text')
                cid,deps=claim(text,required(block,'refs'),[alias,field],status=block.get('status','hypothesis'),limitations=block.get('limitations'))
                analysis[field]=text;analysis['field_claims'][field]=[cid];analysis['fact_ids']+=deps['fact_ids'];evidence_ids+=deps['evidence_ids']
            for horizon in ('intraday','short','medium'):
                data=required(required(item,'horizons'),horizon)
                cid,deps=claim(required(data,'conclusion'),required(data,'refs'),[alias,horizon])
                analysis['horizons'][horizon]={key:required(data,key) for key in ('conclusion','direction','next_observation','review_at','confidence')}
                analysis['horizons'][horizon]['claim_ids']=[cid]
                if data.get('uncertainty'):analysis['horizons'][horizon]['uncertainty']=data['uncertainty']
                evidence_ids+=deps['evidence_ids']
            analysis['fact_ids']=list(dict.fromkeys(analysis['fact_ids']))
            for field in ('update','dynamic_rules'):
                if field in item:analysis[field]=item[field]
            put('analyses',analysis);bundle.update(analysis=aid,claim=analysis['field_claims']['conclusion'][0]);products.append(aid)
            if focused and item.get('observe'):
                observation=item['observe'];action_id=identifier('AC',alias)
                trigger=required(observation,'trigger')
                record=dict(id=action_id,analysis_id=aid,claim_ids=analysis['field_claims']['support']+analysis['field_claims']['invalidation'],
                    priority=analysis['priority'],fact_ids=analysis['fact_ids'],when=trigger,
                    trigger=trigger,expires_at=analysis['expires_at'],target=required(observation,'target'),
                    baseline=required(observation,'baseline'),support=analysis['support'],
                    invalidation=analysis['invalidation'],implication=required(observation,'decision_if'),
                    rule_basis='来源公布或触发条件出现后复核；不预设未公告日期',horizon='unconfirmed')
                put('actions',record);products.append(action_id)
            elif item.get('action'):
                action=item['action'];action_id=identifier('AC',alias)
                record={key:required(action,key) for key in ('when','observe_at','expires_at','target','baseline','support','invalidation','implication','rule_basis')}
                record.update(id=action_id,analysis_id=aid,claim_ids=analysis['field_claims']['support']+analysis['field_claims']['invalidation'],priority=analysis['priority'],fact_ids=analysis['fact_ids'])
                for field in ('calendar_id','session_offset','horizon','dynamic_rule'):
                    if field in action:record[field]=action[field]
                put('actions',record);products.append(action_id)
        elif kind=='observation':
            cid,deps=claim(required(item,'divergence'),required(item,'refs'),[alias,'observation'])
            record={key:required(item,key) for key in ('title','expectation','divergence','mechanism','materiality','opposition','test')}
            record.update(id=identifier('O',alias),kind=item.get('observation_kind','watch'),fact_ids=deps['fact_ids'],claim_ids=[cid],consensus_fact_ids=references(item.get('consensus_refs',[]))['fact_ids'])
            put('observations',record);products.append(record['id']);evidence_ids=deps['evidence_ids'];bundle['claim']=cid
        elif kind=='review':
            reviewed=required(item,'reviewed');checked={group:[] for group in ('facts','claims','analyses','evidence')}
            if 'summary' in item:document['summary']=[]
            if item.get('headline'):document['meta']['title']=item['headline']
            for value in reviewed:
                bundle_value=aliases.get(value)
                for group,singular in (('facts','fact'),('claims','claim'),('analyses','analysis'),('evidence','evidence')):
                    ident=bundle_value.get(singular) if bundle_value else value
                    if ident and any(row['id']==ident for row in document[group]):checked[group].append(ident)
            for summary in item.get('summary',[]):
                cid,deps=claim(required(summary,'text'),required(summary,'refs'),['summary',summary['text']])
                checked['claims'].append(cid)
                record=dict(text=summary['text'],fact_ids=deps['fact_ids'],analysis_ids=[],claim_ids=[cid])
                for field in ('change','priority_object','key_risk'):
                    if field in summary:record[field]=summary[field]
                document['summary'].append(record)
            document['review']=dict(status=item.get('status','self_review'),reviewer=required(item,'reviewer'),method=required(item,'method'),
                                    checked_fact_ids=list(dict.fromkeys(checked['facts'])),checked_claim_ids=list(dict.fromkeys(checked['claims'])),
                                    checked_analysis_ids=list(dict.fromkeys(checked['analyses'])),evidence_ids=list(dict.fromkeys(checked['evidence'])),issues=item.get('issues',[]))
            evidence_ids=checked['evidence']
            if 'featured' in item:document['meta']['featured_metrics']=[aliases[value]['metric'] for value in item['featured']]
            if 'charts' in item:
                document['charts']=item['charts']
            for field in ('observation_review','selection_review','prior_reviews'):
                if field in item:document[field]=item[field]
        elif kind!='task':raise InputError('kind','允许 event / market / company / index / thesis / window / review / task')
        if bundle:aliases[alias]={**aliases.get(alias,{}),**bundle}
        task_item['product_ids']=list(dict.fromkeys(task_item['product_ids']+products))
        task_item['evidence_ids']=list(dict.fromkeys(task_item['evidence_ids']+evidence_ids))
        if item.get('attempt'):
            attempt=item['attempt']
            attempt=dict(attempt,evidence_ids=list(dict.fromkeys(attempt.get('evidence_ids',[])+evidence_ids)))
            if attempt not in task_item['attempts']:task_item['attempts'].append(attempt)
        result=item.get('result',{})
        if result.get('status')=='budget_stop':
            from workflow import remaining
            limits=remaining(state)
            if not limits['timeout_reached'] and limits['queries_remaining']>0:raise InputError('result.status','可见预算尚未到限；继续核心研究或记录真实来源受阻')
        for field in ('status','current_conclusion','next','stop_reason','stop_category'):
            if field in result:task_item[field]=result[field]
        if not result and task_item['status']=='planned':task_item['status']='running'
        receipts.append(dict(alias=alias,ids=bundle,products=products))
    document['coverage']=coverage_view(document['coverage'],document['meta']['window_start'],document['meta']['cutoff'])
    errors=check(document)
    if errors:raise InputError(errors[0]['path'],errors[0]['message'])
    pack=load(work/'evidence-pack.json') if state.get('evidence_sha256') else None
    if pack is not None and digest(work/'evidence-pack.json')!=state['evidence_sha256']:raise InputError('evidence_pack','固定资料包哈希改变')
    checks=validate_document(Path(state['state_root']),materialize(document,work),state['contract'],pack)
    if checks['errors']:raise InputError(checks['errors'][0]['path'],checks['errors'][0]['message'])
    after=fingerprint(document)
    if before!=after:save(work/'briefing.json',document)
    state['tasks']=copy.deepcopy(document['tasks'])
    state['telemetry']['events'].append(dict(kind='import',stage='serialization',wall_ms=(time.perf_counter()-started)*1000,recorded_at=stamp()))
    save(work/'run-state.json',state)
    progress=task_progress(document,state['contract'])
    result=dict(status='unchanged' if before==after else 'submitted',receipts=receipts,sha256=after,
                next_actions=progress['next_actions'],remaining=__import__('workflow').remaining(state),review_needed=dict(facts=[value['id'] for value in document['facts'] if value['id'] not in document['review']['checked_fact_ids']],
                claims=[value['id'] for value in document['claims'] if value['id'] not in document['review']['checked_claim_ids']],
                analyses=[value['id'] for value in document['analyses'] if value['id'] not in document['review']['checked_analysis_ids']]))
    if document['schema_version']>=7:
        result['review_needed_counts']={key:len(value) for key,value in result['review_needed'].items()}
        result['review_needed']={key:value[:3] for key,value in result['review_needed'].items()}
    return result


def import_series(work,input_path,metadata_path):
    started=time.perf_counter();meta=load(metadata_path);raw=Path(input_path).read_bytes()
    if not isinstance(meta,dict):raise InputError('series.metadata','元数据必须为对象')
    if Path(input_path).suffix.lower()=='.csv':
        reader=csv.DictReader(StringIO(raw.decode('utf-8-sig')))
        if not reader.fieldnames or not {'date','value','available_at'}<=set(reader.fieldnames):
            raise ValueError('CSV需要date,value,available_at；空可得时间不等于已公开')
        points=[]
        for row in reader:
            if row['value'].strip():
                value=loads(row['value'])
                if not num(value):raise ValueError('CSV value需有限数值，bool无效')
            else:value=None
            point=dict(date=row['date'],value=value,available_at=row['available_at'] or None,
                       status=row.get('status') or ('missing' if value is None else 'traded'))
            if row.get('session_id'):point['session_id']=row['session_id']
            points.append(point)
    else:
        points=loads(raw.decode('utf-8-sig'))
        if not isinstance(points,list):raise ValueError('JSON序列导入需观测数组')
    if len(points)>200000:raise ValueError('单次导入超过200000点，请按对象分批')
    item=dict(meta,observations=points)
    if 'id' not in item:item['id']='SE_'+fingerprint(meta)[:16]
    errors=check(item,ARRAYS['series'],'series')
    if errors:raise ValueError(canonical(errors[:4]))
    # Retain both authorized original bytes and normalized, addressable points.
    original=put_artifact(work,raw,'.csv' if Path(input_path).suffix.lower()=='.csv' else '.json')
    normalized=put_artifact(work,canonical(points).encode('utf-8'),'.json')
    item.update(observations=[],artifact=normalized)
    result=merge(work,{'series':[item]})
    provenance=Path(work)/'imports'/ (fingerprint(dict(original=original,metadata=meta))+'.json')
    if not provenance.exists():save(provenance,dict(original=original,normalized=normalized,metadata=meta,
        imported_at=stamp(),record_count=len(points),wall_ms=(time.perf_counter()-started)*1000),exclusive=True)
    return dict(**result,series_id=item['id'],record_count=len(points),original=original,normalized=normalized)


def inspect(work,group,ident=None,offset=0,limit=10):
    d=load(Path(work)/'briefing.json')
    if group not in d or not isinstance(d[group],list):raise ValueError('仅可定向查看已知集合')
    rows=d[group]
    if ident:
        rows=[x for x in rows if isinstance(x,dict) and x.get('id')==ident]
    selected=rows[max(0,offset):max(0,offset)+min(30,max(1,limit))]
    result=[]
    for x in selected:
        if group=='series':
            x={k:v for k,v in x.items() if k!='observations'}|{'inline_points':len(x['observations'])}
        result.append(x)
    return dict(group=group,total=len(rows),items=result,next_offset=offset+len(selected) if offset+len(selected)<len(rows) else None)


def compute(work,state,ids=None):
    started=time.perf_counter();d=materialize(load(Path(work)/'briefing.json'),work)
    pack=load(Path(work)/'evidence-pack.json') if state.get('evidence_sha256') else None
    if pack is not None and digest(Path(work)/'evidence-pack.json')!=state['evidence_sha256']:
        raise InputError('evidence_pack','固定资料包哈希发生变化；保留原运行','version_conflict')
    from archive import validate_document
    r=validate_document(Path(state['state_root']),d,state['contract'],pack)
    from capabilities import enforce_delivery
    enforce_delivery(r,d,state.get('preflight'));save(Path(work)/'checks.json',r)
    available=r['metric_details'];selected=ids or list(available)[:20]
    from render import display_plan
    plan=display_plan(d,r) if not r['errors'] else None
    return dict(errors=r['errors'][:6],error_count=len(r['errors']),warning_count=len(r['warnings']),
                metrics={x:available[x] for x in selected if x in available},delivery=r.get('delivery'),
                display_plan=plan,research_completion=r.get('research_completion'),
                wall_ms=(time.perf_counter()-started)*1000,total_metrics=len(available),
                note='计算结果和资料质量已落盘；不代表引文语义或因果验证。')


def record(work,state,event):
    allowed={'query','open','cache','import','compute','render','stage','recovery','usage'}
    batch=event.get('events',[event]) if isinstance(event,dict) else None
    if not isinstance(batch,list) or not 1<=len(batch)<=200:raise InputError('events','需要1—200条真实调用记录')
    usage_keys=('input_tokens','output_tokens','cached_tokens','reasoning_tokens','cost')
    records=[];usage=state['telemetry']['usage']
    for item in batch:
        if not isinstance(item,dict) or item.get('kind') not in allowed or not item.get('stage'):raise InputError('event','记录需对象、有效kind与stage')
        for key in ('wall_ms',*usage_keys):
            if item.get(key) is not None and (not num(item[key]) or item[key]<0):raise ValueError('无效实测开销: '+key)
        for key in usage_keys[:-1]:
            if item.get(key) is not None and type(item[key]) is not int:raise ValueError('实测token数量需整数或null')
        if any(item.get(key) is not None for key in usage_keys) and item.get('measurement')!='host_reported':raise ValueError('token/成本只能记录宿主实际usage；字符数与估算单列')
        logged=dict(item,recorded_at=stamp())
        for key in usage_keys:logged.setdefault(key,None)
        records.append(logged)
        if item['kind']=='usage':usage={key:logged[key] for key in usage_keys}|{'measurement':'host_reported','currency':item.get('currency'),'scope':item.get('scope','unknown')}
    state['telemetry']['events'].extend(records);state['telemetry']['usage']=usage
    save(Path(work)/'run-state.json',state)
    return dict(recorded=True,events=len(state['telemetry']['events']),usage=state['telemetry']['usage'])


def task(work,state,item):
    if load(Path(work)/'briefing.json').get('schema_version',0)>=4:
        return submit(work,state,dict(kind='task',task=item.get('id'),result={key:item[key] for key in ('status','current_conclusion','next','stop_reason','stop_category') if key in item},**({'attempt':item['attempt']} if item.get('attempt') else {})))
    required={'id','question','priority','target_evidence','current_conclusion','query_or_url','result','next','stop_reason','status'}
    if not isinstance(item,dict) or not required<=set(item) or not isinstance(item['id'],str) or not ID.fullmatch(item['id']):raise InputError('task','研究任务缺少问题、目标证据、结果或停止原因')
    if item['status'] not in ('planned','running','done','stopped') or type(item['priority']) is not int or not 1<=item['priority']<=3:raise ValueError('任务状态/优先级无效')
    old=next((x for x in state['tasks'] if x['id']==item['id']),None)
    if old==item:return dict(status='unchanged')
    if old:state['tasks'].remove(old)
    state['tasks'].append(item);state['next']=item['next']
    save(Path(work)/'run-state.json',state)
    return dict(status='recorded',next=item['next'])
