"""Versioned report schema; old v2 publications retain their original contract."""
import copy
from common import ID, num, safe_url

def arr(item): return {'type':'array', 'items':item}
def obj(required, optional=None): return {'type':'object','required':required,'optional':optional or {}}
def enum(*values): return {'type':'enum','values':list(values)}
def nullable(spec): return {'type':'nullable','item':spec}
def mapping(spec): return {'type':'mapping','values':spec}
TEXT={'type':'text'}
STRING={'type':'string'}
BOOL={'type':'bool'}
NUMBER={'type':'number'}
INT={'type':'integer'}
IDENT={'type':'id'}
URL={'type':'url'}
IDS=arr(IDENT)
TEXTS=arr(TEXT)
NULLTEXT=nullable(TEXT)
UNIT=obj(dict(entity_id=IDENT,currency=TEXT,scale=NUMBER,period=TEXT,segment=TEXT,measure=TEXT),
         dict(dimensions=mapping(INT)))
GAP=obj(dict(message=TEXT,impact=TEXT,critical=BOOL),dict(claim_ids=IDS,attempt_ids=IDS))
VINTAGE=obj(dict(id=TEXT,available_at=NULLTEXT))
ARTIFACT=obj(dict(path=TEXT,sha256=TEXT,format=enum('json','csv','text')))
ISSUE=obj(dict(severity=enum('blocking','warning'),message=TEXT,resolved=BOOL),dict(resolution=TEXT,remaining_limitation=TEXT))
EVIDENCE=obj(dict(id=IDENT,source_id=IDENT,locator=TEXT,quote=TEXT,context=TEXT,
                  read_method=enum('original','cached','search_summary'),retrieved_at=TEXT),dict(artifact=ARTIFACT))
SOURCE=obj(dict(id=IDENT,title=TEXT,publisher=TEXT,url=URL,published_at=TEXT,retrieved_at=TEXT,
                kind=enum('official','company','media','data'),read_status=enum('full','partial','unavailable'),
                origin_group=TEXT,vintage=VINTAGE),dict(published_timezone=TEXT,accessed_at=TEXT,
                verification=obj(dict(status=enum('verified','partial','failed','not_attempted'),note=TEXT),dict(checked_at=TEXT,url=URL))))
FACT=obj(dict(id=IDENT,statement=TEXT,source_ids=IDS,evidence_ids=IDS,status=enum('confirmed','reported','conflicted','unverified'),
              core=BOOL,kind=enum('actual','forecast','event'),as_of=TEXT,available_at=NULLTEXT,locator=TEXT),
              dict(event_at=TEXT,effective_at=TEXT,observation_period=obj(dict(start=TEXT,end=TEXT))))
POINT=obj(dict(date=TEXT,value=nullable(NUMBER),available_at=NULLTEXT,status=enum('traded','missing','suspended')),
          dict(session_id=TEXT,vintage=VINTAGE))
SESSION=obj(dict(date=TEXT,close_at=TEXT))
CALENDAR=obj(dict(id=IDENT,market=TEXT,timezone=TEXT,version=TEXT,source_ids=IDS,evidence_ids=IDS,
                  valid_from=TEXT,valid_to=TEXT,complete=BOOL,sessions=arr(SESSION)),dict(synthetic=BOOL))
RULE=obj(dict(kind=enum('session_close'),delay_seconds=INT,evidence_ids=IDS))
SERIES=obj(dict(id=IDENT,label=TEXT,unit=TEXT,basis=enum('price','turnover','yield_percent','shares','count','level'),
                market=TEXT,provider=TEXT,adjustment=TEXT,classification=TEXT,source_ids=IDS,evidence_ids=IDS,
                entity_id=IDENT,frequency=enum('daily','weekly','monthly','irregular'),calendar_id=NULLTEXT,
                completeness=enum('complete','partial','unknown'),scope=TEXT,roll_policy=TEXT,
                vintage=VINTAGE,observations=arr(POINT)),dict(artifact=ARTIFACT,release_rule=RULE,usage=enum('current','background'),freshness_note=TEXT))
METRIC=obj(dict(id=IDENT,label=TEXT,op=enum('observed','return','excess_return','volume_ratio','bp_change','difference',
                'pair_difference','ratio','growth','product','sum','sensitivity'),unit=TEXT,dimensions=UNIT),
           dict(value=nullable(NUMBER),as_of=TEXT,available_at=NULLTEXT,kind=enum('actual','forecast'),
                source_ids=IDS,evidence_ids=IDS,series_id=IDENT,benchmark_id=IDENT,n=INT,
                window_basis=enum('trading_sessions','observations'),signed=BOOL,from_metric=IDENT,to_metric=IDENT,
                inputs=IDS,comparison_basis=TEXT,comparison_evidence_ids=IDS,mapping_id=IDENT,shock=NUMBER))
CLAIM=obj(dict(id=IDENT,text=TEXT,kind=enum('fact','inference','scenario'),status=enum('supported','hypothesis','unknown'),
               fact_ids=IDS,metric_ids=IDS,assumptions=TEXTS,limitations=arr(GAP)),dict(evidence_ids=IDS))
HORIZON=obj(dict(conclusion=TEXT,direction=enum('positive','negative','mixed','neutral','unknown'),claim_ids=IDS,
                 earnings_channel=TEXT,valuation_channel=TEXT,base_case=TEXT,counter_case=TEXT,
                 next_observation=TEXT,review_at=TEXT,confidence=enum('high','medium','low','unknown')))
LEADER=obj(dict(name=TEXT,ticker=TEXT,market=TEXT,entity_id=IDENT,role=enum('industry','trading','both','representative','watch'),
                exposure=TEXT,realization=TEXT,performance=TEXT,catalyst=TEXT,risk=TEXT,fact_ids=IDS,
                claim_ids=IDS,role_evidence=obj({},dict(industry=IDS,trading=IDS))),
           dict(series_id=IDENT,industry_basis=obj(dict(scope=TEXT,period=TEXT,comparison=TEXT,fact_ids=IDS))))
ANALYSIS_TEXT=('sector','title','conclusion','horizon','novelty','earnings','distribution','pricing','expectation',
               'alternative','counterevidence','support','invalidation')
ANALYSIS=obj(dict(id=IDENT,**{k:TEXT for k in ANALYSIS_TEXT},status=enum('supported','watch'),fact_ids=IDS,
                  theme_id=IDENT,thesis_id=IDENT,version=INT,entity_ids=IDS,priority=INT,priority_reason=TEXT,
                  materiality=TEXT,assumptions=TEXTS,review_at=TEXT,expires_at=TEXT,
                  field_claims=mapping(IDS),horizons=obj(dict(intraday=HORIZON,short=HORIZON,medium=HORIZON)),
                  gaps=TEXTS,limitations=arr(GAP),leaders=arr(LEADER),
                  mechanism=arr(obj({'from':TEXT,'to':TEXT,'basis':enum('fact','assumption'),'fact_ids':IDS,'assumption':STRING},dict(claim_ids=IDS)))),
             dict(update=obj(dict(status=enum('new','maintained','supported','weakened','refuted','retired'),previous_version=INT,
                                   new_evidence_ids=IDS,reason=TEXT))))
SUMMARY=obj(dict(text=TEXT,fact_ids=IDS,analysis_ids=IDS,claim_ids=IDS),dict(change=TEXT,priority_object=TEXT,key_risk=TEXT))
ARTICLE=obj(dict(id=IDENT,section=enum('news','ai','market','macro','companies'),title=TEXT,text=TEXT,kind=enum('fact','analysis','watch'),
                 fact_ids=IDS,analysis_ids=IDS,claim_ids=IDS,priority=INT))
ACTION=obj(dict(id=IDENT,analysis_id=IDENT,claim_ids=IDS,priority=INT,when=TEXT,observe_at=TEXT,
                expires_at=TEXT,target=TEXT,baseline=TEXT,support=TEXT,invalidation=TEXT,implication=TEXT,
                rule_basis=TEXT,fact_ids=IDS),dict(calendar_id=IDENT,session_offset=INT))
OBSERVATION=obj(dict(id=IDENT,kind=enum('contrarian','watch'),title=TEXT,expectation=TEXT,consensus_fact_ids=IDS,
                     divergence=TEXT,mechanism=TEXT,materiality=TEXT,opposition=TEXT,test=TEXT,fact_ids=IDS,claim_ids=IDS))
EVENT=obj(dict(id=IDENT,at=TEXT,label=TEXT,status=enum('confirmed','expected'),detail=TEXT,fact_ids=IDS))
CHART=obj(dict(id=IDENT,type=enum('breadth','bars','heatmap','scatter','line','mechanism','timeline'),title=TEXT,takeaway=TEXT,note=TEXT,
               placement=enum('overview','theme','news','ai','market','macro')),dict(analysis_id=IDENT,scope=TEXT,classification=TEXT,
               items=arr(obj(dict(label=TEXT,metric_id=IDENT),dict(category=enum('up','flat','down')))),
               columns=TEXTS,rows=arr(obj(dict(label=TEXT,metric_ids=IDS))),
               points=arr(obj(dict(label=TEXT,x_metric=IDENT,y_metric=IDENT),dict(mapping_id=IDENT))),
               series_ids=IDS,normalize=BOOL,event_ids=IDS))
COVERAGE=obj(dict(id=IDENT,name=TEXT,url=URL,status=enum('checked_new','checked_none','failed','not_checked','cache_reused'),
                  checked_at=NULLTEXT,note=TEXT,source_ids=IDS,obligation_ids=IDS,
                  method=enum('original_index','aggregate','search','cache','not_attempted'),mapping_evidence_ids=IDS,
                  window_start=TEXT,window_end=TEXT))
REVIEW=obj(dict(status=enum('not_reviewed','self_review','independent_review'),reviewer=TEXT,method=TEXT,
                checked_fact_ids=IDS,checked_analysis_ids=IDS,checked_claim_ids=IDS,evidence_ids=IDS,issues=arr(ISSUE)),
           dict(independent_actor_id=TEXT))
MAPPING=obj(dict(id=IDENT,series_ids=IDS,entity_ids=IDS,source_ids=IDS,evidence_ids=IDS,explanation=TEXT,
                 aligned_fields=TEXTS))
PRIOR=obj(dict(thesis_id=IDENT,previous_version=INT,status=enum('supported','weakened','refuted','maintained','retired','unknown'),
               explanation=TEXT,new_evidence_ids=IDS))
META=obj(dict(title=TEXT,date=TEXT,cutoff=TEXT,timezone=TEXT,window_start=TEXT,window_adjustment_reason=STRING,
              profile=TEXT,author=TEXT,mode=enum('live','historical','teaching'),scope=TEXTS,run_id=IDENT,
              evidence_mode=enum('independent','fixed_pack'),requested_grade=enum('full','limited','observation','draft')),
         dict(market_dates=mapping(TEXT),featured_metrics=IDS,section_titles=mapping(TEXT),
              evidence_pack=obj(dict(name=TEXT,sha256=TEXT)),migration_notes=TEXTS))
SCHEMA=obj(dict(schema_version=INT,meta=META,sources=arr(SOURCE),evidence=arr(EVIDENCE),facts=arr(FACT),
                calendars=arr(CALENDAR),series=arr(SERIES),metrics=arr(METRIC),claims=arr(CLAIM),
                summary=arr(SUMMARY),articles=arr(ARTICLE),analyses=arr(ANALYSIS),observations=arr(OBSERVATION),
                actions=arr(ACTION),charts=arr(CHART),coverage=arr(COVERAGE),gaps=TEXTS,review=REVIEW,
                events=arr(EVENT),prior_reviews=arr(PRIOR),mappings=arr(MAPPING)),
           dict(market_environment=arr(obj(dict(variable=TEXT,judgment=TEXT,claim_ids=IDS))),
                visual=obj(dict(status=enum('not_performed','passed','failed'),method=TEXT,notes=TEXT)),
                evidence_differences=arr(obj(dict(group=enum('sources','facts','series','metrics','evidence','calendars'),id=IDENT,
                                                  kind=enum('added','excluded','corrected'),reason=TEXT,evidence_ids=IDS,
                                                  before_sha256=nullable(TEXT),after_sha256=nullable(TEXT))))))

SCHEMA_V2=copy.deepcopy(SCHEMA)
RESEARCH_EVENT=obj(dict(event_key=TEXT,entity=TEXT,subject=TEXT,family=TEXT,version=TEXT,
    attributes=mapping(TEXT),status=enum('lead','pending','confirmed','conflicted','corrected','withdrawn'),
    importance=INT,source_ids=IDS,evidence_ids=IDS,claim_ids=IDS,aliases=TEXTS,
    event_at=NULLTEXT,published_at=NULLTEXT,updated_at=NULLTEXT,effective_at=NULLTEXT,
    first_seen_at=TEXT,last_verified_at=NULLTEXT,last_reported_at=NULLTEXT,
    next_check=TEXT),dict(change_reason=TEXT,reported=BOOL,
        report_ref=obj(dict(section=enum('article','change'),item_id=TEXT)),
        reporting_disposition=enum('retained_pending','excluded'),reporting_reason=TEXT))
CHANGE=obj(dict(event_key=TEXT,kind=enum('new','progress','correction','late_discovery','market','trigger'),
    text=TEXT,why=TEXT,impact=TEXT,claim_ids=IDS),dict(horizon=TEXT,next_observation=TEXT))
SCHEMA['required']['research_events']=arr(RESEARCH_EVENT)
SCHEMA['required']['changes']=arr(CHANGE)
META['optional']['edition']=enum('morning','evening','intraday','snapshot')
ARTICLE['required']['section']=enum('news','ai','market','macro','companies')
COVERAGE['optional'].update(direct_access=enum('available','failed','restricted','not_attempted'),
    fallback_method=TEXT,access_failure=TEXT,content_scope=TEXT,blind_spot=TEXT)

SCHEMA_V3=copy.deepcopy(SCHEMA)
ATTEMPT=obj(dict(at=TEXT,query_or_url=TEXT,result=TEXT,status=enum('ok','failed','restricted','empty'),
                 evidence_ids=IDS),dict(tool_ref=TEXT))
TASK=obj(dict(id=IDENT,question=TEXT,priority=INT,target_evidence=TEXT,current_conclusion=STRING,
              next=TEXT,stop_reason=STRING,status=enum('planned','running','done','verified_none','blocked','budget_stop','user_stop'),
              attempts=arr(ATTEMPT),evidence_ids=IDS,product_ids=IDS),dict(stop_category=enum('uninvestigated','inaccessible','unpublished','conflict','scenario')))
SCHEMA['optional'].update(tasks=arr(TASK),packet_aliases=mapping(mapping(IDENT)))
SOURCE['optional'].update(availability_basis=TEXT,published_granularity=enum('date','timestamp'))
METRIC['optional'].update(scope=TEXT,chart_group=TEXT,chart_takeaway=TEXT,
                         comparison_kind=enum('cross_section','two_period','scale_reference'),formula=TEXT)
ARTICLE['optional']['company']=obj(dict(name=TEXT,ticker=TEXT,entity_id=IDENT,announcement_type=TEXT,announcement_id=TEXT,
                                        conditions=TEXT,financial_baseline=TEXT),dict(metric_ids=IDS))
CHART['required']['placement']=enum('overview','theme','news','ai','market','macro','companies')
CHART['optional'].update(comparison_kind=enum('cross_section','two_period','scale_reference'),generated=BOOL)
COVERAGE['optional']['attempts']=arr(copy.deepcopy(SCHEMA_V3['required']['coverage']['items']))
COVERAGE['optional']['role']=TEXT
COMPACT_ANALYSIS=copy.deepcopy(ANALYSIS)
COMPACT_ANALYSIS['required']['format']=enum('compact')
for field in ('horizon','distribution','counterevidence'):
    COMPACT_ANALYSIS['optional'][field]=COMPACT_ANALYSIS['required'].pop(field)
COMPACT_HORIZON=obj(dict(conclusion=TEXT,direction=enum('positive','negative','mixed','neutral','unknown'),claim_ids=IDS,
                         next_observation=TEXT,review_at=TEXT,confidence=enum('high','medium','low','unknown')),
                    dict(uncertainty=TEXT))
COMPACT_ANALYSIS['required']['horizons']=obj({key:COMPACT_HORIZON for key in ('intraday','short','medium')})

SCHEMA_V4=copy.deepcopy(SCHEMA)
COMPACT_ANALYSIS_V4=copy.deepcopy(COMPACT_ANALYSIS)
DOMAIN=enum('cn_market','cn_official','company','overseas','ai')
CONTENT_ROLE=enum('news','baseline','judgment','market','background','action')
COMPARISON=enum('cross_section','two_period','scale_reference','cross_entity_same_measure','same_entity_over_time','parts_of_whole','size_reference','scenario')
METRIC['optional'].update(metric_kind=TEXT,domain=DOMAIN,frequency=TEXT,price_basis=TEXT,return_type=TEXT,
    universe_id=TEXT,universe_version=TEXT,category=enum('up','down','flat','suspended','missing'),
    precision=INT,approximate=BOOL,support=obj(dict(status=enum('matched','reviewed','needs_review'),locator=TEXT,quote=TEXT),dict(note=TEXT)),
    comparison_kind=COMPARISON,session=TEXT,not_applicable_reason=TEXT)
METRIC['required']['op']['values']+=['range_position','relative_nav','daily_change']
METRIC['optional'].update(previous_close=IDENT)
SERIES['optional'].update(currency=TEXT,scale=NUMBER,domain=DOMAIN,asset_type=enum('index','stock','sector','other'),
    adjustment_available_at=NULLTEXT,universe_id=TEXT,universe_version=TEXT)
ARTICLE['optional'].update(content_role=CONTENT_ROLE,domain=DOMAIN,primary_entity=TEXT,display_title=TEXT,
    event_key=TEXT,interpretation=obj(dict(change=TEXT,channel=TEXT,scale_conditions=TEXT,judgment=TEXT,risk_next=TEXT)),
    disposition=enum('retained','pending','excluded'),disposition_reason=TEXT,baseline_key=TEXT)
CHART['optional'].update(comparison_kind=COMPARISON,vary_by=TEXTS,denominator=TEXT,known_sample=BOOL,window=INT)
CHART['required']['type']['values']+=['comparison_table']
INDEX_SCAN=obj(dict(complete=BOOL,boundary=TEXT,checked_through=TEXT),dict(latest_item_at=TEXT,limitation=TEXT))
COVERAGE['optional']['index_scan']=INDEX_SCAN
COVERAGE['optional']['attempts']['items']['optional']['index_scan']=INDEX_SCAN
SCHEMA['optional'].update(observation_review=obj(dict(status=enum('checked_none','hypotheses','blocked','not_checked'),reason=TEXT,evidence_ids=IDS)),
    selection_review=obj(dict(reason=TEXT,evidence_ids=IDS)))
ACTION['optional'].update(horizon=enum('near','medium','unconfirmed'),dynamic_rule=obj(dict(rule=TEXT,metric_ids=IDS)))
for spec in (ANALYSIS,COMPACT_ANALYSIS):
    spec['optional']['dynamic_rules']=mapping(obj(dict(rule=TEXT,metric_ids=IDS)))
ATTEMPT['optional']['receipt_type']=enum('host_receipt','agent_record')


SCHEMA_V5=copy.deepcopy(SCHEMA)
COMPACT_ANALYSIS_V5=copy.deepcopy(COMPACT_ANALYSIS)
CONTENT_ROLE['values']+=['financial_baseline','context','continuing_event']
SOURCE['required']['kind']['values']+=['public_account']
SOURCE['optional'].update(identity_note=TEXT,source_basis=enum('named','anonymous','denial','correction'),official_response=TEXT)
SOURCE['optional']['usage']=enum('discovery','content')
FACT['optional'].update(proposition=enum('publication','occurrence'),verification_at=TEXT)
ARTICLE['optional'].update(novelty=enum('new','continuing','first_discovery','correction','historical'),stage=TEXT,relevance=TEXT,unknowns=TEXT)
RESEARCH_EVENT['optional'].update(proposition=enum('publication','occurrence'),stage=TEXT)
RESEARCH_EVENT['required']['status']['values']+=['reported']
for spec in (COVERAGE,COVERAGE['optional']['attempts']['items']):
    spec['required']['status']['values']+=['partial']
METRIC['optional'].update(value_identity=enum('official','reported','conditional'),conversion=obj(dict(raw_value=NUMBER,raw_unit=TEXT,raw_scale=NUMBER,evidence_id=IDENT,entity=TEXT,period=TEXT,measure=TEXT)))
for field in ('ticker','announcement_id','conditions','financial_baseline'):
    ARTICLE['optional']['company']['optional'][field]=ARTICLE['optional']['company']['required'].pop(field)
META['optional'].update(revision_note=TEXT,scope_note=TEXT)

SCHEMA_V6=copy.deepcopy(SCHEMA)
COMPACT_ANALYSIS_V6=copy.deepcopy(COMPACT_ANALYSIS)
FOCUSED_ANALYSIS=copy.deepcopy(COMPACT_ANALYSIS)
FACT['optional']['occurrence_evidence_id']=IDENT
FOCUSED_ANALYSIS['required']['format']=enum('focused')
for field in ('novelty','earnings','pricing','expectation'):
    FOCUSED_ANALYSIS['optional'][field]=FOCUSED_ANALYSIS['required'].pop(field)
METRIC['optional']['support']['optional']['audit']=obj(dict(value=NUMBER,unit=TEXT,entity_id=IDENT,
    period=TEXT,measure=TEXT,evidence_hash=TEXT))
ARTICLE['optional']['segments']=arr(obj(dict(text=TEXT,fact_ids=IDS,claim_ids=IDS,source_ids=IDS),dict(superseded=BOOL)))
SCHEMA['optional']['metric_revisions']=arr(obj(dict(metric_id=IDENT,previous=METRIC,current=METRIC,
    reason=TEXT,recorded_at=TEXT)))
ACTION['optional']['trigger']=TEXT
ACTION['optional']['observe_at']=ACTION['required'].pop('observe_at')


def check(value, spec=SCHEMA, path='root', errors=None):
    errors = [] if errors is None else errors
    if spec is SCHEMA and isinstance(value,dict) and value.get('schema_version')==2:spec=SCHEMA_V2
    if spec is SCHEMA and isinstance(value,dict) and value.get('schema_version')==3:spec=SCHEMA_V3
    if spec is SCHEMA and isinstance(value,dict) and value.get('schema_version')==4:spec=SCHEMA_V4
    if spec is SCHEMA and isinstance(value,dict) and value.get('schema_version')==5:spec=SCHEMA_V5
    if spec is SCHEMA and isinstance(value,dict) and value.get('schema_version')==6:spec=SCHEMA_V6
    if spec is SCHEMA_V5['required']['analyses']['items'] and isinstance(value,dict) and value.get('format')=='compact':spec=COMPACT_ANALYSIS_V5
    if spec is ANALYSIS and isinstance(value,dict) and value.get('format')=='compact':spec=COMPACT_ANALYSIS
    if spec is ANALYSIS and isinstance(value,dict) and value.get('format')=='focused':spec=FOCUSED_ANALYSIS
    if spec is SCHEMA_V6['required']['analyses']['items'] and isinstance(value,dict) and value.get('format')=='compact':spec=COMPACT_ANALYSIS_V6
    if spec is SCHEMA_V4['required']['analyses']['items'] and isinstance(value,dict) and value.get('format')=='compact':spec=COMPACT_ANALYSIS_V4
    kind = spec['type']
    def fail(message): errors.append(dict(path=path, message=message, category='input_error'))
    if kind == 'nullable':
        if value is not None: check(value,spec['item'],path,errors)
    elif kind == 'object':
        if not isinstance(value,dict): fail('需要对象'); return errors
        fields={**spec['required'],**spec['optional']}
        for key in spec['required']:
            if key not in value: errors.append(dict(path=path+'.'+key,message='缺少字段',category='input_error'))
        for key,v in value.items():
            if key not in fields: errors.append(dict(path=path+'.'+key,message='未知字段',category='input_error'))
            else: check(v,fields[key],path+'.'+key,errors)
    elif kind == 'mapping':
        if not isinstance(value,dict): fail('需要映射')
        else:
            for key,v in value.items(): check(v,spec['values'],path+'.'+key,errors)
    elif kind == 'array':
        if not isinstance(value,list): fail('需要数组')
        else:
            for i,v in enumerate(value): check(v,spec['items'],f'{path}[{i}]',errors)
    elif kind == 'enum':
        if not isinstance(value,str) or value not in spec['values']: fail('允许值: '+', '.join(spec['values']))
    elif kind == 'integer':
        if type(value) is not int: fail('需要整数；bool不是整数')
    elif kind == 'number':
        if not num(value): fail('需要有限数值；bool不是数字')
    elif kind == 'bool':
        if type(value) is not bool: fail('需要bool')
    elif kind == 'id':
        if not isinstance(value,str) or not ID.fullmatch(value): fail('无效ID')
    elif kind == 'url':
        if not safe_url(value): fail('需要无凭证安全HTTP/S URL')
    elif not isinstance(value,str) or (kind=='text' and not value.strip()): fail('需要'+('非空' if kind=='text' else '')+'文本')
    return errors
