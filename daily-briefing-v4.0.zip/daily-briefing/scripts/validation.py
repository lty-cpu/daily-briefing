"""One shared validator and publication assessment for CLI, runner and renderer."""
from __future__ import annotations
from datetime import date, datetime, timedelta, timezone
import re
from common import TOKEN, fingerprint, get_zone, iso, localize, num, obligations, legacy_obligations, period_bounds, actual_time, stamp
from schema import SCHEMA, ANALYSIS_TEXT, check
from calculations import SERIES_OPS, FINANCIAL_OPS, calculate, inputs, mapping_valid, point_available

GROUPS=('sources','evidence','facts','calendars','series','metrics','claims','articles','analyses',
        'observations','actions','charts','events','mappings','coverage')
FIELD_CLAIMS=('conclusion','novelty','earnings','distribution','pricing','expectation','alternative',
              'counterevidence','support','invalidation','priority_reason','materiality')


def validate(d, contract=None, pack=None, previous=None, legacy_compat=False):
    r=dict(errors=[],warnings=[],values={},metric_details={},check_type='结构、时间、口径与依赖检查；不证明事实或引文语义、因果真实')
    execution_clock=datetime.now(timezone.utc)
    def issue(path,message,category='input_error'):
        dest='warnings' if category in ('insufficient_data','warning') else 'errors'
        item=dict(path=path,message=message,category=category)
        if item not in r[dest]:r[dest].append(item)
    if not isinstance(d,dict) or d.get('schema_version') not in (2,3,4,5,6,7) or type(d.get('schema_version')) is not int:
        issue('schema_version','需要schema 2/3/4/5/6/7；旧输入显式迁移，不覆盖原件');return r
    r['errors']=check(d)
    if r['errors']:return r
    if contract and contract.get('policy_version') and d['schema_version']<3:
        issue('schema_version','新一期必须使用schema 3；旧档案仅按原契约读取，不能绕过新版型门槛')
    if contract and contract.get('research_workflow_version') and d['schema_version']<4:
        issue('schema_version','本期锁定schema4研究流程，不能降级绕过任务门槛')
    if contract and contract.get('research_workflow_version',0)>=2 and d['schema_version']<5:
        issue('schema_version','本期锁定schema5语义流程，不能降级绕过门槛')
    modern=d['schema_version']>=6
    m=d['meta']
    try:
        cutoff=iso(m['cutoff']);zone=get_zone(m['timezone']);local=localize(m['cutoff'],m['timezone'])
        if m['mode']=='live' and cutoff>iso(stamp()):issue('meta.cutoff','live信息截止尚未到来')
        if m['date']!=local.date().isoformat():issue('meta.date','必须按报告时区而非输入偏移计算日期')
        if iso(m['window_start'])>cutoff:issue('meta.window_start','窗口不能晚于截止')
    except (ValueError,TypeError) as exc:issue('meta',str(exc));return r
    if not m['scope']:issue('meta.scope','范围不能为空')
    if m.get('edition') in ('morning','evening','intraday','snapshot'):
        from edition import section_ids
        allowed_sections=section_ids(m['edition'])
    else:allowed_sections={'overview','news','ai','market','sectors','macro','observations','actions','sources'}
    if any(k not in allowed_sections for k in m.get('section_titles',{})):issue('meta.section_titles','未知栏目ID')
    if d['schema_version']>=3 and m.get('edition')=='intraday':
        if contract is None or 'baseline' not in contract:
            issue('context.baseline','盘中核验缺少锁定上下文；不能把未知基线当作首次观察','context_missing')
        elif contract.get('baseline') and previous is None:
            issue('context.baseline','锁定基线不可解析；不能伪造首次观察','context_missing')
        elif not contract.get('baseline') and previous is not None:
            issue('context.baseline','无基线期不应注入其他期的比较状态','version_conflict')
    if contract:
        if d['schema_version']>=3 and m.get('edition')!=contract.get('edition'):
            issue('meta.edition','版型与锁定契约不一致')
        for key,target in [('cutoff','initial_cutoff'),('timezone','timezone'),('date','date'),('scope','scope'),
                           ('profile','profile'),('mode','mode'),('evidence_mode','evidence_mode')]:
            if m[key]!=contract[target]:issue('contract.'+key,'与start锁定请求不一致；需要显式新运行/修订')
        if m['window_start']!=contract['requested_window_start']:
            if not m['window_adjustment_reason'] or iso(m['window_start'])>iso(contract['requested_window_start']):
                issue('meta.window_start','只允许有原因的回溯扩展；保留请求窗口且不延后截止')
    maps={}
    for group in GROUPS:
        maps[group]={}
        for x in d[group]:
            if x['id'] in maps[group]:issue(group+'.'+x['id'],'重复ID')
            maps[group][x['id']]=x
    def refs(ids,group,path):
        for x in ids:
            if x not in maps[group]:issue(path,'不存在的'+group+'引用: '+x)
    if len({a['thesis_id'] for a in d['analyses']})!=len(d['analyses']):issue('analyses.thesis_id','同一报告中的判断ID重复')
    if d['schema_version']>=3:
        from research import compare,has_report_reference
        seen_keys={};reported=set()
        def event_publication_available(event):
            published=event.get('published_at')
            if not published:return False
            if len(published)!=10:return iso(published)<=cutoff
            return any(source['id'] in event.get('source_ids',[]) and source['published_at']==published
                       and source.get('availability_basis') and source['vintage']['available_at']
                       and iso(source['vintage']['available_at'])<=cutoff for source in d['sources'])
        for event in d['research_events']:
            event.setdefault('reported',False)
            key=event['event_key'];identity=(event['entity'],event['subject'],event['family'])
            if key in seen_keys:issue('research_events.'+key,'事件身份重复；跨入口应合并为同一事件')
            seen_keys[key]=identity
            if not 1<=event['importance']<=7:issue('research_events.'+key,'重要性需1—7')
            if key.startswith(('http:','https:')) or key in (event['aliases']):issue('research_events.'+key,'事件键不能是URL或别名')
            for field in ('published_at','updated_at'):
                value=event[field]
                if value:
                    try:
                        if iso(value,date_only=True,tz=zone)>cutoff and not (field=='published_at' and event_publication_available(event)):
                            issue('research_events.'+key+'.'+field,'日期精度不足，不能确定截止前可得' if modern and len(value)==10 else '事实版本/可得时间晚于截止','insufficient_data' if modern and len(value)==10 else 'input_error')
                    except (ValueError,TypeError):issue('research_events.'+key+'.'+field,'版本时间无效')
            first_seen=None;last_verified=None
            for field in ('first_seen_at','last_verified_at'):
                value=event[field]
                if not value:continue
                try:
                    observed=iso(value)
                    if observed>execution_clock:issue('research_events.'+key+'.'+field,'执行观察时间晚于当前执行时钟')
                    if field=='first_seen_at':first_seen=observed
                    else:last_verified=observed
                except (ValueError,TypeError):issue('research_events.'+key+'.'+field,'执行观察时间无效')
            if first_seen and last_verified and last_verified<first_seen:
                issue('research_events.'+key+'.last_verified_at','核验时间不能早于首次发现时间')
            if first_seen and event.get('published_at'):
                try:
                    published=event['published_at']
                    public_time=(iso(published,date_only=True,tz=zone).replace(hour=0,minute=0,second=0,microsecond=0)
                                 if re.fullmatch(r'\d{4}-\d{2}-\d{2}',published) else iso(published))
                    if first_seen<public_time:issue('research_events.'+key+'.first_seen_at','首次发现不能早于公告公开时间')
                    if last_verified and last_verified<public_time:issue('research_events.'+key+'.last_verified_at','核验不能早于公告公开时间')
                except (ValueError,TypeError):pass
            future_target=False
            for field in ('event_at','effective_at'):
                value=event[field]
                if value:
                    try:
                        target_time=iso(value,date_only=True,tz=zone)
                        future_target|=target_time>cutoff
                    except (ValueError,TypeError):issue('research_events.'+key+'.'+field,'事件目标时间无效')
            for field,group in (('source_ids','sources'),('evidence_ids','evidence'),('claim_ids','claims')):
                refs(event[field],group,'research_events.'+key+'.'+field)
            if modern:
                from editorial import identity as derive_identity, dependencies
                ef,ee,es=dependencies(d,event)
                if not ee or not es or not ef:issue('research_events.'+key,'事件必须关联实际证据和命题')
                else:
                    states=[derive_identity(source,e,f['status'],proposition=f.get('proposition','publication'),
                        occurrence_verified=bool(f.get('occurrence_evidence_id')==e['id'] and f.get('verification_at'))) for f in ef for e in ee for source in es if e['source_id']==source['id'] and e['id'] in f['evidence_ids']]
                    if event['status']=='confirmed' and ('confirmed' not in states or any(state in ('lead','pending','conflicted') for state in states)):issue('research_events.'+key,'事件确认强度超过关联命题证据')
                    if event['last_verified_at'] and event['status'] not in ('confirmed','corrected','withdrawn'):issue('research_events.'+key,'非确认事件不得填写确认时间')
            valid_report_ref=has_report_reference(d,event)
            if event.get('report_ref') and not valid_report_ref:
                issue('research_events.'+key+'.report_ref','报告引用必须定位本期正文条目并共享至少一条主张')
            if event.get('reported') and not valid_report_ref:
                if legacy_compat:issue('research_events.'+key+'.reported','v3.1历史记录缺少正文定位；按未闭环事件保守重建','insufficient_data')
                else:issue('research_events.'+key+'.reported','已报道状态缺少有效正文定位，不能伪造增量闭环')
            event['reported']=valid_report_ref
            if valid_report_ref:reported.add(key)
            if event['importance']>=5 and (d['schema_version']>=6 or event['status'] in ('confirmed','corrected','withdrawn')) and not valid_report_ref:
                disposition=event.get('reporting_disposition')
                reason=event.get('reporting_reason','').strip()
                if disposition not in ('retained_pending','excluded') or len(reason)<8 or not event['claim_ids']:
                    issue('research_events.'+key+'.reporting_disposition','重大候选未进入正文时，需声明待报/排除理由并保留可审阅主张','insufficient_data')
                if event.get('reported'):
                    issue('research_events.'+key+'.reporting_disposition','正文已报道事件不能同时标为待报/排除')
            if future_target:
                if not event['published_at'] or not event_publication_available(event):
                    issue('research_events.'+key,'未来事项必须由截止前公开的公告版本支持')
                if not event['source_ids'] or not event['evidence_ids']:
                    issue('research_events.'+key,'未来事项必须保留公告来源与原文证据')
        detected=compare(d['research_events'],previous,m['cutoff'])
        change_keys=set()
        for change in d['changes']:
            key=change['event_key']
            if key in change_keys:issue('changes.'+key,'重复变化')
            change_keys.add(key)
            refs(change['claim_ids'],'claims','changes.'+key+'.claim_ids')
            if change['kind'] not in ('market','trigger') and (key not in detected or detected[key]!=change['kind']):
                issue('changes.'+key,'变化类型与已提交基线的事实版本不一致')
            if change['kind'] not in ('market','trigger') and key not in reported:
                issue('changes.'+key,'正文变化需明确标记本轮已报告的事件版本')
            if not change['claim_ids']:issue('changes.'+key,'变化的原因与影响需要本期可追溯主张')
        if m.get('edition')=='intraday':
            for event in d['research_events']:
                if event['importance']>=5 and (d['schema_version']>=6 or event['status'] in ('confirmed','corrected','withdrawn')) and event['event_key'] in detected and event['event_key'] not in change_keys:
                    disposition=event.get('reporting_disposition')
                    reason=event.get('reporting_reason','').strip()
                    if disposition not in ('retained_pending','excluded') or len(reason)<8 or not event['claim_ids']:
                        issue('changes.'+event['event_key'],'重大已确认变化未进入盘中正文或缺少具体待报/排除理由')
            r['delta']=dict(baseline=contract.get('baseline') if contract else None,detected=detected,reported=sorted(change_keys))
    maps['_sessions']={c['id']:{x['date']:x for x in c['sessions']} for c in d['calendars']}
    refs(m.get('featured_metrics',[]),'metrics','meta.featured_metrics')
    if len(m.get('featured_metrics',[]))>(6 if d['schema_version']>=4 else 4):issue('meta.featured_metrics','首屏关键数值过多')
    def before(value,path,required=False,date_ok=False):
        if value is None:
            issue(path,'可得时间未知，不能作为已核验当前信息', 'insufficient_data' if not required else 'input_error');return None
        try:
            dt=iso(value,date_only=date_ok,tz=zone)
            if dt>cutoff:issue(path,'信息/版本在截止之后可得')
            return dt
        except (ValueError,TypeError):issue(path,'不可解析的ISO日期/时间');return None
    def time_any(value,path,date_ok=False):
        try:return iso(value,date_only=date_ok,tz=zone)
        except (ValueError,TypeError):issue(path,'不可解析的ISO日期/时间');return None
    for source in d['sources']:
        p='sources.'+source['id'];value=source['published_at']
        if modern and source.get('usage')=='discovery':
            time_any(value,p+'.published_at',True)
            retrieved=time_any(source['retrieved_at'],p+'.retrieved_at')
            if retrieved and retrieved>execution_clock:issue(p+'.retrieved_at','实际读取时间晚于当前执行时钟')
            continue
        if re.fullmatch(r'\d{4}-\d{2}-\d{2}',value):
            try:
                tz=iso('2000-01-01T00:00:00'+source.get('published_timezone','-12:00')).tzinfo
                upper=source['vintage']['available_at'] if d['schema_version']>=4 and source.get('availability_basis') else None
                if upper:
                    if iso(upper)>cutoff or iso(upper)<iso(value,date_only=True,tz=tz).replace(hour=0,minute=0,second=0,microsecond=0):issue(p+'.published_at','日期级可得上界无效')
                elif iso(value,date_only=True,tz=tz)>cutoff:
                    issue(p+'.published_at','只有日期不能确认在截止前公开','insufficient_data' if d['schema_version']>=4 and source['vintage']['available_at'] is None else 'input_error')
            except ValueError:issue(p+'.published_timezone','无效UTC偏移')
        else:before(value,p+'.published_at',required=True)
        before(source['vintage']['available_at'],p+'.vintage.available_at')
        retrieved=time_any(source['retrieved_at'],p+'.retrieved_at')
        if retrieved and retrieved>execution_clock:issue(p+'.retrieved_at','实际读取时间晚于当前执行时钟')
        if retrieved and len(value)>10:
            try:
                if retrieved<iso(value):issue(p+'.retrieved_at','读取早于发布')
            except ValueError:pass
    for e in d['evidence']:
        refs([e['source_id']],'sources','evidence.'+e['id'])
        retrieved=time_any(e['retrieved_at'],'evidence.'+e['id']+'.retrieved_at')
        if retrieved and retrieved>execution_clock:issue('evidence.'+e['id']+'.retrieved_at','实际读取时间晚于当前执行时钟')
    for f in d['facts']:
        p='facts.'+f['id'];refs(f['source_ids'],'sources',p);refs(f['evidence_ids'],'evidence',p)
        if modern and any(maps['sources'].get(sid,{}).get('usage')=='discovery' for sid in f['source_ids']):issue(p,'发现索引不能代替消息原文；请按实际读取范围单独登记内容来源')
        if not f['source_ids']:issue(p,'事实缺来源')
        if f['kind']=='actual':
            try:
                violation=actual_time(f['as_of'],f['available_at'],cutoff,m['timezone'])
                if violation:issue(p+'.as_of',violation)
            except ValueError:issue(p+'.as_of','无效时间')
        else:time_any(f['as_of'],p+'.as_of',True)
        before(f['available_at'],p+'.available_at')
        future_targets=[]
        for key in ('event_at','effective_at'):
            if key in f:
                target=time_any(f[key],p+'.'+key,True)
                if target and target>cutoff:future_targets.append((key,target))
        if future_targets and f['kind']=='actual':issue(p,'未来实际值不能作为当前事实；仅可标注为公告事项或预测')
        if future_targets and f['kind']=='event' and (not f['source_ids'] or not f['evidence_ids']):
            issue(p,'未来公告事项需保留截止前可得的来源与原文证据')
        if 'observation_period' in f:
            a=time_any(f['observation_period']['start'],p+'.period.start',True)
            b=time_any(f['observation_period']['end'],p+'.period.end',True)
            if a and b and (a>b or (f['kind']=='actual' and b.astimezone(zone).date()>local.date())):issue(p,'实绩期间无效')
            if f['kind']=='actual':
                try:
                    violation=actual_time(f['observation_period']['end'],f['available_at'],cutoff,m['timezone'],period_end=True)
                    if violation:issue(p+'.observation_period',violation)
                except ValueError:pass
        for eid in f['evidence_ids']:
            if eid in maps['evidence'] and maps['evidence'][eid]['source_id'] not in f['source_ids']:issue(p,'证据片段与事实来源不一致')
        if f['status']=='confirmed' and f['source_ids'] and all(maps['sources'].get(x,{}).get('kind')=='media' for x in f['source_ids']):issue(p,'仅媒体来源请标reported')
    for cal in d['calendars']:
        p='calendars.'+cal['id'];refs(cal['source_ids'],'sources',p);refs(cal['evidence_ids'],'evidence',p)
        try:
            get_zone(cal['timezone']);a=date.fromisoformat(cal['valid_from']);b=date.fromisoformat(cal['valid_to'])
            days=[s['date'] for s in cal['sessions']]
            if days!=sorted(set(days)) or a>b:raise ValueError('会话须唯一有序，范围合法')
            for s in cal['sessions']:
                day=date.fromisoformat(s['date']);dt=localize(s['close_at'],cal['timezone'])
                if not a<=day<=b or dt.date()!=day:raise ValueError('会话日期/收盘时间超出适用范围')
            if cal.get('synthetic') and m['mode']!='teaching':issue(p,'合成日历只允许教学演示')
            if cal['complete'] and (not cal['source_ids'] or not cal['evidence_ids']):issue(p,'完整日历需来源和版本证据，不可用工作日猜测')
        except (ValueError,TypeError) as exc:issue(p,str(exc))
    for s in d['series']:
        p='series.'+s['id'];refs(s['source_ids'],'sources',p);refs(s['evidence_ids'],'evidence',p)
        if not s['source_ids']:issue(p,'原始序列需要来源')
        for eid in s['evidence_ids']:
            if eid in maps['evidence'] and maps['evidence'][eid]['source_id'] not in s['source_ids']:issue(p,'序列片段与声明来源不一致')
        if s['calendar_id']:refs([s['calendar_id']],'calendars',p)
        cal=maps['calendars'].get(s['calendar_id'])
        if cal and cal['market']!=s['market']:issue(p,'序列市场与日历不一致')
        before(s['vintage']['available_at'],p+'.vintage')
        if s.get('adjustment_available_at'):before(s['adjustment_available_at'],p+'.adjustment_available_at')
        rule=s.get('release_rule')
        if rule:
            refs(rule['evidence_ids'],'evidence',p+'.release_rule')
            if not rule['evidence_ids'] or rule['delay_seconds']<0 or not cal:issue(p,'发布规则需日历、非负延迟及原文依据')
        days=[]
        for i,o in enumerate(s['observations']):
            q=p+'.observations['+str(i)+']'
            try:
                day=date.fromisoformat(o['date']);days.append(o['date'])
                if day>local.date():issue(q,'序列观测在未来')
            except ValueError:issue(q,'日期无效')
            av=point_available(o,s,maps)
            if av:before(av,q+'.available_at')
            if av and cal and s['frequency']=='daily' and o['status']=='traded':
                session=maps['_sessions'][cal['id']].get(o['date'])
                try:
                    if session and iso(av)<iso(session['close_at']):issue(q,'完整日会话数值不能在该会话收盘前已知；盘中值用带时点观测指标')
                except ValueError:pass
            if o.get('vintage'):before(o['vintage']['available_at'],q+'.vintage')
            if o['value'] is not None and s['basis'] in ('price','turnover','count','shares') and o['value']<0:issue(q,'该数据类型不能为负')
            if o['status'] in ('missing','suspended') and o['value'] is not None:issue(q,'停牌或缺失必须null，不能以前值补齐')
        if days!=sorted(set(days)):issue(p,'观测日期须唯一且升序')
        if cal and s['frequency']=='daily' and any(day not in maps['_sessions'][cal['id']] for day in days):issue(p,'日度观测不属于声明的有效会话')
        if cal and s['frequency']=='daily' and s.get('usage','current')=='current':
            lag=s.get('release_rule',{}).get('delay_seconds',0)
            expected=[x['date'] for x in cal['sessions'] if iso(x['close_at'])+timedelta(seconds=lag)<=cutoff]
            if expected and (not days or days[-1]<expected[-1]):issue(p,'当前行情滞后于最近应可得会话 '+expected[-1]+'；背景用途需明确usage=background','insufficient_data')
    for mapping in d['mappings']:
        p='mappings.'+mapping['id']
        for key,group in [('series_ids','series'),('source_ids','sources'),('evidence_ids','evidence')]:refs(mapping[key],group,p)
        if not mapping['evidence_ids']:issue(p,'跨源映射缺少口径证据')
    for metric in d['metrics']:
        p='metrics.'+metric['id'];op=metric['op'];dim=metric['dimensions']
        if dim['scale']<=0:issue(p+'.dimensions.scale','数量级必须为正')
        if d['schema_version']>=5:
            from calculations import AMOUNT_SCALES
            if metric['unit'] in AMOUNT_SCALES and dim['scale']!=AMOUNT_SCALES[metric['unit']]:issue(p,'金额单位与scale不一致，需显式转换')
        try:
            period=period_bounds(dim['period'])
            if period and metric.get('kind')=='actual' and period[1]>local.date():issue(p+'.dimensions.period','实绩期间结束在未来')
        except ValueError:issue(p+'.dimensions.period','期间需ISO日期/范围、YYYY-MM、YYYY或YYYY-Qn；财年映射用ISO范围')
        if op=='observed':
            if d['schema_version']>=6 and any(maps['sources'].get(sid,{}).get('usage')=='discovery' for sid in metric.get('source_ids',[])):issue(p,'发现用索引不能作为观测数值证据')
            for key in ('value','as_of','available_at','kind','source_ids','evidence_ids'):
                if key not in metric:issue(p+'.'+key,'观测指标缺少字段')
            if 'as_of' in metric:
                if metric.get('kind')=='actual':
                    try:
                        violation=actual_time(metric['as_of'],metric.get('available_at'),cutoff,m['timezone'])
                        if violation:issue(p+'.as_of',violation)
                        if period and period[0]!=period[1]:
                            violation=actual_time(period[1].isoformat(),metric.get('available_at'),cutoff,m['timezone'],period_end=True)
                            if violation:issue(p+'.dimensions.period',violation)
                    except ValueError:issue(p+'.as_of','时间无效')
                else:time_any(metric['as_of'],p+'.as_of',True)
            before(metric.get('available_at'),p+'.available_at')
            if d['schema_version']>=5:
                if metric.get('precision',2)<0 or metric.get('precision',2)>8:issue(p+'.precision','精度范围0—8')
                if metric.get('category') and (metric['unit'] not in ('家','只','个') or metric.get('value') is not None and (metric['value']<0 or int(metric['value'])!=metric['value'])):issue(p,'广度分类需要非负整数计数')
                if dim['measure'] in ('revenue','profit','net_profit','cash_flow','assets','total_assets','capex') and period and metric.get('as_of','')[:10]!=period[1].isoformat():issue(p+'.as_of','财务观测时点必须是统计期末；公布日保存在来源published_at，不可替代统计期')
            refs(metric.get('source_ids',[]),'sources',p);refs(metric.get('evidence_ids',[]),'evidence',p)
            if not metric.get('source_ids'):issue(p,'观测指标缺少来源')
            for eid in metric.get('evidence_ids',[]):
                if eid in maps['evidence'] and maps['evidence'][eid]['source_id'] not in metric.get('source_ids',[]):issue(p,'观测片段与声明来源不一致')
        elif op in SERIES_OPS:
            for key in ('series_id','n','window_basis'):
                if key not in metric:issue(p+'.'+key,'序列计算缺少字段')
            if metric.get('n',0)<=0:issue(p+'.n','窗口必须为正整数')
            refs([metric.get('series_id','')],'series',p)
            s=maps['series'].get(metric.get('series_id'))
            if s:
                if dim['entity_id']!=s['entity_id']:issue(p,'指标实体与序列实体不一致')
                expected={'return':('price','%'),'excess_return':('price','百分点'),'volume_ratio':('turnover','倍'),'bp_change':('yield_percent','bp')}.get(op)
                if expected and (s['basis'],metric['unit'])!=expected:issue(p,'运算、基础量和单位不符')
                if op=='difference' and metric['unit']!=s['unit']:issue(p,'差值单位不符')
                if metric.get('window_basis')=='observations' and ('交易日' in metric['label']):issue(p,'观测期指标不能标交易日')
                if d['schema_version']>=5 and op in ('return','excess_return','relative_nav') and s.get('asset_type')=='stock' and s['adjustment'] in ('none','raw','unadjusted','不复权'):issue(p,'股票跨期收益需要可核验复权序列；日涨跌单独使用除权昨收')
            if op in ('excess_return','relative_nav'):
                refs([metric.get('benchmark_id','')],'series',p);b=maps['series'].get(metric.get('benchmark_id'))
                if s and b:
                    if b['basis']!='price':issue(p,'基准必须为价格')
                    if any(s[k]!=b[k] for k in ('market','provider','adjustment','classification','scope')) and not mapping_valid(metric.get('mapping_id'),[s,b],maps):issue(p,'不可比基准；跨源组合需完整映射')
        else:
            deps=inputs(metric);refs([x or '' for x in deps],'metrics',p)
            if not deps:issue(p,'计算缺少输入依赖');continue
            if any(x not in maps['metrics'] for x in deps):continue
            ins=[maps['metrics'][x] for x in deps]
            from calculations import AMOUNT_SCALES
            if len(ins)!=(1 if op=='sensitivity' else 2) and op not in ('sum','product'):issue(p,'运算输入个数错误')
            if not metric.get('comparison_basis') or not metric.get('comparison_evidence_ids'):issue(p,'财务计算需口径说明及证据')
            refs(metric.get('comparison_evidence_ids',[]),'evidence',p)
            for x in ins:
                xd=x['dimensions']
                if xd['entity_id']!=dim['entity_id']:issue(p,'财务计算实体不一致')
                if xd['currency'] not in ('none',dim['currency']) and dim['currency']!='none':issue(p,'币种不一致，不能隐式换汇')
            if len({x['dimensions']['currency'] for x in ins if x['dimensions']['currency']!='none'})>1:issue(p,'输入币种不一致')
            if d['schema_version']>=4 and not (op=='ratio' and metric.get('comparison_kind')=='scale_reference') and (len({x.get('scope',x['dimensions']['segment']) for x in ins})>1 or any(x.get('scope',x['dimensions']['segment'])!=metric.get('scope',dim['segment']) for x in ins)):issue(p,'派生计算范围不一致；沪深与含北交所全A不能混算')
            if op in ('pair_difference','growth','sum','sensitivity'):
                for key in ('segment','measure'):
                    if any(x['dimensions'][key]!=ins[0]['dimensions'][key] for x in ins):issue(p,'总量/分部或财务量不一致: '+key)
                from calculations import AMOUNT_SCALES
                if len({x['unit'] for x in ins})>1 and not (d['schema_version']>=5 and all(x['unit'] in AMOUNT_SCALES for x in ins)):issue(p,'同类计算输入单位不同')
            if op=='daily_change':
                if len(ins)!=2 or ins[0]['dimensions']['measure']!='adjusted_previous_close' or ins[1]['dimensions']['measure']!='close' or ins[0].get('as_of')!=ins[1].get('as_of') or metric['unit']!='%':issue(p,'日涨跌必须同会话的除权昨收与当日收盘，不是两日原始close')
            scale_reference=op=='ratio' and metric.get('comparison_kind')=='scale_reference'
            if op in ('ratio','sum','product') and not scale_reference and len({x['dimensions']['period'] for x in ins})>1:issue(p,'同期运算的期间不一致')
            if op in ('ratio','growth') and dim['currency']!='none':issue(p,'无量纲比率输出currency必须为none')
            if op=='pair_difference':
                money_conversion=d['schema_version']>=5 and all(item['unit'] in AMOUNT_SCALES for item in [*ins,metric])
                if not money_conversion and ((ins[0]['unit']=='%' and metric['unit'] not in ('bp','百分点')) or (ins[0]['unit']!='%' and metric['unit']!=ins[0]['unit'])):issue(p,'差值输出单位错误')
            if op=='growth' and metric['unit']!='%':issue(p,'增长率单位为%')
            if op=='ratio' and metric['unit'] not in ('%','倍'):issue(p,'ratio输出限%或倍')
            if op=='ratio' and any(x['unit']!=ins[0]['unit'] for x in ins) and not (d['schema_version']>=5 and all(item['unit'] in AMOUNT_SCALES for item in ins)):issue(p,'ratio只允许同单位或有明确尺度换算的无量纲比值')
            if op=='sum' and metric['unit']!=ins[0]['unit'] and not (d['schema_version']>=5 and all(item['unit'] in AMOUNT_SCALES for item in [*ins,metric])):issue(p,'求和单位错误')
            if op=='sensitivity' and ('shock' not in metric or metric['unit']!=ins[0]['unit']):issue(p,'敏感性需明确相对shock且单位不变')
            if op=='product':
                dimensions={}
                for x in ins:
                    if not x['dimensions'].get('dimensions'):issue(p,'乘积需单位维度，例如money或quantity的幂')
                    for key,power in x['dimensions'].get('dimensions',{}).items():dimensions[key]=dimensions.get(key,0)+power
                dimensions={k:v for k,v in dimensions.items() if v}
                if dimensions!=dim.get('dimensions'):issue(p,'乘积输出单位维度不匹配')
    # Structural references are shared by all display surfaces.
    for group in ('claims','summary','articles','analyses','observations','actions','events'):
        for i,item in enumerate(d[group]):
            p=group+'.'+item.get('id',str(i))
            for key,target in [('fact_ids','facts'),('analysis_ids','analyses'),('claim_ids','claims'),('metric_ids','metrics'),('consensus_fact_ids','facts'),('evidence_ids','evidence')]:
                if key in item:refs(item[key],target,p+'.'+key)
            if group=='claims' and item['status']=='supported' and not (item['fact_ids'] or item['metric_ids']):issue(p,'有据主张需要事实或指标')
            if modern and group=='claims' and item['status']=='supported' and any(maps['facts'].get(fid,{}).get('status') in ('unverified','conflicted') for fid in item['fact_ids']):issue(p,'待证或冲突输入不能升级为有据结论；使用hypothesis/unknown及条件情景')
            if group in ('summary','articles') and not any(item[key] for key in ('fact_ids','analysis_ids','claim_ids')):issue(p,'正文/摘要需要可追溯的事实、判断或主张')
            if group=='articles' and not 1<=item['priority']<=7:issue(p,'新闻优先级必须1—7')
            if group=='observations' and item['kind']=='contrarian' and not item['consensus_fact_ids']:issue(p,'非共识缺少预期基准')
    if len(d['summary'])>(5 if d['schema_version']>=6 else 3):issue('summary','摘要最多5项（旧版最多3项）')
    for a in d['analyses']:
        p='analyses.'+a['id']
        if a['version']<1 or not 1<=a['priority']<=3:issue(p,'版本/优先级无效')
        for field,ids in a['field_claims'].items():
            if field not in FIELD_CLAIMS:issue(p+'.field_claims','未知分析字段: '+field)
            refs(ids,'claims',p+'.'+field)
        for h in a['horizons'].values():
            refs(h['claim_ids'],'claims',p+'.horizons');time_any(h['review_at'],p+'.horizons.review_at')
        for key in ('review_at','expires_at'):time_any(a[key],p+'.'+key)
        for e in a['mechanism']:
            refs(e['fact_ids'],'facts',p+'.mechanism')
            if e['basis']=='fact' and not e['fact_ids']:issue(p,'事实传导需依据')
            if e['basis']=='assumption' and not e['assumption'].strip():issue(p,'假设传导需说明假设')
        for l in a['leaders']:
            refs(l['fact_ids'],'facts',p+'.leaders');refs(l['claim_ids'],'claims',p+'.leaders')
            if l.get('series_id'):refs([l['series_id']],'series',p+'.leaders')
            for role in ('industry','trading'):
                refs(l['role_evidence'].get(role,[]),'facts',p+'.role_evidence')
                if l['role'] in (role,'both') and not l['role_evidence'].get(role):issue(p,'龙头角色缺证据')
            if l['role'] in ('industry','both') and not l.get('industry_basis'):issue(p,'产业龙头缺同业依据')
            if l.get('industry_basis'):refs(l['industry_basis']['fact_ids'],'facts',p+'.industry_basis')
        if a.get('update'):refs(a['update']['new_evidence_ids'],'evidence',p+'.update')
    for a in d['actions']:
        p='actions.'+a['id'];refs([a['analysis_id']],'analyses',p)
        if not 1<=a['priority']<=3:issue(p,'优先级需1—3')
        at=time_any(a['observe_at'],p+'.observe_at') if a.get('observe_at') else None
        end=time_any(a['expires_at'],p+'.expires_at')
        if d['schema_version']>=7 and not at and not a.get('trigger'):issue(p,'近期观察需要已知时点或相对触发条件')
        if at and end and (end<=cutoff or end<at):issue(p,'行动已过期或截止早于观察')
        if a.get('calendar_id'):refs([a['calendar_id']],'calendars',p)
    for e in d['events']:
        event_at=time_any(e['at'],'events.'+e['id'],True)
        if event_at and event_at>cutoff:
            if e['status']!='expected':issue('events.'+e['id'],'未来事项必须标为公告计划，不得呈现为已发生')
            matching=[]
            for fid in e['fact_ids']:
                fact=maps['facts'].get(fid)
                if not fact or fact['kind']!='event':continue
                for key in ('event_at','effective_at'):
                    if fact.get(key):
                        try:
                            target=fact[key]
                            if re.fullmatch(r'\d{4}-\d{2}-\d{2}',target):
                                matches=date.fromisoformat(target)==event_at.astimezone(zone).date()
                            else:matches=iso(target)==event_at
                            if matches:matching.append(fact);break
                        except (ValueError,TypeError):pass
            if not matching:issue('events.'+e['id'],'未来时间线必须引用匹配的已公告事项事实')
    from research import coverage_attempts
    for c in coverage_attempts(d['coverage']):
        p='coverage.'+c['id'];refs(c['source_ids'],'sources',p);refs(c['mapping_evidence_ids'],'evidence',p)
        if c.get('index_scan'):
            time_any(c['index_scan']['checked_through'],p+'.index_scan.checked_through')
            if c['checked_at'] and iso(c['index_scan']['checked_through'])>iso(c['checked_at']):issue(p,'窗口索引不能证明实际检查之后的发布完整性')
        if c['status']!='not_checked' and not c['checked_at']:issue(p,'需要实际访问或缓存获取时刻')
        if c['checked_at']:
            checked=time_any(c['checked_at'],p)
            if checked and checked>execution_clock:issue(p,'访问时间晚于执行时钟')
        time_any(c['window_start'],p);time_any(c['window_end'],p)
        if c['checked_at']:
            try:
                if c['status'] in ('checked_new','checked_none') and iso(c['checked_at'])<min(iso(c['window_end']),cutoff):issue(p,'旧访问不能证明已扫描后来的窗口新增','insufficient_data')
            except ValueError:pass
        if c['method']=='search' and c['status']=='checked_none':issue(p,'搜索无结果不能证明官网无新增')
        if c['method']=='aggregate' and not c['mapping_evidence_ids']:issue(p,'聚合覆盖需范围映射证据')
    review=d['review']
    for key in ('observation_review','selection_review'):
        if key in d:
            refs(d[key]['evidence_ids'],'evidence',key+'.evidence_ids')
            if (key=='selection_review' or d[key]['status']=='checked_none') and not d[key]['evidence_ids']:issue(key,'完成检查需要引用实际候选或原文证据','insufficient_data')
    for analysis in d['analyses']:
        for key,rule in analysis.get('dynamic_rules',{}).items():refs(rule['metric_ids'],'metrics','analyses.'+analysis['id']+'.dynamic_rules.'+key)
    for action in d['actions']:
        if action.get('dynamic_rule'):refs(action['dynamic_rule']['metric_ids'],'metrics','actions.'+action['id']+'.dynamic_rule')
    for key,target in [('checked_fact_ids','facts'),('checked_analysis_ids','analyses'),('checked_claim_ids','claims'),('evidence_ids','evidence')]:refs(review[key],target,'review.'+key)
    if review['status']=='independent_review' and (not review.get('independent_actor_id') or review.get('independent_actor_id')==m['author']):issue('review','独立审核需独立主体记录')
    for x in review['issues']:
        if x['resolved'] and not x.get('resolution'):issue('review.issues','已解决问题需解决说明')
    for group in ('claims','analyses'):
        for item in d[group]:
            for gap in item['limitations']:refs(gap.get('claim_ids',[]),'claims',group+'.'+item['id']+'.limitations')
    for change in d.get('evidence_differences',[]):refs(change['evidence_ids'],'evidence','evidence_differences')
    prior_review_ids=set()
    analyses_by_thesis={item['thesis_id']:item for item in d['analyses']}
    for previous in d['prior_reviews']:
        refs(previous['new_evidence_ids'],'evidence','prior_reviews')
        if previous['thesis_id'] in prior_review_ids:issue('prior_reviews.'+previous['thesis_id'],'同一期观点不能重复复核')
        prior_review_ids.add(previous['thesis_id'])
        if previous['status'] not in ('maintained','unknown') and not previous['new_evidence_ids']:
            issue('prior_reviews.'+previous['thesis_id'],'观点支持变化或退出需引用新证据')
        current=analyses_by_thesis.get(previous['thesis_id'])
        if current:
            update=current.get('update') or {}
            if update and (update.get('status')!=previous['status'] or update.get('previous_version')!=previous['previous_version']):
                issue('prior_reviews.'+previous['thesis_id'],'同一期 prior_review 与 analysis.update 冲突')
            elif not update and previous['status'] not in ('maintained','unknown'):
                issue('prior_reviews.'+previous['thesis_id'],'同一期观点状态变化必须同步记录在 analysis.update')
    def walk(v,path):
        if isinstance(v,str):
            if '{metric:' in TOKEN.sub('',v):issue(path,'数值引用语法错误')
            refs(TOKEN.findall(v),'metrics',path)
        elif isinstance(v,list):
            for i,x in enumerate(v):walk(x,f'{path}[{i}]')
        elif isinstance(v,dict):
            for k,x in v.items():walk(x,path+'.'+k)
    walk(d,'root')
    if d['schema_version']>=4:
        from research import task_progress
        progress=task_progress(d,contract or dict(edition=m.get('edition','snapshot'),scope=m['scope'],profile=m['profile'],requested_window_start=m['window_start'],initial_cutoff=m['cutoff']))
        r['research_completion']=progress
        for task in d.get('tasks',[]):
            refs(task['evidence_ids'],'evidence','tasks.'+task['id'])
            for attempt in task['attempts']:
                observed=time_any(attempt['at'],'tasks.'+task['id'])
                if observed and observed>execution_clock:issue('tasks.'+task['id'],'尝试时间晚于执行时钟')
                refs(attempt['evidence_ids'],'evidence','tasks.'+task['id'])
        for article in d['articles']:
            if article['section']=='companies' and not article.get('company'):issue('articles.'+article['id'],'公司栏目需要公司实体与公告标识；政策应归news')
            if d['schema_version']>=5:
                title=article.get('display_title',article['title'])
                if not re.search(r'[\u3400-\u9fff]',title):issue('articles.'+article['id'],'请提供中文可读标题；内部别名和纯工程标题只留引用字段','insufficient_data')
                if article.get('disposition') in ('excluded','pending') and not article.get('disposition_reason'):issue('articles.'+article['id'],'排除/待核需要明确原因')
                if article.get('content_role')=='news' and not article.get('event_key'):issue('articles.'+article['id'],'新闻缺少事件身份；补齐entity/subject/family/release_id，不按标题猜测')
    validate_charts(d,maps,issue)
    if pack is not None:fixed_comparison(d,pack,issue,r)
    elif m['evidence_mode']=='fixed_pack':
        issue('evidence_pack','v3.1快照未保存原始固定资料包；仅按旧记录兼容读取，不重新认证资料完整性',
              'insufficient_data' if legacy_compat else 'input_error')
    if r['errors']:return r
    r['values'],r['metric_details']=calculate(d,maps,issue)
    if r['errors']:return r
    assess(d,maps,r,contract,issue,previous)
    r['document_sha256']=fingerprint(d)
    return r


def validate_charts(d,maps,issue):
    def need(c,keys):
        for k in keys:
            if k not in c:issue('charts.'+c['id']+'.'+k,'图表缺少字段')
        return all(k in c for k in keys)
    for c in d['charts']:
        typ=c['type'];p='charts.'+c['id'];ids=[];group='metrics'
        if c['placement']=='theme' and c.get('analysis_id') not in maps['analyses']:issue(p,'主题图需要已有analysis_id')
        if typ in ('breadth','bars','comparison_table') and need(c,['items']):
            ids=[x['metric_id'] for x in c['items']]
            if typ=='breadth':
                expected={'up','down'} if c.get('known_sample') else {'up','flat','down'}
                if not c.get('scope') or {x.get('category') for x in c['items']}!=expected or len(c['items'])!=len(expected):issue(p,'广度需互斥完整类别；两类必须标已知涨跌样本')
        elif typ=='heatmap' and need(c,['columns','rows','classification','scope']):
            for row in c['rows']:
                if len(row['metric_ids'])!=len(c['columns']):issue(p,'热力图列不匹配')
                ids+=row['metric_ids']
            for col in zip(*(x['metric_ids'] for x in c['rows'])):
                ms=[maps['metrics'][x] for x in col if x in maps['metrics']]
                if len({(m['op'],m.get('n'),m.get('window_basis'),m['unit']) for m in ms})>1:issue(p,'热力同列窗口/单位不一致')
                ss=[maps['series'][m['series_id']] for m in ms if m.get('series_id') in maps['series']]
                if any(m['op'] not in ('return','excess_return') for m in ms):issue(p,'强弱热力图需可计算收益率')
                if any(s['classification']!=c['classification'] for s in ss):issue(p,'热力图分类与源数据不同')
                if d['schema_version']>=5 and len({(s['frequency'],s['market'],s['adjustment'],s.get('domain')) for s in ss})>1:issue(p,'热力同列频率/市场/复权/领域不一致')
                if len({tuple(o['date'] for o in s['observations'][-ms[i].get('n',1)-1:]) for i,s in enumerate(ss)})>1:issue(p,'热力同列实际窗口不一致')
        elif typ=='scatter' and need(c,['points']):
            for point in c['points']:
                ids += [point['x_metric'],point['y_metric']]
                x=maps['metrics'].get(point['x_metric']);y=maps['metrics'].get(point['y_metric'])
                if not x or not y:continue
                if x['op']!='excess_return' or y['op']!='volume_ratio':issue(p,'散点需超额收益与量能比');continue
                sx=maps['series'].get(x.get('series_id'));sy=maps['series'].get(y.get('series_id'))
                if sx and sy:
                    if sx['entity_id']!=sy['entity_id']:issue(p,'同点横纵轴实体不一致；显示名相同无效')
                    if (x.get('n'),x.get('window_basis'))!=(y.get('n'),y.get('window_basis')):issue(p,'同点横纵轴窗口不一致')
                    if [o['date'] for o in sx['observations'][-x.get('n',1)-1:]] != [o['date'] for o in sy['observations'][-y.get('n',1)-1:]]:issue(p,'同点会话未对齐')
                    if any(sx[k]!=sy[k] for k in ('scope','market','provider','adjustment','classification')) and not mapping_valid(point.get('mapping_id'),[sx,sy],maps):issue(p,'同点跨源/范围不一致且无合法映射')
            xs=[maps['metrics'][pt['x_metric']] for pt in c['points'] if pt['x_metric'] in maps['metrics']]
            if len({(x.get('n'),x.get('window_basis'),x.get('benchmark_id')) for x in xs})>1:issue(p,'散点各点横轴窗口或基准不一致')
        elif typ=='line' and need(c,['series_ids','normalize']):
            ids=c['series_ids'];group='series'
            ss=[maps['series'][x] for x in ids if x in maps['series']]
            if not 1<=len(ss)<=4:issue(p,'折线需1—4序列')
            if c['normalize'] and any(s['basis']!='price' for s in ss):issue(p,'归一化仅用于价格')
            if not c['normalize'] and len({s['unit'] for s in ss})>1:issue(p,'不同单位不能共用纵轴')
            if d['schema_version']>=5 and len({(series['frequency'],series['adjustment'],series.get('domain')) for series in ss})>1:issue(p,'走势频率/复权/领域不一致')
        elif typ=='mechanism' and need(c,['analysis_id']):ids=[c['analysis_id']];group='analyses'
        elif typ=='timeline' and need(c,['event_ids']):ids=c['event_ids'];group='events'
        for x in ids:
            if x not in maps[group]:issue(p,'图表引用不存在: '+x)
        if typ in ('breadth','bars','comparison_table'):
            ms=[maps['metrics'][x] for x in ids if x in maps['metrics']]
            comparison=c.get('comparison_kind','cross_section')
            if d['schema_version']<5:
                if len({(item['unit'],item['dimensions']['currency'],item['dimensions']['scale']) for item in ms})>1:issue(p,'截面单位/币种/数量级不一致')
                if comparison=='cross_section' and len({item.get('as_of',item['dimensions']['period']) for item in ms})>1:issue(p,'截面期间不一致')
                if comparison in ('two_period','scale_reference') and (len(ms)!=2 or len({item['dimensions']['entity_id'] for item in ms})>1):issue(p,'两期/规模比较需两个同实体数值')
                if d['schema_version']>=4 and len({item.get('scope',item['dimensions']['segment']) for item in ms})>1:issue(p,'图表范围不一致')
                if typ=='breadth' and any(item['unit']!='家' or item.get('value') is not None and (item['value']<0 or int(item['value'])!=item['value']) for item in ms):issue(p,'广度需非负整数家数')
                continue
            from calculations import comparison_errors
            if typ=='breadth':ms=[dict(metric,category=item.get('category')) for metric,item in zip(ms,c.get('items',[]))];comparison='parts_of_whole'
            for error in comparison_errors(ms,comparison,c.get('known_sample',False)):issue(p,error)
            if typ=='breadth' and any(x['unit'] not in ('家','只','个') or (x.get('value') is not None and (x['value']<0 or int(x['value'])!=x['value'])) for x in ms):issue(p,'广度需非负整数计数')


def fixed_comparison(d,pack,issue,r):
    changes=[]
    for group in ('sources','facts','series','metrics','evidence','calendars'):
        base={x['id']:x for x in pack.get(group,[])};current={x['id']:x for x in d.get(group,[])}
        for ident in sorted(set(base)|set(current)):
            old=base.get(ident);new=current.get(ident)
            if group=='metrics' and old is None and new['op']!='observed':continue
            if group=='sources':
                old={k:v for k,v in old.items() if k!='verification'} if old else None
                new={k:v for k,v in new.items() if k!='verification'} if new else None
            if old==new:continue
            change=dict(group=group,id=ident,kind='added' if old is None else 'excluded' if new is None else 'corrected',
                        before_sha256=fingerprint(old) if old is not None else None,after_sha256=fingerprint(new) if new is not None else None)
            changes.append(change)
            declared=next((x for x in d.get('evidence_differences',[]) if all(x.get(k)==v for k,v in change.items())),None)
            if not declared:issue('fixed_pack.'+group+'.'+ident,'证据层与原包不同且无精确差异记录')
    r['comparison']=dict(valid_same_input=not changes,changes=changes)


def assess(d,maps,r,contract,issue,previous=None):
    critical_claims=set();important_facts=set();important_metrics=set()
    if d['schema_version']>=7:
        if d['meta']['title'].startswith('每日关注简报'):
            issue('meta.title','综合标题仍是初始模板名','insufficient_data')
        summaries=[re.sub(r'\s+','',row['text']) for row in d['summary']]
        if len(summaries)!=len(set(summaries)):
            issue('summary','摘要逐字重复，需要综合取舍','insufficient_data')
        for article in d['articles']:
            if article.get('relevance') and article['relevance'].strip()==article['text'].strip():
                issue('articles.'+article['id']+'.relevance','意义字段逐字复制正文，无新增解释','insufficient_data')
    for item in d['summary']+d['actions']:
        critical_claims.update(item['claim_ids']);important_facts.update(item['fact_ids'])
    for change in d.get('changes',[]):critical_claims.update(change['claim_ids'])
    for item in d['observations']:
        critical_claims.update(item['claim_ids']);important_facts.update(item['fact_ids']);important_facts.update(item['consensus_fact_ids'])
    from research import has_report_reference
    detected_events=r.get('delta',{}).get('detected',{})
    for event in d.get('research_events',[]):
        if event['importance']>=5 and (d['schema_version']>=6 or event['status'] in ('confirmed','corrected','withdrawn')) and (
                event.get('reported',False) or event['event_key'] in detected_events):
            critical_claims.update(event['claim_ids'])
    def text_metrics(value):
        if isinstance(value,str):important_metrics.update(TOKEN.findall(value))
        elif isinstance(value,list):
            for x in value:text_metrics(x)
        elif isinstance(value,dict):
            for x in value.values():text_metrics(x)
    for group in ('summary','articles','analyses','actions','observations'):text_metrics(d[group])
    analysis_claims={}
    for a in d['analyses']:
        cs={x for ids in a['field_claims'].values() for x in ids}
        cs.update(x for h in a['horizons'].values() for x in h['claim_ids'])
        cs.update(x for l in a['leaders'] for x in l['claim_ids'])
        analysis_claims[a['id']]=cs;critical_claims.update(cs);important_facts.update(a['fact_ids'])
        for edge in a['mechanism']:important_facts.update(edge['fact_ids'])
        for leader in a['leaders']:
            important_facts.update(leader['fact_ids'])
            important_facts.update(x for ids in leader['role_evidence'].values() for x in ids)
            important_facts.update(leader.get('industry_basis',{}).get('fact_ids',[]))
    for item in d['summary']+d['articles']:
        for aid in item['analysis_ids']:critical_claims.update(analysis_claims.get(aid,()))
        important_facts.update(item['fact_ids'])
        critical_claims.update(item['claim_ids'])
    important_metrics.update(d['meta'].get('featured_metrics',[]))
    for chart in d['charts']:
        if chart['placement']=='overview' or d['schema_version']>=4:
            important_metrics.update(x['metric_id'] for x in chart.get('items',[]))
            important_metrics.update(mid for row in chart.get('rows',[]) for mid in row['metric_ids'])
            important_metrics.update(x[k] for x in chart.get('points',[]) for k in ('x_metric','y_metric'))
    for cid in critical_claims:
        claim=maps['claims'].get(cid)
        if claim:important_facts.update(claim['fact_ids']);important_metrics.update(claim['metric_ids'])
    important_facts.update(x['id'] for x in d['facts'] if x['core'])
    def evidence_ok(ids):
        for eid in ids:
            e=maps['evidence'].get(eid)
            if e and e['read_method'] in (('original','cached','search_summary') if d['schema_version']>=6 else ('original','cached')):
                source=maps['sources'].get(e['source_id'])
                if source and source['read_status'] in ('full','partial') and source['vintage']['available_at'] and source['vintage']['id']!='unknown':
                    return True
        return False
    weak_events=[event['event_key'] for event in d.get('research_events',[])
                 if event.get('reported',False) and has_report_reference(d,event) and event['importance']>=5 and not evidence_ok(event['evidence_ids'])]
    for key in weak_events:issue('research_events.'+key,'重大事件缺少可核验的原文版本，不可视作已确认增量','insufficient_data')
    badfacts={fid for fid in important_facts if fid in maps['facts'] and
              (not evidence_ok(maps['facts'][fid]['evidence_ids']) or not maps['facts'][fid]['available_at'] or (d['schema_version']<6 and maps['facts'][fid]['status'] in ('unverified','conflicted')))}
    badmetrics=set();seen=set()
    def metric_ok(mid):
        if mid in seen:return mid not in badmetrics
        seen.add(mid);metric=maps['metrics'].get(mid)
        if not metric:return False
        if metric['op']=='observed':
            good=evidence_ok(metric.get('evidence_ids',[])) and bool(metric.get('available_at'))
            if d['schema_version']>=5:
                from research import metric_support
                good=good and metric_support(metric,maps['evidence'],d['schema_version'])
        elif metric['op'] in SERIES_OPS:
            good=True
            for key in ('series_id','benchmark_id'):
                if key in metric:
                    s=maps['series'].get(metric[key]);good=bool(s) and evidence_ok(s['evidence_ids']) and good
        else:good=all(metric_ok(x) for x in inputs(metric))
        if not good or r['values'].get(mid) is None:badmetrics.add(mid)
        return good
    for mid in (maps['metrics'] if d['schema_version']>=5 else important_metrics):metric_ok(mid)
    for fid in sorted(badfacts):issue('facts.'+fid,'重要结论依赖此事实，但原文片段/时点/真实性状态未就绪；core=false不豁免','insufficient_data')
    for mid in sorted(badmetrics):issue('metrics.'+mid,'重要数值证据未就绪','insufficient_data')
    obligations_list=contract['coverage_obligations'] if contract else (legacy_obligations(d['meta']['profile'],d['meta']['scope'])
        if d['schema_version']==2 else obligations(d['meta']['profile'],d['meta']['scope'],d['meta'].get('edition')))
    obligations_map={x['id']:x for x in obligations_list}
    covered=set()
    from research import coverage_attempts
    complete_windows={};coverage_levels={}
    for c in coverage_attempts(d['coverage']):
        from urllib.parse import urlsplit
        valid_mapping=True
        for oid in c['obligation_ids']:
            if oid not in obligations_map:issue('coverage.'+c['id'],'未知覆盖义务: '+oid);valid_mapping=False
            elif c['method']=='original_index' and obligations_map[oid]['url']:
                expected=urlsplit(obligations_map[oid]['url']);actual=urlsplit(c['url'])
                host=expected.hostname.removeprefix('www.')
                expected_path=expected.path.rstrip('/')
                path=actual.path.rstrip('/')
                channel=obligations_map[oid].get('channel')
                path_ok=path==expected_path or (channel=='official_news' and path.startswith(expected_path+'/'))
                if actual.hostname.removeprefix('www.')!=host or (channel in ('official_news','official_social') and not path_ok):
                    issue('coverage.'+c['id'],'入口角色/账号不匹配；同一域名不代表覆盖全部渠道');valid_mapping=False
            if oid in obligations_map and obligations_map[oid].get('channel')=='official_social':
                if c['method']=='aggregate' or (c['status']=='checked_none' and c.get('direct_access')!='available'):
                    issue('coverage.'+c['id'],'社交替代索引不能证明无发布；保留未覆盖窗口','insufficient_data');valid_mapping=False
        for oid in c['obligation_ids']:
            coverage_levels.setdefault(oid,set()).add('targeted_search' if c['method']=='search' else 'cache_reused' if c['method']=='cache' else c['status'])
        if d['schema_version']>=4 and (not c.get('content_scope') or not evidence_ok(c['mapping_evidence_ids'])):valid_mapping=False
        if d['schema_version']>=5:
            from research import window_verified
            if not window_verified(c,d):valid_mapping=False
        if c['status'] in ('checked_new','checked_none') and c['method'] in ('original_index','aggregate'):
            if valid_mapping and c['checked_at'] and iso(c['checked_at'])>=iso(c['window_end']):
                for oid in c['obligation_ids']:complete_windows.setdefault(oid,[]).append((iso(c['window_start']),iso(c['window_end'])))
            if valid_mapping and c['checked_at'] and iso(c['checked_at'])>=iso(d['meta']['cutoff']) and iso(c['window_start'])<=iso(d['meta']['window_start']) and iso(c['window_end'])>=iso(d['meta']['cutoff']):
                covered.update(c['obligation_ids'])
    for oid,windows in (complete_windows.items() if d['schema_version']>=4 else []):
        end=iso(d['meta']['window_start'])
        for start,stop in sorted(windows):
            if start<=end:end=max(end,stop)
        if end>=iso(d['meta']['cutoff']):covered.add(oid)
    bounded_discovery=(contract or {}).get('research_workflow_version',4 if d['schema_version']>=7 else 0)>=4
    missing=[] if bounded_discovery else [x for x in obligations_list if x['critical'] and x['id'] not in covered]
    local={}
    for a in d['analyses']:
        reasons=[]
        required_fields=[key for key in FIELD_CLAIMS if key in a] if a.get('format')=='compact' else FIELD_CLAIMS
        if any(not a['field_claims'].get(k) for k in required_fields):reasons.append('重要分析字段没有具体主张支持')
        if any(not h['claim_ids'] for h in a['horizons'].values()):reasons.append('三期限未分别建立证据')
        if set(a['fact_ids'])&badfacts:reasons.append('重要事实证据不足')
        if a['gaps'] or any(x['critical'] for x in a['limitations']):reasons.append('本主题存在关键缺口')
        for cid in analysis_claims[a['id']]:
            c=maps['claims'].get(cid)
            if c and (set(c['fact_ids'])&badfacts or set(c['metric_ids'])&badmetrics or any(g['critical'] for g in c['limitations'])):reasons.append('主张依赖或关键缺口未解决')
        local[a['id']]=dict(status='limited' if reasons else 'assessed',reasons=list(dict.fromkeys(reasons)))
    review=d['review'];review_ok=(review['status']!='not_reviewed' and important_facts<=set(review['checked_fact_ids'])
            and critical_claims<=set(review['checked_claim_ids']) and set(maps['analyses'])<=set(review['checked_analysis_ids'])
            and not any(x['severity']=='blocking' and not x['resolved'] for x in review['issues']))
    near=False
    for a in d['actions']:
        try:
            if not a.get('observe_at'):continue
            at=iso(a['observe_at']);cutoff=iso(d['meta']['cutoff'])
            if d['schema_version']>=5:
                from research import near_action
                near=near or near_action(a,d)
                continue
            # A next-calendar-day condition is necessarily within the next three
            # sessions. Longer spans require a sourced session calendar.
            if cutoff<=at<=cutoff+timedelta(days=1):near=True
            cal=maps['calendars'].get(a.get('calendar_id'))
            if cal:
                sessions=[s for s in cal['sessions'] if cutoff<=iso(s['close_at'])]
                if sessions and at<=iso(sessions[min(2,len(sessions)-1)]['close_at']) and at>=cutoff:near=True
        except ValueError:pass
    reasons=[]
    ungrounded=[cid for cid in critical_claims if cid in maps['claims'] and not (maps['claims'][cid]['fact_ids'] or maps['claims'][cid]['metric_ids'])]
    if ungrounded or not (important_facts or important_metrics) or not d['sources'] or not d['evidence']:reasons.append('重要主张没有实质证据基线：'+', '.join(ungrounded))
    unverified_claims=[cid for cid in critical_claims if cid in maps['claims'] and
                       (maps['claims'][cid]['status'] in ('unknown','unverified','conflicted') or
                        any(g['critical'] for g in maps['claims'][cid]['limitations']))]
    if unverified_claims and d['schema_version']<6:reasons.append('重要主张含未知判断或关键证据限制')
    unreported_important=[event['event_key'] for event in d.get('research_events',[])
        if event['importance']>=5 and (d['schema_version']>=6 or event['status'] in ('confirmed','corrected','withdrawn'))
        and event['event_key'] in detected_events and not event.get('reported') and (event.get('reporting_disposition') not in ('retained_pending','excluded')
             or len(event.get('reporting_reason','').strip())<8 or not event['claim_ids'])]
    if unreported_important:reasons.append('重大候选未报告且缺少经过审阅的待报/排除理由')
    if any(w['path'].startswith('series.') and '滞后' in w['message'] for w in r['warnings']):reasons.append('当前行情存在时效限制')
    if missing:reasons.append('必查覆盖尚缺'+str(len(missing))+'项')
    if d['schema_version']>=5:
        pending_events=[article for article in d['articles'] if article.get('content_role')=='news' and article.get('disposition')!='excluded' and (article.get('disposition')=='pending' or not article.get('text') or not article.get('fact_ids') or (d['schema_version']<7 and not (article.get('interpretation') or (d['schema_version']>=6 and article.get('relevance') and article.get('unknowns')))))]
        if pending_events:reasons.append('保留的重要事件尚缺可见事实或必要审阅：'+str(len(pending_events))+'项')
        if any(warning['path'].startswith('articles.') for warning in r['warnings']):reasons.append('正文编辑复核尚未完成')
        completion=r.get('research_completion',{})
        if d['schema_version']>=6:
            from editorial import reportable
            pending_events=[a for a in d['articles']
                if a.get('content_role') in ('news','continuing_event')
                and a.get('disposition','retained')=='retained'
                and (not reportable(d,a) or not a.get('text') or not a.get('fact_ids')
                     or (d['schema_version']<7 and not (a.get('interpretation')
                         or (a.get('relevance') and a.get('unknowns')))))]
            completion['research_goals_met']=bool(completion.get('complete') and not pending_events and review_ok and not unreported_important)
        else:completion['research_goals_met']=bool(completion.get('complete') and not missing and not badfacts and not badmetrics and not pending_events and (near or d['meta'].get('edition')=='intraday'))
        completion['complete']=completion['research_goals_met']
    if d['gaps']:reasons.append('全局资料缺口')
    if any(x['status']=='limited' for x in local.values()):reasons.append('部分主题未完成研究目标')
    if d['schema_version']<6 and (not d['analyses'] or not d['actions'] or not near):reasons.append('缺少完整主题研究或当日至3交易日观察条件')
    if badfacts or badmetrics:reasons.append('重要证据未就绪')
    if weak_events:reasons.append('重大事件原文证据未就绪')
    if not review_ok:reasons.append('研究审阅尚未覆盖依赖闭包')
    if d['schema_version']>=4 and not r.get('research_completion',{}).get('complete'):reasons.append('本期研究模块尚未完成或明确受阻')
    if d['meta']['evidence_mode']=='fixed_pack':reasons.append('固定资料实验不代表独立联网完整覆盖')
    requested=d['meta']['requested_grade']
    grade='draft' if not review_ok or requested=='draft' else ('limited' if (missing and d['schema_version']<7) or unreported_important or not r.get('research_completion',{}).get('complete') else 'full') if d['schema_version']>=6 else 'observation' if not d['analyses'] or not d['actions'] else 'limited' if reasons else 'full'
    if d['schema_version']>=7 and grade=='full' and (badfacts or badmetrics or weak_events or pending_events or unverified_claims or any(w['path']=='meta.title' for w in r['warnings'])):
        grade='limited'
    if d['schema_version']>=3 and d['meta'].get('edition')=='intraday':
        if review['status']=='not_reviewed' or requested=='draft':grade='draft'
        elif missing or d['gaps'] or badfacts or badmetrics or weak_events or ungrounded or unverified_claims or unreported_important or not review_ok or d['meta']['evidence_mode']=='fixed_pack':grade='partial_coverage'
        else:grade='incremental_verified' if (contract or {}).get('baseline') else 'first_observation'
        reasons=[reason for reason in reasons if reason!='缺少完整主题研究或当日至3交易日观察条件']
    if requested in ('limited','observation') and grade=='full':grade=requested
    r['delivery']=dict(grade=grade,requested_grade=requested,reasons=reasons,analysis_status=local,
                       coverage=dict(required=len(obligations_list),covered=len([x for x in obligations_list if x['id'] in covered]),covered_ids=sorted(covered),missing=missing,levels={key:sorted(value) for key,value in coverage_levels.items()}),
                       review_status=review['status'],review_scope_satisfied=review_ok,
                       visual_status=d.get('visual',{}).get('status','not_performed'),structural_pass=not r['errors'],
                       research_truth_certified=False)
    if d['schema_version']>=5:
        coverage=r['delivery']['coverage']
        coverage.update(required=0 if bounded_discovery else sum(bool(item['critical']) for item in obligations_list),
            total=len(obligations_list),covered=0 if bounded_discovery else
            sum(item['critical'] and item['id'] in covered for item in obligations_list),
            optional_total=len(obligations_list) if bounded_discovery else sum(not item['critical'] for item in obligations_list),
            optional_covered=len(covered) if bounded_discovery else
            sum(not item['critical'] and item['id'] in covered for item in obligations_list))
        r['evidence_quality']=dict(unready_fact_ids=sorted(badfacts),unready_metric_ids=sorted(badmetrics),verification='mechanical_support_only')
    if d['schema_version']>=3:
        from research import project
        projected=project(previous,d,'validation_projection',r)
        if projected['overflow_important']:
            r['delta']['overflow_notice']=projected['overflow_notice']
            r['delivery']['reasons'].append(projected['overflow_notice'])
    r['dependency_closure']=dict(claim_ids=sorted(critical_claims),fact_ids=sorted(important_facts),metric_ids=sorted(seen))
    r['unready_metrics']=sorted(badmetrics)
