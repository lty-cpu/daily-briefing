# 正常研究输入（schema7）

执行顺序是 `start自动基础取数 → 五域发现并submit小批量 → 入选公司用data补数 → compute → 一次综合review → finish`。密度、准入、停止和摘要口径以[统一编辑规则](editorial.md)为准；status的下一步优先于重复读规范。命令为 `python <skill>/scripts/run.py submit --run-id <ID> --run-token <TOKEN> --input <UTF-8 JSON文件>`；`{"packets":[...]}`原子提交，失败不部分写入。每个packet都写kind、task及稳定alias；观察用task:themes，审阅用task:synthesis。refs只接受回执别名或事实/指标/证据ID，来源ID不代表已读片段；需要具体对象时用inspect。

## 来源、消息与窗口

每个来源登记可识别发布者、原始链接、真实发布时间或日期、实际读取时间、实际已见的片段和定位。时间及报道边界按[统一编辑规则](editorial.md#准入与措辞)判断。来源 kind 用 official/company/media/data/public_account，`read_method` 用 original/cached/search_summary；只读搜索摘要就标搜索摘要。以下形状示例不得当成真实新闻复用：

```json
{"task":"official","kind":"event","alias":"policy_notice","section":"news","entity_id":"ORG_X","subject":"政策事项","title":"机构X公布政策事项","fact_text":"机构X公布了拟议政策事项，尚待审批。","text":"机构X公布拟议政策，实施仍取决于后续审批。","status":"confirmed","proposition":"publication","stage":"拟议","unknowns":"核对正式批准及生效文件","source":{"title":"政策原文标题","publisher":"机构X","url":"https://example.org/notice","published_at":"2026-09-24T10:00:00+08:00","retrieved_at":"2026-09-24T11:00:00+08:00","version":"首版","kind":"official","read_status":"full","read_method":"original","locator":"正文第2段","quote":"拟议事项须经审批后实施","context":"该段说明的是计划，不是已执行结果"}}
```

`fact_text` 是证据支持的事实命题；`text` 是读者可见正文，先写主体、事项、关键数字/阶段。独立影响确有增量才填 `interpretation` 或 `relevance`。事项发生须在同一原文确实支持时写 `proposition:"occurrence", occurrence_evidence:"current", verification_at:<实际核验时间>`，程序将 current 绑定本条证据ID。媒体报道与窗口完整性口径见[统一编辑规则](editorial.md#准入与措辞)。高重要候选应在 event 或 task 中说明采用、待核或排除及原因。

同一事件后续确认、更正、否认用稳定 `event_identity={entity,subject,family,release_id,version,attributes,importance,next_check,aliases?}`；新来源不能仅因URL或标题变化生成另一个业务事件。改正时用 `novelty:"correction"` 和来源 `source_basis:"correction"`（否认用 `denial`），旧表述保留在可展开历史，主文显示当前版本。`content_role` 是 news/continuing_event/context/financial_baseline；旧财报用 financial_baseline，不能伪装本期新闻。`domain` 独立于 `section`；国内央行是 cn_official，海外变量明确写 overseas，AI 明确写 ai。

有界来源扫描可用 `kind:"window"`，包含 `obligations,url,status,method,checked_at,window_start,window_end,content_scope,note,refs`；状态含义见[统一编辑规则](editorial.md#广度产物和停止条件)。`kind:"index"` 来源只代表已读列表，不自动创造财经事实。任务结果 `result:{status,current_conclusion,next,stop_reason?}`；`blocked` 要有失败尝试，`budget_stop` 只在真实预算到限时用。每次工具尝试可附 `attempt:{at,query_or_url,result,status,evidence_ids,tool_ref}`。

## 数值与更正

`kind:"market"` 的 `rows` 每行写 entity_id、label、value（缺失用 null，0 不等于缺失）、unit、currency、scale、period、as_of、scope、measure、alias。每个观测引用实际 source/evidence，图表只用同口径有效值。市场同一观测的身份由主体、指标、期间/时点、样本与价格口径决定，换 packet alias 不生成第二张卡。不同来源值冲突不能自动并入确定值；核实后用 `update:"correction"`、`correction_reason` 和新的证据提交，保留旧版更正记录。`support:{status:"reviewed",locator,quote,note}` 需说明主体、期间、单位/表头和数值；程序绑定本值、单位、指标、证据版本，改值或改证据后须重新核对。单位转换用 `conversion:{raw_value,raw_unit,raw_scale,evidence_id,entity,period,measure}`，原值须在真实片段中；原表行与表头可由 context 辅助，不用捏造单行全包含。

市场任务的measure用`index_change`（指数日涨跌）、`turnover`（成交额）、`breadth`（同一明确样本的涨跌广度）；breadth的category区分up/down/flat。变化型指标按原文涨跌方向解释数值，“收跌1.22%”可支持-1.22，无需额外signed开关；复核引用须含方向词。同一数值、同一证据重提support或signed会更新复核信息，不新增观测；改变值或证据仍须重新审核。基础行情和公司补数见[有界历史补齐](history-data.md)。宏观任务独立取得海外利率、汇率或能源变量；缺历史不造趋势。

## 深主题、观察和综合编辑

有独立影响才解释普通消息；入选深主题使用 `kind:"thesis",task:"themes"`，元信息填alias、theme、thesis（稳定主题与判断标识）、sector、title、review_at、expires_at、why_this。正常聚焦格式只需 `blocks` 的 `judgment,mechanism,alternative,support,invalidation`，每项 `{text,refs}`。三个期限填 `horizons.intraday/short/medium` 的 `conclusion,direction,refs,next_observation,review_at,confidence`，只写期限差异；direction用positive/negative/mixed/neutral/unknown，confidence用high/medium/low/unknown。比较与选题标准见[统一编辑规则](editorial.md#两层密度)。旧十字段compact仅供旧运行与特殊迁移。

主题的验证条件只在support/invalidation两个block中写一次，必须包含可区分解释的后续结果。`observe:{trigger,target,baseline,decision_if}`四项均为文字；target写核对对象与来源，baseline写事实基准，decision_if只写据共用条件如何调整研究判断，不再建立另一套条件。程序生成关联行动。近期会话用session_offset:1表示下一已核验会话（0为目标日），可加delay_minutes:30在收盘后复核；程序复用报告calendar生成observe_at。已知具体时点也可直接传observe_at/calendar_id；缺日历或未公布日程时保留事件触发，不虚构日期。

非共识与待验证候选按[编辑规则](editorial.md#两层密度)筛查。主题已有合格线索时，在observe中加 `watch:{title,question}`，观察栏引用同一行动。单独提交的observation必填kind、task:themes、alias、title、divergence（未决问题）和refs；另外二选一：有主题则写action_ref（主题别名或行动ID），无主题则写expectation（事实基准）、mechanism、materiality、opposition和test（时点/触发、来源、支持与削弱结果）。同一问题选一种入口，后续同action_ref更新现有卡。默认watch；有公开预期证据才用contrarian与consensus_refs。无合格观察时，observation_review记录已查范围或受阻原因，不能因已有主题就判空。

最后用 `kind:"review",task:"synthesis"` 提交headline、summary:[{text,refs}]、实际已审的reviewed、reviewer/method/status；审阅范围与补审方法以[发布前研究审阅](review-and-evaluation.md)为准。featured引用指标别名或ID，普通备用数据无需列入正文。`finish --preview`只读校验，不消耗正式尝试；正式归档用finish。needs_research按具体缺口补证，needs_review按对象补审，沿用同一任务时钟。
