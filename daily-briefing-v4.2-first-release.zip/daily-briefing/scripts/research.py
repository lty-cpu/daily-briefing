"""Compact cumulative research state within each committed report snapshot."""
import copy
import re
import unicodedata
from datetime import timedelta
from common import fingerprint, iso

STATE_VERSION=3
MAX_EVENTS=200

WORK_PACKAGES=(
    ('market','先取得本期指数、成交额和口径明确的广度；再查少量重点对象历史','market 数值表',1),
    ('companies','先读取本期交易所公告候选，再核验金额或盈利影响最大的公司及最近财务基准','company 公告与基准，或有证据的窗口无重要公告',1),
    ('official','扫描中国官方指定栏目及重大地缘/Fed/AI入口；重要候选逐条处置','event 原文与 window 窗口记录',2),
    ('macro','取得本期利率、汇率或大宗变量并解释传导，不用AI新闻代替','market 宏观数值及 event 传导解释',2),
    ('themes','比较重点对象、业务敞口、量级、竞争解释及三个期限差异','thesis 逐项判断与证据',2),
    ('synthesis','形成综合判断、验证条件，复核证据并选择图表','review 摘要、证据审阅与展示选择',3),
)
WORK_PACKAGES_SOL=(
    ('market','取得截止前可得的指数、成交额和明确样本的市场广度','market 截面与来源',1),
    ('official','有界发现中国官方与重要地缘消息，逐条记录重要候选的去向','event 消息与 window 范围',1),
    ('companies','取得交易所公告候选并核对最重要公司的变化和财务基准','company 消息与基准',1),
    ('macro','独立取得海外利率、汇率或能源变量及传导；国内央行不抵扣此任务','overseas 数值或消息',1),
    ('ai','独立扫描主要AI厂商的新闻、社交与产品入口并记录候选','AI 消息与 window 范围',1),
    ('themes','基于候选比较通常两条主线，安静日可有据少选','focused thesis 或筛选说明',2),
    ('synthesis','一次综合编辑：标题、摘要、近期观察及有目标的核验','review 综合稿与审阅',3),
)


def _quote_value(value, quote, directional=False):
    """Match signed changes using the direction adjacent to the selected number."""
    from decimal import Decimal, InvalidOperation
    expected=Decimal(str(value))
    for match in re.finditer(r'[-+−]?\d[\d,]*(?:\.\d+)?',quote):
        try:
            raw=match.group().replace(',','').replace('−','-')
            number=Decimal(raw)
            if directional:
                prefix=quote[max(0,match.start()-16):match.start()]
                direction=re.search(r'(收跌|下跌|下降|减少|跌幅|降幅|回落|下滑|收涨|上涨|上升|增加|涨幅|升幅|涨|跌)\s*(?:了|为|约|达)?\s*$',prefix)
                if direction:
                    if re.search(r'(?:未|没有|并非|不曾)\s*$',prefix[:direction.start()]):continue
                    sign=-1 if direction[1] in ('收跌','下跌','下降','减少','跌幅','降幅','回落','下滑','跌') else 1
                    if raw[0] in '+-':
                        if number*sign<0:continue
                    else:number*=sign
            if number==expected:return True
        except InvalidOperation:pass
    return False


def metric_support(metric,evidence,schema_version=6):
    from common import num
    if not num(metric.get('value')):return False
    support=metric.get('support',{})
    if support.get('status')=='needs_review':return False
    # A selected API row is itself the numerical source. Its field and unit
    # conversion are checked against the retained row, without a web quote.
    if support.get('note','').startswith('{"api_field"'):
        import json
        try:
            spec=json.loads(support['note']);field=spec['api_field'];factor=spec['raw_factor']
            if not num(factor):return False
            for ident in metric.get('evidence_ids',[]):
                item=evidence.get(ident,{})
                if not item.get('locator','').startswith(('index_daily:','daily:','daily_basic:',
                     'income:','cashflow:','balancesheet:','us_tycr:','sw_daily:','ths_daily:')):continue
                row=json.loads(item['quote']);raw=row.get(field)
                if num(raw) and abs(raw*factor-metric['value'])<=max(1e-8,abs(metric['value'])*1e-10):
                    return True
        except (ValueError,TypeError,KeyError):return False
        return False
    audit=support.get('audit')
    if audit:
        dimensions=metric['dimensions']
        expected=dict(value=metric['value'],unit=metric['unit'],entity_id=dimensions['entity_id'],
                      period=dimensions['period'],measure=dimensions['measure'],
                      evidence_hash=fingerprint(evidence[metric['evidence_ids'][0]]) if metric.get('evidence_ids') and metric['evidence_ids'][0] in evidence else '')
        if audit!=expected:return False
    snippets=[evidence[ident]['quote'] for ident in metric.get('evidence_ids',[]) if ident in evidence and evidence[ident]['read_method'] in ('original','cached')]
    conversion=metric.get('conversion')
    if conversion:
        from decimal import Decimal
        from calculations import AMOUNT_SCALES
        if conversion['raw_unit'] in AMOUNT_SCALES and conversion['raw_scale']!=AMOUNT_SCALES[conversion['raw_unit']]:return False
        if metric['unit'] in AMOUNT_SCALES and metric['dimensions']['scale']!=AMOUNT_SCALES[metric['unit']]:return False
        e=evidence.get(conversion['evidence_id'],{})
        if conversion['evidence_id'] not in metric.get('evidence_ids',[]):return False
        quote=e.get('quote','').replace(',','')
        raw=Decimal(str(conversion['raw_value']))
        tokens=[Decimal(m.group().replace('−','-')) for m in re.finditer(r'[-+−]?\d+(?:\.\d+)?',quote)]
        anchors=(conversion['raw_unit'],conversion['entity'],conversion['period'],conversion['measure'])
        if raw not in tokens or not all(a in quote for a in anchors):return False
        return abs(raw*Decimal(str(conversion['raw_scale']))/Decimal(str(metric['dimensions']['scale']))-Decimal(str(metric['value'])))<Decimal('0.00000001')
    if support.get('status')=='reviewed':
        if not (support.get('locator') and support.get('note') and any(support['quote'] in snippet for snippet in snippets)):
            return False
        if not audit:return schema_version<7  # Old snapshots retain their review contract.
        snippets=[support['quote']]
    directional=metric.get('signed',False) or (schema_version>=7 and
        metric.get('dimensions',{}).get('measure') in ('index_change','sector_change','return','price_change'))
    return any(_quote_value(metric['value'],snippet,directional) for snippet in snippets)


def window_verified(entry,document):
    if entry['status'] not in ('checked_new','checked_none') or entry['method'] not in ('original_index','aggregate'):return False
    if not entry.get('checked_at') or iso(entry['checked_at'])<iso(entry['window_end']):return False
    sources={source['id']:source for source in document['sources']}
    evidence={item['id']:item for item in document['evidence']}
    if not entry.get('content_scope') or not entry['mapping_evidence_ids']:return False
    for ident in entry['mapping_evidence_ids']:
        item=evidence.get(ident,{})
        source=sources.get(item.get('source_id'),{})
        if document['schema_version']>=6 and source.get('usage')=='discovery' and source.get('vintage',{}).get('available_at') and iso(source['vintage']['available_at'])>iso(entry['window_end']):return False
        if item.get('read_method') not in ('original','cached') or source.get('read_status') not in ('full','partial') or not source.get('vintage',{}).get('available_at'):return False
    if document['schema_version']>=5:
        scan=entry.get('index_scan',{})
        if not scan.get('complete') or not scan.get('boundary') or not scan.get('checked_through'):return False
        if iso(scan['checked_through'])<iso(entry['window_end']):return False
    return True


def near_action(action,document):
    if not action.get('observe_at'):return False
    cutoff=iso(document['meta']['cutoff']);at=iso(action['observe_at'])
    if document['schema_version']<5:return cutoff<=at<=cutoff+timedelta(days=1)
    calendar=next((item for item in document['calendars'] if item['id']==action.get('calendar_id')),None)
    if not calendar or not calendar['complete'] or not calendar['source_ids'] or not calendar['evidence_ids']:return False
    if calendar.get('synthetic') and document['meta']['mode']!='teaching':return False
    from common import get_zone
    zone=get_zone(calendar['timezone']);day=cutoff.astimezone(zone).date().isoformat()
    # A post-close check belongs to that session too; it need not precede the close.
    sessions=[item for item in sorted(calendar['sessions'],key=lambda item:item['date']) if item['date']>=day][:3]
    if not any(s['date']==day and at.astimezone(zone).date().isoformat()==day for s in sessions):
        sessions=[item for item in sorted(calendar['sessions'],key=lambda item:item['date']) if iso(item['close_at'])>=cutoff][:3]
    return action.get('horizon')!='medium' and at>=cutoff and any(item['date']==at.astimezone(zone).date().isoformat() for item in sessions)


def task_plan(contract):
    if contract.get('edition')=='intraday':
        packages=[('sentinel','扫描重大事件入口及相对同日已报基线的变化；无变化需窗口证据','window / event；复用 changes 协议',1),
                  ('synthesis','复核本轮变化与下一观察，保持简短','review',2)]
    else:
        packages=list(WORK_PACKAGES_SOL if contract.get('research_workflow_version',0)>=3 and contract.get('mode')!='teaching' else WORK_PACKAGES)
        scope=contract.get('scope',[])
        if contract.get('profile')!='finance-ai':
            packages=[item for item in packages if item[0] not in ('market','companies','macro','ai') or
                      (item[0] in ('market','companies') and 'A股' in scope) or (item[0]=='macro' and any(value in scope for value in ('宏观','全球宏观')))]
            packages=[item for item in packages if item[0]!='ai' or 'AI' in scope]
    return [dict(id=key,question=question,priority=priority,target_evidence=product,current_conclusion='',
                 next=question,stop_reason='',status='planned',attempts=[],evidence_ids=[],product_ids=[])
            for key,question,product,priority in packages]


def coverage_attempts(entries):
    return [attempt for entry in entries for attempt in entry.get('attempts',[entry])]


def coverage_view(entries,window_start=None,window_end=None):
    groups={}
    for entry in entries:
        for obligation in entry['obligation_ids']:
            key=(obligation,entry.get('role','discovery'),window_start or entry['window_start'],window_end or entry['window_end'])
            group=groups.setdefault(key,[])
            for attempt in entry.get('attempts',[entry]):
                item=copy.deepcopy(attempt)
                item.pop('attempts',None);item.pop('role',None)
                item['obligation_ids']=[obligation]
                if item not in group:group.append(item)
    result=[]
    for key,attempts in groups.items():
        attempted=[item for item in attempts if item['status']!='not_checked']
        attempts=attempted or attempts
        representative=max(attempts,key=lambda item:(item['checked_at'] or '',item['status']=='failed'))
        row=copy.deepcopy(representative)
        row.update(id='cov_'+fingerprint(key)[:16],role=key[1],attempts=attempts)
        states={item['status'] for item in attempts}
        if len(states)>1:row['note']='多次尝试并存：'+ '；'.join(dict.fromkeys(item['note'] for item in attempts))
        result.append(row)
    return result


def task_progress(document,contract):
    tasks=document.get('tasks',[]);modern=document.get('schema_version',2)>=6
    # Earlier v4 revision claims omitted the workflow marker from their locked
    # request. Schema 7 revisions still use the v4 bounded research contract.
    workflow_version=contract.get('research_workflow_version',4 if document['schema_version']>=7 else 0)
    sol_protocol=workflow_version>=3 and contract.get('mode')!='teaching'
    bounded_discovery=workflow_version>=4 and contract.get('mode')!='teaching'
    if document.get('schema_version',2)<4:return dict(complete=True,tasks=[],pending=[],stop_reasons=[],next_actions=[])
    by_id={item['id']:item for item in tasks}
    evidence={item['id']:item for item in document['evidence']}
    sources={item['id']:item for item in document['sources']}
    def grounded(ids):
        return bool(ids) and all(ident in evidence and evidence[ident]['read_method'] in (('original','cached','search_summary') if modern else ('original','cached')) and
                                sources.get(evidence[ident]['source_id'],{}).get('read_status') in ('full','partial') for ident in ids)
    def usable(metric):
        available=metric.get('available_at')
        return metric.get('value') is not None and available and iso(available)<=iso(contract['initial_cutoff']) and grounded(metric['evidence_ids']) and (document['schema_version']<5 or metric_support(metric,evidence,document['schema_version']))
    products={item['id']:item for group in ('articles','metrics','analyses','coverage','changes','observations') for item in document[group] if 'id' in item}
    result=[]
    for planned in task_plan(contract):
        item=copy.deepcopy(by_id.get(planned['id'],planned))
        key=item['id'];ids=item['product_ids'];reason=''
        attempts=item['attempts']
        recorded=bool(attempts) and all(attempt.get('query_or_url') and attempt.get('result') for attempt in attempts)
        completed=item['status'] in ('done','verified_none')
        if completed:
            if not recorded or not grounded(item['evidence_ids']):reason='完成声明缺少可核验尝试与原文记录'
            elif key in ('market','macro') and item['status']=='done':
                numeric=[products[ident] for ident in ids if ident in products and products[ident].get('op')=='observed' and products[ident].get('value') is not None]
                if document['schema_version']>=7:
                    domain='overseas' if key=='macro' else 'cn_market'
                    seen={metric['id'] for metric in numeric}
                    numeric.extend(metric for metric in document['metrics']
                                   if metric['id'] not in seen and metric.get('op')=='observed'
                                   and metric.get('value') is not None and metric.get('domain')==domain)
                if key=='macro' and sol_protocol:
                    numeric=[metric for metric in numeric if metric.get('domain')=='overseas']
                usable_numeric=[metric for metric in numeric if usable(metric)]
                if not usable_numeric:reason='缺少截止时已可得、可核验的本期数值'
                elif key=='market' and not {'index_change','turnover','breadth'}<=set(metric['dimensions']['measure'] for metric in usable_numeric):reason='需指数变化、成交额与明确范围的广度；受阻项须写明限制'
                elif key=='macro' and not any(article['section']=='macro' and (not sol_protocol or article.get('domain')=='overseas') for article in document['articles']):reason='海外宏观数值还需独立传导解释'
            elif key=='companies' and item['status']=='done':
                companies=[products[ident] for ident in ids if ident in products and products[ident].get('company')]
                if not companies:reason='无公司实体/公告标识；政策文章不满足公司研究'
                elif modern and not any(a.get('content_role') in ('news','continuing_event') and a.get('text') and a.get('fact_ids') for a in companies):reason='只有财务基线不能完成消息整理；需可见的候选事件事实'
                elif not modern and not all(article['company'].get('financial_baseline') for article in companies):reason='缺少最近公开财务规模基准'
                elif not modern and not all(any(usable(metric) and metric['dimensions']['entity_id']==article['company']['entity_id'] and metric['dimensions']['measure'] in ('revenue','profit','net_profit','cash_flow','assets','total_assets','backlog','capex') for metric in document['metrics'] if metric['op']=='observed') for article in companies):reason='财务基准需要同实体可得的收入/利润/现金流等数值及其来源，不能只写已核验'
                if document['schema_version']>=5 and not modern:
                    candidates=[article for article in companies if article.get('content_role')=='news' and article.get('event_key') and article.get('interpretation')]
                    scans=[entry for entry in coverage_attempts(document['coverage']) if set(entry['obligation_ids']) & {'sse','szse','bse'} and window_verified(entry,document) and '公告' in entry.get('content_scope','')]
                    if not candidates or not scans:reason='需要本期公告候选窗口、逐项事实/影响/风险及财务基线；旧财报不代表本期公告发现'
            elif key=='themes' and item['status']=='done' and not any(analysis['id'] in ids for analysis in document['analyses']):
                if not (modern and document.get('selection_review',{}).get('reason') and grounded(document.get('selection_review',{}).get('evidence_ids',[]))):reason='缺少重点研究或有依据的不入选说明'
            elif key in ('official','sentinel','ai') and item['status']=='done':
                from common import obligations
                required_ids={entry['id'] for entry in contract.get('coverage_obligations',obligations(contract['profile'],contract['scope'],contract.get('edition'))) if entry['critical']}
                if bounded_discovery:
                    required_ids=set()  # Completed bounded discovery is recorded in the task attempt, not 25 site stamps.
                elif sol_protocol:
                    if key=='ai':required_ids={oid for oid in required_ids if oid.startswith(('openai_','anthropic_'))}
                    elif key=='official':required_ids={oid for oid in required_ids if not oid.startswith(('openai_','anthropic_')) and oid not in ('fed_macro','market_data')}
                attempted_ids={oid for entry in coverage_attempts(document['coverage']) if entry['status']!='not_checked' and entry['checked_at'] for oid in entry['obligation_ids']}
                if required_ids-attempted_ids:reason='尚有未尝试的指定窗口；继续扫描或记录有依据的受阻/到限状态'
                elif document['schema_version']>=5 and not modern and required_ids-{oid for entry in coverage_attempts(document['coverage']) if window_verified(entry,document) for oid in entry['obligation_ids']}:reason='核心窗口未核验完成；失败/陈旧索引只证明受阻，不是目标达成'
            elif key=='synthesis' and (document['review']['status']=='not_reviewed' or (contract.get('edition')!='intraday' and (not document['summary'] or (not modern and not document['actions'])))):reason='缺少摘要/验证条件或真实审阅'
            if key=='synthesis' and sol_protocol and not reason:
                if document['meta']['title'].startswith('每日关注简报'):reason='综合标题尚未编辑'
                elif not document['actions'] and not document.get('observation_review',{}).get('reason'):
                    reason='缺少有效观察；如确无可设定条件，需说明具体原因'
            if key=='synthesis' and document['schema_version']>=5 and not modern and contract.get('edition')!='intraday' and not any(near_action(action,document) for action in document['actions']):reason='需要经核验日历支持的当日至3会话观察；中期复核不能代替'
            if key=='synthesis' and workflow_version>=5 and contract.get('edition')!='intraday' and not document['observations']:
                review=document.get('observation_review',{})
                if not review.get('reason') or review.get('status') in (None,'not_checked'):
                    reason='尚未处置待验证观察候选：保留有价值的问题，或登记已查范围及确无候选/受阻原因'
            if item['status']=='verified_none':
                if bounded_discovery and key in ('companies','official','sentinel','ai','themes'):
                    # An honest bounded candidate scan can find no qualifying item;
                    # it does not certify every institution's full publication window.
                    if not any(a.get('query_or_url') and a.get('result') for a in attempts):
                        reason='无新增需要说明已检索范围、时间边界与结果'
                    elif not grounded(item['evidence_ids']):
                        reason='无新增需要可归因的候选列表或搜索记录'
                    if key=='themes' and not (document.get('selection_review',{}).get('reason') and grounded(document.get('selection_review',{}).get('evidence_ids',[]))):
                        reason='零重点需要有证据支持的取舍说明'
                    item['product_check']=reason or '有界发现已记录，未推断全站无遗漏'
                    if reason:item.update(status='running',next=reason)
                    result.append(item)
                    continue
                scans=[attempt for attempt in coverage_attempts(document['coverage']) if attempt['status']=='checked_none' and
                       attempt['method'] in ('original_index','aggregate') and attempt.get('content_scope') and grounded(attempt['mapping_evidence_ids']) and
                       iso(attempt['window_start'])<=iso(contract['requested_window_start']) and iso(attempt['window_end'])>=iso(contract['initial_cutoff'])]
                if key=='companies':
                    scans=[scan for scan in scans if set(scan['obligation_ids']) & {'sse','szse','bse'} and '公告' in scan['content_scope']]
                    required_exchanges={entry['id'] for entry in contract['coverage_obligations']} & {'sse','szse','bse'}
                    if required_exchanges-{oid for scan in scans for oid in scan['obligation_ids']}:reason='公司无重要公告需要目标范围内交易所候选窗口，不能只查一个入口'
                if not scans:reason='无重要新增需要指定入口完整窗口证据，搜索空结果不足'
                if document['schema_version']>=5 and (not scans or any(not window_verified(scan,document) for scan in scans)):reason='无新增需要新鲜且完整的窗口索引证据；陈旧首页、受阻与未检查不能替代'
                if key=='themes' and document['schema_version']>=5:
                    review=document.get('selection_review',{})
                    from common import obligations
                    required={entry['id'] for entry in contract.get('coverage_obligations',obligations(contract['profile'],contract['scope'])) if entry['critical']}
                    covered={oid for entry in coverage_attempts(document['coverage']) if window_verified(entry,document) for oid in entry['obligation_ids']}
                    reason='' if review.get('reason') and grounded(review.get('evidence_ids',[])) and not required-covered and all(article.get('interpretation') for article in document['articles'] if article.get('content_role')=='news' and article.get('disposition')!='excluded') else '零重点需要完整候选扫描、取舍依据及保留事件解读，不能用空白冒充平静日'
                elif key not in ('companies','official','sentinel'):reason='本任务需要本期数值或比较判断，不能用无新增替代研究'
        elif item['status']=='blocked' and (not recorded or not item['stop_reason'] or not any(attempt['status'] in ('failed','restricted') for attempt in attempts)):reason='受阻状态缺少实际失败尝试/错误'
        elif item['status'] in ('budget_stop','user_stop') and not item['stop_reason']:reason='停止需要具体原因'
        if reason:item.update(status='running',next=reason)
        item['product_check']=reason or '符合可见记录约束；程序不证明工具记录真实性'
        result.append(item)
    pending=[item for item in result if item['status'] not in ('done','verified_none','blocked','budget_stop','user_stop')]
    stops=[item for item in result if item['status'] in ('blocked','budget_stop','user_stop')]
    actions=[dict(task_id=item['id'],action=item['next'],input=dict(task=item['id'],kind='market' if item['id']=='market' else 'company' if item['id']=='companies' else 'window' if item['id'] in ('official','sentinel','ai') else 'thesis' if item['id']=='themes' else 'review' if item['id']=='synthesis' else 'event'))
             for item in sorted(pending,key=lambda item:(len(item['attempts'])>0,item['priority']))[:3]]
    return dict(complete=not pending and not stops,workflow_terminal=not pending,research_goals_met=not pending and not stops,tasks=result,pending=[item['id'] for item in pending],
                stop_reasons=[dict(task_id=item['id'],status=item['status'],reason=item['stop_reason']) for item in stops],next_actions=actions)


def event_key(entity,subject,family,release_id):
    """Stable identity fields, never a headline, local F/C id or URL."""
    parts=[]
    for value in (entity,subject,family,release_id):
        normalized=unicodedata.normalize('NFKC',value).casefold().strip()
        normalized=re.sub(r'[^\w-]+','-',normalized,flags=re.UNICODE).strip('-')
        if not normalized:raise ValueError('事件身份字段不能为空')
        parts.append(normalized)
    return ':'.join(parts)


def candidate_matches(candidate,known):
    """Surface possible aliases for human review; ambiguity is never auto-merged."""
    identity=(candidate['entity'],candidate['subject'],candidate['family'])
    aliases=set(candidate.get('aliases',[]))
    return [event['event_key'] for event in known if
            (event['entity'],event['subject'],event['family'])==identity and
            (event['event_key']==candidate['event_key'] or aliases.intersection(event.get('aliases',[])))]


def scan_windows(contract,previous=None):
    """Bounded overlap, by independently successful source role; not a search result."""
    end=iso(contract['initial_cutoff'])
    requested=iso(contract['requested_window_start'])
    roles=(previous or {}).get('coverage',{})
    windows=[]
    for entry in contract['coverage_obligations']:
        if not entry['url']:continue
        last=roles.get(entry['id'])
        overlap=iso(last)-timedelta(hours=24) if last else requested
        start=max(requested,min(overlap,end))
        cold_lookback=contract.get('research_workflow_version',1)>=2 and not last and entry['id'].startswith(('openai_','anthropic_'))
        if cold_lookback:start=min(start,end-timedelta(days=3))
        windows.append(dict(source_id=entry['id'],channel=entry.get('channel','official_index'),url=entry['url'],
                            start=start.isoformat(),end=end.isoformat(),prior_success=last,
                            required=entry['critical']))
    return windows


def evidence_refs(events,publication_id):
    return [dict(item,source_refs=[dict(publication_id=publication_id,id=source_id) for source_id in item['source_ids']],
                 evidence_refs=[dict(publication_id=publication_id,id=evidence_id) for evidence_id in item['evidence_ids']])
            for item in events]


def event_signature(event):
    return dict(version=event['version'],attributes=event['attributes'],status=event['status'],**({key:event.get(key) for key in ('proposition','stage')} if 'proposition' in event else {}))


def market_projection(document,checks):
    observations={}
    for metric in document.get('metrics',[]):
        if metric.get('value_identity')=='conditional' or metric.get('kind')=='forecast' or metric['op']!='observed' or metric['id'] in checks.get('unready_metrics',[]):continue
        dimensions=metric['dimensions']
        key=fingerprint([dimensions['entity_id'],dimensions['measure'],dimensions['segment'],metric.get('frequency'),
            metric.get('session'),metric.get('price_basis'),metric.get('universe_id',metric.get('scope')),metric['unit'],dimensions['scale']])
        observations[key]=dict(entity_id=dimensions['entity_id'],measure=dimensions['measure'],as_of=metric['as_of'],
            value=checks.get('values',{}).get(metric['id']),unit=metric['unit'],scope=metric.get('scope'),source_ids=metric['source_ids'])
    return observations


def has_report_reference(document,event):
    reference=event.get('report_ref')
    if not isinstance(reference,dict):return False
    item_id=reference.get('item_id')
    if reference.get('section')=='change':
        item=next((x for x in document.get('changes',[]) if x.get('event_key')==item_id),None)
    elif reference.get('section')=='article':
        item=next((x for x in document.get('articles',[]) if x.get('id')==item_id),None)
    else:return False
    if document.get('schema_version',3)>=5 and item and item.get('disposition','retained')!='retained':return False
    return bool(item and set(event.get('claim_ids',[])) & set(item.get('claim_ids',[])))


def compare(events,previous,cutoff):
    old={x['event_key']:x for x in (previous or {}).get('events',[])}
    changes={}
    for event in events:
        prior=old.get(event['event_key'])
        if not prior:
            published=event.get('published_at')
            if previous and published and re.fullmatch(r'\d{4}-\d{2}-\d{2}',published):
                # A date alone proves publication before an earlier calendar
                # day, not before an unknown clock time on the same day.
                earlier=published<previous['date']
            else:
                earlier=bool(previous and published and iso(published)<iso(previous['cutoff']))
            changes[event['event_key']]='late_discovery' if earlier else 'new'
            continue
        reported=prior.get('reported_snapshot')
        if reported is None and prior.get('reported_version'):
            legacy_signature=event_signature(prior)
            if prior['reported_version']==fingerprint((legacy_signature['version'],legacy_signature['attributes'],legacy_signature['status'])):
                reported=legacy_signature
        if reported is None:
            changes[event['event_key']]='late_discovery'
            continue
        current=event_signature(event)
        if current==reported:continue
        if event['status'] in ('corrected','withdrawn') and (reported['status']!=event['status'] or reported['attributes']!=event['attributes']):
            changes[event['event_key']]='correction'
        else:
            changes[event['event_key']]='progress'
    return changes


def priority_rechecks(previous,document,limit=5):
    state={e['event_key']:e for e in (previous or {}).get('events',[])}
    state.update({e['event_key']:e for e in document.get('research_events',[])})
    pending=sorted((e for e in state.values() if e.get('importance',0)>=5 and e.get('status') in ('lead','pending','conflicted')),key=lambda e:e.get('importance',0),reverse=True)
    return [{k:e.get(k) for k in ('event_key','entity','subject','status','next_check','evidence_refs')} for e in pending[:limit]]


def project(previous,document,publication_id,checks):
    old=(previous or {}).get('events',[])
    state={event['event_key']:event for event in old}
    for event in evidence_refs(document.get('research_events',[]),publication_id):
        event.setdefault('reported',False)
        prior=state.get(event['event_key'])
        if prior:
            if prior.get('first_seen_at'):
                event['first_seen_at']=prior['first_seen_at']
            else:
                event['observation_integrity']='legacy_first_seen_unknown'
            reported=prior.get('reported_snapshot')
            if reported is None and prior.get('reported_version'):
                legacy_signature=event_signature(prior)
                if prior['reported_version']==fingerprint((legacy_signature['version'],legacy_signature['attributes'],legacy_signature['status'])):
                    reported=legacy_signature
                    event['reported_integrity']='legacy_consistent'
                else:
                    event['reported_integrity']='legacy_unknown'
            elif reported is not None:
                event['reported_integrity']=prior.get('reported_integrity','verified')
            if reported is not None:
                event['reported_snapshot']=copy.deepcopy(reported)
                event['reported_version']=fingerprint((reported['version'],reported['attributes'],reported['status']))
                event['last_reported_at']=prior.get('last_reported_at')
        observed=event_signature(event)
        event['latest_observed']=copy.deepcopy(observed)
        event['latest_signature']=fingerprint(observed)
        event['reported']=bool(event.get('reported') and has_report_reference(document,event))
        if event['reported']:
            event['reported_snapshot']=event_signature(event)
            event['reported_integrity']='verified'
            event['reported_version']=fingerprint((event['version'],event['attributes'],event['status']))
            event['last_reported_at']=document['meta']['cutoff']
        state[event['event_key']]=event
    ordered=sorted(state.values(),key=lambda x:(
        bool(x.get('importance',0)>=5 and x.get('reported_snapshot')!=event_signature(x)),
        x.get('importance',0),x.get('last_verified_at') or ''),reverse=True)
    coverage=dict((previous or {}).get('coverage',{}))
    accepted=set(checks['delivery']['coverage']['covered_ids'])
    for entry in coverage_attempts(document['coverage']):
        if entry['status'] in ('checked_new','checked_none') and entry['method'] in ('original_index','aggregate'):
            for obligation in entry['obligation_ids']:
                if obligation in accepted:
                    coverage[obligation]=entry['window_end']
    important_pending=[x for x in ordered if x.get('importance',0)>=5 and (x.get('reported_snapshot')!=event_signature(x) or document.get('schema_version',3)>=6 and x.get('status') in ('lead','pending','conflicted'))]
    important_keys={x['event_key'] for x in important_pending}
    remaining=[x for x in ordered if x['event_key'] not in important_keys]
    selected=important_pending+remaining[:max(0,MAX_EVENTS-len(important_pending))]
    omitted=max(0,len(ordered)-len(selected))
    overflow_important=max(0,len(important_pending)-MAX_EVENTS)
    result=dict(version=STATE_VERSION if document.get('schema_version',3)>=5 else 2,date=document['meta']['date'],cutoff=document['meta']['cutoff'],
                events=selected,coverage=coverage,omitted=omitted,
                omitted_important=0,overflow_important=overflow_important,
                overflow_notice='重要待报或待核验事件超过常规上限，已保留全部待处理项' if overflow_important else None,
                baseline=publication_id)
    if document.get('schema_version',3)>=5:result['market_observations']=market_projection(document,checks)
    return result
