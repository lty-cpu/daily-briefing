# 有界数据取用

配置位置与读取顺序统一见[Skill入口](../SKILL.md#一次配置按期运行)。`start`先取得交易日历再判版型；`trade_cal`只给开休市日期，常规会话钟点由A股规则补充。旧资料库仍可用 `--calendar` 提供已核验日历。`--web-only` 仅用于用户指定的网页对照，或本轮已有网络/授权失败记录后的回退，不是默认启动参数。

## 网页日历输入

没有token不等于不能生成晚报。先复制 `assets/calendar-input.example.json` 到本轮工作目录，由Agent读取交易所休市通知、交易规则或可信日历后填写；不要让用户每日写JSON。

模板是教学占位，`synthetic:true`、`complete:false`，不能通过live版型资格。用实际来源替换sources/evidence的标题、URL、发布日、读取时间、quote和locator；日期级发布不补造钟点。只列声明核验范围内真实开市日期和15:00收盘时间，周末/节假日无会话；范围覆盖上一有效会话、目标日及后续几个会话。核验完成才设complete=true、删除synthetic，并更新版本/范围；不能只翻两个开关复用示例。

`python <skill>/scripts/run.py options --date <目标日> --calendar <填实的calendar.json>` 验证可用版型，再给start传同一 `--calendar`。支持单calendar内嵌sources/evidence与模板bundle两种形状；后续历史窗口和观察日期复用同一对象，字段详见[数据协议](data-contract.md#序列与会话)。

## 接口职责与收盘数据就绪

Tushare没有强制购买门槛：所需信息可用合格缓存或网页替代。下表区分自动基础取数和按需增强；某项无权限不阻断其他接口。权限数字以供应商当前文档和实际响应为准，不根据token存在就假定可用。

| 用途 | 接口 | 缺少时 |
|---|---|---|
| 版型与会话 | trade_cal | 按上节传核验日历；它不证明行情已入库 |
| 基础市场取数 | index_daily、daily；stock_basic做对象识别 | 逐项网页补齐宽基和截面；index_daily当前要求2000积分 |
| 行业和海外增强 | index_classify / sw_daily、us_tycr | 缺哪项补哪项；sw_daily为5000积分，us_tycr为120积分，并非都属高权限 |
| 入选公司补数 | daily_basic、adj_factor、income、cashflow、balancesheet | 只影响相应估值、复权或财务比较 |
| 显式按需候选 | ths_daily、anns_d | 前者6000积分，后者单独授权；不为完整早晚报强求这两项 |

交易所15:00收盘只开放晚报资格。[daily](https://tushare.pro/document/2?doc_id=27)通常15—16点入库，[daily_basic](https://tushare.pro/document/2?doc_id=32)15—17点，[sw_daily](https://tushare.pro/document/2?doc_id=327)18:30；更新窗口不是对本账号的就绪保证。index_daily未在接口页承诺统一钟点，现有18:30导入边界只是保守重建约束，不可写成实际发布时间。以返回的目标日、有效行和截止证据为准；当日较早取到的少量行不证明全市场已完整入库。权限来源：[指数](https://tushare.pro/document/2?doc_id=95)、[美债](https://tushare.pro/document/2?doc_id=219)、[THS](https://tushare.pro/document/2?doc_id=260)、[公告](https://tushare.pro/document/2?doc_id=176)。

start的data_readiness与运行目录data-status.json保留缺项。晚报早取数时先继续新闻研究，用截止前有据的网页补缺；不要sleep轮询或推迟原截止。后来更新只能作为新的修订。菜单的available仅指会话资格。用户之后自行安排常规晚报时可选择18:30以后并仍做实际检查；Skill不改调度。自动取数到端到端预算的收尾线停止新请求，保留交付时间。

## 进程联网权限

配置了token时，`options`、`start` 和入选公司后的 `data` 需要执行它们的Python进程可访问 `api.tushare.pro`；网页工具可用不代表本地进程可联网。宿主有限制时，创建run前通过其授权工具申请相应取数命令的权限（Codex exec使用 `sandbox_permissions:"require_escalated"`），成功后仍须实际执行取数。`options`取得日历或缓存不等于后续start进程获准联网。`network_permission`是进程连接被拒绝；API认证、积分/接口权限、限流、空响应分别记录，不混为无数据。

授权服务502、超时或审核失败表示命令未执行，单独说明“宿主授权未完成”，不得记为Tushare调用或token故障。Skill不能授予权限或修复审批服务；不得绕过审批，继续已允许的缓存/网页路径并记录本期取数限制。若本轮已确认授权不可得，后续options/start用`--web-only`，公司数据改用已有资料与网页，避免反复尝试受阻进程。授权、纠错、恢复均沿用原请求时间与截止，不重建run刷新预算。命令、日志、报告和正式包均不输出token。

每项依次检查适用缓存、实际Tushare响应、网页补缺。认证失败本轮停止接口，单接口无权限只停该项；暂态故障最多重试一次。接口响应按API名、非敏感参数、响应行、实际取回时间留在运行目录；报告中的来源身份写“Tushare数据”，不得称交易所原文直读。API行可直接支持数值，不需逐点找网页quote。晚取的历史资料标重建基线，不伪装截止前的冻结版本。没有数据不写零。

`start`自动获取最近完整会话的五大宽基、A股有效日线截面、申万2021一级行业与可得美国国债利率，并按需扩展至61个完整会话。目标会话按同一calendar的真实收盘时刻选择，各接口单独检查目标日期行；缺行或截止前可得性未证实时返回pending，不悄悄改取昨日作为今日。空响应和缺目标日的响应不缓存为已就绪。`daily`与`index_daily`均是日线，盘中须另取带实际时点的实时资料；`index_daily.amount`及`daily.amount`为千元，`sw_daily.amount`与`daily_basic`市值为万元，财报金额为元。指数成分成交额不能代表全市场。全市场广度必须说明实际取回的样本、平盘和缺失；达到单次返回上限只标样本。

入选公司之后，用 `python <skill>/scripts/run.py data --run-id <ID> --run-token <TOKEN> --input <UTF-8 JSON文件>`，输入例如 `{"companies":[{"code":"600000.SH","name":"浦发银行"}],"history":true}`。一次最多4家。它获取上市基本信息、日线与每日指标；有复权因子才形成跨期股价序列。合并累计财报取公告日期不晚于本期截止的期间，尽量带同季度上年对照；同日只知日期而无钟点的财报，盘中不能冒充已发布。PE空值保持缺失。取得原始表不等于完成研究，正文须解释经营量级、现金约束和该事件的关系。需明确研究THS概念或公告候选时再按任务取 `ths_daily` / `anns_d`；没有授权走网页。

旧 `history-data` 仅保留files导入及已有缓存；其Tushare/环境变量网络入口已停用，返回迁移提示，取数统一用start/data。批量历史的20会话收益需21个连续真实会话收盘，60需61个；不足时保留实际点、报告缺口，不能填假趋势。股票跨期必须有复权依据；日涨跌以接口的 `pct_chg` 为准。文件与缓存不因本轮复用而冒充重新访问。

