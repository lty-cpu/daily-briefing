"""One verified calendar input for the edition gate and saved research document."""
from common import InputError, fingerprint, iso
from schema import CALENDAR, SCHEMA, check


def observation_time(observation, document):
    """Resolve a requested session against the same saved calendar as the report."""
    import re
    from datetime import timedelta
    from edition import SUPPORTED_A_SHARE_MARKETS
    result={key:observation[key] for key in ('observe_at','calendar_id','session_offset','horizon') if key in observation}
    offset=observation.get('session_offset')
    if offset is None and not result.get('observe_at') and re.search(r'下一(?:个)?(?:有效)?(?:A股)?(?:交易日|会话)',observation.get('trigger','')):
        offset=1
    if offset is None and not result.get('observe_at'):return result
    if offset is not None and (isinstance(offset,bool) or not isinstance(offset,int) or offset<0):
        raise InputError('observe.session_offset','0为目标日，1为下一已核验会话；需非负整数')
    calendars=[c for c in document['calendars'] if c['complete'] and c['source_ids'] and c['evidence_ids']
        and c['market'] in SUPPORTED_A_SHARE_MARKETS
        and (not c.get('synthetic') or document['meta']['mode']=='teaching')
        and c['valid_from']<=document['meta']['date']<=c['valid_to']
        and (not result.get('calendar_id') or c['id']==result['calendar_id'])]
    if len(calendars)!=1:return result
    calendar=calendars[0];day=document['meta']['date'];sessions=sorted(calendar['sessions'],key=lambda s:s['date'])
    if offset is not None:
        candidates=[s for s in sessions if s['date']==day] if offset==0 else [s for s in sessions if s['date']>day][offset-1:offset]
        if not candidates:return result
        delay=observation.get('delay_minutes',0)
        if isinstance(delay,bool) or not isinstance(delay,int) or not 0<=delay<=480:
            raise InputError('observe.delay_minutes','会话收盘后的复核延迟需为0—480分钟')
        at=iso(candidates[0]['close_at'])+timedelta(minutes=delay)
        if result.get('observe_at') and iso(result['observe_at'])!=at:
            raise InputError('observe','observe_at与会话偏移/延迟不一致')
        result.update(observe_at=at.isoformat(),session_offset=offset)
    if result.get('observe_at'):
        from common import get_zone
        observed_day=iso(result['observe_at']).astimezone(get_zone(calendar['timezone'])).date().isoformat()
        if any(s['date']==observed_day for s in sessions):result['calendar_id']=calendar['id']
        elif offset is not None or observation.get('calendar_id'):
            raise InputError('observe.observe_at','观察日期不在所引用的有效会话内')
    return result


def normalize(raw, day=None, allow_unresolved=False):
    """Accept a standalone calendar with provenance or a sources/evidence/calendars bundle."""
    if not isinstance(raw, dict):
        raise InputError('calendar', '期望单个日历对象或 {sources,evidence,calendars} 资料包')
    if 'calendars' in raw:
        path = 'calendar.calendars'
        calendars = raw['calendars']
        sources = raw.get('sources', [])
        evidence = raw.get('evidence', [])
    else:
        path = 'calendar'
        calendars = [raw]
        sources = raw.get('sources', [])
        evidence = raw.get('evidence', [])
    if not isinstance(calendars, list) or not calendars:
        raise InputError(path, '需要至少一个日历对象；整包请使用 calendars:[...]')
    if not isinstance(sources, list) or not isinstance(evidence, list):
        raise InputError('calendar.sources/evidence', '来源与原文记录需为数组')
    cleaned = []
    for index, item in enumerate(calendars):
        if not isinstance(item, dict):
            raise InputError(f'{path}[{index}]', '期望日历对象，包含市场、范围及会话')
        calendar = {k:v for k,v in item.items() if k not in ('sources', 'evidence')}
        errors = check(calendar, CALENDAR, f'{path}[{index}]')
        if errors:
            raise InputError(errors[0]['path'], errors[0]['message'])
        cleaned.append(calendar)
    for label, rows, spec in (('sources',sources,SCHEMA['required']['sources']['items']),
                              ('evidence',evidence,SCHEMA['required']['evidence']['items'])):
        for index, item in enumerate(rows):
            errors = check(item, spec, f'calendar.{label}[{index}]')
            if errors:
                raise InputError(errors[0]['path'], errors[0]['message'])
    by_source = {s['id']:s for s in sources}
    by_evidence = {e['id']:e for e in evidence}
    if len(by_source)!=len(sources) or len(by_evidence)!=len(evidence):
        raise InputError('calendar.sources/evidence', '引用ID重复；请保留唯一原文记录')
    for index, item in enumerate(cleaned):
        if allow_unresolved and not sources and not evidence:
            continue
        for sid in item['source_ids']:
            if sid not in by_source:
                raise InputError(f'{path}[{index}].source_ids', f'{sid} 未在 sources 中；单日历也需附 sources/evidence')
        for eid in item['evidence_ids']:
            record = by_evidence.get(eid)
            if not record or record['source_id'] not in item['source_ids']:
                raise InputError(f'{path}[{index}].evidence_ids', f'{eid} 缺失或未连接所列来源')
        if not item['source_ids'] or not item['evidence_ids']:
            raise InputError(f'{path}[{index}]', '需有实际来源与原文定位；source_ids/evidence_ids 不能为空')
    eligible = [c for c in cleaned if day is None or c['valid_from']<=day<=c['valid_to']]
    if len(eligible)!=1:
        raise InputError(path, f'目标日 {day or "未指定"} 匹配 {len(eligible)} 个日历；请只提供唯一适用日历')
    selected = eligible[0]
    return dict(calendar=selected, sources=sources, evidence=evidence,
                calendars=[selected], fingerprint=fingerprint(selected),
                bundle_fingerprint=fingerprint(dict(calendar=selected,sources=sources,evidence=evidence)),
                unresolved=bool(allow_unresolved and not sources and not evidence))
