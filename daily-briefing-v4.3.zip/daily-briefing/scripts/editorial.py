"""Evidence identity helpers shared by input, checks and display; no separate store."""
from common import InputError, iso


def identity(source, evidence, fact_status='reported', requested=None, proposition='publication', occurrence_verified=False):
    if not source.get('publisher') or not source.get('url') or not evidence.get('quote') or source.get('read_status')=='unavailable':
        raise InputError('source','消息必须有可识别出处、可定位链接和实际已见内容')
    basis=source.get('source_basis','named')
    original=evidence['read_method'] in ('original','cached')
    official=source['kind'] in ('official','company') and original
    if fact_status=='conflicted':return 'conflicted'
    if fact_status=='unverified':return 'pending'
    if basis in ('denial','correction') and official:return 'withdrawn' if basis=='denial' else 'corrected'
    if not original:return 'lead'
    if basis=='anonymous' or source['kind']=='public_account':return 'pending'
    if fact_status=='confirmed' and official and (proposition=='publication' or occurrence_verified):return 'confirmed'
    return 'reported'


def claim_refs(document,item):
    refs=set(item.get('claim_ids',[]))
    for ids in item.get('field_claims',{}).values():refs.update(ids)
    for horizon in item.get('horizons',{}).values():refs.update(horizon.get('claim_ids',[]))
    for analysis in document.get('analyses',[]):
        if analysis['id'] in item.get('analysis_ids',[]):refs.update(claim_refs(document,analysis))
    return refs


def dependencies(document,item):
    facts={f['id']:f for f in document['facts']};claims={c['id']:c for c in document['claims']}
    fids=set(item.get('fact_ids',[]));eids=set(item.get('evidence_ids',[]))
    metrics={m['id']:m for m in document['metrics']}
    for cid in claim_refs(document,item):
        c=claims.get(cid,{})
        fids.update(c.get('fact_ids',[]));eids.update(c.get('evidence_ids',[]))
        for mid in c.get('metric_ids',[]):eids.update(metrics.get(mid,{}).get('evidence_ids',[]))
    for fid in fids:eids.update(facts.get(fid,{}).get('evidence_ids',[]))
    evidence=[e for e in document['evidence'] if e['id'] in eids]
    sids={e['source_id'] for e in evidence}
    return [facts[f] for f in fids if f in facts],evidence,[s for s in document['sources'] if s['id'] in sids]


def label(document,item):
    facts,evidence,sources=dependencies(document,item)
    labels=[]
    if any(s.get('source_basis')=='denial' for s in sources):labels.append('官方否认')
    elif any(s.get('source_basis')=='correction' for s in sources):labels.append('来源更正')
    if any(f['status']=='conflicted' for f in facts):labels.append('来源分歧')
    if any(e['read_method']=='search_summary' for e in evidence):labels.append('仅据搜索摘要')
    if any(f['status']=='unverified' for f in facts) or any(s.get('source_basis')=='anonymous' or s['kind']=='public_account' for s in sources):labels.append('待证消息 · 若属实')
    if any(s['kind']=='media' for s in sources):
        fids={f['id'] for f in facts}
        company=item.get('company') or any(a.get('company') and fids.intersection(a.get('fact_ids',[])) for a in document.get('articles',[]))
        labels.append('媒体报道｜原公告未取得' if company else '媒体报道')
    if not labels and sources:labels.append('公司公告' if any(s['kind']=='company' for s in sources) else '官方发布' if any(s['kind']=='official' for s in sources) else '来源数据')
    if not sources:labels.append('研究判断')
    claims={c['id']:c for c in document['claims']};metrics={m['id']:m for m in document['metrics']}
    mids={mid for cid in claim_refs(document,item) for mid in claims.get(cid,{}).get('metric_ids',[])}
    if any(metric_identity(document,metrics[mid])=='conditional' for mid in mids if mid in metrics) and '待证消息 · 若属实' not in labels:labels.append('若属实情景')
    if any(f.get('available_at') is None for f in facts):labels.append('可得时点未定')
    return ' · '.join(labels)


def reportable(document,item):
    facts,evidence,sources=dependencies(document,item)
    return bool(evidence and sources and all(s.get('publisher') and s.get('url') and s.get('read_status')!='unavailable' for s in sources))


def display_role(article):
    role=article.get('content_role','news')
    if role=='background':return 'continuing_event'
    if role=='baseline':
        return 'financial_baseline' if article.get('company') or article.get('domain')=='company' else 'context'
    return role


def local_time(value,zone):
    if not value:return '时间未定'
    if len(value)==10:return value+'（日期精度）'
    from common import get_zone
    return iso(value).astimezone(get_zone(zone)).strftime('%Y-%m-%d %H:%M')


def metric_identity(document,metric,seen=None):
    from calculations import inputs
    seen=set() if seen is None else seen
    if metric['id'] in seen:return 'official'
    seen.add(metric['id'])
    if metric['op']=='observed':
        if metric.get('value_identity'):return metric['value_identity']
        source_ids=metric.get('source_ids',[])
        return 'reported' if any(s['id'] in source_ids and s['kind'] in ('media','public_account') for s in document['sources']) else 'official'
    metrics={m['id']:m for m in document['metrics']}
    states=[metric_identity(document,metrics[mid],seen) for mid in inputs(metric) if mid in metrics]
    return 'conditional' if 'conditional' in states else 'reported' if 'reported' in states else 'official'
