"""Bounded file-based run state; no services, network calls, or model configuration."""
from __future__ import annotations
import copy
from datetime import datetime, timezone
from pathlib import Path
import time
import traceback
from common import VERSION, canonical, digest, fingerprint, iso, load, resolve_contract, save, stamp
from schema import SCHEMA
from storage import materialize
from capabilities import preflight, read_host_report, summary as capability_summary
from edition import policy

STATE='run-state.json'
SKILL=Path(__file__).resolve().parents[1]
GUIDES={'research-input':'research-input.md','editorial':'editorial.md',
        'live':'live-research.md','research':'research-method.md','analysis':'analysis-cards.md',
        'contract':'data-contract.md','finance':'finance-ai.md','review':'review-and-evaluation.md'}
DEFAULT_BUDGET=dict(soft_queries=40,hard_queries=80,reserved_verifications=12,timeout_seconds=1500,
                    max_finish_attempts=3,page_chars=3500,max_recoveries=8,max_page_replays=2,
                    history_seconds=90,request_timeout_seconds=12,history_retries=2,reserved_seconds=300)


def read_state(work):
    work=Path(work);state=load(work/STATE)
    if state.get('skill_version') not in (VERSION,'4.2','4.0.2','4.0.1','4.0','3.6','3.5','3.3','3.2','3.1','3.0'):
        raise ValueError('未知运行协议；保留原目录并使用对应版本继续，或显式迁移输入')
    request=load(work/'request.json')
    if fingerprint(request)!=state['contract_sha256'] or request!=state['contract']:
        raise ValueError('锁定请求文件/状态不一致；不得修改旧契约，需要新运行')
    return state


def sync_info(work,state,d=None,checks=None):
    review=d['review']['status'] if d else state.get('review_status','not_reviewed')
    visual=d.get('visual',{}).get('status','not_performed') if d else state.get('visual_status','not_performed')
    info=dict(version=VERSION,phase=state['phase'],review_status=review,visual_status=visual,
              model=state['model'],harness=state['harness'],reasoning=state['reasoning'],contract=state['contract'],
              delivery=checks.get('delivery') if checks else state.get('delivery'),usage=state['telemetry']['usage'],
              runtime_capabilities=capability_summary(state.get('preflight')),
              note='程序门槛不证明经济逻辑或事实真实；usage缺失为null。')
    save(work/'run-info.json',info)


def start_inputs(args,edition):
    budget=dict(DEFAULT_BUDGET,**policy(edition)['budget'])
    if args.budget:
        if str(args.budget).lstrip().startswith('{'):raise ValueError('--budget需要UTF-8 JSON文件路径，不接受内联JSON；尚未认领运行')
        supplied=load(args.budget)
        if not isinstance(supplied,dict) or set(supplied)-set(budget):raise ValueError('预算含未知字段')
        budget.update(supplied)
    if any(type(value) is not int or value<=0 for value in budget.values()):raise ValueError('预算必须为正整数')
    if budget['soft_queries']>budget['hard_queries'] or budget['reserved_verifications']>=budget['hard_queries']:raise ValueError('软/硬预算和核验保留额度不合理')
    if not 256<=budget['page_chars']<=6000:raise ValueError('页面字符预算256—6000')
    pack=load(args.evidence_pack) if args.evidence_pack else None
    host=read_host_report(args.capabilities) if args.capabilities else None
    return budget,pack,host


def start(args,work,initial=None):
    work=Path(work).resolve()
    if work.is_relative_to(SKILL.resolve()):raise ValueError('运行目录必须在正式Skill目录之外；正常执行不会写入源码目录')
    if (work/STATE).exists():
        existing=read_state(work)
        if args.cutoff and iso(args.cutoff)!=iso(existing['contract']['initial_cutoff']):raise ValueError('已有运行与新截止冲突')
        return status(work,existing)
    if work.exists() and any(x.name not in ('claim.json','request.json','briefing.json','run-info.json') for x in work.iterdir()):raise ValueError('首次运行需要空目录；已有运行请status/resume')
    budget,pack,host=start_inputs(args,initial['contract'].get('edition','snapshot') if initial else getattr(args,'edition',None) or 'snapshot')
    cutoff=args.cutoff
    if pack:
        pc=pack.get('cutoff',pack.get('meta',{}).get('cutoff'))
        if cutoff and iso(cutoff)!=iso(pc):raise ValueError('固定包截止与请求不同')
        cutoff=pc
    contract=initial['contract'] if initial else resolve_contract(cutoff=cutoff,report_date=args.date,preset=args.preset,zone=args.timezone,
        window=args.window_start,profile=args.profile,scope=args.scope,mode=args.mode,
        evidence_mode='fixed_pack' if pack else 'independent')
    edition=contract.get('edition','snapshot')
    state_root=initial['archive_root'] if initial else (str(Path(args.state_root).resolve()) if args.state_root else None)
    if state_root and Path(state_root).is_relative_to(SKILL):raise ValueError('研究状态必须在技能包外')
    runtime=preflight(work,state_root,host,requires_online=contract['mode']!='teaching' and not pack)
    meta=dict(title='每日关注简报 · '+policy(edition)['label'],edition=edition,date=contract['date'],cutoff=contract['initial_cutoff'],timezone=contract['timezone'],
              window_start=contract['requested_window_start'],window_adjustment_reason='',profile=contract['profile'],
              author=args.model,mode=contract['mode'],scope=contract['scope'],run_id='run_'+fingerprint(dict(contract=contract,created=stamp(),path=str(work)))[:16],
              evidence_mode=contract['evidence_mode'],requested_grade='observation' if edition=='intraday' else 'full')
    d={key:[] for key,spec in SCHEMA['required'].items() if spec['type']=='array'}
    d.update(schema_version=__import__('common').SCHEMA_VERSION,meta=meta,review=dict(status='not_reviewed',reviewer=args.model,method='尚未审阅',
        checked_fact_ids=[],checked_analysis_ids=[],checked_claim_ids=[],evidence_ids=[],issues=[]),
        visual=dict(status='not_performed',method='未执行',notes='未执行视觉验收'))
    if d['schema_version']>=7:d['metric_revisions']=[]
    if runtime['status']=='limited_existing':
        d['gaps'].append('宿主缺少实时研究能力：'+', '.join(runtime['missing'])+'；本轮仅核验已有授权资料，不代表完整联网扫描。')
    for obligation in contract['coverage_obligations']:
        if not obligation['url']:continue
        d['coverage'].append(dict(id=obligation['id'],name=obligation['name'],url=obligation['url'],status='not_checked',
            checked_at=None,note='尚未扫描',source_ids=[],obligation_ids=[obligation['id']],method='not_attempted',
            mapping_evidence_ids=[],window_start=meta['window_start'],window_end=meta['cutoff']))
    if pack:
        for k in ('sources','facts','series','metrics','evidence','calendars'):
            d[k]=copy.deepcopy(pack.get(k,[]))
        meta['evidence_pack']=dict(name='evidence-pack.json',sha256=digest(args.evidence_pack))
        d['evidence_differences']=[]
    if initial and initial.get('calendar_bundle') and not initial['calendar_bundle'].get('unresolved'):
        bundle=initial['calendar_bundle']
        for group in ('sources','evidence','calendars'):
            known={row['id'] for row in d[group]}
            d[group].extend(copy.deepcopy(row) for row in bundle[group] if row['id'] not in known)
    if initial and initial.get('revision_document'):
        d=copy.deepcopy(initial['revision_document'])
        d['meta'].update(meta)
        d['review']['status']='not_reviewed'
        d['review']['method']='修订复核待执行'
        d['review']['checked_fact_ids']=[]
        d['review']['checked_analysis_ids']=[]
        d['review']['checked_claim_ids']=[]
        d['review']['evidence_ids']=[]
    from research import task_plan
    if d['schema_version']>=4:d['tasks']=task_plan(contract)
    phase={'ready':'researching','limited_existing':'limited_research','awaiting_host_report':'needs_preflight','blocked':'blocked'}[runtime['status']]
    state=dict(skill_version=VERSION,phase=phase,created_at=initial['started_at'] if initial else stamp(),contract=contract,contract_sha256=fingerprint(contract),
               budget=budget,budget_calibration='user_override' if args.budget else 'intraday_unmeasured_control_budget' if edition=='intraday' else 'observed_reference_10_runs_not_sla',model=args.model,harness=args.harness,
               reasoning=args.reasoning,state_root=state_root,attempts=[],guides={},context_epochs=['initial'],
               tasks=d.get('tasks',[]),telemetry=dict(events=[],usage=None,character_output=0),
               next=capability_summary(runtime)['next'],preflight=runtime,
               data_config=str(Path(args.config).absolute()) if getattr(args,'config',None) else None)
    if initial:
        state.update(run_id=initial['run_id'],owner=initial['owner'],parent_revision=initial['parent_revision'],
            revision_reason=initial['revision_reason'],scheduled_for=initial['scheduled_for'])
        meta['run_id']=initial['run_id']
        d['meta']['run_id']=initial['run_id']
    if pack:state['evidence_sha256']=digest(args.evidence_pack)
    work.mkdir(parents=True,exist_ok=True)
    if (work/'request.json').exists():
        if load(work/'request.json')!=contract:raise ValueError('中断初始化中的契约不一致')
    else:save(work/'request.json',contract,exclusive=True)
    if pack:(work/'evidence-pack.json').write_bytes(Path(args.evidence_pack).read_bytes())
    if (work/'briefing.json').exists():
        from schema import check
        existing=load(work/'briefing.json')
        if check(existing):raise ValueError('中断初始化的输入损坏，保留现场，不覆盖')
        d=existing
    else:save(work/'briefing.json',d,exclusive=True)
    save(work/STATE,state,exclusive=True)
    sync_info(work,state,d)
    return status(work,state,initial=True)


def update_preflight(work,state,host_path,reason):
    """Only rerun after a supplied host update; no per-command network probes."""
    if state['phase'] in ('published','persistent_confirmed'):raise ValueError('已发布能力记录不覆盖；能力变化从新运行生效')
    if not reason or not reason.strip():raise ValueError('更新预检需要能力变化/首次确认的原因')
    state.setdefault('preflight_updates',[])
    if len(state['preflight_updates'])>=3:raise ValueError('本轮能力更新已达3次；停止循环探测并说明阻塞')
    host=read_host_report(host_path)
    runtime=preflight(work,state.get('state_root'),host,
        requires_online=state['contract']['mode']!='teaching' and not state.get('evidence_sha256'))
    previous=state.get('preflight')
    if previous and previous.get('host')==runtime.get('host') and previous['local']==runtime['local']:
        return dict(status='unchanged',preflight=capability_summary(previous))
    state['preflight_updates'].append(dict(previous=previous,reason=reason,checked_at=runtime['checked_at']))
    state['preflight']=runtime
    state['next']=capability_summary(runtime)['next']
    state['phase']={'ready':'researching','limited_existing':'limited_research','awaiting_host_report':'needs_preflight','blocked':'blocked'}[runtime['status']]
    save(Path(work)/STATE,state);sync_info(Path(work),state)
    return dict(status=state['phase'],preflight=capability_summary(runtime))


def remaining(state):
    events=state['telemetry']['events'];queries=sum(e['kind']=='query' for e in events)
    elapsed=(datetime.now(timezone.utc)-iso(state['created_at'])).total_seconds()
    return dict(queries_logged=queries,queries_remaining=max(0,state['budget']['hard_queries']-queries),
                soft_budget_reached=queries>=state['budget']['soft_queries'],elapsed_seconds=round(elapsed,2),
                seconds_remaining=max(0,state['budget']['timeout_seconds']-elapsed),
                timeout_reached=elapsed>state['budget']['timeout_seconds'],
                closeout_started=elapsed>=state['budget']['timeout_seconds']-state['budget'].get('reserved_seconds',300),
                calibration=state.get('budget_calibration','legacy_unknown'),
                finish_attempts_remaining=max(0,state['budget']['max_finish_attempts']-len(state['attempts'])),
                enforcement='脚本强制本地重试/分页；查询和token仅宿主记录可观测，无法拦截未记录的外部工具')


def visual_update(work,state,result,capabilities_path=None):
    """Publish a new visual annotation revision; preserve the first built snapshot."""
    from schema import check, SCHEMA
    from archive import publish, claim, validate_document, verify, safe_path, research_projection
    if state['phase']!='published':raise ValueError('视觉注释需已正式发布的报告')
    errors=check(result,SCHEMA['optional']['visual'],'visual')
    if errors:raise ValueError(canonical(errors))
    work=Path(work);d=materialize(load(work/'briefing.json'),work);root=Path(state['state_root'])
    if capabilities_path:
        from capabilities import read_host_report, preflight
        updated_host=read_host_report(capabilities_path)
        if result['status']=='passed' and updated_host['capabilities']['visual']!='available':
            raise ValueError('本轮视觉能力未确认可用，不能记录通过')
        updated_runtime=preflight(work,str(root),updated_host,
            requires_online=state['contract']['mode']!='teaching' and not state.get('evidence_sha256'))
        state=copy.deepcopy(state)
        state['preflight']=updated_runtime
    issue_path=safe_path(root,'.runtime/issues/'+state['contract']['issue_key']+'.json')
    latest_output=state.get('output')
    if issue_path.exists():
        issue=load(issue_path)
        if issue.get('publications'):
            publications=issue['publications']
            for previous_relative in reversed(publications):
                previous_commit=verify(root,previous_relative)
                previous_document=load(safe_path(root,previous_relative)/'snapshot.json')['document']
                if previous_document.get('visual')==result and research_projection(previous_document)==research_projection(d):
                    previous_output=str(safe_path(root,previous_relative+'/'+previous_commit['html_name']))
                    return dict(status='unchanged' if previous_relative==publications[-1] else 'superseded',
                                output=previous_output,publication=previous_commit)
            relative=publications[-1];latest_commit=verify(root,relative)
            latest_document=load(safe_path(root,relative)/'snapshot.json')['document']
            latest_output=str(safe_path(root,relative+'/'+latest_commit['html_name']))
            if research_projection(latest_document)!=research_projection(d):
                raise ValueError('发布版本已变化；拒绝以旧研究内容覆盖新修订')
            d=copy.deepcopy(latest_document)
    if d.get('visual')==result:return dict(status='unchanged',output=latest_output)
    d['visual']=result
    pack=load(work/'evidence-pack.json') if state.get('evidence_sha256') else None
    if pack is not None and digest(work/'evidence-pack.json')!=state['evidence_sha256']:
        raise ValueError('固定资料包哈希发生变化，保留原运行')
    checks=validate_document(root,d,state['contract'],pack)
    from capabilities import enforce_delivery
    enforce_delivery(checks,d,state.get('preflight'))
    if checks['errors']:raise ValueError(canonical(checks['errors'][:6]))
    claimed=claim(root,state['contract'],revision=True,reason='视觉注释；研究内容不变')
    if claimed['status']!='new':raise ValueError('已有未完成修订；先恢复该运行')
    newwork=Path(claimed['work_dir']);newstate=copy.deepcopy(state)
    for key in ('publication','published_input_hash','output','host_receipt'):newstate.pop(key,None)
    newstate.update({k:claimed[k] for k in ('run_id','owner','parent_revision','revision_reason')})
    newstate.update(phase='researching',attempts=[],created_at=stamp())
    d['meta']['run_id']=claimed['run_id'];checks=validate_document(root,d,state['contract'],pack)
    enforce_delivery(checks,d,state.get('preflight'))
    save(newwork/'request.json',state['contract']);save(newwork/'briefing.json',d);save(newwork/STATE,newstate)
    published=publish(root,newwork,newstate,d,checks,render_only=True);sync_info(newwork,newstate,d,checks)
    return dict(published,run_id=claimed['run_id'],run_token=claimed['run_token'])


def status(work,state,initial=False):
    d=load(Path(work)/'briefing.json')
    from schema import check
    structural=check(d)
    if structural:return dict(phase=state['phase'],work_dir=str(work),errors=structural[:6],next='输入类型错误，原运行与预算保留')
    coverage=d.get('coverage',[])
    events=state['telemetry']['events']
    from collections import Counter
    metrics=dict(events_by_kind=dict(Counter(e['kind'] for e in events)),
        stage_wall_ms={stage:(sum(e['wall_ms'] for e in events if e['stage']==stage)
            if all(e.get('wall_ms') is not None for e in events if e['stage']==stage) else None)
            for stage in {e['stage'] for e in events}},
        independent_sources=len({s['origin_group'] for s in d.get('sources',[])}),
        cache_hits=sum(e['kind']=='cache' and e.get('result')=='hit' for e in events),
        recovery_epochs=len(state['context_epochs'])-1,characters_returned_by_guide=state['telemetry']['character_output'],
        tokenizer_estimate=None,api_usage=state['telemetry']['usage'])
    contract=state['contract'] if initial else {k:v for k,v in state['contract'].items() if k!='coverage_obligations'}
    from archive import baseline_snapshot, publication_status
    from research import scan_windows, task_progress, priority_rechecks
    if state.get('publication'):
        availability=publication_status(Path(state['state_root']),state['publication'])
        if availability['status']=='missing_publication':return dict(availability,run_id=state['run_id'])
    progress=task_progress(d,state['contract'])
    baseline=baseline_snapshot(Path(state['state_root']),state['contract']) if state.get('state_root') else None
    scan_plan=scan_windows(state['contract'],baseline.get('comparison_state') if baseline else None)
    rechecks=priority_rechecks(baseline.get('comparison_state') if baseline else None,d) if d['schema_version']>=6 else []
    identity={key:state.get(key,'unknown') for key in ('model','harness','reasoning')}
    if d['schema_version']>=7 and initial:
        return dict(phase=state['phase'],work_dir=str(work),goal=dict(edition=contract['edition'],date=contract['date'],
                    scope=contract['scope'],cutoff=contract['initial_cutoff']),remaining=remaining(state),
                    runtime_identity=identity,data_readiness=state.get('data_readiness'),
                    next=progress['next_actions'],calendar_ids=[c['id'] for c in d['calendars']],
                    preflight=capability_summary(state.get('preflight')),
                    note='先有界发现市场、中国官方/地缘、公司、海外与AI，再比较主线；真实执行时钟已开始。')
    if d['schema_version']>=5 and not initial:
        return dict(phase=state['phase'],work_dir=str(work),goal=dict(edition=contract['edition'],date=contract['date'],scope=contract['scope'],cutoff=contract['initial_cutoff']),
            runtime_identity=identity,data_readiness=state.get('data_readiness'),
            remaining=remaining(state),next=progress['next_actions'],priority_rechecks=rechecks,completed=[dict(task_id=item['id'],products=item['product_ids']) for item in progress['tasks'] if item['status'] in ('done','verified_none')],
            evidence_ids=[item['id'] for item in d['evidence']][-12:],baseline=dict(status=contract.get('baseline_status','legacy_unknown'),record=contract.get('baseline')),
            research_completion={key:progress[key] for key in ('workflow_terminal','research_goals_met','pending','stop_reasons')},
            output=state.get('output'),delivery=state.get('delivery'),usage=state['telemetry']['usage'])
    return dict(phase=state['phase'],work_dir=str(work),contract=contract,remaining=remaining(state),
                scan_plan=scan_plan,priority_rechecks=rechecks,
                preflight=capability_summary(state.get('preflight')),
                output=state.get('output'),delivery=state.get('delivery'),next=progress['next_actions'] or state['next'],
                research_completion=progress,
                key_judgments=[dict(id=a.get('id'),conclusion=a.get('conclusion','')[:500]) for a in d.get('analyses',[])[:6]],
                evidence_ids=[x.get('id') for x in d.get('evidence',[])][-30:],
                coverage_gaps=[dict(id=c.get('id'),status=c.get('status')) for c in coverage if c.get('status') not in ('checked_new','checked_none')],
                tasks=progress['tasks'] or state['tasks'][-12:],history=__import__('archive').historical(Path(state['state_root']),state['contract']['initial_cutoff'],state['contract']['mode']) if state.get('state_root') and state['contract'].get('intent')!='independent' else {'cold_start':True},
                guides={k:dict(acknowledged=v['acknowledged'],pending_page=v['pending'] is not None) for k,v in state['guides'].items()},
                telemetry=metrics,usage=state['telemetry']['usage'])


def guide(args,work,state):
    path=SKILL/'references'/GUIDES[args.name]
    text=path.read_text(encoding='utf-8-sig');sha=fingerprint(text)
    epoch=args.context_epoch
    if epoch not in state['context_epochs']:
        if not args.recovery_reason:raise ValueError('新context_epoch需说明真实压缩/截断恢复原因')
        if len(state['context_epochs'])>state['budget']['max_recoveries']:raise ValueError('已达本轮恢复上限；交付状态并说明阻塞')
        state['context_epochs'].append(epoch)
    key=args.name+'@'+epoch
    progress=state['guides'].setdefault(key,dict(sha256=sha,acknowledged=0,pending=None,replays=0,reason=args.recovery_reason))
    if progress['sha256']!=sha:raise ValueError('规范内容在运行中变化；新context_epoch重新读取必要页')
    if args.ack:
        pending=progress['pending']
        if not pending or args.ack!=pending['token']:raise ValueError('页确认token不匹配')
        progress['acknowledged']=pending['end'];progress['pending']=None;progress['replays']=0
    offset=progress['acknowledged']
    if offset>=len(text):
        save(Path(work)/STATE,state)
        return dict(name=args.name,eof=True,fully_acknowledged=True,sha256=sha,next='停止读取；继续当前研究任务。')
    if progress['pending']:
        if not args.replay:raise ValueError('上一页尚未确认；完整看到页末token才传--ack；截断用--replay')
        progress['replays']+=1
        if progress['replays']>state['budget']['max_page_replays']:raise ValueError('同页恢复过多；减小page-chars并记录原因')
    size=min(args.page_chars or state['budget']['page_chars'],6000)
    if not 256<=size:raise ValueError('page-chars至少256')
    end=min(offset+size,len(text));token=fingerprint(dict(sha256=sha,offset=offset,end=end,epoch=epoch))
    progress['pending']=dict(end=end,token=token)
    state['telemetry']['character_output']+=end-offset
    save(Path(work)/STATE,state)
    # Token at the end: if the host truncates it, the page cannot be acknowledged.
    return dict(name=args.name,sha256=sha,offset=offset,end=end,total_characters=len(text),context_epoch=epoch,
                eof=end==len(text),fully_acknowledged=False,content=text[offset:end],
                next='完整读到本页末尾才在下一调用用--ack确认；最后一页也需确认。截断用--replay。',ack_token=token)


def finish(work,state,preview=False):
    from archive import publish, verify
    work=Path(work);started=time.perf_counter()
    original_phase=state['phase']
    try:
        raw=load(work/'briefing.json');semantic=fingerprint(raw)
    except (ValueError,OSError) as exc:
        semantic=digest(work/'briefing.json') if (work/'briefing.json').exists() else 'missing'
        raw=None;parse_error=exc
    if preview and state['phase'] in ('persistent_confirmed','published'):
        return dict(status='already_published',output=state.get('output'),archived=True),0
    if preview and (work/'prepared.json').exists():
        from render import render_report
        d=materialize(raw,work);checks=load(work/'checks.json')
        output=work/'preview.html';output.write_text(render_report(d,checks),encoding='utf-8')
        return dict(status='preview',output=str(output),delivery=checks['delivery'],archived=False),0
    if state['phase']=='persistent_confirmed':
        return dict(status='persistent_confirmed',receipt=load(work/'host-receipt.json'),confirmed_by='host',independent_cloud_restore_tested=False),0
    if state['phase']=='published':
        d=materialize(raw,work)
        if fingerprint(d)!=state['published_input_hash']:raise ValueError('已发布输入改变；必须显式修订')
        result=publish(Path(state['state_root']),work,state,d,load(work/'checks.json'))
        return result,0
    if (work/'prepared.json').exists():
        d=materialize(raw,work);checks=load(work/'checks.json')
        return publish(Path(state['state_root']),work,state,d,checks),0
    runtime=state.get('preflight')
    if state['contract']['mode']!='teaching' and not state.get('evidence_sha256'):
        if not runtime or runtime['status'] in ('blocked','awaiting_host_report'):
            return dict(status='blocked',category='capability_unavailable',preflight=capability_summary(runtime)),3
        if runtime['status']=='limited_existing' and (not isinstance(raw,dict) or not raw.get('sources') or not raw.get('evidence')):
            return dict(status='blocked',category='insufficient_data',preflight=capability_summary(runtime),
                        reason='没有联网核心能力且没有可核验的已有授权资料，终止实时研究；不交付空壳报告。'),3
    prechecked=None;prepared_document=None;prevalidate_ms=0
    if isinstance(raw,dict) and raw.get('schema_version',0)>=4:
        from schema import check
        from research import task_progress
        if not check(raw):
            limits=remaining(state)
            if not limits['timeout_reached'] and limits['queries_remaining']>0:
                raw=copy.deepcopy(raw)
                for task_item in raw.get('tasks',[]):
                    if task_item['status']=='budget_stop':task_item.update(status='running',next='可见预算未到限，继续研究或记录实际故障')
            progress=task_progress(raw,state['contract'])
            stopped=limits['timeout_reached'] or limits['queries_remaining']==0 or any(item['status']=='user_stop' for item in progress['tasks'])
            if progress['pending'] and not stopped and not preview:
                return dict(status='needs_research',research_completion=progress,next_actions=progress['next_actions'],remaining=limits),0
            if (not preview and not stopped and state['contract'].get('research_workflow_version',0)>=5
                    and raw['meta']['requested_grade']=='full'):
                from archive import validate_document
                prepared_document=materialize(raw,work)
                pack=load(work/'evidence-pack.json') if state.get('evidence_sha256') else None
                if pack and digest(work/'evidence-pack.json')!=state['evidence_sha256']:raise ValueError('固定原包哈希改变')
                vstart=time.perf_counter()
                prechecked=validate_document(Path(state['state_root']),prepared_document,state['contract'],pack)
                prevalidate_ms=(time.perf_counter()-vstart)*1000
                missing=prechecked.get('review_missing',{})
                if not prechecked['errors'] and not prechecked.get('delivery',{}).get('review_scope_satisfied',False):
                    return dict(status='needs_review',review_missing=missing,review_status=prepared_document['review']['status'],
                        blocking_issues=[item for item in prepared_document['review']['issues'] if item['severity']=='blocking' and not item['resolved']],
                        next_actions=[dict(task_id='synthesis',action='inspect --group review 查看未审阅对象；核对后补交 reviewed，处理未解决blocking_issues并记录实际review状态。受阻时说明边界并显式请求 limited/draft。')],
                        delivery=prechecked.get('delivery'),remaining=limits),0
            if stopped and progress['pending']:
                raw=copy.deepcopy(raw)
                for task_item in raw['tasks']:
                    if task_item['id'] in progress['pending']:
                        task_item.update(status='user_stop' if any(item['status']=='user_stop' for item in progress['tasks']) else 'budget_stop',
                                         stop_reason='用户明确停止' if any(item['status']=='user_stop' for item in progress['tasks']) else '配置总时限或已记录查询预算到限')
                save(work/'briefing.json',raw);semantic=fingerprint(raw)
    if not preview and len(state['attempts'])>=state['budget']['max_finish_attempts']:
        return dict(status='stopped',reason='已达有限构建尝试上限',remaining=remaining(state)),3
    if not preview and any(a['input_sha256']==semantic and a.get('category')=='input_error' for a in state['attempts']):
        return dict(status='unchanged_input',reason='同一无效输入（忽略JSON空白）不重复检查；按错误定位修正'),3
    if not preview:
        for old in state['attempts']:
            if old['status']=='started':old.update(status='interrupted',category='interrupted')
    number=len(state['attempts'])+1
    attempt=dict(number=number,input_sha256=semantic,status='started',started_at=stamp(),category=None)
    if not preview:state['attempts'].append(attempt)
    if not preview:
        state['phase']='checking';save(work/STATE,state)
    checks=dict(errors=[],warnings=[],values={},metric_details={});d=None;code=2
    try:
        if raw is None:raise parse_error
        d=prepared_document if prepared_document is not None else materialize(raw,work)
        pack=load(work/'evidence-pack.json') if state.get('evidence_sha256') else None
        if pack and digest(work/'evidence-pack.json')!=state['evidence_sha256']:raise ValueError('固定原包哈希改变')
        from archive import validate_document
        vstart=time.perf_counter();checks=prechecked if prechecked is not None else validate_document(Path(state['state_root']),d,state['contract'],pack)
        from capabilities import enforce_delivery
        enforce_delivery(checks,d,runtime)
        attempt['validate_ms']=prevalidate_ms+(time.perf_counter()-vstart)*1000
        if checks['errors']:
            attempt.update(status='failed',category='input_error');state['phase']='needs_input_fix'
        else:
            if preview:
                from render import render_report
                output=work/'preview.html';output.write_text(render_report(d,checks),encoding='utf-8')
                attempt.update(status='preview',category=None)
                return dict(status='preview',output=str(output),delivery=checks['delivery'],archived=False),0
            attempt['validated']=True
            save(work/'checks.json',checks)
            publication=publish(Path(state['state_root']),work,state,d,checks)
            attempt.update(status=publication['status'],category=None)
            state.update(delivery=checks['delivery'],review_status=d['review']['status'],visual_status=d.get('visual',{}).get('status','not_performed'),
                         next='返回真实归档状态；已生成但未归档时仅重试提交，不重做研究。')
            if publication['status'] in ('archive_unconfirmed','ephemeral_only'):state['phase']=publication['status']
            code=0
    except KeyboardInterrupt:
        attempt.update(status='interrupted',category='interrupted');state['phase']='interrupted'
        raise
    except OSError as exc:
        attempt.update(status='failed',category='infrastructure_error');state['phase']='retryable'
        checks['errors'].append(dict(path='build',category='infrastructure_error',message=str(exc),exception_type=type(exc).__name__))
    except ValueError as exc:
        attempt.update(status='failed',category='input_error');state['phase']='needs_input_fix'
        checks['errors'].append(dict(path='input',category='input_error',message=str(exc),exception_type=type(exc).__name__))
    except Exception as exc:
        attempt.update(status='failed',category='program_defect');state['phase']='blocked'
        checks['errors'].append(dict(path='program',category='program_defect',message=str(exc),exception_type=type(exc).__name__,traceback=traceback.format_exc()))
    finally:
        attempt['wall_ms']=(time.perf_counter()-started)*1000
        if preview:
            state['phase']=original_phase
        try:
            if not preview:
                save(work/f'checks-attempt-{number:02d}.json',checks)
                save(work/'checks.json',checks)
                save(work/STATE,state)
                from schema import check
                sync_info(work,state,d if d is not None and not check(d) else None,checks)
        except (OSError,ValueError,TypeError,KeyError) as exc:
            checks['errors'].append(dict(path='diagnostics',category='infrastructure_error',message=str(exc),saved=False));code=3
    return dict(status=publication['status'] if code==0 else state['phase'],output=publication.get('output') if code==0 else state.get('output'),error_count=len(checks['errors']),
                errors=checks['errors'][:6],warning_count=len(checks['warnings']),delivery=checks.get('delivery'),
                checks=str(work/'checks.json'),category=attempt['category'],remaining=remaining(state)),code
