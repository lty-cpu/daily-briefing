# DSH宿主适配

用途 / 何时读：DeepSeek Harness 桌面端的专用说明；入口命中相应任务时读取。

使用Agent模式及本轮实际提供的工具；Chat模式无法执行研究。Skill安装于用户目录的`.dsh/skills/daily-briefing`，研究规范、Python、Tushare和报告模板与Codex共用。

所有run.py子命令传同一 `--config <用户目录>/.dsh/daily-briefing/config.json`，已有配置沿用，不重新init、不切换到Codex资料库。只有配置确实不存在时按[归档使用](archive.md#本地初始化与定位)初始化用户指定目录。

Python优先用实际可见的依赖定位工具；没有则核验本机已有解释器。Windows通过DSH的pwsh或其公开执行工具运行，使用UTF-8，例如 `python -X utf8 -B <skill>/scripts/run.py options --config <上述配置>`。参数中的路径按实际安装位置填写，不照搬另一宿主的绝对目录。

网页使用实际可用的web_search/web_fetch及provider；缺能力如实记录，不把另一个研究任务的成品当作本轮已核验原文。Python进程联网按DSH的权限协议申请，不套用Codex工具名或权限参数、不关闭全局沙箱。失败按[有界数据取用](history-data.md#进程联网权限)处理。

凭据位置与兼容读取见[Skill入口](../SKILL.md#一次配置按期运行)，本机使用 `.dsh/daily-briefing/local_config.json`。

start另传 `--harness dsh --model <当前实际模型> --reasoning <实际级别或unknown> --request-at <原请求ISO时间>`；不可见的字段保持unknown，不从登录账号猜模型。预览使用本宿主实际文件/浏览器工具；缺视觉能力标not_performed，不调用Codex专有面板接口。

实际成功的模型调用和当前工具清单作为能力记录，不凭安装成功宣称可用。
