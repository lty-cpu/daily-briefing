# 期限驱动

用途 / 何时读：做三期限判断、首屏stance或复核期限错配时读取。

| 期限 | 主导驱动族 | 需要解释 | 典型失误 |
|---|---|---|---|
| 当日—3日 | 催化、隔夜跨资产、情绪/特定资金渠道、仓位极端、波动 | 驱动何时出现、已反应多少、下一有效会话如何判别 | 单日价格反推原因，忽略反转基准率 |
| 1—4周 | 相对强弱持续性、政策/财报日程、流动性、广度趋势、拥挤 | 5/20日对照、驱动延续条件、日程窗口 | 外推一日领涨，成交额替代净流入 |
| 1—3月 | 盈利修订、政策周期、估值/ERP、信用与流动性、供需 | 盈利与估值共同作用，时滞及反方 | 只讲订单链，省略折现率、估值和信用 |

每个lean命名指数基准及窗口；包含驱动、风险、带日期的翻转条件和下次核对。不仅引用价格行为。暂不判断必须给具体缺口和解除条件，进入弃权记录。confidence仍是机制把握度，不是概率。

输入driver_family使用以下稳定ID（括号为含义）：intraday用catalyst、cross_asset、sentiment_flow、positioning、volatility；short用relative_strength、policy_earnings、liquidity、breadth、crowding；medium用earnings_revision、policy_cycle、valuation、credit_liquidity、supply_demand。含义对应上表，ID不供读者展示。

跨资产不同步先解释张力：利率、汇率、商品与股票方向不必一致；期限、供给冲击和风险溢价可造成分歧，不能把相关性直接写成因果。
