# 固定市场状态

用途 / 何时读：编辑首屏状态、补宏观数据或解释风格轮动时读取。

状态是现有metric/series的投影，数值、时间和support仍按[研究输入](research-input.md)。完整期报显示固定六组，不随新闻消失；缺值显示未追踪，不能由指数名称猜估值。实际值来自有效缓存、唯一Tushare客户端、网页补缺。

| 组 | 固定观察对象 | 缺项处理 |
|---|---|---|
| 流动性 | 中国10年国债、DR007/一周SHIBOR、LPR、中美10年利差 | 中债/交易中心/央行；无合格时点显示未追踪 |
| 增长 | PMI、CPI/PPI、社融/M2 | 统计局/央行；月份与发布日期分开，API月份不证明发布时间 |
| 外部 | 美债10年/2年、美元指数、USDCNH、布伦特、铜、黄金、VIX | 各自收盘/报价时点、合约与计价；未取不填零 |
| 风险偏好 | 成交、广度、中位涨跌、涨跌停/连板、融资 | 样本、停牌、供应商分类及更新滞后就近标记 |
| 估值 | 沪深300/创业板/科创50 PE/PB、ERP、股息利差 | 指数估值须同口径；不能用个股简单平均充当指数估值 |
| 风格 | 沪深300、中证500、中证1000、红利、300成长/价值 | 同窗相对收益；不是由名称推导久期 |

## 计算和规则

`insights.py`计算1/5/20有效会话变化，利率以bp、价格以%；缺点断开。资金利率的发布日与A股开市日可不同，面板按已核A股会话取交集，原始响应完整保留；LPR按不规则发布序列，不强塞进A股日历。
- 分位：固定3年内实际所得样本，中秩 `(小于当前数+0.5×等于当前数)/n`；显示n和实际窗口，不把61点称为完整3年。
- ERP：同口径正PE时 `100/PE−中国10年国债收益率%`；同时点不可得不计算。
- 截面中位数：有效个股pct_chg等权中位数；成交集中度为成交额前ceil(n/10)只占比。不是资金净流入，也不是市值等权组合收益。
- 行业：1/5/20同窗收益减基准收益，量能比沿用[研究方法](research-method.md#6-资金与市场阶段)。样本与分类版本不可混用。

四轴标签最多各三种有效状态，缺输入额外显示未追踪。标签是“研究规则，非经验证策略”，不自动推出价格立场。

| 轴 | 规则 | 旁显输入 |
|---|---|---|
| 流动性 | 一周SHIBOR 5会话变化≤−10bp宽松，≥10bp偏紧，否则平稳 | 实际变化与日期；仅是该资金价格代理 |
| 风险偏好 | 同样本上涨占比≥60%扩散，≤40%收缩，否则分化 | n与上涨占比；单日代理不称阶段因果 |
| 估值 | PE 3年样本分位≤20%偏低，≥80%偏高，否则中性；至少120点 | PE口径、分位、n、窗口 |
| 增长动能 | PMI≥50.5扩张，≤49.5收缩，否则平稳 | 发布日期与统计月份；无原发布页则未追踪 |

这些阈值是透明的初始研究约定，未拟合收益，也不表示优劣概率。状态和方向不以同一颜色暗示确定性。

## 数据入口与权限

接口字段已核验于2026-09-30；门槛有文档差异，实际账号响应为准。无权限仅停止该接口，网页或未追踪保底。所有接口仍用现有Client、history cache、source/evidence和calendar。

| 变量/接口 | 已核字段与门槛 | 正常路径/回退 |
|---|---|---|
| 中国10年 `yc_cb` | trade_date/curve_type/curve_term/yield；单独授权 | start补；中债原表 |
| `shibor` / `shibor_lpr` | date/1w、date/1y/5y；接口页120，权限总表SHIBOR写2000，存在差异 | start补；交易中心/央行 |
| `cn_cpi` / `cn_ppi` / `cn_m` | month/nt_yoy、ppi_yoy、m2_yoy；600 | data的macro取候选，原发布页证明日期 |
| `cn_pmi` / `sf_month` | month/pmi010000；5000；month/inc_month；2000 | 同上；统计局/央行 |
| `index_dailybasic` | ts_code/trade_date/pe/pe_ttm/pb；接口页2000、总表4000；仅部分指数 | start补；中证/国证估值表；缺行不估算 |
| `margin` | trade_date/exchange_id/rzye；2000 | 更新通常次日08:30—09:05；08:00不能冒充已取得昨日值 |
| `limit_list_d` | trade_date/limit/limit_times；5000，不含ST | start补；实际榜单替代 |
| `fund_share` / `etf_share_size` | 官方页本次不可读，ETF目录核得接口但完整字段/权限未验证 | 仅候选、不自动启用；交易所份额表；未追踪 |
| `index_weight` | index_code/trade_date/con_code/weight；2000 | 名字/成分核验按需；不用权重推导资金 |
| `eco_cal` | date/time/event/value/pre_value/fore_value；2000 | 日历候选需原发布日程核验；不信任后修订预期 |
| 额外指数 `index_daily` | 000905/000852/000922/000918/000919.SH；2000起 | 同一收盘序列；供应商实际代码/名称核对 |

官方依据：[中债](https://tushare.pro/document/2?doc_id=201)、[SHIBOR](https://tushare.pro/document/2?doc_id=149)、[LPR](https://tushare.pro/document/2?doc_id=151)、[CPI](https://tushare.pro/document/2?doc_id=228)、[PPI](https://tushare.pro/document/2?doc_id=245)、[PMI](https://tushare.pro/document/2?doc_id=325)、[M2](https://tushare.pro/document/2?doc_id=242)、[社融](https://tushare.pro/document/2?doc_id=310)、[估值](https://tushare.pro/document/2?doc_id=128)、[融资](https://tushare.pro/document/2?doc_id=58)、[涨跌停](https://tushare.pro/document/2?doc_id=298)、[权重](https://tushare.pro/document/2?doc_id=96)、[日历](https://tushare.pro/document/2?doc_id=233)、[总表](https://tushare.pro/document/1?doc_id=108)。

## 可选输入

review可加stance：`{regime_line,horizons:{intraday/short/medium:{lean,benchmark,window,driver,risk,flip_condition,next_check_at,refs,abstain_reason?,resolve_data?,driver_family?,ledger_id?}},changed_since_prior:[{text,thesis_id?,previous_version?,metric_ids?}],cross_asset_tension?}`。

refs在提交时绑定已有claims；旧归档无stance仍正常打开。立场资格统一见[期限驱动](horizon-drivers.md)。

`kind:"catalyst",task:"synthesis",alias,what,when,why_it_matters,source`，source格式与消息相同；可加prior/consensus/theme_id/scope。日期无钟点就保留日期。正常信息准入不变。

thesis可加`scenarios:[{kind:"base|upside|adverse",narrative,condition_ref:"support|invalidation",horizons:["intraday","short","medium"]}]`，以及`priced_in:{series_id,benchmark_id,event_date,pre_start?,post_end?,valuation_metric_ids?,expectation_evidence_ids?}`。

引用日期的实际可比序列；不满足则显示缺口。

data可加`state:true,macro:true`补状态候选，`base_rates:true`按需首次拉取两宽基至多10年历史；`sector_codes:["801010.SI"]`补最多8个已入选行业的61会话历史。都复用现有Client、calendar、cache和证据；缺权限不阻塞交付。研究概率见[可结算判断账本](forecast-ledger.md)。
