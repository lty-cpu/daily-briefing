"""可结算研究账本：快照为原始记录，账本仅为可重建的追加投影。"""
from pathlib import Path
from common import load,save,fingerprint,iso
from insights import points,contiguous,base_rates,probability,scores

def prepare(document, claim):
    ss={s['id']:s for s in document['series']};s=ss.get(claim.get('series_id'));n=claim.get('sessions')
    if not s or n not in (1,5,20) or s.get('asset_type')!='index':
        return dict(status='unavailable',reason='只结算已命名公共指数的1/5/20会话方向命题')
    xs=points(document,s)
    if not xs or not contiguous(document,s,xs[-1:]):return dict(status='unavailable',reason='基点或日历不足')
    base=base_rates(document,s)['windows'][str(n)]
    if base['n_eff']<30:return dict(status='unavailable',reason=f'非重叠样本不足30，当前n_eff={base["n_eff"]}')
    allowed={e['id'] for e in document['evidence'] if e['read_method'] in ('original','cached')}
    adjustments=claim.get('adjustments',[])
    if any(not set(a.get('evidence_ids',[]))<=allowed for a in adjustments):return dict(status='unavailable',reason='调整引用未读证据')
    p=probability(base['p0'],adjustments)
    if p is None:return dict(status='unavailable',reason='调整须为至多3条−5/0/+5pp且引用证据')
    horizon=claim.get('horizon','intraday' if n==1 else 'short')
    c=dict(claim,status='pending',benchmark=s['label'],entity_id=s['entity_id'],base_date=xs[-1]['date'],base_value=xs[-1]['value'],
        calendar_id=s['calendar_id'],p=p,p0=base['p0'],base_rate=base,window_start=base_rates(document,s)['start'],
        cutoff=document['meta']['cutoff'],horizon=horizon,claim_type='close_above_base',calibration='研究概率（未校准）')
    c['id']='FC_'+fingerprint([s['entity_id'],c['base_date'],n,document['meta']['cutoff'],horizon])[:24]
    return c

def events(root):
    if not root:return []
    folder=Path(root)/'.runtime/forecast-ledger'
    return [load(p) for p in sorted(folder.glob('*.json'))] if folder.exists() else []

def view(root,document):
    try:eligible=[e for e in events(root) if e.get('namespace')==document['meta']['mode'] and e.get('profile')==document['meta']['profile'] and e.get('cutoff') and iso(e['cutoff'])<=iso(document['meta']['cutoff'])]
    except (ValueError,OSError,KeyError,TypeError,AttributeError) as exc:
        return dict(scores([]),status='untracked',reason='账本记录未能完整读取，评分暂不可用',error_type=type(exc).__name__,records=[],resolutions=[],buckets={},pending=0,abstention_rate=None)
    records={e['claim']['id']:e['claim'] for e in eligible if e['kind']=='claim'}
    resolved={e['claim_id']:e for e in eligible if e['kind']=='resolution'}
    ss={s['entity_id']:s for s in document['series'] if s.get('asset_type')=='index'}
    new=[];rows=[]
    for cid,c in records.items():
        if cid in resolved:rows.append(dict(c,**{k:resolved[cid][k] for k in ('outcome','resolved_at','end_date','end_value')}));continue
        s=ss.get(c['entity_id']);xs=points(document,s) if s else []
        positions=[i for i,p in enumerate(xs) if p['date']==c['base_date']]
        if positions:
            window=xs[positions[0]:positions[0]+c['sessions']+1]
            if len(window)==c['sessions']+1 and contiguous(document,s,window) and window[0]['value']==c['base_value']:
                r=dict(kind='resolution',claim_id=cid,outcome=int(window[-1]['value']>c['base_value']),
                    end_date=window[-1]['date'],end_value=window[-1]['value'],resolved_at=document['meta']['cutoff'],
                    cutoff=document['meta']['cutoff'],evidence_ids=s['evidence_ids'])
                new.append(r);rows.append(dict(c,**{k:r[k] for k in ('outcome','resolved_at','end_date','end_value')}));continue
        rows.append(c)
    buckets={}
    for r in rows:buckets.setdefault(r['horizon']+':'+r['claim_type'],[]).append(r)
    result=scores(rows);result.update(records=rows,resolutions=new,
        buckets={k:scores(v) for k,v in buckets.items()},pending=sum('outcome' not in r for r in rows))
    abstentions=[e for e in eligible if e['kind']=='abstention']
    denomin=len(records)+len(abstentions)
    result['abstention_rate']=len(abstentions)/denomin if denomin else None
    return result

def append_publication(root,document,publication):
    """只在成功正式commit后调用；preview无写入。重复回执幂等。"""
    folder=Path(root)/'.runtime/forecast-ledger'
    additions=[dict(kind='claim',claim=c,cutoff=c['cutoff'],publication=publication) for c in document.get('forecast_claims',[]) if c.get('status')=='pending' and prepare(document,c)==c]
    additions+=view(root,document).get('resolutions',[])
    for h,value in document.get('stance',{}).get('horizons',{}).items():
        if value.get('lean')=='abstain':additions.append(dict(kind='abstention',horizon=h,reason=value.get('abstain_reason',''),cutoff=document['meta']['cutoff'],publication=publication))
    for event in additions:
        event.update(namespace=document['meta']['mode'],profile=document['meta']['profile'])
        ident=fingerprint([event['namespace'],event['profile'],event['kind'],event.get('claim',{}).get('id') or event.get('claim_id') or [event['cutoff'],event.get('horizon')]])
        path=folder/(ident+'.json')
        if path.exists():continue
        folder.mkdir(parents=True,exist_ok=True);save(path,event,exclusive=True)
