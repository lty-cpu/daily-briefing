"""现有证据上的确定性研究计算；缺值降级，不联网，不写发布状态。"""
from datetime import date, timedelta
from statistics import median
import math
from common import iso, num, fingerprint

HORIZONS = {'intraday': '当日—3日', 'short': '1—4周', 'medium': '1—3月'}
CORE = (
    ('流动性', '中国10年国债', ('cn_10y',)), ('流动性', 'DR007 / SHIBOR一周', ('dr007', 'shibor_1w')),
    ('流动性', 'LPR一年', ('lpr_1y',)), ('流动性', '中美10年利差', ('cn_us_spread',)),
    ('增长', '制造业PMI', ('pmi',)), ('增长', 'CPI / PPI', ('cpi', 'ppi')),
    ('增长', '社融 / M2', ('sf_month', 'm2_yoy')), ('外部', '美债10年 / 2年', ('us_10y', 'us_2y')),
    ('外部', '美元指数 / 离岸人民币', ('dxy', 'usdcnh')), ('外部', '布伦特 / 铜 / 黄金', ('brent', 'copper', 'gold')),
    ('外部', 'VIX', ('vix',)), ('风险偏好', '有效A股截面', ('participation',)),
    ('风险偏好', '涨停 / 跌停 / 连板', ('limit_up', 'limit_down', 'limit_height')),
    ('风险偏好', '融资余额', ('margin_balance',)), ('估值', '沪深300 PE / PB', ('hs300_pe', 'hs300_pb')),
    ('估值', '创业板 / 科创50 PE', ('cyb_pe', 'star_pe')), ('估值', 'ERP / 股息利差', ('erp', 'dividend_spread')),
    ('风格', '大盘 / 中小盘 / 红利 / 成长价值', ('style',)),
)

def percentile(value, history):
    """中秩经验分位，0—100；缺失不算零。"""
    xs=[x for x in history if num(x)]
    return (sum(x<value for x in xs)+sum(x==value for x in xs)/2)/len(xs)*100 if xs and num(value) else None

def quantile(xs, q):
    xs=sorted(xs)
    if not xs:return None
    p=(len(xs)-1)*q;i=int(p)
    return xs[i]+(xs[min(i+1,len(xs)-1)]-xs[i])*(p-i)

def erp(pe, yield_percent):
    return 100/pe-yield_percent if num(pe) and pe>0 and num(yield_percent) else None

def points(document, series):
    """只用截止前可得、非条件值；连续窗口另核交易日历。"""
    cutoff=iso(document['meta']['cutoff'])
    return sorted([p for p in series['observations'] if p.get('available_at') and
        iso(p['available_at'])<=cutoff and p.get('status')=='traded' and num(p.get('value'))],key=lambda p:p['date'])

def contiguous(document, series, xs):
    if not xs:return False
    cal=next((c for c in document['calendars'] if c['id']==series.get('calendar_id')),None)
    if not cal or not cal['complete'] or cal.get('synthetic') and document['meta']['mode']!='teaching':return False
    a,b=xs[0]['date'][:10],xs[-1]['date'][:10]
    if not cal['valid_from']<=a<=b<=cal['valid_to']:return False
    expected=[s['date'] for s in cal['sessions'] if a<=s['date']<=b]
    return expected==[p['date'][:10] for p in xs]

def changes(document, series):
    xs=points(document,series);out={}
    for n in (1,5,20):
        chosen=xs[-n-1:]
        if len(chosen)!=n+1 or not contiguous(document,series,chosen):out[str(n)]=None;continue
        a,b=chosen[0]['value'],chosen[-1]['value']
        out[str(n)]=(b-a)*100 if series['basis']=='yield_percent' else (b/a-1)*100 if a else None
    return out

def internals(rows):
    valid=[r for r in rows if num(r.get('pct_chg')) and num(r.get('amount')) and r['amount']>=0]
    if not valid:return dict(status='untracked',reason='未取得可核验日线截面')
    total=sum(r['amount'] for r in valid);n=len(valid)
    return dict(status='available',n=n,up=sum(r['pct_chg']>0 for r in valid),down=sum(r['pct_chg']<0 for r in valid),
        flat=sum(r['pct_chg']==0 for r in valid),median=median(r['pct_chg'] for r in valid),
        up_share=sum(r['pct_chg']>0 for r in valid)/n*100,
        top_decile_turnover=sum(sorted((r['amount'] for r in valid),reverse=True)[:math.ceil(n/10)])/total*100 if total else None,
        amount=total/100000,sample=len(rows)>=6000,
        method='有效日线截面等权中位数；成交集中度为按成交额排序前ceil(n/10)只占比；不代表净流入')

def base_rates(document, series, horizons=(1,5,20), condition=None):
    xs=points(document,series)
    if not xs:return dict(status='unavailable',reason='无截止前可用历史')
    end=date.fromisoformat(xs[-1]['date'][:10]);begin=end-timedelta(days=3653)
    xs=[p for p in xs if p['date'][:10]>=begin.isoformat()]
    cal=next((c for c in document['calendars'] if c['id']==series.get('calendar_id')),None)
    dates=[p['date'][:10] for p in xs]
    sessions={s['date']:i for i,s in enumerate(cal['sessions'])} if cal else {}
    valid_cal=bool(cal and cal['complete'] and (not cal.get('synthetic') or document['meta']['mode']=='teaching'))
    def sequence(start,end):
        return valid_cal and dates[start] in sessions and dates[end] in sessions and sessions[dates[end]]-sessions[dates[start]]==end-start and all(d in sessions for d in dates[start:end+1])
    out=dict(status='available',series_id=series['id'],benchmark=series['label'],start=xs[0]['date'],end=xs[-1]['date'],
             method='固定前瞻会话收益；严格正收益为1；n_eff为贪心不重叠窗口数；非因果策略',windows={})
    for n in horizons:
        vals=[];effective=[];last=-n-1
        for i in range(len(xs)-n):
            window=xs[i:i+n+1]
            if not sequence(i,i+n) or window[0]['value']<=0:continue
            if condition:
                # 条件只能使用窗口起点及之前的数据，禁止用未来状态回填历史。
                prior=xs[max(0,i-20):i+1]
                kind=condition.get('kind')
                if kind=='prior20':
                    if len(prior)!=21 or not sequence(i-20,i):continue
                    prev=(prior[-1]['value']/prior[0]['value']-1)*100
                else:
                    # 宽度/估值/量能条件必须使用各历史起点当时可得的状态序列。
                    state_series=next((s for s in document['series'] if s['id']==condition.get('series_id')),None)
                    if not state_series or kind not in ('breadth','valuation_percentile','volume_ratio'):continue
                    history=[p for p in points(document,state_series) if p['date'][:10]<=xs[i]['date'][:10] and iso(p['available_at'])<=iso(xs[i]['available_at'])]
                    if not history:continue
                    prev=history[-1]['value']
                    if kind=='valuation_percentile':
                        if len(history)<120:continue
                        prev=percentile(prev,[p['value'] for p in history])
                if not condition['low']<=prev<condition['high']:continue
            ret=(window[-1]['value']/window[0]['value']-1)*100
            vals.append(ret)
            if i>=last+n:last=i;effective.append(ret)
        out['windows'][str(n)]=dict(n=len(vals),n_eff=len(effective),p0=sum(v>0 for v in vals)/len(vals) if vals else None,
             median=median(vals) if vals else None,q1=quantile(vals,.25),q3=quantile(vals,.75),
             state=condition or {'kind':'unconditional'})
    return out

def probability(p0, adjustments):
    if not num(p0) or not 0<=p0<=1 or len(adjustments)>3:return None
    if any(a.get('pp') not in (-5,0,5) or not a.get('evidence_ids') for a in adjustments):return None
    # 启发式步长用于限制任意精度，并不声称是数据拟合系数。
    p=max(.05,min(.95,p0+sum(a['pp'] for a in adjustments)/100))
    return math.floor(p*20+.5)/20

def scores(records):
    resolved=[r for r in records if r.get('outcome') in (0,1) and num(r.get('p')) and num(r.get('p0'))]
    n=len(resolved)
    if not n:return dict(n=0,hit_rate=None,brier=None,brier_base=None,skill_score=None,bins=[])
    brier=sum((r['p']-r['outcome'])**2 for r in resolved)/n
    base=sum((r['p0']-r['outcome'])**2 for r in resolved)/n
    bins=[]
    if n>=30:
        for lo in (0,.2,.4,.6,.8):
            group=[r for r in resolved if lo<=r['p']<(lo+.2) or lo==.8 and r['p']==1]
            if group:bins.append(dict(low=lo,high=lo+.2,n=len(group),forecast=sum(r['p'] for r in group)/len(group),
                realized=sum(r['outcome'] for r in group)/len(group)))
    return dict(n=n,hit_rate=sum((r['p']>=.5)==bool(r['outcome']) for r in resolved)/n,
        brier=brier,brier_base=base,skill_score=1-brier/base if base else None,bins=bins)

def evidence_grade(document, evidence_ids):
    em={e['id']:e for e in document['evidence']};sm={s['id']:s for s in document['sources']}
    es=[em[x] for x in evidence_ids if x in em]
    if not es:return 'C'
    if all(e['read_method'] in ('original','cached') and sm.get(e['source_id'],{}).get('kind') in ('official','company','data') and
        sm.get(e['source_id'],{}).get('read_status')=='full' for e in es):return 'A'
    return 'B'

def build(document,checks):
    """固定面板从现有指标投影，不创造第二套数值身份。"""
    values=checks.get('values',{});unready=set(checks.get('unready_metrics',[]));metrics=document['metrics']
    by_measure={};series_by_id={s['id']:s for s in document['series']}
    for m in metrics:
        if m['id'] in unready or m.get('value_identity')=='conditional' or m.get('kind')=='forecast':continue
        if not num(values.get(m['id'])):continue
        key=m['dimensions']['measure'];key={'treasury_yield_y10':'us_10y','treasury_yield_y2':'us_2y'}.get(key,key);by_measure.setdefault(key,[]).append(m)
    for key in by_measure:by_measure[key].sort(key=lambda m:m.get('as_of',m['dimensions']['period']))
    def selected(keys):return [m for k in keys for m in by_measure.get(k,[])[-1:]]
    tiles=[]
    for group,label,keys in CORE:
        ms=selected(keys);entries=[]
        if keys==('style',):
            ss=[s for s in document['series'] if s.get('asset_type')=='index' and any(word in s['label'] for word in ('沪深300','中证500','中证1000','红利','成长','价值'))]
            for s in ss:
                xs=points(document,s)
                if xs:entries.append(dict(label=s['label'],value=xs[-1]['value'],unit=s['unit'],as_of=xs[-1]['date'],series_id=s['id'],
                    deltas=changes(document,s),percentile=None,n=len(xs),window='已取会话',evidence_ids=s['evidence_ids']))
        for m in ms:
            s=series_by_id.get(m.get('series_id'));xs=points(document,s) if s else []
            # 固定3年观察窗；样本不足明确显示，不拿61点冒充完整3年。
            floor=(date.fromisoformat(document['meta']['date'])-timedelta(days=1096)).isoformat()
            hist=[p['value'] for p in xs if p['date'][:10]>=floor]
            entries.append(dict(label=m['label'],value=values[m['id']],unit=m['unit'],as_of=m.get('as_of',m['dimensions']['period']),
                metric_id=m['id'],series_id=m.get('series_id'),deltas=changes(document,s) if s else {},
                percentile=percentile(values[m['id']],hist) if len(hist)>=30 else None,n=len(hist),window='3年内实际所得样本',
                evidence_ids=m.get('evidence_ids',[])))
        tiles.append(dict(group=group,label=label,status='available' if entries else 'untracked',entries=entries))
    axes=[]
    def latest(key):
        ms=by_measure.get(key,[]);return values[ms[-1]['id']] if ms else None
    for label,key,rule in [('流动性','shibor_1w','一周SHIBOR的5会话变化≤−10bp为宽松，≥10bp为偏紧，否则平稳'),
                            ('风险偏好','participation','上涨占比≥60%为扩散，≤40%为收缩，否则分化'),
                            ('估值','hs300_pe','3年样本PE中秩分位≤20%为偏低，≥80%为偏高，否则中性'),
                            ('增长动能','pmi','PMI≥50.5为扩张，≤49.5为收缩，否则平稳')]:
        value=latest(key);state=None;input_text='未追踪'
        if key=='pmi' and value is not None:state='扩张' if value>=50.5 else '收缩' if value<=49.5 else '平稳';input_text=f'PMI {value:g}'
        elif key=='participation' and value is not None:state='扩散' if value>=60 else '收缩' if value<=40 else '分化';input_text=f'上涨占比 {value:.1f}%'
        elif key=='shibor_1w':
            entry=next((e for t in tiles for e in t['entries'] if e.get('metric_id') and metrics_by_id(metrics)[e['metric_id']]['dimensions']['measure']==key),None)
            delta=entry.get('deltas',{}).get('5') if entry else None
            if delta is not None:state='宽松' if delta<=-10 else '偏紧' if delta>=10 else '平稳';input_text=f'5会话变化 {delta:+.1f}bp'
        elif key=='hs300_pe':
            ms=by_measure.get(key,[]);entry=next((e for t in tiles for e in t['entries'] if ms and e.get('metric_id')==ms[-1]['id']),None)
            p=entry.get('percentile') if entry else None
            if p is not None and entry['n']>=120:state='偏低' if p<=20 else '偏高' if p>=80 else '中性';input_text=f'PE分位 {p:.1f}%，n={entry["n"]}'
        axes.append(dict(label=label,state=state or '未追踪',input=input_text,rule=rule))
    rates=[]
    for s in document['series']:
        if s.get('asset_type')=='index' and s['label'] in ('沪深300','上证指数'):
            rates.append(base_rates(document,s));rates.append(base_rates(document,s,condition=dict(kind='prior20',low=-100,high=0)))
            rates.append(base_rates(document,s,condition=dict(kind='prior20',low=0,high=1000)))
            for kind,measure,bounds in [('breadth','participation',[(0,40),(40,60),(60,101)]),
                ('valuation_percentile','hs300_pe',[(0,20),(20,80),(80,101)]),
                ('volume_ratio','volume_ratio',[(0,.8),(.8,1.2),(1.2,100)])]:
                ms=by_measure.get(measure,[]);sid=ms[-1].get('series_id') if ms else None
                if sid and sid in series_by_id:
                    rates.extend(base_rates(document,s,condition=dict(kind=kind,series_id=sid,low=lo,high=hi)) for lo,hi in bounds)
    # 同日可审核输入的派生状态，只投影计算，不建立第二套metric身份。
    for label,keys,formula,unit,destination in [('中美10年利差',('cn_10y','us_10y'),lambda a,b:(a-b)*100,'bp','中美10年利差'),
        ('沪深300 ERP',('hs300_pe','cn_10y'),erp,'百分点','ERP / 股息利差'),
        ('股息利差',('dividend_yield','cn_10y'),lambda a,b:a-b,'百分点','ERP / 股息利差')]:
        ms=selected(keys)
        if len(ms)!=2 or len({m.get('as_of',m['dimensions']['period'])[:10] for m in ms})!=1:continue
        value=formula(*(values[m['id']] for m in ms))
        if value is None:continue
        tile=next(t for t in tiles if t['label']==destination)
        tile['status']='available';tile['entries'].append(dict(label=label,value=value,unit=unit,as_of=ms[0].get('as_of',ms[0]['dimensions']['period']),
            metric_ids=[m['id'] for m in ms],evidence_ids=list(dict.fromkeys(x for m in ms for x in m.get('evidence_ids',[]))),
            deltas={},n=0,percentile=None,window='同日输入；派生公式见研究规则'))
    internal=dict(status='untracked',reason='截面统计尚未进入可审核的统一数值路径')
    nums={key:latest(key) for key in ('participation','median_return','turnover_concentration')}
    breadth=[m for m in by_measure.get('breadth',[]) if m.get('category') in ('up','down','flat')]
    counts={m['category']:values[m['id']] for m in breadth}
    if all(num(v) for v in nums.values()) and set(counts)=={'up','down','flat'}:
        n=sum(counts.values());ms=selected(('participation',));as_of=ms[0].get('as_of') if ms else None
        internal=dict(status='available',n=n,up=counts['up'],down=counts['down'],flat=counts['flat'],up_share=nums['participation'],
            median=nums['median_return'],top_decile_turnover=nums['turnover_concentration'],sample=n>=6000,as_of=as_of,
            method='统一数值证据的有效日线截面；涨跌中位数为等权描述，成交集中度为成交额前ceil(n/10)只占比，不代表资金净流入。')
    return dict(tiles=tiles,axes=axes,base_rates=rates,sectors=sector_context(document,checks),
        internals=internal,rule_label='研究规则，非经验证策略')

def sector_context(document,checks):
    """同分类行业×1/5/20会话超额收益与量能比；缺历史保持空格。"""
    byid={s['id']:s for s in document['series']};bench=next((s for s in document['series'] if s['label']=='沪深300' and s.get('asset_type')=='index'),None)
    bd=changes(document,bench) if bench else {};values=checks.get('values',{});unready=set(checks.get('unready_metrics',[]));result=[]
    bm=next((m for m in document['metrics'] if m['dimensions']['measure']=='index_change' and '沪深300' in m['label'] and m['id'] not in unready),None)
    for m in document['metrics']:
        if m['dimensions']['measure']!='sector_change' or m['id'] in unready or not num(values.get(m['id'])):continue
        entity=m['dimensions']['entity_id'];s=next((v for v in byid.values() if v['entity_id']==entity and v['basis']=='price'),None)
        sd=changes(document,s) if s else {};diff={str(n):sd.get(str(n))-bd[str(n)] if sd.get(str(n)) is not None and bd.get(str(n)) is not None else None for n in (1,5,20)}
        if diff['1'] is None and bm and m.get('as_of')==bm.get('as_of') and num(values.get(bm['id'])):diff['1']=values[m['id']]-values[bm['id']]
        volume=next((v for v in byid.values() if v['entity_id']==entity and v['basis']=='turnover'),None);vx=points(document,volume) if volume else []
        chosen=vx[-21:];ratio=None
        if len(chosen)==21 and contiguous(document,volume,chosen) and sum(p['value'] for p in chosen[:-1])>0:ratio=chosen[-1]['value']/(sum(p['value'] for p in chosen[:-1])/20)
        result.append(dict(label=m['label'].replace('涨跌幅',''),classification=m.get('scope','分类未登记'),as_of=m.get('as_of'),deltas=diff,volume_ratio=ratio,
            metric_id=m['id'],evidence_ids=list(dict.fromkeys(m.get('evidence_ids',[])+(s.get('evidence_ids',[]) if s else [])+(volume.get('evidence_ids',[]) if volume else [])))))
    valid=[r['deltas']['1'] for r in result if r['deltas']['1'] is not None]
    return dict(rows=result,benchmark='沪深300',dispersion=max(valid)-min(valid) if valid else None,leadership=sum(v>0 for v in valid),n=len(valid),method='同会话行业收益−沪深300收益；量能比=当日成交额/此前20会话均额')

def metrics_by_id(metrics):return {m['id']:m for m in metrics}

def priced_in(document,checks,analysis):
    """三层阶梯保留；无事件时点或预期锚定时不越级。"""
    spec=analysis.get('priced_in',{});out=dict(tier=1,label='未见明确反应',observations=[],missing=[])
    if not spec:return dict(tier=0,label='市场反应尚未量化',observations=[],missing=['未提供同窗对象与基准'])
    byid={s['id']:s for s in document['series']}
    for sid in (spec.get('series_id'),spec.get('benchmark_id')):
        if sid not in byid:return dict(tier=0,label='可比序列不足',observations=[],missing=['对象或基准序列缺失'])
    target,bench=(byid[spec[k]] for k in ('series_id','benchmark_id'))
    tx=points(document,target);bx=points(document,bench)
    t={p['date']:p['value'] for p in tx};b={p['date']:p['value'] for p in bx}
    for name,start,end in [('事前',spec.get('pre_start'),spec.get('event_date')),('事后',spec.get('event_date'),spec.get('post_end'))]:
        tw=[p for p in tx if start and end and start<=p['date']<=end];bw=[p for p in bx if start and end and start<=p['date']<=end]
        if start in t and end in t and start in b and end in b and t[start]>0 and b[start]>0 and contiguous(document,target,tw) and contiguous(document,bench,bw):
            out['observations'].append(dict(label=name,value=((t[end]/t[start]-1)-(b[end]/b[start]-1))*100,unit='百分点',start=start,end=end))
    if any(abs(x['value'])>1e-9 for x in out['observations']):
        out.update(tier=2,label='已有反应、充分程度未知')
    metrics={m['id']:m for m in document['metrics']}
    valuations=[mid for mid in spec.get('valuation_metric_ids',[]) if mid in checks.get('values',{}) and mid not in checks.get('unready_metrics',[]) and metrics[mid].get('kind')!='forecast' and metrics[mid].get('value_identity')!='conditional']
    readable={e['id'] for e in document['evidence'] if e['read_method'] in ('original','cached')}
    anchors=[eid for eid in spec.get('expectation_evidence_ids',[]) if eid in readable]
    if valuations and anchors and out['observations']:
        out.update(tier=3,label='存在估值 / 预期支持的定价判断')
    else:out['missing']=['估值位置缺失' if not valuations else '','公开预期锚缺失' if not anchors else '']
    out['valuation_metric_ids']=valuations;out['expectation_evidence_ids']=anchors
    return out

def quality_notes(document):
    """新增门槛沿用审阅语义，只提示补研究，不阻断原有交付。"""
    notes=[];stance=document.get('stance',{})
    for key,h in stance.get('horizons',{}).items():
        missing=[f for f in ('benchmark','window','driver','risk','flip_condition','next_check_at') if not h.get(f)]
        if missing:notes.append(HORIZONS.get(key,key)+'：缺 '+ '、'.join(missing))
        if h.get('lean')=='abstain' and not all(h.get(k) for k in ('abstain_reason','resolve_data')):notes.append(HORIZONS[key]+'：暂不判断缺原因与补数路径')
        if not h.get('claim_ids'):notes.append(HORIZONS.get(key,key)+'：未关联既有判断，首屏只显示未审阅状态')
        if h.get('lean')!='abstain' and not stance_ready(document,key,h):notes.append(HORIZONS.get(key,key)+'：驱动家族、已审判断或带日期的翻转条件不足，降为暂不判断')
    if stance and not stance.get('cross_asset_tension'):notes.append('尚未说明利率、汇率、商品与权益的相互印证或张力')
    for a in document['analyses']:
        if not a.get('materiality'):notes.append(a['title']+'：尚未说明改变的经济变量')
    return notes

def stance_ready(document,key,h):
    """首屏是已审判断的投影；无驱动、价格独证及无日期条件降级。"""
    families={'intraday':{'catalyst','cross_asset','sentiment_flow','positioning','volatility'},
        'short':{'relative_strength','policy_earnings','liquidity','breadth','crowding'},
        'medium':{'earnings_revision','policy_cycle','valuation','credit_liquidity','supply_demand'}}
    ids=set(h.get('claim_ids',[]));claims={c['id']:c for c in document['claims']}
    if not ids or not ids<=set(document['review']['checked_claim_ids']) or not ids<=set(claims):return False
    if h.get('lean')=='abstain':return bool(h.get('abstain_reason') and h.get('resolve_data'))
    import re
    if h.get('driver_family') not in families.get(key,set()) or not re.search(r'\d{4}-\d{2}-\d{2}',h.get('flip_condition','')):return False
    return any(claims[i].get('evidence_ids') or claims[i].get('fact_ids') for i in ids)
