"""离线研究仪表界面；原栏目和证据链由现有Renderer保留。"""
import re
from html import escape
from insights import build, evidence_grade, priced_in, HORIZONS,stance_ready

def e(value):return escape(str(value),quote=True)
def number(value,unit='',signed=False):
    if value is None:return '未追踪'
    return (f'{value:+,.2f}' if signed else f'{value:,.2f}')+unit
def tag(grade):return {'A':'● 原文 / 原表核对','B':'◐ 媒体 / 部分读取','C':'○ 假设待验证'}.get(grade,'○ 假设待验证')

def evidence_widget(document,ids):
    byid={x['id']:x for x in document['evidence']};sources={x['id']:x for x in document['sources']}
    grade=evidence_grade(document,ids)
    body=''
    for ident in dict.fromkeys(ids):
        x=byid.get(ident)
        if not x:continue
        s=sources.get(x['source_id'],{})
        body+='<div><b><a href="'+e(s.get('url','#sources'))+'">'+e(s.get('publisher','未知来源'))+'</a></b> · '+e({'original':'原始读取','cached':'缓存复用','search_summary':'搜索摘要'}.get(x['read_method'],x['read_method']))+' · '+e({'full':'完整读取','partial':'部分读取','unavailable':'不可读取'}.get(s.get('read_status'),'读取范围未登记'))+'<p>'+e(x['quote'])+'</p><small>'+e(x['locator'])+' · 发布 '+e(s.get('published_at',''))+'<br>可得边界 '+e(s.get('vintage',{}).get('available_at') or '未知')+' · 实际读取 '+e(x.get('retrieved_at','未记录'))+'</small></div>'
    return '<details class="evidence-widget grade-'+grade+'"><summary>'+tag(grade)+'</summary><div class="evidence-content">'+(body or '暂无独立证据；研究假设需后续观察')+'</div></details>'

def claim_evidence(document,claim_ids):
    out=[];claims={c['id']:c for c in document['claims']};facts={f['id']:f for f in document['facts']};metrics={m['id']:m for m in document['metrics']}
    for cid in claim_ids:
        c=claims.get(cid,{})
        out+=c.get('evidence_ids',[])
        for fid in c.get('fact_ids',[]):out+=facts.get(fid,{}).get('evidence_ids',[])
        for mid in c.get('metric_ids',[]):out+=metrics.get(mid,{}).get('evidence_ids',[])
    return list(dict.fromkeys(out))

def decision(document,checks,state):
    stance=document.get('stance',{});score=document.get('forecast_summary',{});n=score.get('n',0)
    line=stance.get('regime_line') or '市场状态资料尚不足，三个期限保留有条件判断'
    axes=''.join('<span><b>'+e(a['label'])+'</b> '+e(a['state'])+'</span>' for a in state['axes'])
    changes=stance.get('changed_since_prior',[])
    change_text='；'.join(c['text'] for c in changes[:3]) or '尚无可比的上期状态变更记录'
    prior=document.get('prior_reviews',[])
    names={a['thesis_id']:a['title'] for a in document['analyses']}
    prior_text='；'.join({'supported':'获支持','weakened':'削弱','refuted':'推翻','maintained':'维持','unknown':'待证','retired':'退出'}.get(r['status'],r['status'])+'：'+names.get(r['thesis_id'],'上期主题'+str(i+1))[:14] for i,r in enumerate(prior[:2])) or '上期无可比结算记录'
    out='<section id="decision" class="decision"><div class="decision-title"><span class="kicker">30秒 · 今日结论</span><h1>'+e(line[:60])+'</h1><div class="axis-strip">'+axes+'</div><p class="changes"><b>本期变化</b> '+e(change_text)+'</p><a class="track-chip" href="#scorecard">'+e(prior_text)+' · '+('样本不足 n='+str(n) if n<30 else '已结算 n='+str(n))+' · '+str(score.get('pending',0))+'条待结算</a></div><div class="lean-matrix">'
    labels={'up':'▲ 偏多','down':'▼ 偏空','neutral':'◆ 中性','abstain':'○ 暂不判断'}
    oldh={k:(a,v) for a in document['analyses'] for k,v in a.get('horizons',{}).items()};expanded=''
    for key,label in HORIZONS.items():
        h=stance.get('horizons',{}).get(key)
        if h:
            reviewed=set(document['review']['checked_claim_ids'])
            ids=h.get('claim_ids',[]);qualified=stance_ready(document,key,h)
            lean=h['lean'] if qualified else 'abstain'
            grade=evidence_grade(document,claim_evidence(document,ids)) if qualified else 'C'
            driver=h['driver'] if qualified else '未审阅的综合立场；需先核对引用判断'
            flip=h['flip_condition'];check=h['next_check_at'];benchmark=h['benchmark']+' · '+h['window']
            abstain=h.get('abstain_reason','');resolve=h.get('resolve_data','')
        elif key in oldh:
            a,v=oldh[key];lean='abstain'
            grade='C';driver=v['conclusion'];flip=a['invalidation'];check=v['review_at'];benchmark='旧报告未登记统一比较基准'
            abstain='旧归档只提供原主题方向；未补写历史立场';resolve='新一期登记统一基准与窗口'
        else:
            lean='abstain';grade='C';driver='缺少本期限驱动证据';flip='补齐基准、驱动及失效条件后复核';check='资料补齐后';benchmark='基准 / 窗口未登记';abstain='本期尚无可审阅判断';resolve='需要价格基准与该期限驱动证据'
        out+='<div class="lean-row"><div class="lean-head"><b>'+e(label)+'</b><strong class="lean-'+lean+'">'+labels[lean]+'</strong><span class="evidence-pips">'+tag(grade)+'</span></div><small>'+e(benchmark)+'</small><p>'+e(driver)+'</p><p class="flip"><b>翻转</b> '+e(flip)+'</p><small class="next-check"><b>下次核对</b> '+e(check)+'</small>'
        if lean=='abstain':out+='<small class="missing">'+e(abstain+'；'+resolve)+'</small>'
        expanded+='<h3>'+e(label)+'</h3><p>'+e(driver)+'</p><p>风险：'+e(h.get('risk','旧报告未登记统一风险') if h else abstain)+'</p><p>翻转：'+e(flip)+'</p><p>解除暂不判断：'+e(resolve or '以上条件改变后复核')+'</p>'
        claim=next((c for c in document.get('forecast_claims',[]) if h and c.get('id')==h.get('ledger_id') and c.get('status')=='pending'),None)
        if claim:out+='<small>研究概率（未校准） '+number(claim['p']*100,'%')+' · p0='+number(claim['p0']*100,'%')+' · n='+str(claim['base_rate']['n'])+' / n_eff='+str(claim['base_rate']['n_eff'])+'</small>'
        out+='</div>'
    if stance.get('cross_asset_tension'):expanded+='<p class="tension">跨市场张力：'+e(stance['cross_asset_tension'])+'</p>'
    return out+'</div></section><details class="lean-full"><summary>三期限完整依据、风险与解除条件</summary>'+expanded+'</details>'

def dashboard(document,checks,state,renderer):
    out='<section id="state" class="state-panel"><h2>固定市场状态 <small>3分钟 · '+e(state['rule_label'])+'</small></h2><div class="regime-rules">'
    for a in state['axes']:out+='<details><summary>'+e(a['label']+' · '+a['state'])+'</summary><p>'+e(a['input'])+'</p><small>'+e(a['rule'])+'</small></details>'
    out+='</div><div class="state-tiles">'
    for group in dict.fromkeys(t['group'] for t in state['tiles']):
        tiles=[t for t in state['tiles'] if t['group']==group]
        out+='<article class="regime-tile '+('untracked' if not any(t['entries'] for t in tiles) else '')+'"><h3>'+e(group)+'</h3>'
        missing=[t['label'] for t in tiles if not t['entries']]
        for tile,x in [(t,x) for t in tiles for x in t['entries']]:
            out+='<div class="tile-entry"><span>'+e(x['label'])+'</span><b class="tile-value">'+number(x['value'],x['unit'])+'</b><small>截至 '+e(x['as_of'])+'</small>'
            if x.get('deltas'):
                out+='<div class="delta-row">'+''.join('<span>'+k+'日 '+number(x['deltas'].get(k),'bp' if any(w in tile['label'] for w in ('国债','SHIBOR','美债')) else '%',True)+'</span>' for k in ('1','5','20'))+'</div>'
            p=x.get('percentile')
            if p is not None:out+='<div class="percentile" role="img" aria-label="分位 '+number(p,'%')+'"><span style="width:'+str(max(0,min(100,p)))+'%"></span></div><small>'+e(x['window'])+' · 分位 '+number(p,'%')+' · n='+str(x['n'])+'</small>'
            else:out+='<small class="missing">历史分位未计算 · n='+str(x.get('n',0))+'</small>'
            if x.get('series_id') in renderer.series:out+=renderer.spark(x['series_id'])
            out+=evidence_widget(document,x.get('evidence_ids',[]))+'</div>'
        if missing:out+='<p class="missing">未追踪：'+e('、'.join(missing))+'</p>'
        out+='</article>'
    out+='</div><div class="internals"><h3>市场内部结构</h3>'
    internal=state.get('internals',{})
    if internal.get('status')=='available':
        out+='<p>'+e(internal.get('as_of',''))+' · 有效样本 '+str(internal['n'])+'只'+(' · 仅为样本' if internal.get('sample') else '')+'</p><div class="internals-grid">'
        for label,key,unit in [('上涨占比','up_share','%'),('个股中位涨跌','median','%'),('前一成成交集中度','top_decile_turnover','%')]:
            out+='<div><small>'+label+'</small><b>'+number(internal.get(key),unit)+'</b></div>'
        out+='</div><p>'+e(internal.get('method',''))+'</p>'
        for name in ('1日','5日','20日'):out+='<small>'+name+'历史比较：'+e(internal.get('context',{}).get(name,'未取得可比截面'))+' </small>'
    else:out+='<p class="empty">未取得可核验的全市场截面；指数涨幅不能代替个股中位数。</p>'
    out+='</div>'+sector_panel(document,state['sectors'])
    # 基准率是分布背景；从不直接变成立场或策略。
    out+='<details class="base-rate-table"><summary>历史基准率 · 样本和实际窗口</summary><div class="table-wrap"><table><thead><tr><th>基准 / 条件 / 窗口</th><th>n / n_eff</th><th>严格正收益比例</th><th>中位数 [Q1,Q3]</th></tr></thead><tbody>'
    for rate in state.get('base_rates',[]):
        if rate.get('status')!='available':continue
        for n,x in rate['windows'].items():
            kind=x['state']['kind'];label={'unconditional':'无条件','prior20':'前20会话','breadth':'广度','valuation_percentile':'估值分位','volume_ratio':'量能比'}.get(kind,kind)
            if kind!='unconditional':label+=' ['+str(x['state'].get('low'))+','+str(x['state'].get('high'))+')'
            out+='<tr><td>'+e(rate['benchmark']+' / '+label+' / '+n+'会话')+'<small>'+e(rate['start']+' → '+rate['end'])+'</small></td><td>'+str(x['n'])+' / '+str(x['n_eff'])+'</td><td>'+number(x['p0']*100 if x['p0'] is not None else None,'%')+'</td><td>'+number(x['median'],'%')+' ['+number(x['q1'],'%')+','+number(x['q3'],'%')+']</td></tr>'
    return out+'</tbody></table></div><p>经验背景分布，存在重叠和选择偏差，不是未来概率。历史不足明确保持缺值。</p></details></section>'

def sector_panel(document,state):
    out='<div class="sector-instrument"><h3>行业相对强弱与轮动</h3><p>'+e(state['method'])+'；基准 '+e(state['benchmark'])+'</p>'
    if not state['rows']:return out+'<p class="empty">未取得可比行业截面与历史，未绘制热力图或轮动点。</p></div>'
    out+='<p>同口径可比行业 '+str(state['n'])+'个，跑赢基准 '+str(state['leadership'])+'个；单日超额收益极差 '+number(state['dispersion'],'百分点')+'</p><div class="table-wrap"><table class="heatmap"><thead><tr><th>行业 / 日期</th><th>1会话超额</th><th>5会话超额</th><th>20会话超额</th><th>量能比</th></tr></thead><tbody>'
    for r in state['rows']:
        out+='<tr><td>'+e(r['label'])+'<small>'+e(r['classification']+' · '+str(r['as_of']))+'</small></td>'
        for n in ('1','5','20'):
            v=r['deltas'][n];out+='<td class="'+('pos' if v is not None and v>0 else 'neg' if v is not None and v<0 else '')+'">'+number(v,'pp',True)+'</td>'
        out+='<td>'+number(r['volume_ratio'],'倍')+'</td></tr>'
    out+='</tbody></table></div>'
    valid=[r for r in state['rows'] if r['deltas']['5'] is not None and r['volume_ratio'] is not None]
    if valid:
        lo=min([0]+[r['deltas']['5'] for r in valid])-1;hi=max([0]+[r['deltas']['5'] for r in valid])+1;top=max([2]+[r['volume_ratio'] for r in valid])
        X=lambda v:50+(v-lo)/(hi-lo)*540;Y=lambda v:260-v/top*220
        out+='<svg viewBox="0 0 640 320" role="img" aria-label="轮动象限，数值在上表"><title>5会话超额收益×当日量能比</title><line class="refline" x1="'+str(X(0))+'" x2="'+str(X(0))+'" y1="40" y2="260"/><line class="refline" x1="50" x2="590" y1="'+str(Y(1))+'" y2="'+str(Y(1))+'"/>'
        for text,x,y in [('放量领先',440,30),('放量落后',60,30),('缩量领先',440,280),('缩量落后',60,280)]:out+='<text x="'+str(x)+'" y="'+str(y)+'">'+text+'</text>'
        for r in valid:out+='<circle cx="'+str(X(r['deltas']['5']))+'" cy="'+str(Y(r['volume_ratio']))+'" r="4" fill="var(--accent)"/><text x="'+str(X(r['deltas']['5'])+6)+'" y="'+str(Y(r['volume_ratio']))+'">'+e(r['label'])+'</text>'
        out+='</svg>'
    else:out+='<p class="missing">轮动象限未绘点：5会话历史或此前20会话成交基线不足。</p>'
    return out+'</div>'

def calendar(document):
    out='<section id="catalyst-calendar"><h2>未来催化日历</h2>'
    cals=document['calendars'];today=document['meta']['date']
    upcoming=sorted({s['date'] for c in cals for s in c['sessions'] if s['date']>=today})[:5]
    out+='<p class="calendar-sessions">未来五个有效会话：'+(e(' / '.join(upcoming)) if upcoming else '日历待核验')+'</p>'
    if not document.get('catalysts'):return out+'<p class="empty">未登记有出处的预定催化；不凭惯例生成事件日期。</p></section>'
    out+='<ol class="catalyst-list">'
    for c in sorted(document['catalysts'],key=lambda c:c['when']):
        out+='<li><time>'+e(c['when'])+'</time><div><h3>'+e(c['what'])+'</h3><p>'+e(c['why_it_matters'])+'</p><small>前值：'+e(c.get('prior') or '未取得')+' · 预期：'+e(c.get('consensus') or '无公开预期数据')+'</small>'+evidence_widget(document,c['evidence_ids'])+'</div></li>'
    return out+'</ol></section>'

def scorecard(document,renderer):
    out='<section id="scorecard"><h2>上期判断复核与记录</h2>'
    labels={'supported':'支持','weakened':'削弱','refuted':'推翻','maintained':'维持','unknown':'尚无法判断','retired':'退出'}
    for r in document.get('prior_reviews',[]):out+='<article class="prior-call"><b>'+e(labels[r['status']])+'</b><p>'+e(r['explanation'])+'</p>'+renderer.evidence_refs(r['new_evidence_ids'])+'</article>'
    summary=document.get('forecast_summary',{});n=summary.get('n',0)
    if summary.get('status')=='untracked':out+='<p class="missing">'+e(summary['reason'])+'</p>'
    out+='<p class="score-line">'+('样本不足 n='+str(n)+'；未校准。' if n<30 else '已结算 '+str(n)+'条。')+('命中率 '+number(summary['hit_rate']*100,'%')+' · Brier '+number(summary['brier'])+' · 相对基准技能分 '+number(summary['skill_score']) if n else '尚无可结算预测记录')+'</p><p>待结算 '+str(summary.get('pending',0))+'条；弃权比例 '+number(summary.get('abstention_rate')*100 if summary.get('abstention_rate') is not None else None,'%')+'</p>'
    for bucket,score in summary.get('buckets',{}).items():
        horizon,_,kind=bucket.partition(':');bucket_label=HORIZONS.get(horizon,'其他期限')+' / '+{'close_above_base':'收盘高于基点'}.get(kind,'其他已登记命题')
        out+='<p>'+e(bucket_label)+' · n='+str(score['n'])+' · '+('未校准' if score['n']<30 else '已满足频率展示样本门槛；仍不等于已验证策略')+'</p>'
        if score.get('bins'):
            out+='<svg viewBox="0 0 320 280" role="img" aria-label="可靠性分箱，明细在下表"><title>研究概率与实际频率</title><line class="refline" x1="40" x2="280" y1="240" y2="20"/>'
            for b in score['bins']:out+='<circle fill="var(--accent)" cx="'+str(40+b['forecast']*240)+'" cy="'+str(240-b['realized']*220)+'" r="5"/><text x="'+str(44+b['forecast']*240)+'" y="'+str(235-b['realized']*220)+'">n='+str(b['n'])+'</text>'
            out+='</svg><div class="table-wrap"><table><tr><th>概率箱</th><th>平均概率</th><th>实际频率</th><th>n</th></tr>'+''.join('<tr><td>'+number(b['low']*100,'%')+'—'+number(b['high']*100,'%')+'</td><td>'+number(b['forecast']*100,'%')+'</td><td>'+number(b['realized']*100,'%')+'</td><td>'+str(b['n'])+'</td></tr>' for b in score['bins'])+'</table></div>'
    if n:
        out+='<details><summary>评分方法与结算明细</summary><p>Brier=平均(p−结果)²；技能分=1−Brier/Brier基准。结果由实际收盘与已核验会话结算。</p>'
        for r in summary.get('records',[]):out+='<p>'+e(r['benchmark'])+' '+e(r['base_date'])+' +'+str(r['sessions'])+'会话：'+('尚待结算' if 'outcome' not in r else '结果 '+str(r['outcome']))+'</p>'
        out+='</details>'
    elif not document.get('prior_reviews'):out+='<p class="empty">旧报告未登记可结算预测，显示“尚无记录”；本期未假造历史战绩。</p>'
    return out+'</section>'

def theme_enrichment(document,checks,a):
    scenarios=a.get('scenarios',[])
    out='<div class="theme-instruments">'
    gauge=priced_in(document,checks,a)
    out+='<div class="priced-in"><b>定价依据 · '+e(gauge['label'])+'</b><div class="tier-meter" aria-label="定价阶梯 '+str(gauge['tier'])+'">'+''.join('<span class="'+('filled' if i<=gauge['tier'] else '')+'">'+str(i)+'</span>' for i in (1,2,3))+'</div>'
    for x in gauge['observations']:out+='<small>'+e(x['label'])+'超额收益 '+number(x['value'],'百分点',True)+' · '+e(x['start']+' → '+x['end'])+'</small>'
    out+='<small>'+e('；'.join(m for m in gauge['missing'] if m))+'</small></div>'
    if scenarios:
        out+='<div class="scenario-strip">'
        for s in scenarios:out+='<div><b>'+{'base':'基准情景','upside':'上行情景','adverse':'不利情景'}[s['kind']]+'</b><p>'+e(s['narrative'])+'</p><small>'+e(' / '.join(HORIZONS.get(x,x) for x in s['horizons']))+' · <a href="#a-'+e(a['id'])+'">引用同一'+('支持' if s['condition_ref']=='support' else '失效')+'条件</a></small></div>'
        out+='</div>'
    return out+'</div>'

def compose(document,checks,legacy,renderer):
    import copy
    document=copy.deepcopy(document)
    from forecast_ledger import prepare
    # 模型或merge手填概率不能绕过基准率与调整计算。
    document['forecast_claims']=[c for c in document.get('forecast_claims',[]) if c.get('status')=='pending' and prepare(document,c)==c]
    main=re.search(r'<main>([\s\S]*?)</main>',legacy).group(1)
    sections={m.group(2):m.group(1) for m in re.finditer(r'(<section data-report-section id="([^"]+)">[\s\S]*?</section>)',main)}
    if 'sources' in sections:
        sections['sources']=re.sub(r'<details><summary>上期判断复核</summary>[\s\S]*?</details>','',sections['sources'],count=1)
    state=build(document,checks)
    # 旧深主题所有文字保留，新增仪表只引用同一验证条件。
    for a in document['analyses']:
        key='sectors' if 'sectors' in sections else 'market'
        needle='<article class="analysis" id="a-'+e(a['id'])+'">'
        if key in sections:sections[key]=sections[key].replace(needle,needle+theme_enrichment(document,checks,a),1)
    # 前瞻期限页签仅增强；关闭JS时三个期限全部可读。
    for key,section in list(sections.items()):
        section=re.sub(r'<div class="horizon-grid">([\s\S]*?)</div><div class="verification">',
            lambda m:'<div class="horizon-tabs" data-enhancement hidden role="tablist" aria-label="研究期限">'+''.join('<button role="tab" aria-selected="'+str(i==0).lower()+'" data-horizon="'+str(i)+'">'+e(label)+'</button>' for i,label in enumerate(HORIZONS.values()))+'</div><div class="horizon-grid">'+m.group(1)+'</div><div class="verification">',section)
        sections[key]=section
    # 消息正文仍默认可见，补充的出处抽屉使用details渐进增强。
    for a in document['articles']:
        ids=claim_evidence(document,a['claim_ids'])
        for fid in a['fact_ids']:
            ids += next((f['evidence_ids'] for f in document['facts'] if f['id']==fid),[])
        for k in sections:
            pattern=r'(<article class="article [^"]*" id="article-'+re.escape(e(a['id']))+r'">)'
            sections[k]=re.sub(pattern,lambda m:m.group(1)+evidence_widget(document,ids),sections[k],count=1)
    meta=document['meta'];grade=checks['delivery']['grade'];labels={'draft':'草稿','limited':'有限交付','observation':'观察交付','full':'完整交付','partial_coverage':'部分覆盖','incremental_verified':'增量已核','first_observation':'首次观察'}
    meter={'draft':1,'limited':2,'observation':3,'full':4,'partial_coverage':2,'incremental_verified':4,'first_observation':3}.get(grade,1)
    mast='<header class="masthead"><div><b>每日关注</b><span>'+e({'morning':'早报','evening':'晚报','intraday':'盘中观察','snapshot':'即时研究'}.get(meta.get('edition'),'研究'))+' · '+e(meta['date'])+' · 截止 '+e(meta['cutoff'][11:16])+' 北京时间</span></div><div class="toolbar"><span class="grade-meter" aria-label="'+labels[grade]+'">'+('●'*meter+'○'*(4-meter))+' '+labels[grade]+'</span><button data-theme-toggle>深浅色</button><button data-copy-summary>复制摘要</button><button data-print>打印</button></div></header>'
    depth='<nav class="depth-nav" aria-label="阅读深度"><a href="#decision">30秒 · 结论</a><a href="#state">3分钟 · 状态</a><a href="#news">完整 · 证据</a><details class="evidence-legend"><summary>● ◐ ○ 证据图例</summary><p>● 已读原文 / 原表并核对；◐ 媒体或部分读取 / 搜索摘要；○ 假设待验证。证据强度不等于结果发生概率。</p></details></nav>'
    summary='<div class="summary-strip"><h2>'+e(meta['title'])+'</h2>'+''.join('<p>'+renderer.text(s['text'])+renderer.refs(s['fact_ids'])+renderer.claim_refs(s['claim_ids'])+'</p>' for s in document['summary'][:5])+'</div>'
    content=decision(document,checks,state)+dashboard(document,checks,state,renderer)
    order=['overview','sectors'];content+=''.join(sections.pop(k,'') for k in order)+calendar(document)+summary
    order=['status','changes','news','companies','ai','market','macro','observations','actions','next']
    content+=''.join(sections.pop(k,'') for k in order)+scorecard(document,renderer)
    content+=''.join(sections.values())
    content+='<footer>研究观察 / 研究规则，不是经验证的交易策略。信息截止 '+e(meta['cutoff'])+'；离线快照，不自动刷新。<br>生成时间 '+e(checks.get('generated_at','未记录'))+' · 后补资料保留实际读取时点。</footer>'
    nav='<nav class="bottom-tabs" aria-label="报告导航">'+''.join('<a href="#'+key+'">'+label+'</a>' for key,label in [('decision','结论'),('state','状态'),('sectors' if 'sectors' in main else 'market','主题'),('catalyst-calendar','日历'),('news' if 'news' in main else 'changes','消息'),('scorecard','复盘'),('sources','来源')])+'</nav>'
    rail='<aside class="right-rail"><h3>下一步检查</h3>'+''.join('<a href="#decision">'+e(HORIZONS.get(k,k))+' · '+e(v['next_check_at'])+'</a>' for k,v in document.get('stance',{}).get('horizons',{}).items())+'<hr><small>证据强度</small><p>● 原文 / 原表核对<br>◐ 转述 / 部分读取<br>○ 假设待验证</p><a href="#sources">展开来源与复核</a></aside>'
    result=mast+depth+'<div class="research-layout"><main>'+content+'</main>'+rail+'</div>'+nav+'<dialog class="evidence-drawer" aria-label="来源证据"><button data-close-drawer>关闭证据</button><div class="drawer-content"></div></dialog>'
    # 旧摘要移入新信息架构后，附录的返回引用需指向仍可见的引用。
    oldrefs=dict(re.findall(r'<a id="(ref-[0-9]+)" href="#([^"]+)"',legacy))
    newrefs={}
    for ident,target in re.findall(r'<a id="(ref-[0-9]+)" href="#([^"]+)"',result):newrefs.setdefault(target,ident)
    ids=set(re.findall(r'\bid="([^"]+)"',result))
    result=re.sub(r'href="#(ref-[0-9]+)"',lambda m:'href="#'+(m.group(1) if m.group(1) in ids else newrefs.get(oldrefs.get(m.group(1)),'sources'))+'"',result)
    return result
