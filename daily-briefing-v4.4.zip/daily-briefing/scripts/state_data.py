"""固定状态的数据补充，仍使用唯一Tushare客户端、缓存和证据模型。"""
from datetime import date,timedelta
from pathlib import Path
import time
from common import load,save,num,iso,canonical,stamp,fingerprint
from storage import put_artifact
from insights import internals,build
import tushare_data as ts

ENDPOINTS={'yc_cb':201,'shibor':149,'shibor_lpr':151,'cn_cpi':228,'cn_ppi':245,'cn_pmi':325,
    'cn_m':242,'sf_month':310,'index_dailybasic':128,'margin':58,'limit_list_d':298,
    'fund_share':207,'etf_share_size':408,'index_weight':96,'eco_cal':233}
ts.DOCS.update(ENDPOINTS)

def precompute(work,state):
    """数据阶段物化计算投影；失败只降级新面板，不动发布事务。"""
    from storage import materialize
    from validation import validate
    started=time.perf_counter()
    try:
        doc=materialize(load(Path(work)/'briefing.json'),work);checks=validate(doc)
        result=build(doc,checks) if not checks['errors'] else dict(status='untracked',reason='现有输入待修正')
    except (ValueError,OSError,KeyError,TypeError,ZeroDivisionError) as exc:result=dict(status='untracked',reason='新增计算未完成',error_type=type(exc).__name__)
    save(Path(work)/'insights.json',result)
    elapsed=(time.perf_counter()-started)*1000
    state['telemetry']['events'].append(dict(kind='stage',stage='insight_precompute',wall_ms=elapsed,recorded_at=stamp()))
    save(Path(work)/'run-state.json',state)
    return dict(output='insights.json',wall_ms=round(elapsed,2),status=result.get('status','computed'))

def sector_history(work,state,client,codes):
    """最多8个已入选行业的61会话历史；未授权仅留下缺口。"""
    from data_io import merge
    doc=load(Path(work)/'briefing.json');day=ts._last_session(doc,doc['meta']['cutoff'])
    if not day or not doc['calendars']:return dict(status='untracked',reason='日历未核验')
    if not isinstance(codes,list) or len(codes)>8:return dict(status='untracked',reason='一次至多8个入选申万行业')
    sessions=sorted(s['date'] for s in doc['calendars'][0]['sessions'] if s['date']<=day)[-61:]
    if not sessions:return dict(status='untracked',reason='没有完整会话')
    result=dict(items={});patch=dict(sources=[],evidence=[],series=[])
    for code in codes:
        response=ts._query(client,'sw_daily',dict(ts_code=code,start_date=ts.ymd(sessions[0]),end_date=ts.ymd(day)),
            'ts_code,trade_date,name,close,pct_change,amount',doc['meta']['cutoff'],ts._available(day,'sw_daily'),'market',result)
        if not response or not response['rows']:continue
        rows=sorted(response['rows'],key=lambda r:r['trade_date']);row=rows[-1];label=row.get('name') or code
        source,evidence=ts._source_rows(work,'sw_daily',response,[row],day,ts._available(day,'sw_daily'),patch)[0]
        series=ts._series(code,label,rows,sessions,'sw_daily',response,source,evidence,doc['calendars'][0]['id'],asset_type='sector',classification='申万2021一级行业')
        patch['series'].append(series)
        amount=dict(series,id='SVOL_'+fingerprint(code)[:22],label=label+'成交额',basis='turnover',unit='万元',
            observations=[dict(date=ts.day_iso(r['trade_date']),value=r.get('amount'),available_at=ts._available(ts.day_iso(r['trade_date']),'sw_daily'),status='traded' if num(r.get('amount')) else 'missing') for r in rows])
        patch['series'].append(amount)
    if patch['series']:merge(work,patch)
    return dict(status='available' if patch['series'] else 'untracked',series=len(patch['series']),items=result['items'])

def long_history(work,state,client):
    """按需两指数、至多10年、三段各≤3000行；同一缓存月度复用。"""
    from data_io import merge
    from storage import cache_get,cache_put
    doc=load(Path(work)/'briefing.json');cutoff=doc['meta']['cutoff'];day=ts._last_session(doc,cutoff)
    if not day or not doc['calendars']:return dict(status='untracked',reason='日历未核验')
    root=Path(state['state_root'])/'.runtime';key='BASE_HISTORY_'+day[:7].replace('-','')
    hit=cache_get(root,key,cutoff)
    if hit['status']=='cache_reused':
        patch=hit['entry']['data']
        current={s['id']:s for s in doc['series']}
        for s in patch.get('series',[]):
            recent=current.get(s['id'],{})
            s['observations']=sorted({p['date']:p for p in s['observations']+recent.get('observations',[])}.values(),key=lambda p:p['date'])
            s['source_ids']=list(dict.fromkeys(s['source_ids']+recent.get('source_ids',[])))
            s['evidence_ids']=list(dict.fromkeys(s['evidence_ids']+recent.get('evidence_ids',[])))
        for c in patch.get('calendars',[]):
            recent=next((v for v in doc['calendars'] if v['id']==c['id']),{})
            c['sessions']=sorted({p['date']:p for p in c['sessions']+recent.get('sessions',[])}.values(),key=lambda p:p['date'])
            c['valid_to']=max(c['valid_to'],recent.get('valid_to',c['valid_to']))
            for k in ('source_ids','evidence_ids'):c[k]=list(dict.fromkeys(c[k]+recent.get(k,[])))
        merge(work,patch);return dict(status='cache_reused',month=day[:7])
    begin=(date.fromisoformat(day)-timedelta(days=3653)).isoformat();result=dict(items={})
    response=fetch_response=ts._query(client,'trade_cal',dict(exchange='SSE',start_date=ts.ymd(begin),end_date=ts.ymd(day)),
        'exchange,cal_date,is_open,pretrade_date',cutoff,None,'market',result,cache=False)
    if not response:return dict(status='untracked',reason='历史日历缺失',items=result['items'])
    sessions=sorted(ts.day_iso(r['cal_date']) for r in response['rows'] if str(r.get('is_open'))=='1')
    if len(response['rows'])>=6000:return dict(status='untracked',reason='历史日历达到上限，需分段核验')
    patch=dict(sources=[],evidence=[],calendars=[],series=[])
    cal=doc['calendars'][0];row=dict(valid_from=begin,valid_to=day,open_days=sessions,exchange='SSE')
    source,evidence=ts._source_rows(work,'trade_cal',response,[row],day,None,patch)[0]
    expanded=dict(cal,valid_from=begin,sessions=sorted({s['date']:s for s in cal['sessions']+[dict(date=d,close_at=ts.day_upper(d,15,0)) for d in sessions]}.values(),key=lambda x:x['date']),
        source_ids=list(dict.fromkeys(cal['source_ids']+[source['id']])),evidence_ids=list(dict.fromkeys(cal['evidence_ids']+[evidence['id']])))
    patch['calendars'].append(expanded)
    for code,label in [('000300.SH','沪深300'),('000001.SH','上证指数')]:
        rows=[];responses=[]
        for chunk in range(3):
            a=date.fromisoformat(begin)+timedelta(days=chunk*1220);b=min(date.fromisoformat(day),a+timedelta(days=1219))
            if a>b:continue
            in_chunk=[d for d in sessions if a.isoformat()<=d<=b.isoformat()]
            if not in_chunk:continue
            end=in_chunk[-1]
            r=ts._query(client,'index_daily',dict(ts_code=code,start_date=ts.ymd(a.isoformat()),end_date=ts.ymd(end)),
                'ts_code,trade_date,close,pre_close,pct_chg,amount',cutoff,ts._available(end,'index_daily'),'market',result)
            if r and len(r['rows'])<3000:rows+=r['rows'];responses.append(r)
        if not rows:continue
        r=dict(responses[-1],rows=rows,params=dict(ts_code=code,start_date=ts.ymd(begin),end_date=ts.ymd(day),segments=[v['params'] for v in responses]))
        ordered=sorted(rows,key=lambda x:x['trade_date']);current=ordered[-1]
        source,evidence=ts._source_rows(work,'index_daily',r,[current],ts.day_iso(current['trade_date']),ts._available(ts.day_iso(current['trade_date']),'index_daily'),patch,title='Tushare有界指数历史 · '+label)[0]
        patch['series'].append(ts._series(code,label,rows,sessions,'index_daily',r,source,evidence,cal['id']))
    if patch['series']:
        merge(work,patch)
        # 统一cache保存已物化series；缓存工件路径不能指向另一个run。
        cached={k:[{kk:vv for kk,vv in row.items() if kk!='artifact'} for row in v] for k,v in patch.items()}
        cache_put(root,dict(id=key,layer='market',source_url=ts.DOC_URL+'95',retrieved_at=stamp(),vintage_at=ts._available(day,'index_daily'),
            valid_until=ts.day_upper((date.fromisoformat(day)+timedelta(days=32)).isoformat()),recheck_triggers=['source_revision','scope_change'],data=cached))
        return dict(status='available',series=len(patch['series']),begin=begin,end=day,items=result['items'])
    return dict(status='untracked',items=result['items'])

def collect(work,state,client,request=None):
    request=request or {};work=Path(work);doc=load(work/'briefing.json');cutoff=doc['meta']['cutoff']
    day=ts._last_session(doc,cutoff)
    result=dict(items={},calls_before=client.calls,computed_ms=None)
    if not day:return dict(items={'state':dict(status='untracked',reason='没有核验的完整会话')})
    patch=dict(sources=[],evidence=[],metrics=[],series=[])
    cal=doc['calendars'][0];sessions=sorted(s['date'] for s in cal['sessions'] if s['date']<=day)[-61:]
    start=sessions[0] if sessions else day
    def fetch(api,params,fields,available=None):
        return ts._query(client,api,params,fields,cutoff,available,'market',result)
    def register(api,response,rows,field,label,measure,unit='%',available=None,rate=False):
        rows=[r for r in rows if num(r.get(field))];rows.sort(key=lambda r:str(r.get('trade_date') or r.get('date')))
        if not rows:return
        row=rows[-1];observed=ts.day_iso(row.get('trade_date') or row.get('date'));available=available or ts.day_upper(observed)
        if iso(available)>iso(cutoff):result['items'][api+':'+field]=dict(status='untracked',reason='截止前可得性未证');return
        source,evidence=ts._source_rows(work,api,response,[row],observed,available,patch,title='Tushare状态数据 · '+label)[0]
        metric=ts._metric(api,row,field,row[field],unit,measure,label,observed,available,source,evidence,domain='overseas' if api=='us_tycr' else 'cn_market')
        patch['metrics'].append(metric)
        obs=[dict(date=ts.day_iso(r.get('trade_date') or r.get('date')),value=r[field],available_at=ts.day_upper(ts.day_iso(r.get('trade_date') or r.get('date'))),status='traded') for r in rows]
        sid='SSTATE_'+fingerprint([api,field,row.get('ts_code')])[:22]
        event_release=api=='shibor_lpr'
        skipped=[]
        if not event_release:
            session_days={s['date'] for s in cal['sessions']}
            skipped=[p['date'] for p in obs if p['date'] not in session_days]
            obs=[p for p in obs if p['date'] in session_days]
        if skipped:result['items'][api+':calendar_alignment']=dict(status='partial',omitted_dates=skipped,reason='原始响应保留；面板变化仅用已核A股会话的交集，不把其他发布日当A股交易日')
        series=dict(id=sid,label=label,unit=unit,basis='yield_percent' if rate else 'level',market='A股',provider='Tushare数据',adjustment='none',
            classification='state',source_ids=[source['id']],evidence_ids=[evidence['id']],entity_id=metric['dimensions']['entity_id'],frequency='daily',
            calendar_id=None if event_release else cal['id'],completeness='partial',scope='接口实际覆盖',roll_policy='none',vintage=dict(id=api+':'+response['retrieved_at'],available_at=available),observations=obs,
            domain='cn_market',usage='background',freshness_note='接口历史值，非实时；日度变化使用已核A股会话交集，利率按bp')
        if event_release:series['frequency']='irregular'
        metric['series_id']=sid;patch['series'].append(series)
    window=dict(start_date=ts.ymd(start),end_date=ts.ymd(day))
    response=fetch('shibor',window,'date,on,1w',ts.day_upper(day,12,0))
    if response:register('shibor',response,response['rows'],'1w','SHIBOR一周','shibor_1w',rate=True)
    response=fetch('shibor_lpr',dict(start_date=ts.ymd((date.fromisoformat(day)-timedelta(days=100)).isoformat()),end_date=ts.ymd(day)),'date,1y,5y')
    if response:register('shibor_lpr',response,response['rows'],'1y','一年LPR','lpr_1y',rate=True)
    response=fetch('yc_cb',dict(window,ts_code='1001.CB',curve_type='0',curve_term=10),'trade_date,ts_code,curve_type,curve_term,yield')
    if response:register('yc_cb',response,[r for r in response['rows'] if str(r.get('curve_type'))=='0' and r.get('curve_term')==10],'yield','中国10年国债收益率','cn_10y',rate=True)
    # 官方接口只承诺部分指数估值；缺行不由个股均值伪造指数PE。
    for code,label,measure in [('399006.SZ','创业板PE','cyb_pe'),('000300.SH','沪深300PE','hs300_pe'),('000688.SH','科创50PE','star_pe')]:
        response=fetch('index_dailybasic',dict(window,ts_code=code),'ts_code,trade_date,pe,pe_ttm,pb')
        if response:register('index_dailybasic',response,response['rows'],'pe_ttm',label,measure,unit='倍')
    # 上一会话的融资在次日08:30后才常规更新；08:00不能使用当日后取得值冒充冻结版。
    older=sessions[-2] if len(sessions)>1 else None
    if older:
        response=fetch('margin',dict(trade_date=ts.ymd(older)),'trade_date,exchange_id,rzye',ts.day_upper(day,9,5))
        if response and response['rows']:
            allrows=response['rows'];seen={r.get('exchange_id') for r in allrows}
            if {'SSE','SZSE'}<=seen:
                row=dict(trade_date=ts.ymd(older),rzye=sum(r['rzye'] for r in allrows if num(r.get('rzye'))))
                available=ts.day_upper(day,9,5)
                if iso(available)<=iso(cutoff):register('margin',response,[row],'rzye','融资余额（实际交易所覆盖）','margin_balance',unit='元',available=available)
                else:result['items']['margin']=dict(status='untracked',reason='截止早于参考更新边界，需已留存快照或网页时间证据')
    response=fetch('limit_list_d',dict(trade_date=ts.ymd(day)),'trade_date,ts_code,limit,limit_times')
    if response and response['rows']:
        rows=response['rows'];summary=dict(trade_date=ts.ymd(day),up=sum(r.get('limit')=='U' for r in rows),down=sum(r.get('limit')=='D' for r in rows),
            height=max((r.get('limit_times',0) for r in rows if num(r.get('limit_times'))),default=0))
        for f,label,measure in [('up','非ST涨停数','limit_up'),('down','非ST跌停数','limit_down'),('height','最高连板数（非ST）','limit_height')]:
            register('limit_list_d',response,[summary],f,label,measure,unit='只' if f!='height' else '板')
    if request.get('macro'):
        end=(date.fromisoformat(day).replace(day=1)-timedelta(days=1)).strftime('%Y%m')
        for api,fields in [('cn_cpi','month,nt_yoy'),('cn_ppi','month,ppi_yoy'),('cn_pmi','month,pmi010000'),('cn_m','month,m2_yoy'),('sf_month','month,inc_month')]:
            response=fetch(api,dict(start_m=str(int(end[:4])-3)+end[4:],end_m=end),fields)
            if response:
                put_artifact(work,canonical(dict(api=api,params=response['params'],rows=response['rows'],retrieved_at=response['retrieved_at'])).encode('utf-8'),'.json')
                result['items'][api].update(status='untracked',reason='API月份不能证明实际发布日期；通过原发布页面market packet补齐')
    from data_io import merge
    if any(patch.values()):merge(work,{k:v for k,v in patch.items() if v})
    doc=load(work/'briefing.json')
    # 同口径截面工件已经由start留存，不进行第二次网页搜值。
    cross=[];cross_raw=None
    for path in (work/'artifacts').rglob('*.json') if (work/'artifacts').exists() else []:
        try:raw=load(path)
        except (ValueError,OSError):continue
        if raw.get('api')=='daily' and raw.get('params',{}).get('trade_date')==ts.ymd(day):cross=raw['rows'];cross_raw=raw;break
    if cross:
        internal=internals(cross);internal['as_of']=day;merge(work,dict(market_internals=internal))
        doc=load(work/'briefing.json')
        # 中位数和占比进入现有metric/support体系，供首屏状态引用。
        response=dict(params=dict(trade_date=ts.ymd(day)),fields=list(cross[0]),rows=cross,retrieved_at=cross_raw['retrieved_at'],cached=True)
        p=dict(sources=[],evidence=[],metrics=[])
        summary=dict(trade_date=ts.ymd(day),n=internal['n'],median_pct=internal['median'],up_pct=internal['up_share'],concentration_pct=internal['top_decile_turnover'])
        source,evidence=ts._source_rows(work,'daily',response,[summary],day,ts._available(day,'daily'),p,title='Tushare截面确定性统计')[0]
        for f,measure,label in [('median_pct','median_return','有效A股截面涨跌中位数'),('up_pct','participation','有效A股截面上涨占比'),('concentration_pct','turnover_concentration','前一成个股成交集中度')]:
            p['metrics'].append(ts._metric('daily',summary,f,summary[f],'%',measure,label,day,ts._available(day,'daily'),source,evidence))
        merge(work,p)
    result['calls']=client.calls-result.pop('calls_before');save(work/'state-data-status.json',result)
    return result
