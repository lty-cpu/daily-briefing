"""Small, optional Tushare data path for the existing briefing document.

The local credential is read from the host's persistent settings, never from a report or
the archive. API results are data sources, with their original rows retained
outside the Skill in the run's artifact directory.
"""
from __future__ import annotations

from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
import json
import re
import urllib.error
import urllib.request

from common import InputError, canonical, fingerprint, iso, load, loads, num, save, stamp, localize
from storage import cache_get, cache_put, put_artifact

SKILL = Path(__file__).resolve().parents[1]
API_URL = 'https://api.tushare.pro'
DOC_URL = 'https://tushare.pro/document/2?doc_id='
DOCS = dict(trade_cal=26, stock_basic=25, index_daily=95, daily=27,
            daily_basic=32, adj_factor=28, income=33, cashflow=44,
            balancesheet=36, us_tycr=219, index_classify=181,
            sw_daily=327, ths_daily=260, anns_d=176)
BENCHMARKS = (('000001.SH', '上证指数'), ('399001.SZ', '深证成指'),
              ('399006.SZ', '创业板指'), ('000300.SH', '沪深300'),
              ('000688.SH', '科创50'), ('000905.SH','中证500'),
              ('000852.SH','中证1000'), ('000922.SH','中证红利'),
              ('000918.SH','300成长'), ('000919.SH','300价值'))


def settings_path(config_path=None):
    """Archive configuration selects its sibling secret file, never its contents."""
    if config_path:
        return Path(config_path).expanduser().absolute().with_name('local_config.json')
    base = Path.home() / '.dsh' / 'daily-briefing' if '.dsh' in SKILL.parts else Path.home() / '.daily-briefing'
    return base / 'local_config.json'


def local_token(config_path=None):
    """Return (token, warning); an invalid optional file never blocks research."""
    candidates = [settings_path(config_path), settings_path(), SKILL / 'local_config.json']
    path = next((p for p in candidates if p.exists()), None)
    if path is None:
        return None, None
    try:
        settings = load(path)
        if not isinstance(settings, dict):
            raise ValueError('配置根值应为JSON对象')
        token = settings.get('tushare_token')
        if token is None or token == '':
            return None, None
        if not isinstance(token, str) or not token.strip():
            raise ValueError('tushare_token应为非空字符串')
        return token.strip(), None
    except (OSError, ValueError) as exc:
        return None, 'local_config.json 无效，已转缓存/网页路径；请核对JSON格式和tushare_token字段。'


class DataFailure(Exception):
    def __init__(self, category):
        self.category = category
        super().__init__(category)


def failure_category(code, message):
    """An API-permission message may mention token without rejecting the token."""
    message = str(message).lower()
    if any(x in message for x in ('每分钟', '每小时', '每天最多', '频次', '频率', 'rate limit', 'too many')):
        return 'rate_limit'
    if code == 2002 or any(x in message for x in ('权限', '积分', 'permission', 'points', 'access denied')):
        return 'permission'
    if re.search(r'(?:token|认证|authentication|auth)\s*(?:is\s*|格式)?(?:无效|错误|过期|失效|失败|不正确|不对|invalid|expired|failed)', message) or re.search(r'(?:invalid|expired)\s+(?:access\s+)?token', message):
        return 'authentication'
    return 'api_error'


class Client:
    """One-run permission and retry state; no provider registry or SDK."""
    def __init__(self, archive_root=None, *, disabled=False, transport=None, config_path=None):
        self.token, self.warning = local_token(config_path)
        if disabled:
            self.token = None
        self.root = Path(archive_root) if archive_root else None
        self.transport = transport or self._transport
        self.auth_failed = False
        self.denied = set()
        self.calls = 0
        self.cache_hits = 0
        self.deadline = None

    @staticmethod
    def _transport(payload, timeout):
        request = urllib.request.Request(API_URL, data=canonical(payload).encode('utf-8'),
                                         headers={'Content-Type': 'application/json'}, method='POST')
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, *args, **kwargs):
                raise DataFailure('redirect_refused')
        try:
            with urllib.request.build_opener(NoRedirect).open(request, timeout=timeout) as response:
                raw = response.read(12000001)
            if len(raw) > 12000000:
                raise DataFailure('response_limit')
            return loads(raw.decode('utf-8'))
        except urllib.error.HTTPError as exc:
            raise DataFailure('authentication' if exc.code == 401 else 'permission' if exc.code == 403 else
                              'rate_limit' if exc.code == 429 else 'transient') from None
        except (OSError, TimeoutError) as exc:
            reason = getattr(exc, 'reason', exc)
            if isinstance(reason, PermissionError) or getattr(reason, 'winerror', None) == 10013:
                raise DataFailure('network_permission') from None
            raise DataFailure('transient') from None
        except (ValueError, UnicodeError):
            raise DataFailure('invalid_response') from None

    def query(self, api, params, fields, *, cutoff=None, vintage=None, layer='market',
              timeout=7, cache=True):
        if api not in DOCS:
            raise ValueError('未支持的Tushare接口')
        params = {key: value for key, value in params.items() if value is not None and value != ''}
        identity = 'TS_' + fingerprint([api, params, fields])[:28]
        if cache and self.root and cutoff:
            hit = cache_get(self.root / '.runtime', identity, cutoff)
            if hit['status'] == 'cache_reused':
                cached_rows = hit['entry']['data']['rows']
                target = params.get('trade_date') or params.get('end_date')
                dated = api in ('daily','index_daily','daily_basic','adj_factor','sw_daily','ths_daily')
                if cached_rows and (not dated or not target or any(str(r.get('trade_date')) == target for r in cached_rows)):
                    self.cache_hits += 1
                    return dict(rows=cached_rows, api=api, params=params,
                                fields=fields, retrieved_at=hit['actual_retrieved_at'], cached=True)
        if not self.token:
            raise DataFailure('no_token')
        if self.auth_failed:
            raise DataFailure('authentication')
        if api in self.denied:
            raise DataFailure('permission')
        payload = dict(api_name=api, token=self.token, params=params, fields=fields)
        last = None
        for attempt in range(2):
            try:
                left = (self.deadline - iso(stamp())).total_seconds() if self.deadline else timeout
                if left <= 0:
                    raise DataFailure('budget_stop')
                self.calls += 1
                response = self.transport(payload, min(timeout, left))
                if not isinstance(response, dict):
                    raise DataFailure('invalid_response')
                if response.get('code') != 0:
                    raise DataFailure(failure_category(response.get('code'), response.get('msg', '')))
                data = response.get('data') or {}
                names, items = data.get('fields'), data.get('items')
                if not isinstance(names, list) or not isinstance(items, list):
                    raise DataFailure('invalid_response')
                rows = [dict(zip(names, row)) for row in items]
                if any(len(row) != len(names) for row in items):
                    raise DataFailure('invalid_response')
                retrieved = stamp()
                target = params.get('trade_date') or params.get('end_date')
                dated = api in ('daily','index_daily','daily_basic','adj_factor','sw_daily','ths_daily')
                target_present = not dated or not target or any(str(r.get('trade_date')) == target for r in rows)
                if rows and target_present and cache and self.root and cutoff and vintage and iso(vintage) <= iso(cutoff) and iso(vintage) <= iso(retrieved):
                    cache_put(self.root / '.runtime', dict(id=identity, layer=layer,
                        source_url=DOC_URL + str(DOCS[api]), retrieved_at=retrieved,
                        vintage_at=vintage, valid_until=(iso(cutoff) + timedelta(days=7 if api=='stock_basic' else 370)).isoformat(),
                        recheck_triggers=['source_revision', 'scope_change'],
                        data=dict(rows=rows, api=api, params=params, fields=fields)))
                return dict(rows=rows, api=api, params=params, fields=fields,
                            retrieved_at=retrieved, cached=False)
            except DataFailure as exc:
                last = exc
                if exc.category == 'authentication':
                    self.auth_failed = True
                if exc.category == 'permission':
                    self.denied.add(api)
                if exc.category == 'network_permission':
                    self.warning = '当前Python进程访问Tushare接口被系统或沙箱拒绝；这是进程联网权限问题，不是接口无数据。'
                if exc.category not in ('transient', 'rate_limit') or attempt:
                    break
        raise last


def ymd(day):
    return day.replace('-', '')


def day_iso(value):
    value = str(value)
    return f'{value[:4]}-{value[4:6]}-{value[6:8]}'


def day_upper(day, hour=23, minute=59):
    return datetime.combine(date.fromisoformat(day), time(hour, minute),
                            timezone(timedelta(hours=8))).isoformat()


def record(api, response, row, *, day, vintage=None, title=None):
    """One selected API row as a source/evidence pair; never a web quote."""
    visible = {key: value for key, value in row.items() if value is not None}
    locator = api + ':' + fingerprint([response['params'], visible])[:16]
    sid = 'S_' + fingerprint([api, response['params'], day, vintage, visible])[:24]
    eid = 'E_' + fingerprint([sid, visible])[:24]
    quote = canonical(visible)
    source = dict(id=sid, title=title or f'Tushare数据 · {api}', publisher='Tushare数据',
                  url=DOC_URL + str(DOCS[api]), published_at=day,
                  published_timezone='+08:00', published_granularity='date',
                  availability_basis='API观测日期；精确发布钟点未获证',
                  retrieved_at=response['retrieved_at'], kind='data', read_status='partial',
                  origin_group='Tushare:' + api,
                  vintage=dict(id=f'{api}:{day}', available_at=vintage), usage='content')
    evidence = dict(id=eid, source_id=sid, locator=locator, quote=quote,
                    context='Tushare API响应字段；原始行见本轮运行工件；获取时间与观测日期分开。',
                    read_method='cached' if response['cached'] else 'original',
                    retrieved_at=response['retrieved_at'])
    return source, evidence


def calendar_bundle(day, client):
    """Fetch the gate calendar before edition selection; return None for web fallback."""
    cached_path = client.root / '.runtime' / 'calendar' / (day + '.json') if client.root else None
    if cached_path and cached_path.exists():
        try:
            cached = load(cached_path)
            age = iso(stamp()) - iso(cached['retrieved_at'])
            if age <= timedelta(days=7) or day < iso(stamp()).date().isoformat():
                return cached['bundle']
        except (OSError, ValueError, KeyError, TypeError):
            pass
    if not client.token:
        return None
    target = date.fromisoformat(day)
    start = target - timedelta(days=24)
    end = target + timedelta(days=24)
    try:
        result = client.query('trade_cal', dict(exchange='SSE', start_date=ymd(start.isoformat()),
                                                end_date=ymd(end.isoformat())),
                              'exchange,cal_date,is_open,pretrade_date', cache=False)
    except DataFailure:
        return None
    rows = result['rows']
    if not rows or not any(day_iso(row.get('cal_date')) == day for row in rows):
        return None
    open_days = sorted(day_iso(row['cal_date']) for row in rows if str(row.get('is_open')) == '1')
    if not open_days or len([x for x in open_days if x > day]) < 3:
        return None
    row = dict(api='trade_cal', exchange='SSE', valid_from=start.isoformat(),
               valid_to=end.isoformat(), open_days=open_days)
    source, evidence = record('trade_cal', result, row, day=day,
                              title='Tushare交易日历 · 上交所日历及A股常规会话规则')
    calendar = dict(id='CAL_' + fingerprint([start.isoformat(), end.isoformat(), open_days])[:22],
                    market='A股', timezone='Asia/Shanghai', version='trade_cal:' + result['retrieved_at'],
                    source_ids=[source['id']], evidence_ids=[evidence['id']],
                    valid_from=start.isoformat(), valid_to=end.isoformat(), complete=True,
                    sessions=[dict(date=d, close_at=day_upper(d, 15, 0)) for d in open_days])
    bundle = dict(sources=[source], evidence=[evidence], calendars=[calendar],
                calendar=calendar, open_days=open_days, closed_days=[day_iso(row['cal_date']) for row in rows
                                                               if str(row.get('is_open')) == '0'],
                prior_session=max((x for x in open_days if x < day), default=None),
                next_sessions=[x for x in open_days if x > day][:3],
                provenance='trade_cal开休市日期；15:00由A股常规交易规则补充，不是trade_cal字段')
    if cached_path:
        save(cached_path, dict(retrieved_at=result['retrieved_at'], bundle=bundle))
    return bundle


def _source_rows(work, api, response, selected, day, vintage, patch, title=None):
    """Keep a bounded document excerpt and the entire response outside the Skill."""
    artifact = put_artifact(work, canonical(dict(api=api, params=response['params'],
                                                 fields=response['fields'], rows=response['rows'],
                                                 retrieved_at=response['retrieved_at'])).encode('utf-8'), '.json')
    result = []
    for row in selected:
        source, evidence = record(api, response, row, day=day, vintage=vintage, title=title)
        evidence['artifact'] = artifact
        patch['sources'].append(source)
        patch['evidence'].append(evidence)
        result.append((source, evidence))
    return result


def _metric(api, row, field, value, unit, measure, label, day, available,
            source, evidence, *, domain='cn_market', currency='none', scale=1,
            segment='all', period=None, price_basis=None, scope=None, category=None,
            raw_factor=1):
    metric = dict(id='M_' + fingerprint([api, row.get('ts_code'), day, field, period])[:24],
                  label=label, op='observed', value=value, unit=unit, as_of=period or day,
                  available_at=available, kind='actual', source_ids=[source['id']],
                  evidence_ids=[evidence['id']], domain=domain, frequency='daily',
                  value_identity='reported', support=dict(status='matched', locator=evidence['locator'],
                      quote=evidence['quote'], note=canonical(dict(api_field=field,
                          raw_factor=raw_factor))),
                  dimensions=dict(entity_id='ENT_' + fingerprint(row.get('ts_code', api))[:20],
                                  currency=currency, scale=scale, period=period or day,
                                  segment=segment, measure=measure))
    if price_basis:metric['price_basis'] = price_basis
    if scope:metric['scope'] = scope
    if category:metric['category'] = category
    metric['support']['audit']=dict(value=value,unit=unit,entity_id=metric['dimensions']['entity_id'],
        period=metric['dimensions']['period'],measure=measure,evidence_hash=fingerprint({k:v for k,v in evidence.items() if k!='artifact'}))
    chart_groups={
        'index_change':('宽基与风格指数同日涨跌','同一交易日的宽基与风格涨跌幅用于比较方向和强弱。'),
        'sector_change':('申万一级行业同日涨跌','申万2021一级行业显示本期分化。'),
        'breadth':('A股有效截面涨跌家数','有效日线截面区分上涨、下跌和平盘；停牌与缺失不算零。'),
    }
    if measure in chart_groups:
        metric['chart_group'],metric['chart_takeaway']=chart_groups[measure]
    return metric


def _available(day, api):
    if api == 'daily':return day_upper(day, 16, 0)
    if api == 'daily_basic':return day_upper(day, 17, 0)
    if api in ('sw_daily', 'index_daily', 'ths_daily'):return day_upper(day, 18, 30)
    return day_upper(day)


def _last_session(document, cutoff):
    sessions = sorted(s['date'] for c in document['calendars'] for s in c['sessions']
                      if iso(s['close_at']) <= iso(cutoff))
    return sessions[-1] if sessions else None


def _extend_calendar(work, document, client, latest, patch):
    if not document['calendars']:
        return []
    cal = document['calendars'][0]
    existing = sorted(s['date'] for s in cal['sessions'] if s['date'] <= latest)
    if len(existing) >= 61:
        return existing[-61:]
    start = (date.fromisoformat(latest) - timedelta(days=130)).isoformat()
    try:
        response = client.query('trade_cal', dict(exchange='SSE', start_date=ymd(start),
                            end_date=ymd(latest)), 'exchange,cal_date,is_open,pretrade_date',
                            cache=False)
    except DataFailure:
        return existing
    open_days = sorted(day_iso(r['cal_date']) for r in response['rows'] if str(r.get('is_open')) == '1')
    if len(open_days) < len(existing):
        return existing
    row = dict(api='trade_cal', exchange='SSE', valid_from=start, valid_to=cal['valid_to'],
               open_days=open_days)
    source, evidence = _source_rows(work, 'trade_cal', response, [row], latest, None, patch)[0]
    expanded = dict(cal, valid_from=start,
                    sessions=sorted({s['date']: s for s in cal['sessions'] +
                       [dict(date=d, close_at=day_upper(d, 15, 0)) for d in open_days]}.values(),
                                    key=lambda x: x['date']),
                    source_ids=list(dict.fromkeys(cal['source_ids'] + [source['id']])),
                    evidence_ids=list(dict.fromkeys(cal['evidence_ids'] + [evidence['id']])))
    patch['calendars'].append(expanded)
    return open_days[-61:]


def _series(code, label, rows, sessions, api, response, source, evidence, calendar_id,
            *, asset_type='index', market='A股', adjustment='none', classification='broad'):
    seen = {}
    for row in rows:
        day = day_iso(row['trade_date'])
        if day not in sessions or not num(row.get('close')):
            continue
        seen[day] = dict(date=day, value=row['close'], available_at=_available(day, api),
                         status='traded')
    observations = [seen[d] for d in sorted(seen)]
    return dict(id='TSER_' + fingerprint([api, code, adjustment])[:24], label=label,
                unit='点' if asset_type != 'stock' else '元', basis='price', market=market,
                provider='Tushare数据', adjustment=adjustment, classification=classification,
                source_ids=[source['id']], evidence_ids=[evidence['id']],
                entity_id='ENT_' + fingerprint(code)[:20], frequency='daily',
                calendar_id=calendar_id, completeness='complete' if len(observations) >= 61 else 'partial',
                scope='指数成分' if asset_type == 'index' else '个股', roll_policy='none',
                vintage=dict(id=api + ':' + response['retrieved_at'],
                             available_at=_available(observations[-1]['date'], api) if observations else None),
                observations=observations, domain='cn_market', asset_type=asset_type,
                usage='current' if observations and observations[-1]['date'] == sessions[-1] else 'background',
                freshness_note='日线；盘中不可当作实时行情')


def _query(client, api, params, fields, cutoff, vintage, layer, result, *, cache=True):
    try:
        response = client.query(api, params, fields, cutoff=cutoff, vintage=vintage,
                                layer=layer, cache=cache)
        if api in ('daily','index_daily','daily_basic','adj_factor','sw_daily','ths_daily'):
            target = params.get('trade_date') or params.get('end_date')
            current = [r for r in response['rows'] if str(r.get('trade_date')) == target]
            if target and not current:
                result['items'][api] = dict(status='pending', reason='target_session_not_returned',
                    expected_session=day_iso(target), rows=len(response['rows']))
                return None
            if vintage and iso(vintage) > iso(cutoff):
                result['items'][api] = dict(status='pending', reason='cutoff_availability_unproven',
                    expected_session=day_iso(target), rows=len(current))
                return None
        result['items'][api] = dict(status='available' if response['rows'] else 'empty',
                                    rows=len(response['rows']), cached=response['cached'])
        return response
    except DataFailure as exc:
        result['items'][api] = dict(status='web_fallback', reason=exc.category)
        return None


def bootstrap(work, state, client):
    """Automatic basic data after start; errors are item-level web fallbacks."""
    from data_io import merge
    work = Path(work)
    doc = load(work / 'briefing.json')
    cutoff = state['contract']['initial_cutoff']
    client.deadline = iso(state['created_at']) + timedelta(seconds=state['budget']['timeout_seconds']-state['budget'].get('reserved_seconds',300))
    begun = datetime.now(timezone.utc)
    result = dict(route='tushare' if client.token else 'cache_or_web', warning=client.warning,
                  items={}, calls=0, cache_hits=0, next=[])
    patch = dict(sources=[], evidence=[], calendars=[], series=[], metrics=[])
    latest = _last_session(doc, cutoff)
    result['target_session'] = latest
    if not latest:
        result['next'].append('先用有效档案或交易所日历核验最近完整会话，再通过网页补市场数值')
    else:
        sessions = _extend_calendar(work, doc, client, latest, patch)
        calendar_id = doc['calendars'][0]['id'] if doc['calendars'] else None
        if sessions and calendar_id:
            for code, label in BENCHMARKS:
                response = _query(client, 'index_daily', dict(ts_code=code,
                    start_date=ymd(sessions[0]), end_date=ymd(latest)),
                    'ts_code,trade_date,close,pre_close,pct_chg,amount',
                    cutoff, _available(latest, 'index_daily'), 'market', result)
                if not response or not response['rows']:
                    result['items']['index_daily:' + code] = dict(result['items']['index_daily'])
                    continue
                rows = [r for r in response['rows'] if r.get('ts_code') == code and
                        day_iso(r.get('trade_date')) in sessions]
                current = next((r for r in rows if day_iso(r['trade_date']) == latest), None)
                if not current:
                    result['items']['index_daily:' + code] = dict(status='web_fallback', reason='not_updated')
                    continue
                source, evidence = _source_rows(work, 'index_daily', response, [current],
                                                latest, _available(latest, 'index_daily'), patch,
                                                title='Tushare指数日线 · ' + label)[0]
                series = _series(code, label, rows, sessions, 'index_daily', response,
                                 source, evidence, calendar_id)
                patch['series'].append(series)
                for field, measure, unit, metric_label in (
                    ('close', 'close', '点', label + '收盘'),
                    ('pct_chg', 'index_change', '%', label + '涨跌幅'),
                    ('amount', 'index_constituent_turnover', '亿元', label + '成分成交额')):
                    value = current.get(field)
                    if not num(value):continue
                    if field == 'amount':value = value / 100000
                    patch['metrics'].append(_metric('index_daily', current, field, value, unit,
                        measure, metric_label, latest, _available(latest, 'index_daily'),
                        source, evidence, currency='CNY' if field == 'amount' else 'none',
                        scale=100000000 if field == 'amount' else 1,
                        price_basis='raw', scope='指数成分',
                        raw_factor=0.00001 if field == 'amount' else 1))
                result['items']['index_daily:' + code] = dict(status='available',
                    points=len(series['observations']), missing=max(0, 61-len(series['observations'])))
            response = _query(client, 'daily', dict(trade_date=ymd(latest)),
                'ts_code,trade_date,close,pre_close,pct_chg,amount',
                cutoff, _available(latest, 'daily'), 'market', result)
            if response and response['rows']:
                valid = [r for r in response['rows'] if day_iso(r.get('trade_date')) == latest and
                         num(r.get('pct_chg')) and num(r.get('amount'))]
                if valid:
                    up = sum(r['pct_chg'] > 0 for r in valid)
                    down = sum(r['pct_chg'] < 0 for r in valid)
                    flat = len(valid) - up - down
                    amount = sum(r['amount'] for r in valid) / 100000
                    summary = dict(trade_date=ymd(latest), observed=len(valid), returned=len(response['rows']),
                                   up=up, down=down, flat=flat, amount_100m_cny=amount,
                                   sample=response['rows'].__len__() >= 6000)
                    source, evidence = _source_rows(work, 'daily', response, [summary],
                        latest, _available(latest, 'daily'), patch,
                        title='Tushare A股日线截面 · 范围与样本见字段')[0]
                    for field, value, unit, measure, label, category in (
                        ('up', up, '只', 'breadth', '上涨个股', 'up'),
                        ('down', down, '只', 'breadth', '下跌个股', 'down'),
                        ('flat', flat, '只', 'breadth', '平盘个股', 'flat'),
                        ('amount_100m_cny', amount, '亿元', 'turnover', 'A股有效截面成交额', None)):
                        patch['metrics'].append(_metric('daily', summary, field, value, unit,
                            measure, label, latest, _available(latest, 'daily'), source, evidence,
                            currency='CNY' if unit == '亿元' else 'none',
                            scale=100000000 if unit == '亿元' else 1,
                            scope='Tushare日线有效A股截面' + ('样本' if summary['sample'] else ''),
                            category=category))
                    result['items']['daily'] = dict(status='available', observed=len(valid),
                        returned=len(response['rows']), sample=summary['sample'])
                    if summary['sample']:result['next'].append('A股日线达到单次返回上限，广度和成交额仅为样本；网页补全')
        response = _query(client, 'stock_basic', dict(exchange='', list_status='L'),
            'ts_code,symbol,name,industry,market,exchange,list_status,list_date',
            cutoff, day_upper(latest), 'fundamental', result)
        if response:
            if len(response['rows']) >= 6000:
                result['items']['stock_basic']['status'] = 'sample'
            put_artifact(work, canonical(dict(api='stock_basic', params=response['params'],
                rows=response['rows'], retrieved_at=response['retrieved_at'])).encode('utf-8'), '.json')
        classify = _query(client, 'index_classify', dict(level='L1', src='SW2021'),
            'index_code,industry_name,parent_code,level,is_pub,src',
            cutoff, day_upper(latest), 'market', result)
        if classify and classify['rows']:
            sectors = {r['index_code']: r for r in classify['rows']
                       if r.get('level') == 'L1' and str(r.get('is_pub', '1')) == '1'}
            sw = _query(client, 'sw_daily', dict(trade_date=ymd(latest)),
                'ts_code,trade_date,name,close,pct_change,amount',
                cutoff, _available(latest, 'sw_daily'), 'market', result)
            if sw and sw['rows']:
                selected = [r for r in sw['rows'] if r.get('ts_code') in sectors and
                            day_iso(r.get('trade_date')) == latest]
                for row in selected:
                    source, evidence = _source_rows(work, 'sw_daily', sw, [row], latest,
                        _available(latest, 'sw_daily'), patch,
                        title='Tushare申万2021一级行业日线 · ' + sectors[row['ts_code']]['industry_name'])[0]
                    for field, measure, unit, label, factor in (
                        ('pct_change', 'sector_change', '%', '涨跌幅', 1),
                        ('amount', 'sector_turnover', '亿元', '成交额', 0.0001)):
                        if num(row.get(field)):
                            patch['metrics'].append(_metric('sw_daily', row, field,
                                row[field] * factor, unit, measure,
                                sectors[row['ts_code']]['industry_name'] + label,
                                latest, _available(latest, 'sw_daily'), source, evidence,
                                currency='CNY' if unit == '亿元' else 'none',
                                scale=100000000 if unit == '亿元' else 1,
                                scope='申万2021一级行业', raw_factor=factor))
                result['items']['sw_daily'] = dict(status='available' if selected else 'web_fallback',
                    industries=len(selected), reason=None if selected else 'not_updated')
    local_day = iso(cutoff).astimezone(timezone(timedelta(hours=8))).date()
    start = (local_day - timedelta(days=12)).isoformat()
    response = _query(client, 'us_tycr', dict(start_date=ymd(start),
                         end_date=ymd(local_day.isoformat())), 'date,y2,y10,y30',
                         cutoff, day_upper(start), 'market', result, cache=False)
    if response and response['rows']:
        eligible = [r for r in response['rows'] if r.get('date') and
                    iso(day_upper((date.fromisoformat(day_iso(r['date'])) + timedelta(days=1)).isoformat())) <= iso(cutoff)]
        selected = sorted(eligible, key=lambda r:r['date'], reverse=True)[:2]
        for row in selected:
            observation = day_iso(row['date'])
            upper = day_upper((date.fromisoformat(observation) + timedelta(days=1)).isoformat())
            source, evidence = _source_rows(work, 'us_tycr', response, [row], observation,
                                            upper, patch, title='Tushare美国国债收益率曲线')[0]
            for field, label in (('y2','美债2年'),('y10','美债10年'),('y30','美债30年')):
                if num(row.get(field)):
                    patch['metrics'].append(_metric('us_tycr', row, field, row[field], '%',
                        'treasury_yield_' + field, label, observation, upper, source, evidence,
                        domain='overseas', scope='美国国债收益率'))
        result['items']['us_tycr'] = dict(status='available' if selected else 'web_fallback',
            dates=[day_iso(r['date']) for r in selected], reason=None if selected else 'not_yet_available')
    patch = {key: value for key, value in patch.items() if value}
    if patch:
        merge(work, patch)
    result['calls'], result['cache_hits'] = client.calls, client.cache_hits
    required = ['daily'] + ['index_daily:' + code for code, _ in BENCHMARKS[:5]]
    result['optional_style_missing']=['index_daily:'+code for code,_ in BENCHMARKS[5:] if result['items'].get('index_daily:'+code,{}).get('status')!='available']
    missing = [key for key in required if result['items'].get(key, {}).get('status') != 'available']
    if result['items'].get('daily', {}).get('sample') and 'daily' not in missing:
        missing.append('daily')
    result['closing_readiness'] = dict(provider='Tushare',checked_at=stamp(),target_session=latest,
        status='ready' if not missing else 'partial' if len(missing)<len(required) else 'unavailable',missing=missing)
    if missing and state['contract']['edition'] == 'evening':
        result['next'].append('本期收盘数据未齐：按缺项网页补证或如实有限交付；不以昨日行情代替今日，不等待数据刷新截止。')
    result['next'].extend(['五域有界发现重要事件；入选公司后用data --input补财务与复权历史'])
    state['data_readiness'] = result['closing_readiness']
    state['telemetry']['events'].append(dict(kind='stage',stage='data_bootstrap',
        wall_ms=(datetime.now(timezone.utc)-begun).total_seconds()*1000,recorded_at=stamp()))
    save(work / 'run-state.json', state)
    save(work / 'data-status.json', result)
    from state_data import collect
    state_begun=datetime.now(timezone.utc)
    try:result['state_layer']=collect(work,state,client)
    except (ValueError,OSError,KeyError,TypeError) as exc:
        result['state_layer']=dict(status='untracked',reason='新增状态补数未完成，沿用已得基础资料',error_type=type(exc).__name__)
    state['telemetry']['events'].append(dict(kind='stage',stage='state_precompute',wall_ms=(datetime.now(timezone.utc)-state_begun).total_seconds()*1000,recorded_at=stamp()))
    result['calls'],result['cache_hits']=client.calls,client.cache_hits
    from state_data import precompute
    result['insights']=precompute(work,state)
    save(work/'run-state.json',state);save(work/'data-status.json',result)
    return result


FINANCIAL_FIELDS = {
    'income': ('revenue,n_income_attr_p',
               (('revenue', 'revenue', '营业收入'),
                ('n_income_attr_p', 'net_profit', '归母净利润'))),
    'cashflow': ('n_cashflow_act',
                 (('n_cashflow_act', 'cash_flow', '经营现金流净额'),)),
    'balancesheet': ('money_cap,st_borr,lt_borr,non_cur_liab_due_1y',
                     (('money_cap', 'cash', '货币资金'),
                      ('st_borr', 'short_debt', '短期借款'),
                      ('lt_borr', 'long_debt', '长期借款'),
                      ('non_cur_liab_due_1y', 'due_debt', '一年内到期非流动负债'))),
}


def _financial_rows(rows, cutoff, limit=3):
    """Consolidated cumulative rows known by cutoff; no silent latest-row pick."""
    eligible = []
    for row in rows:
        announced = row.get('f_ann_date') or row.get('ann_date')
        period = row.get('end_date')
        if not announced or not period or str(row.get('report_type')) != '1':
            continue
        if iso(day_upper(day_iso(announced))) > iso(cutoff):
            continue
        if day_iso(period) > localize(cutoff, 'Asia/Shanghai').date().isoformat():
            continue
        eligible.append(row)
    by_period = {}
    for row in sorted(eligible, key=lambda r:(str(r.get('f_ann_date') or r.get('ann_date')),
                                              str(r.get('update_flag') or ''))):
        by_period[day_iso(row['end_date'])] = row
    if not by_period:
        return []
    periods = sorted(by_period, reverse=True)
    latest = periods[0]
    comparable = str(int(latest[:4]) - 1) + latest[4:]
    chosen = [latest]
    if comparable in by_period:
        chosen.append(comparable)
    chosen.extend(p for p in periods if p not in chosen)
    return [by_period[p] for p in chosen[:limit]]


def add_companies(work, state, request, client=None):
    """One bounded supplement for selected names, with per-API fallback."""
    from data_io import merge
    work = Path(work)
    client = client or Client(state['state_root'], disabled=request.get('web_only', False),config_path=state.get('data_config'))
    client.deadline = iso(state['created_at']) + timedelta(seconds=state['budget']['timeout_seconds']-state['budget'].get('reserved_seconds',300))
    companies = request.get('companies', [])
    if not isinstance(companies, list) or len(companies) > 4:
        raise InputError('companies', '一次只补最多4家入选公司')
    result = dict(route='tushare' if client.token else 'cache_or_web', warning=client.warning,
                  companies=[], items={}, calls=0, cache_hits=0)
    if request.get('sector_codes'):
        from state_data import sector_history
        try:result['sector_history']=sector_history(work,state,client,request['sector_codes'])
        except (ValueError,OSError,KeyError,TypeError) as exc:result['sector_history']=dict(status='untracked',error_type=type(exc).__name__)
    if request.get('base_rates'):
        from state_data import long_history
        try:result['base_rate_history']=long_history(work,state,client)
        except (ValueError,OSError,KeyError,TypeError) as exc:result['base_rate_history']=dict(status='untracked',error_type=type(exc).__name__)
    if request.get('state') or request.get('macro'):
        from state_data import collect
        try:result['state_layer']=collect(work,state,client,request)
        except (ValueError,OSError,KeyError,TypeError) as exc:result['state_layer']=dict(status='untracked',error_type=type(exc).__name__)
    if not companies and not request.get('announcements') and not request.get('ths_concepts'):
        result['calls'],result['cache_hits']=client.calls,client.cache_hits
        from state_data import precompute
        result['insights']=precompute(work,state)
        return result
    doc = load(work / 'briefing.json')
    cutoff = state['contract']['initial_cutoff']
    latest = _last_session(doc, cutoff)
    if not latest:
        result['items']['daily'] = dict(status='web_fallback', reason='no_complete_session')
        return result
    calendar = doc['calendars'][0] if doc['calendars'] else None
    patch = dict(sources=[], evidence=[], series=[], metrics=[])
    sessions = sorted(s['date'] for s in calendar['sessions'] if s['date'] <= latest) if calendar else []
    if calendar and request.get('history', True):
        patch['calendars'] = []
        sessions = _extend_calendar(work, doc, client, latest, patch)
    basic = _query(client, 'stock_basic', dict(exchange='', list_status='L'),
        'ts_code,symbol,name,industry,market,exchange,list_status,list_date',
        cutoff, day_upper(latest), 'fundamental', result)
    by_code = {r['ts_code']:r for r in basic['rows']} if basic else {}
    by_name = {r['name']:r for r in basic['rows']} if basic else {}
    for entry in companies:
        if not isinstance(entry, dict):
            raise InputError('companies', '公司需提供{code,name}对象')
        code = entry.get('code')
        name = entry.get('name')
        known = by_code.get(code) if code else by_name.get(name)
        if known:
            code = known['ts_code']
            name = known['name']
        if not isinstance(code, str) or not code.endswith(('.SH','.SZ','.BJ')):
            result['companies'].append(dict(name=name, status='web_fallback', reason='code_unresolved'))
            continue
        name = name or code
        company = dict(code=code, name=name, basic=known, items={})
        if known:
            row = {k: known.get(k) for k in ('ts_code','name','industry','market','list_status','list_date')}
            _source_rows(work, 'stock_basic', basic, [row], latest,
                         day_upper(latest) if iso(day_upper(latest)) <= iso(cutoff) else None, patch,
                         title='Tushare股票基础信息 · ' + name)
        if sessions:
            start = sessions[max(0, len(sessions)-61)]
            daily = _query(client, 'daily', dict(ts_code=code, start_date=ymd(start),
                end_date=ymd(latest)), 'ts_code,trade_date,close,pre_close,pct_chg,amount',
                cutoff, _available(latest, 'daily'), 'market', result)
            if daily and daily['rows']:
                rows = [r for r in daily['rows'] if r.get('ts_code') == code and
                        day_iso(r.get('trade_date')) in sessions]
                current = next((r for r in rows if day_iso(r['trade_date']) == latest), None)
                if current:
                    source, evidence = _source_rows(work, 'daily', daily, [current], latest,
                        _available(latest, 'daily'), patch, title='Tushare个股日线 · ' + name)[0]
                    for field, measure, unit, label, factor in (
                        ('close','close','元','收盘价',1),
                        ('pct_chg','stock_change','%','日涨跌幅',1),
                        ('amount','stock_turnover','亿元','成交额',0.00001)):
                        if num(current.get(field)):
                            patch['metrics'].append(_metric('daily', current, field,
                                current[field]*factor, unit, measure, name+label,
                                latest, _available(latest, 'daily'), source, evidence,
                                currency='CNY' if unit in ('元','亿元') else 'none',
                                scale=100000000 if unit=='亿元' else 1,
                                scope='个股', raw_factor=factor))
                    company['items']['daily'] = dict(status='available', date=latest)
                    if request.get('history', True) and len(rows) >= 2:
                        factor = _query(client, 'adj_factor', dict(ts_code=code,
                            start_date=ymd(start), end_date=ymd(latest)),
                            'ts_code,trade_date,adj_factor', cutoff,
                            _available(latest, 'daily'), 'market', result)
                        if factor and factor['rows']:
                            factors = {day_iso(r['trade_date']):r['adj_factor'] for r in factor['rows']
                                       if r.get('ts_code') == code and num(r.get('adj_factor'))}
                            base = factors.get(latest)
                            if base and base > 0:
                                factor_row = next(r for r in factor['rows'] if day_iso(r['trade_date']) == latest)
                                fs, fe = _source_rows(work, 'adj_factor', factor, [factor_row], latest,
                                    _available(latest, 'daily'), patch,
                                    title='Tushare复权因子 · ' + name)[0]
                                adjusted = [dict(r, close=r['close']*factors[day_iso(r['trade_date'])]/base)
                                    for r in rows if num(r.get('close')) and day_iso(r['trade_date']) in factors]
                                series = _series(code, name+'后复权归一价格', adjusted, sessions,
                                    'daily', daily, source, evidence, calendar['id'],
                                    asset_type='stock', adjustment='qfq_normalized_to_'+latest,
                                    classification='stock')
                                series['source_ids'].append(fs['id'])
                                series['evidence_ids'].append(fe['id'])
                                patch['series'].append(series)
                                company['items']['history'] = dict(status='available',
                                    points=len(series['observations']), missing=max(0,61-len(series['observations'])))
                            else:company['items']['history'] = dict(status='web_fallback', reason='adj_factor_missing')
                        else:company['items']['history'] = dict(status='web_fallback', reason='adj_factor_unavailable')
                else:company['items']['daily'] = dict(status='web_fallback', reason='suspended_or_not_updated')
        basic_daily = _query(client, 'daily_basic', dict(ts_code=code, trade_date=ymd(latest)),
            'ts_code,trade_date,turnover_rate,pe_ttm,pb,total_mv,circ_mv',
            cutoff, _available(latest, 'daily_basic'), 'fundamental', result)
        if basic_daily and basic_daily['rows']:
            row = next((r for r in basic_daily['rows'] if r.get('ts_code') == code and
                        day_iso(r.get('trade_date')) == latest), None)
            if row:
                source, evidence = _source_rows(work, 'daily_basic', basic_daily, [row], latest,
                    _available(latest, 'daily_basic'), patch,
                    title='Tushare每日指标 · ' + name)[0]
                for field, measure, unit, label, factor in (
                    ('turnover_rate','turnover_rate','%','换手率',1),
                    ('pe_ttm','pe_ttm','倍','滚动市盈率',1),
                    ('pb','pb','倍','市净率',1),
                    ('total_mv','market_cap','亿元','总市值',0.0001),
                    ('circ_mv','float_market_cap','亿元','流通市值',0.0001)):
                    if num(row.get(field)):
                        patch['metrics'].append(_metric('daily_basic', row, field,
                            row[field]*factor, unit, measure, name+label, latest,
                            _available(latest, 'daily_basic'), source, evidence,
                            currency='CNY' if unit=='亿元' else 'none',
                            scale=100000000 if unit=='亿元' else 1,
                            scope='个股', raw_factor=factor))
                company['items']['daily_basic'] = dict(status='available', date=latest)
        begin = (date.fromisoformat(latest)-timedelta(days=825)).isoformat()
        for api, (fields, mappings) in FINANCIAL_FIELDS.items():
            response = _query(client, api, dict(ts_code=code, start_date=ymd(begin),
                end_date=ymd(latest)),
                'ts_code,ann_date,f_ann_date,end_date,report_type,comp_type,update_flag,'+fields,
                cutoff, day_upper(begin), 'fundamental', result)
            if not response:continue
            selected = _financial_rows(response['rows'], cutoff)
            if not selected:
                company['items'][api] = dict(status='web_fallback', reason='no_known_consolidated_period')
                continue
            company['items'][api] = dict(status='available', periods=[day_iso(r['end_date']) for r in selected],
                                         basis='consolidated_cumulative')
            for row in selected:
                period = day_iso(row['end_date'])
                announced = day_iso(row.get('f_ann_date') or row['ann_date'])
                available = day_upper(announced)
                source, evidence = _source_rows(work, api, response, [row], announced,
                    available, patch, title='Tushare' + api + '合并累计报表 · ' + name)[0]
                for field, measure, label in mappings:
                    if num(row.get(field)):
                        patch['metrics'].append(_metric(api, row, field, row[field]/100000000,
                            '亿元', measure, name+label+'（合并累计）', period, available,
                            source, evidence, domain='company', currency='CNY',
                            scale=100000000, segment='consolidated_cumulative', period=period,
                            scope='合并累计报表', raw_factor=0.00000001))
        result['companies'].append(company)
    if request.get('announcements'):
        start = (date.fromisoformat(state['contract']['date'])-timedelta(days=3)).isoformat()
        ann = _query(client, 'anns_d', dict(start_date=ymd(start),
            end_date=ymd(state['contract']['date'])),
            'ann_date,ts_code,name,title,url,rec_time', cutoff, day_upper(start),
            'news', result, cache=False)
        if ann:
            put_artifact(work, canonical(dict(api='anns_d', params=ann['params'],
                rows=ann['rows'], retrieved_at=ann['retrieved_at'])).encode('utf-8'), '.json')
            candidates=[]
            for row in ann['rows']:
                day=day_iso(row.get('ann_date')) if row.get('ann_date') else None
                if not day or day>state['contract']['date']:continue
                rec=row.get('rec_time')
                if rec:
                    try:
                        at=iso(rec)
                        if at>iso(cutoff):continue
                    except (ValueError,TypeError):
                        if iso(day_upper(day))>iso(cutoff):continue
                elif iso(day_upper(day))>iso(cutoff):continue
                candidates.append({k:row.get(k) for k in ('ann_date','ts_code','name','title','url','rec_time')})
            result['announcements']=dict(candidates=candidates[:25],returned=len(candidates),
                truncated=len(ann['rows'])>=2000 or len(candidates)>25,
                note='仅为公告候选；合同条款需读取原文。')
    concepts=request.get('ths_concepts',[])
    if not isinstance(concepts,list) or len(concepts)>3:
        raise InputError('ths_concepts','一次最多3个已核实代码的THS概念')
    for concept in concepts:
        code=concept.get('code') if isinstance(concept,dict) else None
        if not isinstance(code,str) or not code.endswith('.TI'):
            raise InputError('ths_concepts.code','需已核实的THS板块指数代码')
        response=_query(client,'ths_daily',dict(ts_code=code,trade_date=ymd(latest)),
            'ts_code,trade_date,close,pct_change,turnover_rate',cutoff,
            _available(latest,'ths_daily'),'market',result)
        if not response or not response['rows']:continue
        row=next((r for r in response['rows'] if r.get('ts_code')==code),None)
        if not row:continue
        name=concept.get('name') or code
        source,evidence=_source_rows(work,'ths_daily',response,[row],latest,
            _available(latest,'ths_daily'),patch,title='Tushare THS板块日线 · '+name)[0]
        for field,measure,unit,label in (('close','sector_close','点','收盘'),
                                         ('pct_change','sector_change','%','涨跌幅'),
                                         ('turnover_rate','sector_turnover_rate','%','换手率')):
            if num(row.get(field)):
                patch['metrics'].append(_metric('ths_daily',row,field,row[field],unit,
                    measure,name+label,latest,_available(latest,'ths_daily'),source,evidence,
                    scope='THS概念板块'))
    patch = {key:value for key,value in patch.items() if value}
    if patch:merge(work,patch)
    result['calls'],result['cache_hits'] = client.calls,client.cache_hits
    from state_data import precompute
    result['insights']=precompute(work,state)
    return result
